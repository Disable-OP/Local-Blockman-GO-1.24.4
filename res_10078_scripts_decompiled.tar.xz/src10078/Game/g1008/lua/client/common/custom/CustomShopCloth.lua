CustomShopCloth.curCloth = nil
CustomShopCloth.curTimerKey = nil

function CustomShopCloth:onTabChange(_)
  LuaTimer:cancel(self.curTimerKey)
  local goodsList = CustomShopConfig:getGoodsListByType(CustomGoodsType.Cloth)
  for _, tabs in pairs(goodsList) do
    for _, goods in pairs(tabs.GoodsList) do
      local setting = self.Settings[goods.SettingId]
      if setting then
        GUICustomShop:unloadBodyPart(setting.PartName)
      end
    end
  end
  for _, tabs in pairs(goodsList) do
    for _, goods in pairs(tabs.GoodsList) do
      if goods.Status == CustomShopGoodsStatus.Equiped then
        local setting = self.Settings[goods.SettingId]
        if setting then
          GUICustomShop:useBodyPart(setting.PartName, setting.MeshName)
        end
      end
    end
  end
end

function CustomShopCloth:onSelectGoods(goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  CustomShopCloth.curCloth = setting
  GUICustomShop:useBodyPart(setting.PartName, setting.MeshName)
  GUICustomShop:playSkill(setting.Action)
  LuaTimer:cancel(self.curTimerKey)
  self.curTimerKey = LuaTimer:scheduleTimer(function()
    if CustomShopCloth.curCloth then
      GUICustomShop:playSkill("idle")
      GUICustomShop:playSkill(CustomShopCloth.curCloth.Action)
    end
  end, GUICustomShop.awPlayer1:GetActor():GetSkillTimeLength(setting.Action) + 1000)
end

function CustomShopCloth:onEquipGoods(goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  GUICustomShop:useBodyPart(setting.PartName, setting.MeshName)
end

function CustomShopCloth:onUnloadGoods(goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  GUICustomShop:unloadBodyPart(setting.PartName)
end

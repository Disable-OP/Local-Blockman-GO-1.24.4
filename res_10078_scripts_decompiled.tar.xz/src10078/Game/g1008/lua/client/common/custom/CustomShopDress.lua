CustomShopDress.curDress = nil

function CustomShopDress:onTabChange(isSelect)
  if isSelect then
    return
  end
  if CustomShopDress.curDress then
    GUICustomShop:unloadBodyPart(CustomShopDress.curDress.PartName)
    GUICustomShop:initPlayerActor()
    GUICustomShop:playSkill("idle")
    CustomShopDress.curDress = nil
  end
end

function CustomShopDress:onSelectGoods(goods)
  local dress = self.Settings[goods.SettingId]
  if not dress then
    return
  end
  CustomShopDress.curDress = dress
  GUICustomShop:useBodyPart(dress.PartName, dress.MeshName)
  if dress.PartName == "armor_head" then
    GUICustomShop:useBodyPart("custom_hair", "", true)
  end
  GUICustomShop:playSkill(dress.Action)
end

function CustomShopDress:onEquipGoods(goods)
  if Game:isEnableIndie() and GameType == "g1046" then
    local dress = self.Settings[goods.SettingId]
    if not dress then
      return
    end
    if dress.PartName == "armor_head" then
      GUIIndieMain:onUpdatePlayerModel()
    end
  end
end

function CustomShopDress:onUnloadGoods(goods)
  if Game:isEnableIndie() and GameType == "g1046" then
    local dress = self.Settings[goods.SettingId]
    if not dress then
      return
    end
    if dress.PartName == "armor_head" then
      GUIIndieMain:onUpdatePlayerModel()
    end
  end
end

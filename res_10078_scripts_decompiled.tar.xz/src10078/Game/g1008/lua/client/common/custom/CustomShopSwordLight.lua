CustomShopSwordLight.curSwordLight = nil
CustomShopSwordLight.curTimerKey = nil

function CustomShopSwordLight:onTabChange(isSelect)
  LuaTimer:cancel(self.curTimerKey)
  if isSelect then
    return
  end
  if CustomShopSwordLight.curSwordLight then
    GUICustomShop:unloadBodyPart(CustomShopSwordLight.curSwordLight.PartName)
    GUICustomShop:playSkill("idle")
    CustomShopSwordLight.curSwordLight = nil
  end
end

function CustomShopSwordLight:onSelectGoods(goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  CustomShopSwordLight.curSwordLight = setting
  GUICustomShop:useBodyPart(setting.PartName, setting.MeshName)
  GUICustomShop:playSkill(CustomShopSwordLight:randomAction(setting))
  LuaTimer:cancel(self.curTimerKey)
  self:playAction()
end

function CustomShopSwordLight:playIdle()
  if CustomShopSwordLight.curSwordLight then
    GUICustomShop:playSkill("idle")
    self.curTimerKey = LuaTimer:schedule(function()
      self:playAction()
    end, CustomShopSwordLight.curSwordLight.IdleTime)
  end
end

function CustomShopSwordLight:playAction()
  if CustomShopSwordLight.curSwordLight then
    local action = CustomShopSwordLight:randomAction(CustomShopSwordLight.curSwordLight)
    GUICustomShop:playSkill(action)
    self.curTimerKey = LuaTimer:schedule(function()
      self:playIdle()
    end, GUICustomShop.awPlayer1:GetActor():GetSkillTimeLength(action))
  end
end

function CustomShopSwordLight:randomAction(setting)
  return setting.ExtraAction[math.random(1, #setting.ExtraAction)]
end

function CustomShopSwordLight:randomSceneAction(setting)
  return setting.ExtraSceneAction[math.random(1, #setting.ExtraSceneAction)]
end

function CustomShopSwordLight:getSettingBySceneAction(action)
  for _, setting in pairs(self.Settings) do
    if setting.SceneAction == action then
      return setting
    end
  end
end

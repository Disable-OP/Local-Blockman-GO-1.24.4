CustomShopPet.curSwordLight = nil
CustomShopPet.curTimerKey = 0

local function playAction(setting)
  GUICustomShop.awPet1:SetActor1(setting.ActorName, "idle", 0)
  GUICustomShop.awPet2:SetActor1(setting.ActorName, "idle", 0)
  GUICustomShop:playSkill(setting.uiPlayerSkill)
  GUICustomShop.awPet1:SetActor1(setting.ActorName, setting.uiSkillName, 0)
  GUICustomShop.awPet2:SetActor1(setting.ActorName, setting.uiSkillName, 0)
  GUICustomShop.awPet2:SetRotateY(GUICustomShop.awPlayer2:GetRotateY())
  GUICustomShop.awPet1:SetRotateY(GUICustomShop.awPlayer1:GetRotateY())
end

function CustomShopPet:onTabChange(isSelect)
  LuaTimer:cancel(self.curTimerKey)
  GUIManager:getWindowByName("BedWarCustomShop-Pet-Layout1"):SetVisible(isSelect)
  GUIManager:getWindowByName("BedWarCustomShop-Pet-Layout2"):SetVisible(isSelect)
end

function CustomShopPet:onSelectGoods(goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  GUICustomShop.awPet1:SetXPosition({
    setting.uiXOffset,
    0
  })
  GUICustomShop.awPet1:SetYPosition({
    setting.uiYOffset,
    0
  })
  GUICustomShop.awPet2:SetXPosition({
    setting.uiXOffset,
    0
  })
  GUICustomShop.awPet2:SetYPosition({
    setting.uiYOffset,
    0
  })
  GUICustomShop.awPet1:SetWidth({
    setting.scale,
    0
  })
  GUICustomShop.awPet2:SetWidth({
    setting.scale,
    0
  })
  playAction(setting)
  local playerTime = GUICustomShop.awPlayer1:GetActor():GetSkillTimeLength(setting.uiPlayerSkill)
  local petTime = GUICustomShop.awPet1:GetActor():GetSkillTimeLength(setting.uiSkillName)
  local time = petTime
  if playerTime > petTime then
    time = playerTime
  end
  LuaTimer:cancel(self.curTimerKey)
  self.curTimerKey = LuaTimer:scheduleTimer(function()
    playAction(setting)
  end, time)
end

local curIndieTimerKey = 0

local function playActionMain(setting)
  if not GUIIndieMain.awPet:GetActor():getHasInited() then
    LuaTimer:schedule(function()
      playActionMain(setting)
    end, 50)
    return
  end
  GUIIndieMain.awPet:SetActor1(setting.ActorName, "idle", 0)
  GUIIndieMain.awPet:SetActor1(setting.ActorName, setting.uiSkillName, 0)
  local petTime = GUIIndieMain.awPet:GetActor():GetSkillTimeLength(setting.uiSkillName)
  LuaTimer:cancel(curIndieTimerKey)
  curIndieTimerKey = LuaTimer:scheduleTimer(function()
    GUIIndieMain.awPet:SetActor1(setting.ActorName, "idle", 0)
    GUIIndieMain.awPet:SetActor1(setting.ActorName, setting.uiSkillName, 0)
  end, petTime)
end

function CustomShopPet:onEquipGoods(goods)
  if Game:isEnableIndie() and GameType == "g1046" then
    local setting = self.Settings[goods.SettingId]
    if not setting then
      return
    end
    GUIIndieMain.awPet:SetVisible(true)
    GUIIndieMain.awPet:SetXPosition({
      setting.uiXOffsetMain,
      0
    })
    GUIIndieMain.awPet:SetYPosition({
      setting.uiYOffsetMain,
      0
    })
    GUIIndieMain.awPet:SetWidth({
      setting.scale * setting.scaleMain,
      0
    })
    GUIIndieMain.awPet:SetActor1(setting.ActorName, setting.uiSkillName, 0)
    playActionMain(setting)
  end
end

function CustomShopPet:onUnloadGoods(goods)
  if Game:isEnableIndie() and GameType == "g1046" then
    local setting = self.Settings[goods.SettingId]
    if not setting then
      return
    end
    GUIIndieMain.awPet:SetVisible(false)
  end
end

function CustomShopPet:getPendantById(id)
  if self.Settings[tostring(id)] ~= nil then
    return self.Settings[tostring(id)].pendant
  end
  return nil
end

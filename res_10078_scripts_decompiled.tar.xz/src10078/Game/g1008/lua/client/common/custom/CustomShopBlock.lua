CustomShopBlock.curBlock = nil
CustomShopBlock.curTimerKey = nil

function CustomShopBlock:onTabChange(isSelect)
  LuaTimer:cancel(self.curTimerKey)
  if isSelect then
    return
  end
  if CustomShopBlock.curBlock then
    GUICustomShop:setSingleActor(CustomShopBlock.curBlock.ShowConfig)
    CustomShopBlock.curBlock = nil
  end
end

function CustomShopBlock:onSelectGoods(goods)
  local block = self.Settings[goods.SettingId]
  if not block then
    return
  end
  CustomShopBlock.curBlock = block
  GUICustomShop:setSingleActor(block.ShowConfig)
  LuaTimer:cancel(self.curTimerKey)
  self.curTimerKey = LuaTimer:scheduleTimer(function()
    GUICustomShop.awActor:SetRotateY(GUICustomShop.awActor:GetRotateY() + 1)
  end, 20)
end

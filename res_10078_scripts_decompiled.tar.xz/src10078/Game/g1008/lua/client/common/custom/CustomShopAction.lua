CustomShopAction.curAction = nil
CustomShopAction.curTimerKey = nil

function CustomShopAction:onTabChange(isSelect)
  LuaTimer:cancel(self.curTimerKey)
  if isSelect then
    return
  end
  if CustomShopAction.curAction then
    GUICustomShop:unloadBodyPart(CustomShopAction.curAction.PartName)
    GUICustomShop:playSkill("idle")
    CustomShopAction.curAction = nil
  end
end

function CustomShopAction:onSelectGoods(goods)
  local action = self.Settings[goods.SettingId]
  if not action then
    return
  end
  CustomShopAction.curAction = action
  GUICustomShop:useBodyPart(action.PartName, action.MeshName)
  LuaTimer:cancel(self.curTimerKey)
  GUICustomShop:playSkill(CustomShopAction.curAction.Action)
  local length = GUICustomShop.awPlayer1:GetActor():GetSkillTimeLength(CustomShopAction.curAction.Action)
  if length == 0 then
    return
  end
  self.curTimerKey = LuaTimer:scheduleTimer(function()
    if CustomShopAction.curAction then
      GUICustomShop:playSkill("idle")
      GUICustomShop:playSkill(CustomShopAction.curAction.Action)
    end
  end, length)
end

function CustomShopAction:onEquipGoods(goods)
  local action = self.Settings[goods.SettingId]
  if not action then
    return
  end
  if GUIAction then
    GUIAction:addActionToList(action)
  end
end

function CustomShopAction:onUnloadGoods(goods)
  local action = self.Settings[goods.SettingId]
  if not action then
    return
  end
  if GUIAction then
    GUIAction:removeActionFromList(action.ActionId)
  end
end

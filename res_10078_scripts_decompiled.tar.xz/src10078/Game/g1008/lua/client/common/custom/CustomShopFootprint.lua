CustomShopFootprint.curFootprint = nil

function CustomShopFootprint:onTabChange(isSelect)
  if isSelect then
    return
  end
  if CustomShopFootprint.curFootprint then
    GUICustomShop:unloadBodyPart(CustomShopFootprint.curFootprint.PartName)
    GUICustomShop:playSkill("idle")
    CustomShopFootprint.curFootprint = nil
  end
end

function CustomShopFootprint:onSelectGoods(goods)
  local footprint = self.Settings[goods.SettingId]
  if not footprint then
    return
  end
  CustomShopFootprint.curFootprint = footprint
  GUICustomShop:useBodyPart(footprint.PartName, footprint.MeshName)
  GUICustomShop:playSkill(footprint.Action)
end

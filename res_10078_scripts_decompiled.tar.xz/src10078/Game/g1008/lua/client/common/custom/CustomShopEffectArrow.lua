CustomShopEffectArrow.curEffectArrow = nil

function CustomShopEffectArrow:onTabChange(isSelect)
  if isSelect then
    return
  end
  if CustomShopEffectArrow.curEffectArrow then
    GUICustomShop:unloadBodyPart(CustomShopEffectArrow.curEffectArrow.PartName)
    GUICustomShop:playSkill("idle")
    CustomShopEffectArrow.curEffectArrow = nil
  end
end

function CustomShopEffectArrow:onSelectGoods(goods)
  local effectArrow = self.Settings[goods.SettingId]
  if not effectArrow then
    return
  end
  CustomShopEffectArrow.curEffectArrow = effectArrow
  GUICustomShop:useBodyPart(effectArrow.PartName, effectArrow.MeshName)
  GUICustomShop:playSkill(effectArrow.Action)
end

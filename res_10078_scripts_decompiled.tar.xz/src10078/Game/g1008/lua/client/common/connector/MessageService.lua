local MessageService = class("MessageService", require("engine_base.connector.IConnectorMsgHandler"))
local ChatService = T(Global, "ChatService")
local FriendService = T(Global, "FriendService")
local ConnectorCenter = T(Global, "ConnectorCenter")
local ConnectorDispatch = T(Global, "ConnectorDispatch")
local Game2ConnectorMsgType = {
  PrivateMsg = 30001,
  TeamMsg = 30002,
  GameMsg = 30003,
  WorldMsg = 30004,
  GroupMsg = 30005,
  LangGroupMsg = 30006,
  JoinLangGroupMsg = 30103,
  SameServerMsg = 31001
}
local Connector2GameMsgType = {
  PrivateMsg = 30011,
  TeamMsg = 30012,
  GameMsg = 30013,
  WorldMsg = 30014,
  GroupMsg = 30015,
  LangGroupMsg = 30016,
  SameServerMsg = 31001
}

local function buildMsgUserInfo()
  local cache = UserInfoCache:GetCache(Game:getPlatformUserId())
  local info = {
    userId = Game:getPlatformUserId(),
    name = StringUtil.getRealName(cache and cache.name or CGame.Instance():getPlayerName()),
    colorfulNickName = cache and cache.colorfulNickName,
    picUrl = CGame.Instance():getPicUrl(),
    sex = cache and cache.sex or 1,
    curHeadFrame = cache and cache.curHeadFrame or 0
  }
  return info
end

function MessageService:init()
  self.range = {30000, 39999}
  self.services = {
    {
      range = {0, 999},
      service = ChatService
    },
    {
      range = {1000, 1999},
      service = FriendService
    }
  }
end

function MessageService:initMsgFunc()
  self:registerMsgFunc(Connector2GameMsgType.PrivateMsg, self.onPrivateMsg)
  self:registerMsgFunc(Connector2GameMsgType.TeamMsg, self.onTeamMsg)
  self:registerMsgFunc(Connector2GameMsgType.GameMsg, self.onGameMsg)
  self:registerMsgFunc(Connector2GameMsgType.WorldMsg, self.onWorldMsg)
  self:registerMsgFunc(Connector2GameMsgType.GroupMsg, self.onGroupMsg)
  self:registerMsgFunc(Connector2GameMsgType.LangGroupMsg, self.onLangGroupMsg)
  self:registerMsgFunc(Connector2GameMsgType.SameServerMsg, self.onSameServerMsg)
end

function MessageService:onMsgForward(_, _, data, funcName)
  for _, service in pairs(self.services) do
    if data.type >= service.range[1] and data.type <= service.range[2] then
      local func = service.service[funcName]
      if not func then
        LogUtil.logWarning("[MessageService:onMsgForward] can not find func, funcName=" .. funcName .. " type=" .. data.type)
        return
      end
      func(service.service, _, _, data)
      return
    end
  end
end

function MessageService:onPrivateMsg(_, _, data)
  self:onMsgForward(_, _, data, "onPrivateMsg")
end

function MessageService:onTeamMsg(_, _, data)
  self:onMsgForward(_, _, data, "onTeamMsg")
end

function MessageService:onGameMsg(_, _, data)
  self:onMsgForward(_, _, data, "onGameMsg")
end

function MessageService:onWorldMsg(_, _, data)
  self:onMsgForward(_, _, data, "onWorldMsg")
end

function MessageService:onGroupMsg(_, _, data)
  self:onMsgForward(_, _, data, "onGroupMsg")
end

function MessageService:onLangGroupMsg(_, _, data)
  self:onMsgForward(_, _, data, "onLangGroupMsg")
end

function MessageService:onSameServerMsg(_, _, data)
  self:onMsgForward(_, _, data, "onSameServerMsg")
end

function MessageService:sendJoinInLangGroup(lang)
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.JoinLangGroupMsg, {lang = lang})
end

function MessageService:sendMsgToPrivate(targetId, type, data)
  local msg = {
    sendId = Game:getPlatformUserId(),
    targetId = targetId,
    type = type,
    data = data
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.PrivateMsg, msg)
  return msg
end

function MessageService:sendMsgToTeam(type, data)
  local TeamService = T(Global, "TeamService")
  if not TeamService:isInTeam(Game:getPlatformUserId()) then
    return
  end
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.TeamMsg, {
    sendId = Game:getPlatformUserId(),
    type = type,
    data = data,
    teamId = TeamService.teamId,
    regionId = TeamService.regionId
  })
end

function MessageService:sendMsgToGame(type, data)
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.GameMsg, {
    sendId = Game:getPlatformUserId(),
    type = type,
    data = data,
    gameType = GameType,
    engineVersion = EngineVersionSetting.getEngineVersion(),
    info = buildMsgUserInfo()
  })
end

function MessageService:sendMsgToWorld(type, data)
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.WorldMsg, {
    sendId = Game:getPlatformUserId(),
    type = type,
    data = data,
    info = buildMsgUserInfo()
  })
end

function MessageService:sendMsgToGroup(type, data)
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.GroupMsg, {
    sendId = Game:getPlatformUserId(),
    type = type,
    data = data,
    gameId = Game:getGameId(),
    info = buildMsgUserInfo()
  })
end

function MessageService:sendMsgToLangGroup(type, data, group)
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.LangGroupMsg, {
    sendId = Game:getPlatformUserId(),
    type = type,
    data = data,
    info = buildMsgUserInfo(),
    group = group
  })
end

function MessageService:sendMsgToSameServer(type, data)
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.SameServerMsg, {
    sendId = Game:getPlatformUserId(),
    type = type,
    data = data
  })
end

ConnectorDispatch:registerHandler(T(Global, "MessageService", MessageService.new()))

local ChatService = T(Global, "ChatService")
local ChatClient = T(Global, "ChatClient")

function ChatService:pretreatmentMsg(data)
  if not TableUtil.tableContain(Define.ChatMsgType, data.type) then
    data.type = Define.ChatMsgType.None
    return
  end
  if data.type == Define.ChatMsgType.TextMsg then
    if #data.data.content < 7 then
      return
    end
    local pre = data.data.content:sub(1, 6)
    if pre == "[lang]" then
      data.data.content = Lang:getString(data.data.content:sub(7, #data.data.content))
    end
    return
  end
end

function ChatService:onPrivateMsg(_, _, data)
  self:pretreatmentMsg(data)
  ChatClient:addPrivateChatMsgData(data)
  UserInfoCache:GetCacheByUserIds({
    data.sendId
  }, function()
    if data.sendId == Game:getPlatformUserId() then
      Events.ReceiveChatMsgEvent:invoke(data.targetId, data)
    else
      Events.ReceiveChatMsgEvent:invoke(data.sendId, data)
    end
  end)
end

function ChatService:onTeamMsg(_, _, data)
  self:pretreatmentMsg(data)
  ChatClient:getChatDB():addChatMsgData("team", data, false)
  UserInfoCache:GetCacheByUserIds({
    data.sendId
  }, function()
    Events.ReceiveChatMsgEvent:invoke("team", data)
  end)
end

function ChatService:onGameMsg(_, _, data)
  self:pretreatmentMsg(data)
  ChatClient:getChatDB():addChatMsgData("game", data, false)
  UserInfoCache:UpdateUserInfos({
    data.info
  })
  Events.ReceiveChatMsgEvent:invoke("game", data)
end

function ChatService:onWorldMsg(_, _, data)
  self:pretreatmentMsg(data)
  ChatClient:getChatDB():addChatMsgData("world", data, false)
  UserInfoCache:UpdateUserInfos({
    data.info
  })
  Events.ReceiveChatMsgEvent:invoke("world", data)
end

function ChatService:onGroupMsg(_, _, data)
  self:pretreatmentMsg(data)
  ChatClient:getChatDB():addChatMsgData("group", data, false)
  UserInfoCache:UpdateUserInfos({
    data.info
  })
  Events.ReceiveChatMsgEvent:invoke("group", data)
end

function ChatService:onLangGroupMsg(_, _, data)
  self:pretreatmentMsg(data)
  ChatClient:getChatDB():addChatMsgData(data.group or "lang", data, false)
  UserInfoCache:UpdateUserInfos({
    data.info
  })
  Events.ReceiveChatMsgEvent:invoke(data.group or "lang", data)
end

function ChatService:onSameServerMsg(_, _, data)
  self:pretreatmentMsg(data)
  ChatClient:getChatDB():addChatMsgData("same_server", data, false)
  Events.ReceiveChatMsgEvent:invoke("same_server", data)
end

function ChatService:sendMsgToPrivate(targetId, type, data)
  local MessageService = T(Global, "MessageService")
  local msg = MessageService:sendMsgToPrivate(targetId, type, data)
  self:onPrivateMsg(nil, nil, msg)
end

function ChatService:sendMsgToTeam(type, data)
  local MessageService = T(Global, "MessageService")
  MessageService:sendMsgToTeam(type, data)
end

function ChatService:sendMsgToGame(type, data)
  local MessageService = T(Global, "MessageService")
  MessageService:sendMsgToGame(type, data)
end

function ChatService:sendMsgToWorld(type, data)
  local MessageService = T(Global, "MessageService")
  MessageService:sendMsgToWorld(type, data)
end

function ChatService:sendMsgToGroup(type, data)
  local MessageService = T(Global, "MessageService")
  MessageService:sendMsgToLangGroup(type, data, "group")
end

function ChatService:sendMsgToLangGroup(type, data)
  local MessageService = T(Global, "MessageService")
  MessageService:sendMsgToLangGroup(type, data, "lang")
end

function ChatService:sendMsgToSameServer(type, data)
  local MessageService = T(Global, "MessageService")
  MessageService:sendMsgToSameServer(type, data)
end

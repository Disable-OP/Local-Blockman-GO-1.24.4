GoodsStorePrivilege = {}

function GoodsStorePrivilege:init(config)
  self.id = tonumber(config.Id)
  self.tabId = tonumber(config.TabId)
end

function GoodsStorePrivilege:onPlayerBuy(player)
end

function GoodsStorePrivilege:onBuyGoods(goods)
  if not Privilege.checkHavePrivilege(self.id) then
    return goods.Count
  end
  if goods.TabId == self.tabId then
    return goods.Count * 2
  end
  return goods.Count
end

require("common.custom.CustomShopBlock")
require("common.custom.CustomShopFootprint")
require("common.custom.CustomShopEffectArrow")
require("common.custom.CustomShopAction")
require("common.custom.CustomShopSwordLight")
require("common.custom.CustomShopPet")
require("common.custom.CustomShopCloth")
require("common.custom.CustomShopDress")

function CustomShop:init()
  EventObservable:registerDataCallBack("CustomShopData", function(data)
    local TabIds = {}
    for _, item in pairs(data) do
      local goods = CustomShopConfig:getGoodsConfig(item[CustomGoodsIndex.Id])
      if goods then
        goods.Time = item[CustomGoodsIndex.Time]
        if goods.Status ~= item[CustomGoodsIndex.Status] then
          goods.Status = item[CustomGoodsIndex.Status]
          if goods.Status == CustomShopGoodsStatus.Equiped then
            CustomShop:callModuleFunc("onEquipGoods", CustomShopConfig:getGoodsType(goods), goods)
          else
            CustomShop:callModuleFunc("onUnloadGoods", CustomShopConfig:getGoodsType(goods), goods)
          end
        end
        TabIds[tostring(goods.TabId)] = true
      end
    end
    for tabId, _ in pairs(TabIds) do
      local goodsList = CustomShopConfig:getGoodsList(tonumber(tabId))
      table.sort(goodsList, function(a, b)
        if a.Time ~= b.Time then
          return a.Time < b.Time
        end
        return a.Weight < b.Weight
      end)
    end
    if GUICustomShop then
      GUICustomShop:updateListUI()
    end
  end, JsonBuilderProcessor)
  EventObservable:registerDataCallBack("BuyCustomGoodsSuccess", function(goodsId)
    GUICustomShop:showBuyGoodsSuccess(goodsId)
  end)
end

CustomShop:init()

function CustomShop:onBuyGoods(goods, coinId)
  CommonPacketSender:sendBuyCustomGoods(goods.Id, coinId)
end

function CustomShop:onEquipGoods(goods)
  CommonPacketSender:sendEquipCustomGoods(goods.Id)
  ReportUtil.reportCustomShopEquip(goods.Id)
end

function CustomShop:onUnloadGoods(goods)
  CommonPacketSender:sendUnloadCustomGoods(goods.Id)
  ReportUtil.reportCustomShopUnload(goods.Id)
end

function CustomShop:onTabChange(tab, isSelect)
  CustomShop:callModuleFunc("onTabChange", tab.type, isSelect)
end

function CustomShop:onSelectGoods(goods)
  CustomShop:callModuleFunc("onSelectGoods", CustomShopConfig:getGoodsType(goods), goods)
end

ClientStore = {}

local function init()
  EventObservable:registerDataCallBack("BuyGoodsSuccess", function(goodsId)
    ClientStore:onBuyGoodsSuccess(goodsId)
  end)
  EventObservable:registerDataCallBack("PrivilegeData", function(data)
    Privilege.updatePrivilegeData(data)
  end, JsonBuilderProcessor)
end

init()

local function checkUpgradeGoods(itemId)
  if not StoreConfig:needCheckUpgrade(itemId) then
    return
  end
  local oldItemId = ItemMapping:getOldItemId(itemId)
  local newGoods = StoreConfig:getNextUpgradeGoods(oldItemId)
  StoreConfig:replaceUpgradeGoods(newGoods)
end

local function isEquipItem(itemId)
  local inv = Game:getPlayer():getInventory()
  for index = 101, 104 do
    local info = inv:getItemStackInfo(index - 1)
    if info.id == itemId then
      return true
    end
  end
  return false
end

local function getEquipLevel(levelGroup)
  return StoreConfig:getEquipArmorLevel(Game:getPlayer(), levelGroup)
end

local function getPlayerInventoryInfo(player, armorDuration)
  local MAIN_INVENTORY_COUNT = 100
  local ARMOR_INVENTORY_COUNT = 6
  local inv = player:getInventory()
  local inventory = {}
  inventory.item = {}
  inventory.gun = {}
  inventory.armor = {}
  for i = 1, MAIN_INVENTORY_COUNT + ARMOR_INVENTORY_COUNT do
    local info = inv:getItemStackInfo(i - 1)
    if info.id > 0 and info.id < 10000 then
      local item = {}
      item.id = info.id
      item.meta = info.meta
      item.num = info.num
      item.stackIndex = i - 1
      if i <= MAIN_INVENTORY_COUNT then
        if GunSetting.isGunItem(item.id) then
          item.num = 1
          item.meta = 0
          item.bullets = info.bullets
          table.insert(inventory.gun, item)
        else
          table.insert(inventory.item, item)
        end
      else
        item.num = 1
        if armorDuration == nil then
          item.meta = 0
        end
        if item.id >= 3377 and item.id <= 3439 then
          item.meta = info.meta
        end
        table.insert(inventory.armor, item)
      end
    end
  end
  return inventory
end

function ClientStore:checkBuyBullet(player, gunId, buyCount)
  buyCount = buyCount or 1
  local needCount = 0
  local info = getPlayerInventoryInfo(player)
  local setting = GunSetting.getGunSetting(gunId)
  local maxBulletNum = tonumber(setting.maxBulletNum)
  local gunNum = 0
  for _, gun in pairs(info.gun) do
    if gun.id == 3576 then
      gunNum = gunNum + 1
      needCount = needCount + (maxBulletNum - gun.bullets)
    end
  end
  if buyCount > needCount then
    return false, gunNum
  end
  return true, gunNum
end

function ClientStore:checkAllUpgradeGoods()
  local inv = Game:getPlayer():getInventory()
  for index = 1, 36 do
    local info = inv:getItemStackInfo(index - 1)
    if info.id ~= 0 then
      checkUpgradeGoods(info.id)
    end
  end
  for index = 101, 104 do
    local info = inv:getItemStackInfo(index - 1)
    if info.id ~= 0 then
      checkUpgradeGoods(info.id)
    end
  end
end

function ClientStore:onGameStart()
  local _info = GameInfoManager:getPlayerInfo(Game:getPlatformUserId())
  if not _info then
    return
  end
  local teamId = _info:getValue("teamId")
  Game:getPlayer():setTeamId(tonumber(teamId))
  GameInfoManager:registerObserver(teamId, function(info)
    for _, gainId in pairs(TeamGainType) do
      local level = tonumber(info:getValue(gainId)) + 1
      local goods = StoreConfig:getUpgradeGoods(tonumber(gainId), level)
      if goods and goods.Level == level then
        StoreConfig:replaceUpgradeGoods(goods)
      end
    end
    if GUIStore then
      GUIStore:updateListUI()
    end
    if GUIUpgradeStore then
      GUIUpgradeStore:updateListUI()
    end
  end)
end

function ClientStore:onBuyGoods(goods, callback)
  local storeId = StoreConfig:getGoodsStoreId(goods)
  if storeId == StoreId.GoodsStore then
    GameAnalytics:design(1, {
      "G_goods_shop_buy",
      tostring(goods.Id)
    })
  elseif storeId == StoreId.CubeStore then
    if GameType == "g1046" then
      GameAnalytics:design(1, {
        "H_cube_shop_buy",
        tostring(goods.Id)
      })
    else
      GameAnalytics:design(1, {
        "G_cube_shop_buy",
        tostring(goods.Id)
      })
    end
  elseif storeId == StoreId.UpgradeStore then
    GameAnalytics:design(1, {
      "G_upgrade_shop_buy",
      tostring(goods.Id)
    })
  end
  if goods.Price < 0 then
    return
  end
  if 0 <= goods.LimitCount and goods.LimitCount == 0 then
    callback(false, Lang:getTipString(1008012))
    return
  end
  if goods.Type == GoodsType.Item then
    local inv = Game:getPlayer():getInventory()
    if not inv:isCanAddItem(goods.ItemId, 0, goods.Count) then
      callback(false, Lang:getString("lottery_full_Inventory"))
      return
    end
  elseif goods.Type == GoodsType.BulletClip then
    local canBuy, gunNum = ClientStore:checkBuyBullet(PlayerManager:getClientPlayer().Player, goods.ItemId, goods.Count)
    if not canBuy then
      if 0 < gunNum then
        callback(false, Lang:getTipString(1008043))
      else
        callback(false, Lang:getTipString(1008047))
      end
      return
    end
  end
  local currency = StoreConfig:getCurrencyConfig(goods.CurrencyId)
  if not currency then
    return
  end
  local success = false
  if 0 < currency.ItemId then
    if PlayerWallet.getCoinNum(currency.Id) < goods.Price then
      callback(false, Lang:getString("lack_of_money"))
      return
    end
    CommonPacketSender:sendBuyGoods(goods.Id)
    success = true
  else
    PayHelper.checkMoney(currency.RealId, goods.Price, function(canBuy)
      if canBuy then
        CommonPacketSender:sendBuyGoods(goods.Id)
        success = true
      end
    end)
  end
  if success then
    if 0 < goods.LimitCount then
      goods.LimitCount = goods.LimitCount - 1
    end
    callback(true)
  end
end

function ClientStore:onBuyGoodsSuccess(goodsId)
  local goods = StoreConfig:getGoodsById(goodsId)
  if not goods then
    return
  end
  self:checkAllUpgradeGoods()
  local storeId = StoreConfig:getGoodsStoreId(goods)
  if storeId == StoreId.UpgradeStore then
    GUIUpgradeStore:onBuyGoodsSuccess(goods)
  else
    GUIStore:onBuyGoodsSuccess(goods)
  end
end

function ClientStore:setGoodsUI(tvName, ivImage, ivMoney, tvMoney, btnBuy, data)
  tvName:SetText(Lang:getString(data.Name))
  ivImage:SetHexagonImage("", "")
  ivImage:SetRenderAsBlock(false)
  ivMoney:SetHexagonImage("", "")
  ivMoney:SetRenderAsBlock(false)
  if #data.Image > 10 then
    ivImage:SetImage(data.Image)
  elseif data.ItemId > 0 then
    GuiItemStack.showItemIcon(ivImage, data.ItemId, 0, "")
  else
    ivImage:SetImage("")
  end
  local config = StoreConfig:getCurrencyConfig(data.CurrencyId)
  if config then
    if config.ItemId > 0 then
      GuiItemStack.showItemIcon(ivMoney, config.ItemId, 0, "")
    elseif 0 < config.RealId then
      ivMoney:SetImage(PayHelper.getMoneyIcon(config.RealId))
    else
      ivMoney:SetImage("")
    end
  else
    ivMoney:SetImage("")
  end
  tvMoney:SetText(tostring(data.Price))
  local width = tvMoney:GetTextWidth()
  ivMoney:SetVisible(data.Price ~= -1)
  tvMoney:SetVisible(data.Price ~= -1)
  ivMoney:SetXPosition({
    0,
    -(5 + width / 2)
  })
  if data.Price == -1 then
    btnBuy:SetEnabled(false)
    btnBuy:SetText(Lang:getString("gui_shop_good_max_level"))
  elseif data.Type == GoodsType.Armor then
    if isEquipItem(data.ItemId) then
      btnBuy:SetEnabled(false)
      btnBuy:SetText(Lang:getString("gui_shop_good_using"))
      ivMoney:SetVisible(false)
      tvMoney:SetVisible(false)
    else
      if getEquipLevel(data.LevelGroup) > data.Level then
        btnBuy:SetEnabled(false)
      else
        btnBuy:SetEnabled(true)
      end
      btnBuy:SetText("")
    end
  else
    btnBuy:SetEnabled(true)
    btnBuy:SetText("")
  end
  if data.Price == -2 then
    ivMoney:SetVisible(false)
  end
end

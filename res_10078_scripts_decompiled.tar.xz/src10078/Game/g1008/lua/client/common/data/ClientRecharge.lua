Listener.registerCallBack(Events.SumRechargeCreateItemsEvent, function()
  local defineContentWidth = 1133
  local defineContentHeight = 541
  local defineRewardWidth = 198
  local name = string.gsub(GUISumRechargeLayout.__name, ".json", "-")
  local llContent = GUISumRechargeLayout:getChildWindow(name .. "Content", GUIType.Layout)
  local btnClose = GUISumRechargeLayout:getChildWindow(name .. "Close", GUIType.Button)
  local totalWidth = btnClose:GetPixelSize().x - 30
  if defineContentWidth > totalWidth then
    defineContentHeight = math.floor(defineContentHeight / defineContentWidth * totalWidth)
    defineRewardWidth = math.floor(defineRewardWidth / defineContentWidth * totalWidth)
    defineContentWidth = math.floor(totalWidth)
  end
  llContent:SetWidth({0, defineContentWidth})
  llContent:SetHeight({0, defineContentHeight})
  GUISumRechargeLayout:setRewardWidth(defineRewardWidth)
  local config = SumRechargeConfig:getSumRecharge(GUISumRechargeLayout.currentId)
  local tvTitle1 = GUISumRechargeLayout:getChildWindow(name .. "Title1", GUIType.StaticText)
  local tvTitle2 = GUISumRechargeLayout:getChildWindow(name .. "Title2", GUIType.StaticText)
  local tvTitle3 = GUISumRechargeLayout:getChildWindow(name .. "Title3", GUIType.StaticText)
  local tvTitle4 = GUISumRechargeLayout:getChildWindow(name .. "Title4", GUIType.StaticText)
  tvTitle1:SetText(Lang:getString(config.TitleLang))
  tvTitle2:SetText(Lang:getString(config.TitleLang))
  tvTitle3:SetText(Lang:getString(config.TitleLang .. "2"))
  tvTitle4:SetText(Lang:getString(config.TitleLang .. "2"))
  if not string.find(Lang:getLang(), "zh_") then
    tvTitle1:SetFont(GUIFontManager:Instance():GetFont("YSB36"))
    tvTitle2:SetFont(GUIFontManager:Instance():GetFont("YSB36"))
    tvTitle3:SetFont(GUIFontManager:Instance():GetFont("YSB36"))
    tvTitle4:SetFont(GUIFontManager:Instance():GetFont("YSB36"))
  end
  local btnCharge = GUISumRechargeLayout:getChildWindow(name .. "Recharge", GUIType.Button)
  btnCharge:registerEvent(GUIEvent.ButtonClick, function()
    if GUISumRechargeLayout.currentGCube >= config.GCube then
      ReportUtil.reportGetFirstRecharge(GUISumRechargeLayout.currentId)
    else
      ReportUtil.reportBuyFirstRecharge(GUISumRechargeLayout.currentId)
    end
  end)
  local mainName = string.gsub(GUISumRechargeMain.__name, ".json", "-")
  local btnChargeMain = GUISumRechargeMain:getChildWindow(mainName .. "Icon", GUIType.Button)
  btnChargeMain:registerEvent(GUIEvent.ButtonClick, function()
    GameAnalytics:design(1, {
      "ui_firstrecharge",
      tostring(config.Id)
    })
  end)
  return true
end)
Listener.registerCallBack(Events.SumRechargeResultEvent, function(id)
  local function func()
    CustomDialog:hide()
    
    local name = string.gsub(GUISumRechargeResult.__name, ".json", "-")
    GUISumRechargeResult:getChildWindow(name .. "Title-Text1", GUIType.StaticText):SetText(Lang:getString("sum.recharge.receive.success"))
    GUISumRechargeResult:getChildWindow(name .. "Title-Text2", GUIType.StaticText):SetText(Lang:getString("sum.recharge.receive.success"))
    local config = SumRechargeConfig:getSumRecharge(id)
    for i = 1, 3 do
      local reward = config.Rewards[i]
      if reward then
        GUISumRechargeResult:getChildWindow(name .. "Reward-Count" .. tostring(i), GUIType.StaticText):SetText(string.format("x%s", tostring(reward.Count)))
        GUISumRechargeResult:getChildWindow(name .. "Reward-Name" .. tostring(i), GUIType.StaticText):SetText(Lang:getString(reward.NameLang))
      end
    end
  end
  
  if CustomDialog and GUISumRechargeResult then
    func()
  else
    GUIManager:registerQueue(func)
  end
end)

BuffInfo = {}
BuffInfo.Buffs = {}

function BuffInfo:initRegister()
  CommonDataEvents:registerCallBack("BuffInfo", function(data)
    self.onBuffInfoChange(data)
  end, DataBuilderProcessor)
  Listener.registerCallBack(CEvents.ClickMainControlEvent, self.onClickMainControl)
end

function BuffInfo.onBuffInfoChange(data)
  local buffId = data:getNumberParam("buffId")
  local type = data:getNumberParam("type")
  local duration = data:getNumberParam("duration")
  if duration == 0 then
    for index, buff in pairs(BuffInfo.Buffs) do
      if buff.type == type then
        table.remove(BuffInfo.Buffs, index)
      end
    end
  else
    local buffConfig = BuffConfig:getBuffByType(type)
    if buffConfig.overlayType == 1 then
      local hadBuff = false
      for _, buff in pairs(BuffInfo.Buffs) do
        if buff.buffId == buffId then
          buff.endTime = os.time() + buffConfig.duration
          hadBuff = true
        end
      end
      if not hadBuff then
        BuffInfo:addBuff(buffId, type, duration)
      end
    elseif buffConfig.overlayType == 2 then
      local hadBuff = false
      for _, buff in pairs(BuffInfo.Buffs) do
        if buff.buffId == buffId then
          buff.endTime = buff.endTime + duration
          hadBuff = true
        end
      end
      if not hadBuff then
        BuffInfo:addBuff(buffId, type, duration)
      end
    else
      BuffInfo:addBuff(buffId, type, duration)
    end
  end
end

function BuffInfo.onClickMainControl()
  GamePacketSender:sendBedWarPlayerClickMainControl()
end

function BuffInfo:addBuff(buffId, type, duration)
  local buffConfig = BuffConfig:getBuffByType(type)
  if not buffConfig then
    return
  end
  local config = {
    buffId = buffId,
    type = type,
    endTime = os.time() + duration,
    image = buffConfig.image
  }
  table.insert(self.Buffs, config)
end

local oldGetMoneyByCoinId = PlayerWallet.getMoneyByCoinId

function PlayerWallet.getMoneyByCoinId(coinId)
  if coinId == 1 and isBeta then
    return oldGetMoneyByCoinId(Define.Money.FAKE_DIAMOND)
  else
    return oldGetMoneyByCoinId(coinId)
  end
end

local UIUtils = T(Global, "UIUtils")
TreasureChallenge = {}
TreasureChallenge.rewardData = {}
TreasureChallenge.challengeConfig = {}
TreasureChallenge.needTip = false

local function sortTask(taskGroup, task, index)
  if task.status == Define.TaskStatus.FINISHED then
    table.remove(taskGroup, index)
    table.insert(taskGroup, 1, task)
  elseif task.status == Define.TaskStatus.RECEIVED then
    taskGroup[#taskGroup + 1] = task
    table.remove(taskGroup, index)
  end
end

local function sortReward(rewardData, reward, index)
  if reward.status == Define.ChallengeStatus.Experiencing then
    table.remove(rewardData, index)
    table.insert(rewardData, 1, reward)
  elseif reward.status == Define.ChallengeStatus.Completed then
    rewardData[#rewardData + 1] = reward
    table.remove(rewardData, index)
  end
end

function TreasureChallenge:init()
  EventObservable:registerDataCallBack("ReceiveNewChallenge", function(rewardId)
    self:onReceiveNewChallenge(rewardId)
  end)
  EventObservable:registerDataCallBack("GiveUpChallenge", function(rewardId)
    self:onGiveUpChallenge(rewardId)
  end)
  EventObservable:registerDataCallBack("ChallengeTimeout", function()
    self:onChallengeTimeout()
  end)
  EventObservable:registerDataCallBack("ChallengeTaskInfo", function(data)
    self:onTaskProcessChange(data)
  end, DataBuilderProcessor)
  EventObservable:registerDataCallBack("ChallengePoints", function(data)
    self:onChallengePointsChange(data)
  end, DataBuilderProcessor)
  EventObservable:registerDataCallBack("FinishChallenge", function(rewardId)
    self:onFinishChallenge(rewardId)
  end)
  EventObservable:registerDataCallBack("SyncChallengeInfo", function(data)
    self:onSyncChallengeInfo(data)
  end, JsonBuilderProcessor)
  EventObservable:registerDataCallBack("ChallengeTimesChange", function(times)
    self:onPlayerOpenTreasureChallenge(times)
  end)
  EventObservable:registerDataCallBack("ChallengeTimes", function(times)
    self:buildRewardData(times)
  end)
  EventObservable:registerDataCallBack("NewChallenge", function()
    self.needTip = true
  end)
end

function TreasureChallenge:buildRewardData(times)
  self.rewardData = {}
  self.challengeConfig = TreasureChallengeConfig:getChallengeByTimes(times)
  if not self.challengeConfig then
    return
  end
  for _, reward in pairs(self.challengeConfig.rewardList) do
    local taskGroup = {}
    local taskGroupConfig = TaskConfig:getTaskByGroupId(reward.taskGroupId)
    for _, taskConfig in pairs(taskGroupConfig) do
      local task = {
        taskId = taskConfig.Id,
        desc = taskConfig.Desc,
        GoalNum = taskConfig.GoalNum,
        reward = taskConfig.Reward,
        progress = 0,
        status = Define.TaskStatus.UNACCEPTED
      }
      table.insert(taskGroup, task)
    end
    local item = {
      rewardId = reward.rewardId,
      itemId = reward.itemId,
      type = reward.type,
      itemType = reward.itemType,
      dressTab = reward.dressTab,
      introduce = reward.introduce,
      scale1 = reward.scale1,
      offset1 = reward.offset1,
      scale2 = reward.scale2,
      offset2 = reward.offset2,
      status = Define.ChallengeStatus.NotAccepted,
      needPoints = reward.needPoints,
      havePoints = 0,
      taskGroup = taskGroup,
      name = reward.name,
      image = reward.image,
      actorName = reward.actorName,
      uiSkillName = reward.uiSkillName,
      minDays = reward.minDays,
      isRecommend = reward.isRecommend
    }
    self.rewardData[reward.seq] = item
  end
end

function TreasureChallenge:getRewardData(rewardId)
  for index, reward in pairs(self.rewardData) do
    if reward.rewardId == tonumber(rewardId) then
      return reward, index
    end
  end
  return nil, nil
end

function TreasureChallenge:onReceiveNewChallenge(rewardId)
  for index, reward in pairs(self.rewardData) do
    if reward.rewardId == tonumber(rewardId) then
      reward.status = Define.ChallengeStatus.Experiencing
    elseif reward.status == Define.ChallengeStatus.Experiencing then
      reward.status = Define.ChallengeStatus.NotAccepted
      reward.havePoints = 0
    end
    sortReward(self.rewardData, reward, index)
  end
  GUITreasureChallenge:onDataChange(self.rewardData)
  self:updateRedPoint()
  if GUIChallengeTask.rewardId == tonumber(rewardId) then
    GUIChallengeTask:canUndergoReward()
    GUIChallengeTask:refreshUI(tonumber(rewardId))
  end
end

function TreasureChallenge:onGiveUpChallenge(rewardId)
  for _, reward in pairs(self.rewardData) do
    if reward.rewardId == tonumber(rewardId) then
      reward.havePoints = 0
      reward.status = Define.ChallengeStatus.NotAccepted
      for _, task in pairs(reward.taskGroup) do
        task.progress = 0
        task.status = Define.TaskStatus.UNACCEPTED
      end
      break
    end
  end
  self:updateRedPoint()
  GUITreasureChallenge:onDataChange(self.rewardData)
  if GUIChallengeTask.rewardId == tonumber(rewardId) then
    GUIChallengeTask:refreshUI(tonumber(rewardId))
  end
end

function TreasureChallenge:onChallengeTimeout()
  GUITreasureChallenge:onDataChange({})
  GUIChallengeTask:hide()
  GUITreasureChallenge:hide()
end

function TreasureChallenge:onFinishChallenge(rewardId)
  local reward, index = self:getRewardData(rewardId)
  reward.status = Define.ChallengeStatus.Completed
  GUIChallengeTask:hide()
  GUIChallengeRewardReceive:init(reward, false)
  GUIChallengeTask.rewardId = 0
  sortReward(self.rewardData, reward, index)
  GUITreasureChallenge:onDataChange(self.rewardData)
  self:updateRedPoint()
end

function TreasureChallenge:onRefreshTask(data)
end

function TreasureChallenge:onTaskProcessChange(data)
  local times = data:getParam("times")
  local rewardId = data:getNumberParam("rewardId")
  local taskId = data:getNumberParam("taskId")
  local progress = data:getNumberParam("progress")
  local status = data:getNumberParam("status")
  if times ~= TreasureChallengeConfig.times then
    return
  end
  for _, item in pairs(self.rewardData) do
    if item.rewardId == rewardId then
      for index, task in pairs(item.taskGroup) do
        if task.taskId == taskId then
          task.progress = progress
          task.status = status
          sortTask(item.taskGroup, task, index)
          break
        end
      end
      break
    end
  end
  self:updateRedPoint()
  GUITreasureChallenge:onDataChange(self.rewardData)
  if GUIChallengeTask.rewardId == rewardId then
    GUIChallengeTask:refreshUI(rewardId)
  end
end

function TreasureChallenge:onChallengePointsChange(data)
  local times = data:getParam("times")
  local rewardId = data:getNumberParam("rewardId")
  local Points = data:getNumberParam("Points")
  if times ~= TreasureChallengeConfig.times then
    return
  end
  for _, item in pairs(self.rewardData) do
    if item.rewardId == rewardId then
      item.havePoints = Points
    end
  end
  GUITreasureChallenge:onDataChange(self.rewardData)
  if GUIChallengeTask.rewardId == rewardId then
    GUIChallengeTask:refreshUI(rewardId)
    GUIChallengeTask:showGiftAnim()
  end
end

function TreasureChallenge:onFinishTask(taskId)
  CommonPacketSender:sendFinishTask(taskId)
end

function TreasureChallenge:onPlayerOpenTreasureChallenge(times)
  self:buildRewardData(times)
  GUITreasureChallenge:onDataChange(self.rewardData)
end

function TreasureChallenge:showNewChallengeTip()
  if self.needTip then
    GUITreasureChallenge:hide()
    CustomDialog.builder().setHideLeftButton().setTitleText("gui_bed_war_new_challenge").setContentText(Lang:getString("gui_bed_war_new_challenge_tip")).setRightText("gui_dialog_tip_btn_sure").setRightClickListener(function()
      GUITreasureChallenge:show(true)
    end).show()
    CommonPacketSender:openNewChallenge()
    self.needTip = false
  end
end

function TreasureChallenge:onSyncChallengeInfo(data)
  for _, reward in pairs(data) do
    for index, item in pairs(self.rewardData) do
      if item.rewardId == reward.rewardId then
        item.status = reward.status
        item.havePoints = reward.havePoints
        sortReward(self.rewardData, item, index)
      end
    end
  end
  if not GUITreasureChallenge then
    GUIManager:registerQueue(function()
      GUITreasureChallenge:onDataChange(self.rewardData)
    end)
  else
    GUITreasureChallenge:onDataChange(self.rewardData)
  end
end

function TreasureChallenge:updateRedPoint()
  for _, item in pairs(self.rewardData) do
    if item.status == Define.ChallengeStatus.Experiencing then
      for _, task in pairs(item.taskGroup) do
        if task.status == Define.TaskStatus.FINISHED then
          UIUtils.updateRedDotCount(Define.RedDotKey.Challenge, 1)
          return true
        end
      end
    end
  end
  UIUtils.updateRedDotCount(Define.RedDotKey.Challenge, 0)
  return false
end

return TreasureChallenge

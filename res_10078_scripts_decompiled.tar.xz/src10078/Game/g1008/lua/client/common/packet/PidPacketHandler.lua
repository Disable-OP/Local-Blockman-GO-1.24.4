local handler = T(Global, "PacketHandlers")

function handler:AlarmWarning(packet)
  GUIMain:upScreenEffect(tonumber(packet.time))
  GUIBedWarGameTips:showGameTip(Lang:getString("prop.alarm.tip.warning"))
end

function handler:AlarmDisappear(packet)
  GUIBedWarGameTips:showGameTip(Lang:getString("prop.alarm.tip.disappear"))
end

function handler:ShowGameTip(packet)
  GUIBedWarGameTips:showGameTip(Lang:getString(packet.lang))
end

function handler:StartSinging(packet)
  GUIPlayerInfo:startSinging(packet.time or 1)
  GUIPlayerInfo:setSingingIcon(packet.icon or Define.SingingIcon.Teleport)
end

function handler:BreakSinging(packet)
  GUIPlayerInfo:breakSinging()
end

function handler:MountHurt(packet)
  local entityId = EntityCache:getClientId(tonumber(packet.entityId))
  
  local function setOnHurt(isHurting)
    local entity = EntityCache:getEntity(entityId)
    if not entity then
      return
    end
    entity.entity:setHurting(isHurting)
  end
  
  setOnHurt(true)
  LuaTimer:schedule(function()
    setOnHurt(false)
  end, 300)
end

function handler:UpdateItemCd(packet)
  local function func()
    GUIPlayerInventory:UpdateItemCd(packet.itemId, packet.totalTime, packet.curTime or packet.totalTime)
  end
  
  if GUIPlayerInventory then
    func()
  else
    GUIManager:registerQueue(func)
  end
end

function handler:PropPacketData(packet)
  local function func()
    GUIPropPacket:refreshUI(json.decode(packet.data))
  end
  
  if GUIPropPacket then
    func()
  else
    GUIManager:registerQueue(func)
  end
end

function handler:InitPlayerLevel(packet)
  GUIManager:setPlayerLevelForBedWar(packet.playerLevel)
end

function handler:CheckMoneyTip(packet)
  packet.type = packet.type or 1
  packet.price = packet.price or 0
  PayHelper.checkMoney(packet.type, packet.price, function()
  end)
end

return handler

CommonPacketSender = {}

function CommonPacketSender:sendBuyCustomGoods(goodsId, coinId)
  local data = DataBuilder.new():addParam("goodsId", goodsId):addParam("coinId", coinId):getData()
  PacketSender:sendLuaCommonData("BuyCustomGoods", data)
end

function CommonPacketSender:sendBuyGoodsWithChipAndKey(goodsId)
  local data = DataBuilder.new():addParam("goodsId", goodsId):getData()
  PacketSender:sendLuaCommonData("BuyCustomGoodsWithChipAndKey", data)
end

function CommonPacketSender:sendEquipCustomGoods(goodsId)
  PacketSender:sendLuaCommonData("EquipCustomGoods", tostring(goodsId))
end

function CommonPacketSender:sendUnloadCustomGoods(goodsId)
  PacketSender:sendLuaCommonData("UnloadCustomGoods", tostring(goodsId))
end

function CommonPacketSender:sendBuyBlockGoods(goodsId)
  PacketSender:sendLuaCommonData("BuyBlockGoods", tostring(goodsId))
end

function CommonPacketSender:sendEquipBlockGoods(goodsId)
  PacketSender:sendLuaCommonData("EquipBlockGoods", tostring(goodsId))
end

function CommonPacketSender:sendUnloadBlockGoods(goodsId)
  PacketSender:sendLuaCommonData("UnloadBlockGoods", tostring(goodsId))
end

function CommonPacketSender:sendStartChallengeTask(rewardId)
  PacketSender:sendLuaCommonData("StartChallenge", rewardId)
end

function CommonPacketSender:sendGiveUpChallengeTask(rewardId)
  PacketSender:sendLuaCommonData("GiveUpChallenge", rewardId)
end

function CommonPacketSender:sendFinishTask(taskId)
  PacketSender:sendLuaCommonData("FinishTask", taskId)
end

function CommonPacketSender:openNewChallenge()
  PacketSender:sendLuaCommonData("openNewChallenge")
end

function CommonPacketSender:sendBuyGoods(goodsId)
  PacketSender:sendLuaCommonData("BuyGoods", tostring(goodsId))
end

function CommonPacketSender:sendUseAction(actionId)
  PacketSender:sendLuaCommonData("UseAction", tostring(actionId))
end

function CommonPacketSender:sendBedWarOpenLotteryBox(id, num)
  local data = DataBuilder.new():addParam("chestId", id):addParam("num", num):getData()
  PacketSender:sendLuaCommonData("OpenLotteryBox", data)
end

function CommonPacketSender:sendPlayerOpenLicense()
  PacketSender:sendLuaCommonData("OpenLicense")
end

function CommonPacketSender:sendUseMovieTicket(type, params)
  local data = DataBuilder.new():addParam("params", params):addParam("type", type):getData()
  PacketSender:sendLuaCommonData("UseMovieTicket", data)
end

function CommonPacketSender:sendReportFriendCount(count)
  local data = DataBuilder.new():addParam("count", count):getData()
  PacketSender:sendLuaCommonData("ReportFriendCount", data)
end

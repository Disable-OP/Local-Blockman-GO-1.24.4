local ClientPlayer = class("ClientPlayer", BasePlayer)
PlayerManager:registerClientPlayerClass(ClientPlayer)
PlayerManager:registerOtherPlayerClass(ClientPlayer)

function ClientPlayer:init()
  GameInfoManager:registerObserver(self.userId, function(info)
    self:onPlayerInfoUpdate(info)
  end)
  self.lastShowHP = 0
  self.lastShowName = ""
  self.doubleJumpCount = 1
  self.curJumpCount = 0
  self.cameraSensitive = 0
end

function ClientPlayer:isMe()
  return self.userId == Game:getPlatformUserId()
end

function ClientPlayer:onPlayerSpawn()
  local info = GameInfoManager:getPlayerInfo(self.userId)
  if not info then
    return
  end
  if StoreConfig and self:isMe() then
    StoreConfig:resetGoodsStore()
  end
  self:onPlayerInfoUpdate(info)
end

function ClientPlayer:onPlayerInfoUpdate(info)
  local petId = tonumber(info:getValue("petId"))
  if tonumber(petId) == 0 then
    PetManager:subPet(self, tostring(petId))
    return
  end
  if self.Player then
    PetManager:addPet(self, tostring(petId))
  end
end

function ClientPlayer:onUpdate()
  if not self.Player then
    return
  end
  if self:isMe() then
    if self.Player:isUsingItem() then
      local itemId = self.Player:getHeldItemId()
      local item = Item.getItemById(itemId)
      if item then
        local class = item:getClassName()
        if class == "ItemBow" and self.cameraSensitive == 0 then
          self.cameraSensitive = Blockman.Instance().m_gameSettings:getCameraSensitive()
          Blockman.Instance().m_gameSettings:setCameraSensitive(self.cameraSensitive * GameConfig.bowSensitiveMultiplier)
        end
      end
    elseif self.cameraSensitive ~= 0 then
      Blockman.Instance().m_gameSettings:setCameraSensitive(self.cameraSensitive)
      self.cameraSensitive = 0
    end
  end
  local showName = self.Player:getShowName()
  local curHp = math.floor(self.Player:getHealth() + 0.5)
  if self.lastShowHP == curHp and self.lastShowName == showName then
    return
  end
  self.lastShowHP = curHp
  local nameList = StringUtil.split(showName, "\n")
  if string.find(showName, "\226\153\165") then
    table.remove(nameList)
  end
  local hpText = "\226\150\162FFFFFFFF" .. tostring(curHp) .. "\226\150\162FFFF1F1F  \226\153\165  "
  table.insert(nameList, hpText)
  self.lastShowName = table.concat(nameList, "\n")
  self.Player:setShowName(self.lastShowName)
end

function ClientPlayer:onLogout()
  if isGameStart then
    return
  end
  GameInfoManager:clearInfo("PlayerInfo", self.userId)
end

function ClientPlayer:startFpsRecord()
  if not Root.getFPS then
    LogUtil.log("function (Root.Instance():getFPS()) not exist")
    return
  end
  self.minute_nim_fps = 99999
  self.minute_max_fps = 0
  self.sum_fps = 0
  self.times_fps = 0
  self.total_sum_fps = 0
  self.total_times_fps = 0
  Listener.registerCallBack(CEvents.GameMainTickEvent, function()
    self:updateFps()
  end)
  LuaTimer:scheduleTimer(function()
    self:sendFps()
  end, 60000)
end

function ClientPlayer:updateFps()
  local cur_fps = Root.Instance():getFPS()
  if 1000 < cur_fps then
    return
  end
  self.minute_nim_fps = math.min(self.minute_nim_fps, cur_fps)
  self.minute_max_fps = math.max(self.minute_max_fps, cur_fps)
  self.sum_fps = self.sum_fps + cur_fps
  self.times_fps = self.times_fps + 1
  self.total_sum_fps = self.total_sum_fps + cur_fps
  self.total_times_fps = self.total_times_fps + 1
end

function ClientPlayer:sendFps()
  PlayerManager:getClientPlayer():sendPacket({
    pid = "UpdateRunningFps",
    minute_average_fps = math.floor(self.sum_fps / self.times_fps),
    minute_max_fps = self.minute_max_fps,
    minute_nim_fps = self.minute_nim_fps,
    total_average_fps = math.floor(self.total_sum_fps / self.total_times_fps)
  })
  self.minute_nim_fps = 99999
  self.minute_max_fps = 0
  self.sum_fps = 0
  self.times_fps = 0
end

return ClientPlayer

local storeTable = {}
local dressConfig = {}
DressStoreConfig = {}

local function onLoad()
  if GameType == "g1046" then
    DressStoreConfig.loadStoreTable()
  end
  DressStoreConfig.loadDress()
end

function DressStoreConfig.loadStoreTable()
  local items = FileUtil.getConfigFromCsv("setting/StoreTabSetting.csv", 3)
  for _, item in pairs(items) do
    table.insert(storeTable, {
      Id = tonumber(item.Id),
      Name = tostring(item.Name),
      Icon = tostring(item.Icon),
      Type = tonumber(item.Type)
    })
  end
  table.sort(storeTable, function(a, b)
    if a.Id < b.Id then
      return true
    else
      return false
    end
  end)
end

function DressStoreConfig.loadDress()
  local items = FileUtil.getConfigFromCsv("setting/DressSetting.csv", 3)
  for _, item in pairs(items) do
    local temp
    if item.HasGet == 1 then
      temp = "DRESS_STATUS_HAS_GET"
    else
      temp = "DRESS_STATUS_LOCK"
    end
    local data = {
      Id = tonumber(item.Id),
      ItemId = tonumber(item.ItemId),
      TabType = tonumber(item.TabType),
      Name = tostring(item.Name),
      Image = tostring(item.Image),
      LockImage = tostring(item.LockImage),
      Actor = tostring(item.Actor),
      BodyId = tostring(item.BodyId),
      ModelActorBody = tostring(item.ModelActorBody),
      ModelActorBodyId = tostring(item.ModelActorBodyId),
      Icon = tostring(item.Icon),
      PriceType = tonumber(item.PriceType),
      Price = tonumber(item.Price),
      UnlockLevel = tonumber(item.UnlockLevel),
      LockTip = tostring(item.LockTip),
      SortWeight = tonumber(item.SortWeight),
      HasGet = tonumber(item.HasGet),
      Describe = tostring(item.Describe),
      ChipImg = tostring(item.ChipImg),
      Status = temp
    }
    dressConfig[item.Id] = data
  end
end

function DressStoreConfig:getDressTables()
  return storeTable
end

function DressStoreConfig:getDressConfigByType(type)
  if dressConfig == nil then
    return false
  end
  local result = {}
  for _, item in pairs(dressConfig) do
    if item.TabType == type then
      table.insert(result, item)
    end
  end
  local statue = {}
  for _, dress in pairs(result) do
    statue[dress.Id] = UIDressStore:getStatuesById(dress.Id)
  end
  table.sort(result, function(a, b)
    if statue[a.Id] ~= statue[b.Id] then
      if statue[a.Id] == 2 and statue[b.Id] == 1 then
        return a.SortWeight > b.SortWeight
      end
      if statue[a.Id] == 1 and statue[b.Id] == 2 then
        return a.SortWeight > b.SortWeight
      end
      return statue[a.Id] > statue[b.Id]
    end
    return a.SortWeight > b.SortWeight
  end)
  return result
end

function DressStoreConfig:findStoreDressById(id)
  for _, item in pairs(dressConfig) do
    if item.Id == id then
      return item
    end
  end
  return false
end

function DressStoreConfig:findStoreDressByItemId(itemId)
  for _, item in pairs(dressConfig) do
    if item.Id == itemId then
      return item
    end
  end
  return false
end

function DressStoreConfig:findStoreDressByTabType(type)
  local result = {}
  for _, item in pairs(dressConfig) do
    if item.TabType == type then
      table.insert(result, item)
    end
  end
  return result
end

function DressStoreConfig:parseUpdateStoreDressData()
end

function DressStoreConfig:getNewCount()
  local count = 0
  for _, item in pairs(dressConfig) do
    if item.type == "DRESS_STATUS_NEW" then
      count = count + 1
    end
  end
  return count
end

onLoad()
return DressStoreConfig

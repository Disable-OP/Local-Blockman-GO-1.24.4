local Rewards = MemoryPool.newTable()

local function loadConfig()
  ConfigLoader.setPreprocessorPath("common/config_preprocessor/")
  Rewards = ConfigLoader.getConfig("setting/RewardSetting.csv")
end

loadConfig()
RewardConfig = {}

function RewardConfig.findRewardById(rewardId)
  return Rewards[tostring(rewardId)]
end

function RewardConfig.findRewardByIds(rewardIds)
  local rewards = {}
  local ids = StringUtil.split(rewardIds, "#")
  for _, id in pairs(ids) do
    table.insert(rewards, RewardConfig.findRewardById(id))
  end
  return rewards
end

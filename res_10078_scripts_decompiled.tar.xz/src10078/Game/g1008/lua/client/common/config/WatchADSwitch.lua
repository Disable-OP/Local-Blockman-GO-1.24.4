WatchADSwitch = {}
local WatchADSwitchConfig = {}

function WatchADSwitch:init()
  local items = FileUtil.getConfigFromCsv("setting/WatchADSwitch.csv", 2)
  for _, item in pairs(items) do
    table.insert(WatchADSwitchConfig, {
      Index = tonumber(item.index),
      Type = tonumber(item.type),
      Switch = tonumber(item.switch)
    })
  end
end

function WatchADSwitch:getSwitchBoolByType(type)
  for _, item in pairs(WatchADSwitchConfig) do
    if type == item.Type then
      return item.Switch == 1
    end
  end
  return false
end

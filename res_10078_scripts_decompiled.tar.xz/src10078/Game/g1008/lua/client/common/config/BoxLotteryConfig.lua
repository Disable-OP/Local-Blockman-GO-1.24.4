local LotteryBox = {}
local LotteryBoxReward = {}
GUIBoxLotteryConfig = {}

function GUIBoxLotteryConfig.loadBoxConfig()
  local items = FileUtil.getConfigFromCsv("setting/BoxSetting.csv", 3)
  for _, item in pairs(items) do
    table.insert(LotteryBox, {
      Id = tonumber(item.Id),
      Type = tonumber(item.Type),
      Name = tostring(item.Name),
      Actor = tostring(item.Actor),
      ActorBody = tostring(item.ActorBody),
      ActorBodyId = tostring(item.ActorBodyId),
      Image = tostring(item.Image),
      MatImage = tostring(item.MatImage),
      NeedKey = tonumber(item.NeedKey),
      AddIntegral = tonumber(item.AddIntegral),
      NeedIntegral = tonumber(item.NeedIntegral)
    })
  end
end

function GUIBoxLotteryConfig.loadRewardConfig()
  ConfigLoader.setPreprocessorPath("common/config_preprocessor/")
  LotteryBoxReward = ConfigLoader.getConfig("setting/BoxRewardSetting.csv")
end

function GUIBoxLotteryConfig:getLotteryBoxs()
  return LotteryBox
end

function GUIBoxLotteryConfig:cleanConfig()
  LotteryBox = {}
  LotteryBoxReward = {}
end

function GUIBoxLotteryConfig:findLotteryBoxById(id)
  for _, box in pairs(LotteryBox) do
    if box.Id == id then
      return box
    end
  end
  return false
end

function GUIBoxLotteryConfig:findLotteryBoxByType(type)
  if LotteryBox == nil then
    return
  end
  for _, Box in pairs(LotteryBox) do
    if Box.Type == type then
      return Box
    end
  end
end

function GUIBoxLotteryConfig:findLotteryBoxRewardByType(type)
  if LotteryBoxReward == nil then
    return
  end
  local result = {}
  for _, Box in pairs(LotteryBoxReward) do
    if Box.Type == type and Box.Weight ~= 0 then
      table.insert(result, Box)
    end
  end
  return result
end

function GUIBoxLotteryConfig:findLotteryBoxRewardById(id)
  for _, box in pairs(LotteryBoxReward) do
    if box.Id == id then
      return box
    end
  end
  return false
end

return GUIBoxLotteryConfig

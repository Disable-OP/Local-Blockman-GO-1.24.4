local Settings = {}

local function loadConfig()
  local settings = FileUtil.getConfigFromCsv("setting/SwordLightEffect.csv")
  for _, item in pairs(settings) do
    local data = {
      Effect = item.Effect,
      Offset = VectorUtil.str2Vector3(item.OffsetParams, "#"),
      Scale = VectorUtil.str2Vector3(item.ScaleParams, "#")
    }
    Settings[item.Action] = data
  end
end

loadConfig()
SwordLightEffectConfig = {}

function SwordLightEffectConfig.getConfigByAction(action)
  return Settings[action]
end

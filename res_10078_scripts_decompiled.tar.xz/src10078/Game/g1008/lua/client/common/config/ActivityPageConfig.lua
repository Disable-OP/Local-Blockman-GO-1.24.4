local ConfigList = {}

local function init()
  local settings = FileUtil.getConfigFromCsv("common/ActivityPageConfig.csv", 3, true)
  for _, item in pairs(settings) do
    local data = {}
    data.startTime, data.endTime = 0, -1
    if item.startDate ~= "#" then
      local _, _, year, month, day, hour, min, sec = string.find(item.startDate, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
      data.startTime = DateUtil.date2BeiJingTime({
        year = year,
        month = month,
        day = day,
        hour = hour,
        min = min,
        sec = sec
      })
    end
    if item.endDate ~= "#" then
      local _, _, year, month, day, hour, min, sec = string.find(item.endDate, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
      data.endTime = DateUtil.date2BeiJingTime({
        year = year,
        month = month,
        day = day,
        hour = hour,
        min = min,
        sec = sec
      })
    end
    data.id = tonumber(item.id)
    data.sort = tonumber(item.sort)
    data.uiJson = item.uiJson .. ".json"
    data.imageset = item.imageset
    table.insert(ConfigList, data)
  end
  table.sort(ConfigList, function(a, b)
    return a.sort < b.sort
  end)
end

init()
return ConfigList

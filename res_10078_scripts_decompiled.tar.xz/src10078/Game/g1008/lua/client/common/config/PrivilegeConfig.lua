require("common.privilege.GoodsStorePrivilege")
local PrivilegeCard = {}

local function init()
  local mappings = {GoodsStorePrivilege = GoodsStorePrivilege}
  local config = FileUtil.getConfigFromYml("setting/PrivilegeSetting", true)
  for _, item in pairs(config.Privileges or {}) do
    local class = mappings[item.Name]
    if class then
      class:init(item)
    end
  end
  LuaTimer:schedule(function()
    for _, privilege in pairs(PrivilegeCard) do
      privilege.Time = privilege.Time - 60
    end
    GUIStore:updateListUI()
  end, 60000, 60000)
end

init()
Privilege = {}

function Privilege.checkHavePrivilege(privilegeId)
  if #PrivilegeCard == 0 then
    return false
  end
  for _, privilege in pairs(PrivilegeCard) do
    if privilege.Id == privilegeId and 0 < privilege.Time then
      return true
    end
  end
  return false
end

function Privilege.updatePrivilegeData(data)
  PrivilegeCard = data
end

function Privilege.getPrivilegeTime(privilegeId)
  for _, privilege in pairs(PrivilegeCard) do
    if privilege.Id == privilegeId then
      return privilege.Time
    end
  end
  return 0
end

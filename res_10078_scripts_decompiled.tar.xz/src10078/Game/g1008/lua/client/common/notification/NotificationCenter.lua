local NotificationCenter = T(Global, "NotificationCenter")

function NotificationCenter:init()
  Events.OnNotificationHandlerEvent:registerCallBack(function(notification)
    if not notification.operation then
      return
    end
    local func = NotificationCenter[notification.operation]
    if not func then
      return
    end
    func(NotificationCenter, notification)
  end)
end

function NotificationCenter:AcceptResponse(notification)
  local userId = tonumber(notification.message)
  if not userId then
    return
  end
  Events.FriendOperationClientEvent:invoke(Define.FriendOperationType.Agree, userId)
  local user = UserManager.Instance():findUser(userId)
  if not user then
    return
  end
  user.isSend = false
  user.isFriend = true
  user.isFriendRequest = false
  UserManager.Instance():updateUserList(3)
end

function NotificationCenter:Refuse(notification)
  local userId = tonumber(notification.message)
  if not userId then
    return
  end
  Events.FriendOperationClientEvent:invoke(Define.FriendOperationType.Refuse, userId)
  local user = UserManager.Instance():findUser(userId)
  if not user then
    return
  end
  user.isSend = false
  user.isFriend = false
  user.isFriendRequest = false
  UserManager.Instance():updateUserList(3)
end

function NotificationCenter:Delete(notification)
  local userId = tonumber(notification.message)
  if not userId then
    return
  end
  Events.FriendOperationClientEvent:invoke(Define.FriendOperationType.Delete, userId)
  local user = UserManager.Instance():findUser(userId)
  if not user then
    return
  end
  user.isSend = false
  user.isFriend = false
  user.isFriendRequest = false
  UserManager.Instance():updateUserList(3)
end

function NotificationCenter:Request(notification)
  local info = json.decode(notification.message)
  if not info or not info.userId then
    return
  end
  Events.FriendOperationClientEvent:invoke(Define.FriendOperationType.Request, info.userId)
  local user = UserManager.Instance():findUser(info.userId)
  if not user then
    return
  end
  user.isSend = false
  user.isFriendRequest = true
  UserManager.Instance():updateUserList(3)
end

NotificationCenter:init()

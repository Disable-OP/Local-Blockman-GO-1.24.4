ClientNewReportUtil = {}
local changeModelTimes = 0

function ClientNewReportUtil:onPlayerChangePersonView(type)
  PlayerManager:getClientPlayer():sendPacket({
    pid = "GameAnalytics",
    event = "ChangePersonView",
    pushData = json.encode({type = type})
  })
end

function ClientNewReportUtil:onPlayerJump(type)
  PlayerManager:getClientPlayer():sendPacket({
    pid = "GameAnalytics",
    event = "onPlayerJump",
    pushData = json.encode({type = type})
  })
end

function ClientNewReportUtil:onReportCurrentControlModel(model)
  PlayerManager:getClientPlayer():sendPacket({
    pid = "GameAnalytics",
    event = "CurrentControlModel",
    pushData = json.encode({model = model})
  })
end

function ClientNewReportUtil:onPlayerChangeControlModel(oldModel, newModel)
  if changeModelTimes == 0 then
    changeModelTimes = changeModelTimes + 1
    return
  end
  PlayerManager:getClientPlayer():sendPacket({
    pid = "GameAnalytics",
    event = "ChangeControlModel",
    pushData = json.encode({oldModel = oldModel, newModel = newModel})
  })
end

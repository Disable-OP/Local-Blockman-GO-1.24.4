local function newDesign(event, event_map)
  if isTest then
    local Message = ""
    
    Message = Message .. " event : " .. tostring(event)
    for key, value in pairs(event_map) do
      Message = Message .. "  ||  key: " .. key .. "   value : " .. tostring(value)
    end
    UIHelper.showToast(Message, 5000)
  end
  GameAnalytics:newDesign(event, event_map)
end

local ReportEvent = {}

function ReportEvent.click_activity_page_button(buttonId)
  newDesign("click_activity_page_button", {buttonId = buttonId})
end

function ReportEvent.click_main_button(buttonId)
  newDesign("click_main_button", {buttonId = buttonId})
end

function ReportEvent.click_Mode_button(buttonId)
  newDesign("click_Mode_button", {buttonId = buttonId})
end

function ReportEvent.click_chat_button(buttonId)
  newDesign("click_chat_button", {buttonId = buttonId})
end

function ReportEvent.send_chat_text(type)
  newDesign("send_chat_text", {type = type})
end

function ReportEvent.send_chat_emoji(type)
  newDesign("send_chat_emoji", {type = type})
end

ClientReportEvent = ReportEvent

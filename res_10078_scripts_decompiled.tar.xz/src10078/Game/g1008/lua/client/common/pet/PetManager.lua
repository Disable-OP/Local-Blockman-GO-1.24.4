PetManager = {}
local pets = {}

function PetManager:init()
  Listener.registerCallBack(CEvents.GameMainTickEvent, function()
    self:onTick()
  end)
end

function PetManager:addPet(player, petId)
  local pet = pets[tostring(player.userId)]
  if pet then
    if pet.petId == petId then
      return
    end
    PetManager:subPet(player)
  end
  pet = GamePet.new(player, petId)
  if pet.entityId then
    pets[tostring(player.userId)] = pet
  end
end

function PetManager:subPet(player)
  local pet = pets[tostring(player.userId)]
  if pet then
    pet:destroy()
  end
  pets[tostring(player.userId)] = nil
end

function PetManager:onTick()
  for _, pet in pairs(pets) do
    pet:onUpdate()
  end
end

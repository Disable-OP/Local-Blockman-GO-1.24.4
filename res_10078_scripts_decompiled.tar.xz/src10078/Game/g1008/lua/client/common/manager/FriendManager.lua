local FriendManager = T(Global, "FriendManager")
local UIUtils = T(Global, "UIUtils")
local FriendService = T(Global, "FriendService")
local WebPageUtil = T(Global, "WebPageUtil")
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
local self = FriendManager
local CdTime = {
  [Define.FriendOperationType.Request] = 30,
  [Define.FriendOperationType.Agree] = 5,
  [Define.FriendOperationType.Screen] = 10
}
local OpTime = {
  [Define.FriendOperationType.Request] = {},
  [Define.FriendOperationType.Agree] = {},
  [Define.FriendOperationType.Screen] = {}
}

function FriendManager.Init()
  self.recommend = {}
  self.friendsMap = {}
  self.totalFriendCount = 0
  Listener.registerCallBack(Events.FriendOperationClientEvent, function(opType, userId)
    if opType == Define.FriendOperationType.Agree then
      self.friendsMap[userId] = true
      self.totalFriendCount = self.totalFriendCount + 1
      CommonPacketSender:sendReportFriendCount(self.totalFriendCount)
      local friends = FriendManager.GetFriends()
      table.insert(friends, 1, userId)
      UserInfoCache:GetCacheByUserIds({userId}, function()
        UserInfoCache:GetCache(userId).friend = true
        Events.FinishLoadFriendDataEvent:invoke()
      end)
      local requests = FriendManager.GetUndoFriendRequest()
      local request = TableUtil.findElementByFun(requests, function(request)
        return request.userId == userId
      end)
      if request then
        request.requestStatus = 1
      end
      Events.FinishParseRequestsDataEvent:invoke()
    elseif opType == Define.FriendOperationType.Refuse then
      local requests = FriendManager.GetUndoFriendRequest()
      local request = TableUtil.findElementByFun(requests, function(request)
        return request.userId == userId
      end)
      if request then
        request.requestStatus = 2
      end
      Events.FinishParseRequestsDataEvent:invoke()
    elseif opType == Define.FriendOperationType.Delete then
      self.friendsMap[userId] = nil
      self.totalFriendCount = self.totalFriendCount - 1
      local friends = FriendManager.GetFriends()
      TableUtil.tableRemove(friends, userId)
      local info = UserInfoCache:GetCache(userId)
      if info then
        info.friend = false
      end
      Events.FinishLoadFriendDataEvent:invoke()
      CommonPacketSender:sendReportFriendCount(self.totalFriendCount)
    elseif opType == Define.FriendOperationType.Request then
      UserInfoCache:GetCacheByUserIds({userId}, function()
        local cache = UserInfoCache:GetCache(userId)
        cache.requestStatus = 0
        local requests = FriendManager.GetAllFriendRequest()
        local request = TableUtil.findElementByFun(requests, function(request)
          return request.userId == userId
        end)
        if request then
          TableUtil.tableRemove(requests, request)
        end
        table.insert(requests, 1, cache)
        self.UpdateRequestCount()
        Events.FinishParseRequestsDataEvent:invoke()
      end)
    end
  end)
  WebPageUtil:createWebPage("Friend", function(pageNo, pageSize, callback)
    local url = "/friend/api/v2/friends"
    local params = {
      {"pageNo", pageNo},
      {"pageSize", pageSize}
    }
    WebService.asyncGet(url, params, function(data, code)
      if code ~= 1 then
        return
      end
      local friends = self.GetFriends()
      local items = data.data or {}
      local userIds = UserInfoCache:UpdateUserInfos(items)
      PlayerCustomInfoUtil:GetPlayersCustomDataValue(userIds, {
        Define.PlayerCustomInfo.CurHeadFrame
      })
      for _, userId in pairs(userIds) do
        self.friendsMap[userId] = true
        TableUtil.tableRemove(friends, userId)
      end
      callback(userIds)
      self.totalFriendCount = data.totalSize
      CommonPacketSender:sendReportFriendCount(self.totalFriendCount)
    end)
  end, 20, Events.FinishLoadFriendDataEvent)
  WebPageUtil:createWebPage("FriendRequest", function(pageNo, pageSize, callback)
    local url = "/bedwar/api/v1/friends/apply/list/get"
    local params = {
      {"pageNo", pageNo},
      {"pageSize", pageSize}
    }
    WebService.asyncGet(url, params, function(data, code)
      if not data then
        return
      end
      local items = data.data or {}
      for _, item in pairs(items) do
        local requestStatus = item.status
        local onlineStatus = item.onlineStatus
        item.requestStatus = requestStatus
        item.status = onlineStatus
      end
      callback(items)
      self.UpdateRequestCount()
      local userIds = UserInfoCache:UpdateUserInfos(items)
      PlayerCustomInfoUtil:GetPlayersCustomDataValue(userIds, {
        Define.PlayerCustomInfo.CurHeadFrame
      })
      Events.FinishParseRequestsDataEvent:invoke()
    end)
  end, 20)
end

function FriendManager.GetTotalFriendCount()
  return self.totalFriendCount
end

function FriendManager.GetFriends()
  return WebPageUtil:getWebPageItems("Friend")
end

function FriendManager.GetAllFriendRequest()
  return WebPageUtil:getWebPageItems("FriendRequest")
end

function FriendManager.GetUndoFriendRequest()
  local requests = {}
  local items = WebPageUtil:getWebPageItems("FriendRequest")
  for _, item in pairs(items) do
    if item.requestStatus == 0 then
      table.insert(requests, item)
    end
  end
  return requests
end

function FriendManager.IsFriend(userId)
  if self.friendsMap[userId] then
    return true
  end
  local userInfo = UserInfoCache:GetCache(userId)
  if userInfo and userInfo.friend == true then
    return true
  end
  return false
end

function FriendManager.UpdateRequestCount()
  local requests = FriendManager.GetUndoFriendRequest()
  UIUtils.updateRedDotCount(Define.RedDotKey.FriendApply, #requests)
end

function FriendManager.ParseFriendRecommend(data)
  if not data or not next(data) then
    UIHelper.showToast(Lang:getString("gui.no.recommend.data"))
  end
  UserInfoCache:UpdateUserInfos(data)
  self.recommend = data
  Events.FinishParseRecommendDataEvent:invoke()
  FriendManager.UpdateCdTime(Game:getPlatformUserId(), Define.FriendOperationType.Screen)
end

function FriendManager.LoadFriendData()
  WebPageUtil:loadMorePageItem("Friend", true)
end

local function isOutOfCdTime(opType, id)
  local osTime = os.time()
  local opTime = OpTime[opType][tostring(id)] or osTime
  return osTime >= opTime
end

function FriendManager.CanAddFriend(id)
  return isOutOfCdTime(Define.FriendOperationType.Request, id)
end

function FriendManager.UpdateCdTime(id, opType)
  if not (OpTime[opType] and CdTime[opType]) or CdTime[opType] == 0 then
    return
  end
  OpTime[opType][tostring(id)] = os.time() + CdTime[opType]
end

function FriendManager.GetLastCdTime(id, opType)
  local opTime = OpTime[opType][tostring(id)] or os.time()
  return opTime - os.time()
end

function FriendManager.FriendOperation(operation, userId, msg)
  if CdTime[operation] and not isOutOfCdTime(operation, userId) then
    return
  end
  local cfg = {
    [Define.FriendOperationType.Agree] = {
      url = "/friend/api/v1/friends/%s/agreement",
      method = "asyncPut"
    },
    [Define.FriendOperationType.Refuse] = {
      url = "/friend/api/v1/friends/%s/rejection",
      method = "asyncPut"
    },
    [Define.FriendOperationType.Delete] = {
      url = "/friend/api/v1/friends",
      method = "asyncDelete"
    },
    [Define.FriendOperationType.Request] = {
      url = "/friend/api/v1/friends",
      method = "asyncPost"
    }
  }
  local params, body
  if operation == Define.FriendOperationType.Delete then
    params = {
      {
        "friendId",
        tostring(userId)
      }
    }
  elseif operation == Define.FriendOperationType.Request then
    body = {
      friendId = tostring(userId),
      msg = msg or ""
    }
  else
    params = {
      {
        "friendId",
        tostring(userId)
      }
    }
  end
  local url = string.format(cfg[operation].url, userId)
  local method = WebService[cfg[operation].method]
  if method then
    method(url, params, body, function(data, code)
      if code ~= 1 then
        return
      end
      if CdTime[operation] and not isOutOfCdTime(operation, userId) then
        return
      end
      self.UpdateCdTime(userId, operation)
      FriendService:sendFriendOperation(userId, operation)
      if operation ~= Define.FriendOperationType.Request then
        Events.FriendOperationClientEvent:invoke(operation, userId)
      end
      local user = UserManager.Instance():findUser(userId)
      if not user then
        return
      end
      if operation == Define.FriendOperationType.Agree then
        user.isFriend = true
        user.isFriendRequest = false
      elseif operation == Define.FriendOperationType.Refuse then
        user.isSend = false
        user.isFriend = false
        user.isFriendRequest = false
      elseif operation == Define.FriendOperationType.Delete then
        user.isSend = false
        user.isFriend = false
        user.isFriendRequest = false
      elseif operation == Define.FriendOperationType.Request then
        user.isSend = true
      end
      UserManager.Instance():updateUserList(3)
    end)
  end
end

function FriendManager.LoadMoreFriend()
  WebPageUtil:loadMorePageItem("Friend")
end

function FriendManager.LoadMoreFriendRequest()
  WebPageUtil:loadMorePageItem("FriendRequest")
end

function FriendManager.LoadFriendRecommend()
  local url = "/bedwar/api/v1/friends/recommend/get"
  local params = {
    {
      "userId",
      tostring(Game:getPlatformUserId())
    }
  }
  WebService.asyncGet(url, params, function(data, code)
    if code ~= 1 then
      print("FriendManager.LoadFriendRecommend response error", json.encode(params), json.encode(data))
      return
    end
    FriendManager.ParseFriendRecommend(data)
  end)
end

function FriendManager.LoadFriendRecommendWithScreen(data)
  if not data.type then
    return
  end
  local url = "/bedwar/api/v1/friends/search/get"
  local params = {
    {
      "type",
      data.type
    },
    {
      "userId",
      tostring(Game:getPlatformUserId())
    }
  }
  if data.language then
    table.insert(params, {
      "language",
      data.language
    })
  end
  if data.searchText then
    table.insert(params, {
      "searchText",
      data.searchText
    })
  end
  if data.sex then
    table.insert(params, {
      "sex",
      data.sex
    })
  end
  if data.rank then
    table.insert(params, {
      "rank",
      data.rank
    })
  end
  WebService.asyncGet(url, params, function(response, code)
    if code ~= 1 then
      print("FriendManager.LoadFriendRecommendWithScreen response error", json.encode(params), json.encode(response))
      return
    end
    FriendManager.ParseFriendRecommend(response)
  end)
end

function FriendManager.CanScreen(id)
  return isOutOfCdTime(Define.FriendOperationType.Screen, id)
end

FriendManager.Init()
return FriendManager

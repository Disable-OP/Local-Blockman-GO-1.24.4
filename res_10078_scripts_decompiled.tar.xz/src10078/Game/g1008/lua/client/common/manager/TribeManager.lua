local TribeManager = T(Global, "TribeManager")
local Members = {}

local function LoadTribeInfo()
end

local function LoadTribeMembers()
  local GetTribeMemberApi = "/clan/api/v1/clan/tribe/member"
  WebService.asyncGet(GetTribeMemberApi, {}, function(data, code)
    if data then
      Members = UserInfoCache:UpdateUserInfos(data)
      Events.FinishLoadTribeMemberEvent:invoke()
    end
  end)
end

function TribeManager.Init()
  Members = {}
  LoadTribeInfo()
  LoadTribeMembers()
end

function TribeManager.LoadTribeMembers()
  LoadTribeMembers()
end

function TribeManager.GetMembers()
  return Members
end

TribeManager.Init()

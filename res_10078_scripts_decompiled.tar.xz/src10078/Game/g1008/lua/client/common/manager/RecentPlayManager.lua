local RecentPlayManager = T(Global, "RecentPlayManager")
local Players = {}

function RecentPlayManager.Init()
  CommonDataEvents:registerCallBack("RecentPlayRecord", function(data)
    local userIds = StringUtil.split(data, ",", false, true)
    Players = userIds
    RecentPlayManager.RefreshPlayersData()
  end)
end

function RecentPlayManager.RefreshPlayersData()
  if #Players == 0 then
    Events.FinishLoadRecentPlayEvent:invoke()
    return
  end
  WebService:GetUserInfos(Players, function(userInfos)
    UserInfoCache:UpdateUserInfos(userInfos)
    Events.FinishLoadRecentPlayEvent:invoke()
  end)
end

function RecentPlayManager.GetPlayers()
  return Players
end

RecentPlayManager.Init()

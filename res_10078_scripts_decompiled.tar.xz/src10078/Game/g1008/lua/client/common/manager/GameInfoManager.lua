GameInfoManager = class("GameInfoManager", BaseInfoManager)
local instance
local ObserverList = {}

function GameInfoManager.Instance()
  if not instance then
    instance = GameInfoManager.new()
  end
  return instance
end

local function setPlayerAttr(userId, times)
  times = times or 60
  if times <= 0 then
    return
  end
  local info = BaseInfoManager:getPlayerInfo(userId)
  if not info then
    return
  end
  local user = UserManager.Instance():findUser(tonumber(userId))
  if user then
    info:setValue("picUrl", user.picUrl)
    local playerName = tostring(user.userName)
    playerName = playerName:gsub(TextFormat.colorStart, "")
    playerName = playerName:gsub("\n", " ")
    info:setValue("userName", playerName)
  else
    LuaTimer:schedule(function()
      setPlayerAttr(userId, times - 1)
    end, 1000)
  end
end

function GameInfoManager:register()
  local observable = EventObservable.new()
  observable:registerDataCallBack("InfoNew", function(dataStr)
    local table = StringUtil.split(dataStr, "'")
    local className = table[1]
    local infoKey = table[2]
    local infoIndex = table[3]
    if infoIndex and infoKey and infoIndex then
      self:newInfo(className, infoKey, infoIndex)
      if className ~= "PlayerInfo" then
        return
      end
      setPlayerAttr(infoKey)
    end
  end)
  observable:registerDataCallBack("InfoUpdate", function(dataStr)
    local infoChangeList = StringUtil.split(dataStr, "!")
    for _, changeInfoStr in pairs(infoChangeList) do
      local data = StringUtil.split(changeInfoStr, ":")
      local infoIndex = data[1]
      table.remove(data, 1)
      for _, infoStr in pairs(data) do
        local table = StringUtil.split(infoStr, "'")
        local keyIndex = table[1]
        local value = table[2]
        if infoIndex and keyIndex and value then
          local info = self:getInfoByIndex(infoIndex)
          if info then
            info:setValueByIndex(keyIndex, value)
          end
        end
      end
    end
  end)
end

function GameInfoManager:onTick()
  local infoMap = self:getAllInfo()
  for _, info in pairs(infoMap) do
    if info.isChange then
      info.isChange = false
      if ObserverList[info.infoKey] then
        for _, callBack in pairs(ObserverList[info.infoKey]) do
          callBack(info)
        end
      end
    end
  end
end

function GameInfoManager:registerObserver(infoKey, callBack)
  self = self or instance
  ObserverList[tostring(infoKey)] = ObserverList[tostring(infoKey)] or {}
  table.insert(ObserverList[tostring(infoKey)], callBack)
end

function GameInfoManager:unregisterObserver(infoKey)
  self = self or instance
  ObserverList[tostring(infoKey)] = nil
end

function GameInfoManager:clearInfo(className, infoKey)
  self.super:clearInfo(className, infoKey)
  self:unregisterObserver(infoKey)
end

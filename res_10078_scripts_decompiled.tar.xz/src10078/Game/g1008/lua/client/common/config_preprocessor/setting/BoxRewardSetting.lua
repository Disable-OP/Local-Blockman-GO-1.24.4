local items = util.readCsv(path, 3)
local LotteryBoxReward = {}
for _, item in pairs(items) do
  table.insert(LotteryBoxReward, {
    Id = tonumber(item.Id),
    Type = tonumber(item.Type),
    RewardId = tonumber(item.RewardId),
    Weight = tonumber(item.Weight),
    IsCore = tonumber(item.IsCore)
  })
end
return LotteryBoxReward

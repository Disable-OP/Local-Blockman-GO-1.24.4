local PEChatMsgDB = class("PEChatMsgDB", require("common.chat.db.IChatMsgDB"))
local uuid = require("engine_base.util.uuid")

function PEChatMsgDB:ctor()
  self.super.ctor(self)
  self.loading = {}
end

function PEChatMsgDB:onLoadChatMsgListFinished(chatId, msgList)
  local chatMsgList = self.chatMsgListMap[chatId]
  TableUtil.mergeArray(msgList, chatMsgList)
  self.chatMsgListMap[chatId] = msgList
  local isFinished = false
  local requests = self.loading[chatId]
  if requests then
    for _, request in pairs(requests) do
      if #msgList < request.size then
        isFinished = true
      end
      self.super.getChatMsgList(self, chatId, request.types, request.callback, request.msgId, request.size)
    end
  end
  if isFinished then
    self.loadDBFinishedTag[chatId] = true
  end
  self.loading[chatId] = nil
end

function PEChatMsgDB:getChatMsgList(chatId, types, callback, msgId, size)
  self.super.loadDBMsgData(self, chatId)
  if self:isLoadDBFinished(chatId) then
    self.super.getChatMsgList(self, chatId, types, callback, msgId, size)
    return
  end
  if tonumber(chatId) == nil then
    self.super.getChatMsgList(self, chatId, types, callback, msgId, size)
    self.loadDBFinishedTag[chatId] = true
    return
  end
  if self.loading[chatId] then
    table.insert(self.loading[chatId], {
      types = types,
      callback = callback,
      msgId = msgId,
      size = size
    })
    return
  end
  self.loading[chatId] = {
    {
      types = types,
      callback = callback,
      msgId = msgId,
      size = size
    }
  }
  if msgId ~= nil then
    CGame.Instance():getShellInterface():getTalkDetail(tostring(chatId), tonumber(msgId) or -1, size or 20)
  else
    local chatMsgList = self.chatMsgListMap[chatId]
    if chatMsgList and 0 < #chatMsgList then
      msgId = chatMsgList[1].msgId
    end
    CGame.Instance():getShellInterface():getTalkDetail(tostring(chatId), tonumber(msgId) or -1, size or 20)
  end
end

function PEChatMsgDB:addChatMsgData(chatId, data, save)
  data.time = data.time or os.time()
  if not data.msgId then
    uuid.seed()
    data.msgId = uuid()
  end
  self.super.addChatMsgData(self, chatId, data)
end

function PEChatMsgDB:clearMsgCache(chatId)
  self.super.clearMsgCache(self, chatId)
  CGame.Instance():getShellInterface():clearTalkDetail(tostring(chatId))
end

return PEChatMsgDB

local PCChatMsgDB = class("PCChatMsgDB", require("common.chat.db.IChatMsgDB"))
local uuid = require("engine_base.util.uuid")

local function getChatDBFileName(chatId)
  return string.format("chat/%s_%s.cache", Game:getPlatformUserId(), chatId)
end

function PCChatMsgDB:ctor()
  self.super.ctor(self)
  os.execute("mkdir chat")
end

function PCChatMsgDB:loadDBMsgData(chatId)
  self.super.loadDBMsgData(self, chatId)
  local file = io.open(getChatDBFileName(chatId), "r")
  if not file then
    return
  end
  local lines = StringUtil.split(file:read("*a"), "\n")
  file:close()
  local chatMsgList = self.chatMsgListMap[chatId]
  local cacheCount = #chatMsgList
  local dbEnd = #lines - cacheCount
  if dbEnd <= 0 then
    return
  end
  local dbStart = math.max(#lines - 99 - cacheCount, 1)
  local pos = 1
  for i = dbStart, dbEnd do
    local line = lines[i]
    local data = json.decode(line)
    table.insert(chatMsgList, pos, data)
    pos = pos + 1
  end
end

function PCChatMsgDB:addChatMsgData(chatId, data, save)
  data.time = os.time()
  uuid.seed()
  data.msgId = uuid()
  self.super.addChatMsgData(self, chatId, data)
  if save then
    local file = io.open(getChatDBFileName(chatId), "a+")
    file:write(json.encode(data) .. "\n")
    file:close()
  end
end

function PCChatMsgDB:getChatMsgList(chatId, types, callback, msgId, size)
  if not self:isLoadDBFinished(chatId) then
    self.loadDBFinishedTag[chatId] = true
    self:loadDBMsgData(chatId)
  end
  self.super.getChatMsgList(self, chatId, types, callback, msgId, size)
end

function PCChatMsgDB:clearMsgCache(chatId)
  self.super.clearMsgCache(self, chatId)
  local file = io.open(getChatDBFileName(chatId), "r")
  if not file then
    return
  end
  file:close()
  file = io.open(getChatDBFileName(chatId), "w")
  file:write("")
  file:close()
end

return PCChatMsgDB

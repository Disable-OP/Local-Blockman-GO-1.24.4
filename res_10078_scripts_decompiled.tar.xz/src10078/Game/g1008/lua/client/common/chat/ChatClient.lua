local ChatService = T(Global, "ChatService")
local MessageService = T(Global, "MessageService")
local ChatClient = T(Global, "ChatClient")
local EmojiConfig = T(Global, "EmojiConfig")
local JniHandler = {}
local sendMessage = ShellInterface.sendMessage

function ShellInterface:sendMessage(messageType, msgData)
  msgData.senderUserId = tostring(Game:getPlatformUserId())
  sendMessage(self, messageType, json.encode(msgData))
end

local function processJniMsg(messageType, msg)
  local data = {
    sendId = tonumber(msg.senderUserId),
    targetId = tonumber(msg.receiverUserId),
    msgId = msg.messageId,
    time = msg.receivedTime,
    type = messageType
  }
  if messageType == Define.ChatMsgType.TextMsg then
    data.data = {
      content = msg.content
    }
  elseif messageType == Define.ChatMsgType.ImageMsg then
    data.data = {
      uri = msg.uri
    }
  elseif messageType == Define.ChatMsgType.VoiceMsg then
    data.data = {
      uri = msg.uri
    }
  elseif messageType == Define.ChatMsgType.VideoMsg then
    data.data = {
      uri = msg.uri,
      step = msg.step
    }
  elseif messageType == Define.ChatMsgType.CustomMsg then
    local content = json.safe_decode(msg.content)
    if type(content) ~= "table" then
      data.type = Define.ChatMsgType.None
      return data
    end
    if not TableUtil.tableContain(Define.CustomChatMsgType, content.type) then
      data.type = Define.ChatMsgType.None
      return data
    end
    data.data = {content = content}
  else
    return nil
  end
  return data
end

function JniHandler:onReceiveMessage(sourceType, messageType, content)
  local data = processJniMsg(messageType, json.decode(content))
  if data then
    MessageService:onPrivateMsg(nil, nil, data)
  end
end

function JniHandler:onTalkList(talkList)
end

function JniHandler:onTalkDetail(targetId, detail)
  targetId = tonumber(targetId)
  local chatDB = ChatClient:getChatDB()
  if chatDB.__cname ~= "PEChatMsgDB" then
    return
  end
  local items = json.decode(detail)
  local msgList = {}
  while 0 < #items do
    local item = json.decode(table.remove(items))
    local data = processJniMsg(item.messageType, item)
    if data then
      if not data.targetId then
        data.targetId = data.sendId == Game:getPlatformUserId() and targetId or Game:getPlatformUserId()
      end
      if not data.sendId then
        data.sendId = data.targetId == Game:getPlatformUserId() and targetId or Game:getPlatformUserId()
      end
      ChatService:pretreatmentMsg(data)
      table.insert(msgList, data)
    end
  end
  chatDB:onLoadChatMsgListFinished(targetId, msgList)
end

function onChatHandler(name, ...)
  local func = JniHandler[name]
  if not func then
    return
  end
  func(JniHandler, ...)
end

function ChatClient:init()
  self.chatMsgDB = nil
  if Platform.isWindow() then
    self.chatMsgDB = require("common.chat.db.PCChatMsgDB").new()
  else
    self.chatMsgDB = require("common.chat.db.PEChatMsgDB").new()
  end
  self.chatCd = {}
end

function ChatClient:checkChatCd(type, cd)
  local time = self.chatCd[type] or 0
  if os.time() - time >= (cd or 4) then
    self.chatCd[type] = os.time()
    return true
  end
  UIHelper.showToast(Lang:getString("gui.chat.fast.send"), 4000)
  return false
end

function ChatClient:getChatDB()
  return self.chatMsgDB
end

function ChatClient:addPrivateChatMsgData(data)
  if data.sendId == Game:getPlatformUserId() then
    self.chatMsgDB:addChatMsgData(data.targetId, data, true)
  else
    self.chatMsgDB:addChatMsgData(data.sendId, data, true)
  end
end

function ChatClient:sendTextMsgToTarget(targetId, content)
  if Platform.isWindow() then
    local data = {content = content}
    ChatService:sendMsgToPrivate(targetId, Define.ChatMsgType.TextMsg, data)
  else
    local data = {
      receiverUserId = tostring(targetId),
      content = content,
      conversationType = "private"
    }
    CGame.Instance():getShellInterface():sendMessage(Define.ChatMsgType.TextMsg, data)
  end
end

function ChatClient:sendTextMsgToTeam(content)
  if not self:checkChatCd("team") then
    return false
  end
  local data = {content = content}
  ChatService:sendMsgToTeam(Define.ChatMsgType.TextMsg, data)
  return true
end

function ChatClient:sendTeamInviteToGroup(msg)
  if not self:checkChatCd("group", 10) then
    return
  end
  local TeamService = T(Global, "TeamService")
  if not TeamService:isOwner() then
    return
  end
  local data = TeamService:buildTeamInviteContentData(msg)
  ChatService:sendMsgToGroup(Define.ChatMsgType.TeamInviteMsg, data)
  UIHelper.showToast(Lang:getString("gui.send.success"))
end

function ChatClient:sendTextMsgToGroup(content)
  if not self:checkChatCd("group") then
    return false
  end
  local data = {content = content}
  ChatService:sendMsgToGroup(Define.ChatMsgType.TextMsg, data)
  return true
end

function ChatClient:sendGameEmojiMsgToGroup(icon)
  if not self:checkChatCd("group") then
    return
  end
  local content = {
    type = Define.CustomChatMsgType.EmojiMsg,
    emojiData = icon
  }
  local data = {content = content}
  ChatService:sendMsgToGroup(Define.ChatMsgType.CustomMsg, data)
end

function ChatClient:sendTextMsgToLangGroup(content)
  if not self:checkChatCd("lang") then
    return false
  end
  local data = {content = content}
  ChatService:sendMsgToLangGroup(Define.ChatMsgType.TextMsg, data)
  return true
end

function ChatClient:sendGameEmojiMsgToLangGroup(icon)
  if not self:checkChatCd("lang") then
    return
  end
  local content = {
    type = Define.CustomChatMsgType.EmojiMsg,
    emojiData = icon
  }
  local data = {content = content}
  ChatService:sendMsgToLangGroup(Define.ChatMsgType.CustomMsg, data)
end

function ChatClient:sendGameEmojiMsgToTeam(icon)
  if not self:checkChatCd("team") then
    return
  end
  local content = {
    type = Define.CustomChatMsgType.EmojiMsg,
    emojiData = icon
  }
  local data = {content = content}
  ChatService:sendMsgToTeam(Define.ChatMsgType.CustomMsg, data)
end

function ChatClient:sendGameEmojiMsgToTarget(targetId, icon)
  local content = {
    type = Define.CustomChatMsgType.EmojiMsg,
    emojiData = icon
  }
  if Platform.isWindow() then
    local data = {content = content}
    ChatService:sendMsgToPrivate(targetId, Define.ChatMsgType.CustomMsg, data)
  else
    local data = {
      receiverUserId = tostring(targetId),
      content = json.encode(content),
      conversationType = "private"
    }
    CGame.Instance():getShellInterface():sendMessage(Define.ChatMsgType.CustomMsg, data)
  end
end

function ChatClient:sendTextMsgToSameServer(content)
  if not self:checkChatCd("same_server") then
    return false
  end
  local data = {content = content}
  ChatService:sendMsgToSameServer(Define.ChatMsgType.TextMsg, data)
  return true
end

function ChatClient:getPrivateMsgCache(userId, types, callback, msgId, size)
  self.chatMsgDB:getChatMsgList(userId, types, callback, msgId, size)
end

function ChatClient:getTeamMsgCache(types, callback, msgId, size)
  self.chatMsgDB:getChatMsgList("team", types, callback, msgId, size)
end

function ChatClient:getGameMsgCache(types, callback, msgId, size)
  self.chatMsgDB:getChatMsgList("game", types, callback, msgId, size)
end

function ChatClient:getLangGroupMsgCache(types, callback, msgId, size)
  self.chatMsgDB:getChatMsgList("lang", types, callback, msgId, size)
end

function ChatClient:getWorldMsgCache(types, callback, msgId, size)
  self.chatMsgDB:getChatMsgList("world", types, callback, msgId, size)
end

function ChatClient:clearMsgCache(chatId)
  self.chatMsgDB:clearMsgCache(chatId)
end

function ChatClient:startRecordVoice(targetId)
  CGame.Instance():getShellInterface():startRecordVoice(tostring(targetId))
end

function ChatClient:stopRecordVoice(targetId, isCancel)
  CGame.Instance():getShellInterface():stopRecordVoice(tostring(targetId), isCancel)
end

function ChatClient:playVoice(uri)
  CGame.Instance():getShellInterface():playVoice(uri)
end

function ChatClient:chatMsgToString(chatMsg, textColor)
  local info = UserInfoCache:GetCache(chatMsg.sendId)
  local name
  if info then
    name = info.name
  else
    name = "userId:" .. chatMsg.sendId
  end
  if chatMsg.sendId == Game:getPlatformUserId() then
    name = "\226\150\162FFFF9F2E" .. name
  end
  local format, text = "%s" .. (textColor or "\226\150\162FF8085BC") .. " : %s", ""
  if chatMsg.type == Define.ChatMsgType.TextMsg then
    text = string.format(format, name, chatMsg.data.content)
  elseif chatMsg.type == Define.ChatMsgType.ImageMsg then
    text = string.format(format, name, Lang:getString("gui.chat.short.image"))
  elseif chatMsg.type == Define.ChatMsgType.VoiceMsg then
    text = string.format(format, name, Lang:getString("gui.chat.short.voice"))
  elseif chatMsg.type == Define.ChatMsgType.VideoMsg then
    text = string.format(format, name, Lang:getString("gui.chat.short.team"))
  elseif chatMsg.type == Define.ChatMsgType.CustomMsg then
    if chatMsg.data.content.type == Define.CustomChatMsgType.EmojiMsg then
      local config = EmojiConfig:getCfgByIcon(chatMsg.data.content.emojiData)
      if config then
        text = string.format(format, name, Lang:getString(config.name))
      else
        text = string.format(format, name, Lang:getString("gui.chat.short.emoji"))
      end
    end
  elseif chatMsg.type == Define.ChatMsgType.TeamInviteMsg then
    text = string.format(format, name, Lang:getString("gui.chat.short.team"))
  end
  return text
end

ChatClient:init()

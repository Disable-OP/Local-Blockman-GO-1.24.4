local IChatMsgDB = class("IChatMsgDB")

local function getCutMsgList(chatMsgList, startIndex, endIndex)
  if #chatMsgList == 0 then
    return chatMsgList
  end
  if endIndex < startIndex then
    return {}
  end
  startIndex = math.max(startIndex, 1)
  endIndex = math.min(endIndex, #chatMsgList)
  local result = {}
  for i = startIndex, endIndex do
    table.insert(result, chatMsgList[i])
  end
  return result
end

local function getEndMsgIndexByMsgId(chatMsgList, msgId)
  if msgId == nil then
    return #chatMsgList
  end
  for index, chatMsg in pairs(chatMsgList) do
    if chatMsg.msgId == msgId then
      return index - 1
    end
  end
  return 0
end

function IChatMsgDB:ctor()
  self.chatMsgListMap = {}
  self.loadDBFinishedTag = {}
end

function IChatMsgDB:loadDBMsgData(chatId)
  if self.chatMsgListMap[chatId] then
    return
  end
  self.chatMsgListMap[chatId] = {}
end

function IChatMsgDB:isLoadDBFinished(chatId)
  return self.loadDBFinishedTag[chatId]
end

function IChatMsgDB:addChatMsgData(chatId, data, save)
  local chatMsgList = self.chatMsgListMap[chatId]
  if not chatMsgList then
    chatMsgList = {}
    self.chatMsgListMap[chatId] = chatMsgList
  end
  table.insert(chatMsgList, data)
end

function IChatMsgDB:getChatMsgList(chatId, types, callback, msgId, size)
  size = size or 100
  local chatMsgList = self.chatMsgListMap[chatId]
  if not types then
    local endIndex = getEndMsgIndexByMsgId(chatMsgList, msgId)
    local startIndex = math.max(endIndex - size + 1, 1)
    callback(getCutMsgList(chatMsgList, startIndex, endIndex))
    return
  end
  local result = {}
  for _, item in pairs(chatMsgList) do
    if TableUtil.tableContain(types, item.type) then
      table.insert(result, item)
    end
  end
  local endIndex = getEndMsgIndexByMsgId(result, msgId)
  local startIndex = math.max(endIndex - size + 1, 1)
  callback(getCutMsgList(result, startIndex, endIndex))
end

function IChatMsgDB:clearMsgCache(chatId)
  self.chatMsgListMap[chatId] = {}
end

return IChatMsgDB

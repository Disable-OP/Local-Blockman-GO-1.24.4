local GetCustomValueApi = "/bedwar/api/v1/user/game/date/value/get"
local PageLikePlayerApi = "/bedwar/api/v1/thumbs-up"
local GetPageLikeCountApi = "/bedwar/api/v1/thumbs-up"
local UploadVisitorApi = "/bedwar/api/v1/visitor/upload"
local GetVisitorListApi = "/bedwar/api/v1/visitor/infos"
local FollowOtherPlayerApi = "/bedwar/api/v1/follow/add"
local CancelFollowPlayerApi = "/bedwar/api/v1/follow/del"
local EnquiryFollowRelations = "/bedwar/api/v1/follow/relation/get"
local GetFollowCountApi = "/bedwar/api/v1/follow/number/data/get"
local GetFansListApi = "/bedwar/api/v1/fans/list/get"
local GetFollowsListApi = "/bedwar/api/v1/follow/list/get"
local GetCustomValueListApi = "/bedwar/api/v1/user/game/date/batch/value/get"

function WebService:GetPlayerCustomDataValue(userId, fields, callback)
  local params = {
    {
      "userId",
      tostring(userId)
    },
    {
      "fields",
      table.concat(fields, ",")
    }
  }
  WebService.asyncGet(GetCustomValueApi, params, function(data, code)
    if not data then
      return
    end
    local userInfo = {}
    userInfo.userId = userId
    for _, key_value in pairs(data) do
      userInfo[key_value.key] = key_value.value
    end
    UserInfoCache:UpdateUserInfos({userInfo})
    callback(code, data)
  end)
end

function WebService:GetPlayerPageLikeCount(userId, callback)
  local params = {
    {
      "userId",
      tostring(userId)
    }
  }
  WebService.asyncGet(PageLikePlayerApi, params, function(data, code)
    if not data then
      return
    end
    local userInfo = {}
    userInfo.userId = userId
    userInfo.pageLike = data
    UserInfoCache:UpdateUserInfos({userInfo})
    callback(code, data)
  end)
end

function WebService:GivePlayerPageLike(beneficiaryId, userId, callback)
  if beneficiaryId == userId then
    return
  end
  local params = {
    {
      "beneficiaryId",
      tostring(beneficiaryId)
    },
    {
      "userId",
      tostring(userId)
    }
  }
  WebService.asyncPost(GetPageLikeCountApi, params, "{}", function(data, code)
    callback(code)
  end)
end

function WebService:UploadVisitorInfo(userId, visitorId)
  if userId == visitorId then
    return
  end
  local params = {
    {
      "userId",
      tostring(userId)
    },
    {
      "visitorId",
      tostring(visitorId)
    }
  }
  WebService.asyncPost(UploadVisitorApi, params, "{}", function(data, code)
  end)
end

function WebService:getVisitorListInfo(userId, callback)
  local params = {
    {
      "userId",
      tostring(userId)
    }
  }
  WebService.asyncGet(GetVisitorListApi, params, function(data, code)
    if not data then
      return
    end
    local userInfo = {}
    userInfo.userId = userId
    for key, value in pairs(data) do
      userInfo[key] = value
    end
    UserInfoCache:UpdateUserInfos({userInfo})
    callback(code, data)
  end)
end

function WebService:FollowOtherPlayer(userId, targetId, callback)
  if userId == targetId then
    return
  end
  local params = {
    {
      "targetId",
      tostring(targetId)
    },
    {
      "userId",
      tostring(userId)
    }
  }
  WebService.asyncGet(FollowOtherPlayerApi, params, function(data, code)
    local userInfo1 = {}
    local userInfo2 = {}
    userInfo1.userId = userId
    userInfo1.followNum = data.userFollowNum
    userInfo2.userId = targetId
    userInfo2.fansNum = data.targetFansNum
    userInfo2.followStatus = data.followStatus
    UserInfoCache:UpdateUserInfos({userInfo1, userInfo2})
    callback(code, data)
  end)
end

function WebService:CancelFollowOtherPlayer(userId, targetId, callback)
  if userId == targetId then
    return
  end
  local params = {
    {
      "targetId",
      tostring(targetId)
    },
    {
      "userId",
      tostring(userId)
    }
  }
  WebService.asyncGet(CancelFollowPlayerApi, params, function(data, code)
    local userInfo1 = {}
    local userInfo2 = {}
    userInfo1.userId = userId
    userInfo1.followNum = data.userFollowNum
    userInfo2.userId = targetId
    userInfo2.fansNum = data.targetFansNum
    userInfo2.followStatus = data.followStatus
    UserInfoCache:UpdateUserInfos({userInfo1, userInfo2})
    callback(code, data)
  end)
end

function WebService:EnquiryFollowRelations(userId, targetIds, callback)
  local params = {
    {
      "targetIds",
      table.concat(targetIds, ",")
    },
    {"userId", userId}
  }
  WebService.asyncGet(EnquiryFollowRelations, params, function(data, code)
    if not data then
      return
    end
    for _, userInfo in pairs(data) do
      UserInfoCache:UpdateUserInfos({userInfo})
    end
    callback(code, data)
  end)
end

function WebService:GetFollowPlayerCount(userId, callback)
  if not userId then
    return
  end
  local params = {
    {
      "userId",
      tostring(userId)
    }
  }
  WebService.asyncGet(GetFollowCountApi, params, function(data, code)
    if not data then
      return
    end
    data.userId = userId
    UserInfoCache:UpdateUserInfos({data})
    callback(code, data)
  end)
end

function WebService:GetPlayerFansList(userId, pageNo, callback)
  if not userId then
    return
  end
  local params = {
    {
      "userId",
      tostring(userId)
    },
    {
      "pageNo",
      tostring(pageNo)
    }
  }
  WebService.asyncGet(GetFansListApi, params, function(data, code)
    if not data then
      return
    end
    UserInfoCache:UpdateUserInfos(data.data)
    callback(code, data)
  end)
end

function WebService:GetPlayerFollowList(userId, pageNO, callback)
  if not userId then
    return
  end
  local params = {
    {
      "userId",
      tostring(userId)
    },
    {
      "pageNo",
      tostring(pageNO)
    }
  }
  WebService.asyncGet(GetFollowsListApi, params, function(data, code)
    if not data then
      return
    end
    UserInfoCache:UpdateUserInfos(data.data)
    callback(code, data)
  end)
end

function WebService:GetPlayersCustomDataValue(userIds, fields, callback)
  local params = {
    {
      "userIds",
      table.concat(userIds, ",")
    },
    {
      "fields",
      table.concat(fields, ",")
    }
  }
  WebService.asyncGet(GetCustomValueListApi, params, function(data, code)
    if not data then
      return
    end
    local userInfo = {}
    for userId, _userInfo in pairs(data) do
      local data = {}
      data.userId = tonumber(userId)
      for _, info in pairs(_userInfo) do
        data[info.key] = info.value
      end
      table.insert(userInfo, data)
    end
    UserInfoCache:UpdateUserInfos(userInfo)
    if callback then
      callback(code, data)
    end
  end)
end

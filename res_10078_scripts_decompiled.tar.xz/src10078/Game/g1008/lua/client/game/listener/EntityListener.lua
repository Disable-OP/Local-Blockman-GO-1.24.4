EntityListener = {}

function EntityListener:init()
  BaseListener.registerCallBack(CEvents.SpawnEntityEvent, self.onSpawnEntity)
  Listener.registerCallBack(CEvents.AttackActorNpcEvent, self.onAttackActorNpc)
  CommonDataEvents:registerCallBack("SendSignal", function(data)
    local startPos = VectorUtil.newVector3(data:getParam("posX"), data:getParam("posY"), data:getParam("posZ"))
    MessageEffectConfig:shootFlares(data:getParam("senderId"), data:getParam("id"), startPos)
  end, DataBuilderProcessor)
  DataBuilderProcessor:registerMapping("MonsterSpeed", {"entityId", "speed"})
  CommonDataEvents:registerCallBack("MonsterSpeed", function(data)
    local entityId = data:getNumberParam("entityId")
    local speed = data:getNumberParam("speed")
    local entity = EntityCache:getEntityByServerId(entityId)
    if entity then
      entity:setSpeed(speed)
    end
  end, DataBuilderProcessor)
  DataBuilderProcessor:registerMapping("MonsterFrameInterval", {
    "entityId",
    "frameInterval"
  })
  CommonDataEvents:registerCallBack("MonsterFrameInterval", function(data)
    local entityId = data:getNumberParam("entityId")
    local frameInterval = data:getNumberParam("frameInterval")
    local entity = EntityCache:getEntityByServerId(entityId)
    if entity then
      entity:setFrameInterval(frameInterval)
    end
  end, DataBuilderProcessor)
  DataBuilderProcessor:registerMapping("MonsterPos", {
    "entityId",
    "position",
    "stepInAir"
  })
  CommonDataEvents:registerCallBack("MonsterPos", function(data)
    local entityId = data:getNumberParam("entityId")
    local pos = data:getVector3Param("position")
    local stepInAir = data:getParam("stepInAir") == "1"
    local entity = EntityCache:getEntityByServerId(entityId)
    if entity then
      entity:setPosition(pos, stepInAir)
    end
  end, DataBuilderProcessor)
  DataBuilderProcessor:registerMapping("MonsterAction", {"entityId", "action"})
  CommonDataEvents:registerCallBack("MonsterAction", function(data)
    local entityId = data:getNumberParam("entityId")
    local action = data:getParam("action")
    local entity = EntityCache:getEntityByServerId(entityId)
    if entity then
      entity:playAction(action)
    end
  end, DataBuilderProcessor)
  DataBuilderProcessor:registerMapping("MonsterHP", {"entityId", "hp"})
  CommonDataEvents:registerCallBack("MonsterHP", function(data)
    local entityId = data:getNumberParam("entityId")
    local hp = data:getParam("hp")
    local entity = EntityCache:getEntityByServerId(entityId)
    if entity then
      entity:setHP(hp)
    end
  end, DataBuilderProcessor)
  DataBuilderProcessor:registerMapping("MonsterDie", {"entityId"})
  CommonDataEvents:registerCallBack("MonsterDie", function(data)
    local entityId = data:getNumberParam("entityId")
    local entity = EntityCache:getEntityByServerId(entityId)
    if entity then
      entity:onDie()
    end
  end, DataBuilderProcessor)
  DataBuilderProcessor:registerMapping("MonsterKnockBack", {
    "entityId",
    "distance",
    "yaw"
  })
  CommonDataEvents:registerCallBack("MonsterKnockBack", function(data)
    local entityId = data:getNumberParam("entityId")
    local distance = data:getNumberParam("distance")
    local yaw = data:getNumberParam("yaw")
    local entity = EntityCache:getEntityByServerId(entityId)
    if entity then
      entity:onKnockBack(distance, yaw)
    end
  end, DataBuilderProcessor)
end

function EntityListener.onSpawnEntity(lEntity)
  if lEntity and lEntity.type == EntityType.SessionNpc then
    LuaTimer:schedule(function()
      if lEntity.entity and lEntity.entity:getActorName() == "g1008_diamond.actor" then
        lEntity.entity:setBoolProperty("banClicked", true)
      end
    end, 1000)
  end
end

function EntityListener.onAttackActorNpc(entityId)
  local entity = EntityCache:getEntity(entityId)
  if entity == nil then
    return true
  end
  local type = entity.entity:getIntProperty("Type")
  if type == StoreNpcType.Goods then
    GUIStore:show(StoreId.GoodsStore)
    return false
  end
  if type == StoreNpcType.Upgrade then
    GUIUpgradeStore:show(StoreId.UpgradeStore)
    return false
  end
  return true
end

BlockListener = {}

function BlockListener:init()
  Listener.registerCallBack(CEvents.BlockStartBreakEvent, function(_, blockId, blockPos)
    return BlockListener.checkBreakBlock(_, blockId, blockPos, 15)
  end)
  Listener.registerCallBack(CEvents.BlockAbortBreakEvent, function(_, blockId, blockPos)
    return BlockListener.checkBreakBlock(_, blockId, blockPos, 2)
  end)
  Listener.registerCallBack(CEvents.BlockBreakEvent, function(_, blockId, blockPos)
    return BlockListener.checkBreakBlock(_, blockId, blockPos, 2)
  end)
  Listener.registerCallBack(CEvents.PlayerPlaceBlockEvent, function(_, blockId, blockMeta, blockPos)
    local lua_player = PlayerManager:getClientPlayer()
    local holdId = lua_player.Player:getHeldItemId()
    local skill = SkillConfig:getSkill(holdId)
    if skill and skill.isPlaceBlock then
      lua_player:sendPacket({
        pid = "PlaceBlockSkill",
        x = blockPos.x,
        y = blockPos.y,
        z = blockPos.z
      })
      local useResult = Blockman.Instance().m_playerControl:useItem(lua_player.Player, EngineWorld:getWorld(), lua_player.Player:getHeldItem())
    end
    return BlockListener.checkPlaceBlock(_, blockId, blockMeta, blockPos)
  end)
  Listener.registerCallBack(CEvents.BlockCanHarvestEvent, function(blockId)
    return BlockListener.onBlockCanHarvest(blockId)
  end)
  Listener.registerCallBack(CEvents.onPlayerClickEvent, function(touchPointX, touchPointY)
    return BlockListener.onPlayerClick(touchPointX, touchPointY)
  end)
  Listener.registerCallBack(CEvents.ClickAirEvent, function(isClickAir)
    return BlockListener.onClickAir(isClickAir)
  end)
end

function BlockListener.checkBreakBlock(_, blockId, blockPos, tipTime)
  if ItemMapping:getOldItemId(ItemMapping:getOldItemId(blockId)) ~= BlockID.OBSIDIAN then
    return true
  end
  local heldItemId = PlayerManager:getClientPlayer().Player:getHeldItemId()
  if ItemMapping:getOldItemId(heldItemId) == ItemID.PICKAXE_DIAMOND then
    return true
  end
  MsgSender.sendBottomTips(tipTime, 1008021)
  return false
end

function BlockListener.checkPlaceBlock(_, blockId, blockMeta, blockPos)
  local isInArea = TeamConfig:isInTeamArea(blockPos)
  if not isInArea then
    return true
  end
  local tipStr = Lang:getTipString(1008002)
  local heldItemId = PlayerManager:getClientPlayer().Player:getHeldItemId()
  if heldItemId == 2417 or heldItemId == 2418 then
    GUIBedWarGameTips:showGameTip(tipStr)
    return false
  end
  return true
end

function BlockListener.onBlockCanHarvest(blockId)
  if ItemMapping:getOldItemId(ItemMapping:getOldItemId(blockId)) ~= BlockID.OBSIDIAN then
    return true
  end
  local heldItemId = PlayerManager:getClientPlayer().Player:getHeldItemId()
  if ItemMapping:getOldItemId(heldItemId) == ItemID.PICK_AXE_GOLD then
    return true
  end
  return false
end

function BlockListener.onClickAir(isClickAir)
  return PlaceBlockHelper:onClickAir(isClickAir)
end

function BlockListener.onPlayerClick(touchPointX, touchPointY)
  PlaceBlockHelper:onPlayerClickScreen(touchPointX, touchPointY)
end

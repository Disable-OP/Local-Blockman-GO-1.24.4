PlayerListener = {}

function PlayerListener:init()
  Listener.registerCallBack(Events.GoAppShopEvent, function(type)
    GUIStore:hide()
    if type == Define.Money.KEY then
      GUIStore:show(StoreId.CubeStore, 8)
    else
      GUIStore:show(StoreId.CubeStore)
    end
    return false
  end)
  Listener.registerCallBack(CEvents.PlayerPlayBaseActionEvent, self.onPlayerPlayAction)
  Listener.registerCallBack(CEvents.PlayerPlayUpperActionEvent, self.onPlayerPlayAction)
  Listener.registerCallBack(CEvents.AttackEntityEvent, self.onAttackEntity)
  Listener.registerCallBack(CEvents.PlayerOnReadyJumpingEvent, self.onPlayerOnReadyJumping)
  Listener.registerCallBack(CEvents.PlayerJumpEvent, self.onPlayerJump)
  Listener.registerCallBack(CEvents.PlayerTryJumpEvent, self.onPlayerTryJump)
  Listener.registerCallBack(CEvents.UseFishHookHitEntityEvent, self.onUseFishHookHitEntity)
  Listener.registerCallBack(CEvents.HurtCemaraEffectEvent, self.onHurtCemaraEffect)
end

function PlayerListener.onPlayerPlayAction(player, _, skill)
  if not isGameStart then
    return
  end
  if skill.value ~= "attack2" then
    return
  end
  local item = Item.getItemById(player:getHeldItemId())
  if not item then
    return
  end
  local class = item:getClassName()
  if class == "ItemSword" or class == "ItemPickaxe" or class == "ItemAxe" or class == "ItemShears" then
    local info = GameInfoManager:getPlayerInfo(player:getPlatformUserId())
    if not info then
      return
    end
    local curSettingLight = info:getValue("curSwordLight")
    local setting = CustomShopSwordLight.Settings[curSettingLight]
    if setting then
      skill.value = CustomShopSwordLight:randomAction(setting)
    end
  end
end

local function getCameraPos(offset)
  local camera = SceneManager.Instance():getMainCamera()
  local pos = camera:getPosition()
  local dir = camera:getDirection()
  local right = camera:getRight()
  local down = VectorUtil.sub3(VectorUtil.ZERO, camera:getUp())
  local frontOff, rightOff, downOff = offset.x, offset.y, offset.z
  pos.x = pos.x + dir.x * frontOff
  pos.y = pos.y + dir.y * frontOff
  pos.z = pos.z + dir.z * frontOff
  pos.x = pos.x + right.x * rightOff
  pos.y = pos.y + right.y * rightOff
  pos.z = pos.z + right.z * rightOff
  pos.x = pos.x + down.x * downOff
  pos.y = pos.y + down.y * downOff
  pos.z = pos.z + down.z * downOff
  return pos
end

function PlayerListener.onClickScenePlayAction()
  if not GUIBedWarSetting then
    return true
  end
  if not GUIBedWarSetting:isFirstPerspective() then
    return true
  end
  local item = Item.getItemById(Game:getPlayer():getHeldItemId())
  if not item then
    return true
  end
  local class = item:getClassName()
  if class ~= "ItemSword" and class ~= "ItemPickaxe" and class ~= "ItemAxe" and class ~= "ItemShears" then
    return true
  end
  local info = GameInfoManager:getPlayerInfo(Game:getPlayer():getPlatformUserId())
  if not info then
    return true
  end
  local curSettingLight = info:getValue("curSwordLight")
  local setting = CustomShopSwordLight.Settings[curSettingLight]
  if not setting then
    return true
  end
  local skillName = CustomShopSwordLight:randomSceneAction(setting)
  local effectSetting = SwordLightEffectConfig.getConfigByAction(skillName)
  if not effectSetting or not effectSetting.Effect then
    return true
  end
  local pos = getCameraPos(effectSetting.Offset)
  local effect = EngineWorld:addSimpleEffect(effectSetting.Effect, pos, -Game:getPlayer():getYaw(), -1, effectSetting.Scale.x, effectSetting.Scale.y, effectSetting.Scale.z)
  if not effect then
    return
  end
  effect.mPitch = -Game:getPlayer():getPitch()
  LuaTimer:scheduleTimerWithEnd(function()
    effect.mPosition = getCameraPos(effectSetting.Offset)
  end, function()
    effect.mDuration = 0
  end, 10, 80)
  return true
end

function PlayerListener.onAttackEntity(entityId)
  local player = PlayerManager:getPlayerByEntityId(entityId)
  if not player then
    return true
  end
  return PlayerListener.onClickScenePlayAction()
end

function PlayerListener.onPlayerTryJump(entityId)
  local Player = Blockman.Instance():getPlayer()
  local myPlayer = PlayerManager:getClientPlayer()
  if not Player or not myPlayer then
    LogUtil.log("[g1008] Game | Listener | PlayerListener | onPlayerTryJump | not Player", LogUtil.LogLevel.Error)
    return true
  end
  if tostring(Player:hashCode()) ~= tostring(entityId) then
    return true
  end
  if myPlayer.curJumpCount <= 0 then
    return false
  end
  return true
end

function PlayerListener.onPlayerJump(platformUserId)
  local myPlayer = PlayerManager:getClientPlayer()
  if not myPlayer or not myPlayer.Player then
    return
  end
  if tostring(myPlayer.userId) ~= tostring(platformUserId) then
    return
  end
  myPlayer.curJumpCount = myPlayer.curJumpCount - 1
end

function PlayerListener.onPlayerOnReadyJumping(entityId, onGround)
  local myPlayer = PlayerManager:getClientPlayer()
  if not myPlayer or not myPlayer.Player then
    return
  end
  if tostring(myPlayer.entityId) ~= tostring(entityId) then
    return
  end
  if onGround == true then
    myPlayer.curJumpCount = myPlayer.doubleJumpCount
  end
end

function PlayerListener.onUseFishHookHitEntity(anglerId, targetId)
  local angler = PlayerManager:getPlayerByEntityId(anglerId)
  local target = PlayerManager:getPlayerByEntityId(targetId)
  if not target or not angler then
    return true
  end
  local anglerInfo = GameInfoManager:getPlayerInfo(angler.userId)
  local targetInfo = GameInfoManager:getPlayerInfo(target.userId)
  if not anglerInfo or not targetInfo then
    return true
  end
  if anglerInfo:getValue("teamId") == targetInfo:getValue("teamId") then
    return false
  end
  return true
end

function PlayerListener.onHurtCemaraEffect(entityPlayer)
  if entityPlayer:isOnFlyingMount() or entityPlayer:isOnFloatingMount() then
    return false
  end
  return true
end

print("game.util.ClientHelper")
local old_onAppActionTrigger = ClientHelper.onAppActionTrigger

function ClientHelper.onAppActionTrigger(type, ...)
  print(" ClientHelper.onAppActionTrigger", type)
  if type == 8 then
    GamePacketSender:sendSettlementShare()
  end
  old_onAppActionTrigger(type, ...)
end

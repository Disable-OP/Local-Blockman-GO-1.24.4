PlaceBlockHelper = {}
local faceOffset = {
  north = VectorUtil.newVector3(0, 0, -1),
  south = VectorUtil.newVector3(0, 0, 1),
  west = VectorUtil.newVector3(-1, 0, 0),
  east = VectorUtil.newVector3(1, 0, 0)
}
local diagonalOffset = {
  westNorth = VectorUtil.newVector3(-1, 0, -1),
  westSouth = VectorUtil.newVector3(-1, 0, 1),
  westNorth = VectorUtil.newVector3(1, 0, -1),
  eastSouth = VectorUtil.newVector3(1, 0, 1)
}
local face = {
  north = 3,
  south = 2,
  west = 5,
  east = 4
}
local curClickScreenPos

local function getHitPointInfo(player, curClickScreenPos)
  local camera = SceneManager.Instance():getMainCamera()
  local pos = camera:getPosition()
  local dir = camera:getDirection()
  local real
  local hitInfo = HitInfo.new()
  local ray = Ray.new(pos, dir)
  camera:getCameraRay(ray, curClickScreenPos)
  local selfPos = player:getPosition()
  local y = selfPos.y - 1.6
  local plane = Plane.new(VectorUtil.UNIT_Y, -y)
  ray:hitPlane(plane, real, hitInfo)
  hitInfo.hitPos = VectorUtil.newVector3(hitInfo.hitPos.x, math.floor(hitInfo.hitPos.y), hitInfo.hitPos.z)
  return hitInfo
end

local function checkCanPlaceBlock(pos)
  local blockId = EngineWorld:getBlockId(pos)
  local canAttach = {}
  local canBuild = {}
  local canPlace = false
  if blockId ~= 0 then
    return canPlace, canAttach, canBuild
  end
  for index, posOffset in pairs(faceOffset) do
    local newPos = VectorUtil.add3(pos, posOffset)
    blockId = EngineWorld:getBlockId(newPos)
    if blockId ~= 0 then
      canAttach[index] = newPos
      canPlace = true
    else
      table.insert(canBuild, newPos)
    end
  end
  for _, posOffset in pairs(diagonalOffset) do
    local newPos = VectorUtil.add3(pos, posOffset)
    blockId = EngineWorld:getBlockId(newPos)
    if blockId == 0 then
      table.insert(canBuild, newPos)
    end
  end
  return canPlace, canAttach, canBuild
end

local function findBuildPos(player, initPos, curDepth)
  local isCanPlace, attachList, buildList = checkCanPlaceBlock(initPos)
  local targetPos, targetFace
  if curDepth > (GameConfig.placeBlockMaxDepth or 1) then
    return isCanPlace, targetPos, targetFace
  end
  curDepth = curDepth + 1
  local playerPos = player:getPosition()
  playerPos = VectorUtil.toBlockVector3(playerPos.x, playerPos.y, playerPos.z)
  if isCanPlace then
    local minDistance = GameConfig.placeBlockMaxBuildDistance
    for index, attachPos in pairs(attachList) do
      local curDistance = VectorUtil.distance(attachPos, playerPos)
      if minDistance > curDistance then
        minDistance = curDistance
        targetPos = attachPos
        targetFace = face[index]
      end
    end
  else
    if 2 < #buildList then
      table.sort(buildList, function(a, b)
        return VectorUtil.distance(a, playerPos) < VectorUtil.distance(b, playerPos)
      end)
    end
    for _, pos in pairs(buildList) do
      return findBuildPos(player, pos, curDepth)
    end
  end
  return isCanPlace, targetPos, targetFace
end

local function findFrontBlock(player, direction)
  local oneStep, curFace
  if math.abs(direction.x) >= math.abs(direction.z) then
    if direction.x > 0 then
      oneStep = VectorUtil.newVector3(1, 0, 0)
    else
      oneStep = VectorUtil.newVector3(-1, 0, 0)
    end
  elseif direction.z > 0 then
    oneStep = VectorUtil.newVector3(0, 0, 1)
  else
    oneStep = VectorUtil.newVector3(0, 0, -1)
  end
  local playerPos = player:getPosition()
  playerPos = VectorUtil.toBlockVector3(playerPos.x, playerPos.y, playerPos.z)
  local startPos = VectorUtil.toBlockVector3(playerPos.x, playerPos.y - 2, playerPos.z)
  local times = GameConfig.buildRoadModeMaxDistance
  local finalPos = startPos
  local isCanPlace = false
  for i = 1, times do
    if EngineWorld:getBlockId(finalPos) == 0 then
      local _isCanPlace, _finalPos, _curFace = findBuildPos(player, finalPos, 1)
      if _isCanPlace then
        return _isCanPlace, _finalPos, _curFace
      end
    else
      finalPos = VectorUtil.add3(finalPos, oneStep)
    end
  end
  if EngineWorld:getBlockId(startPos) == 0 then
    for _, offset in pairs(faceOffset) do
      isCanPlace, finalPos, curFace = findBuildPos(player, VectorUtil.add3(startPos, offset), 1)
      if isCanPlace then
        return isCanPlace, finalPos, curFace
      end
    end
  end
  return isCanPlace, finalPos, curFace
end

function PlaceBlockHelper:onPlayerClickScreen(touchPointX, touchPointY)
  curClickScreenPos = {x = touchPointX, y = touchPointY}
end

function PlaceBlockHelper:onClickAir(isClickAir)
  if not isClickAir then
    curClickScreenPos = nil
    return true
  end
  if not curClickScreenPos then
    return true
  end
  local player = PlayerManager:getClientPlayer()
  if not player then
    return true
  end
  local hitInfo = getHitPointInfo(player, curClickScreenPos)
  local initPos = VectorUtil.toBlockVector3(hitInfo.hitPos.x, hitInfo.hitPos.y - 1, hitInfo.hitPos.z)
  local isCanPlace, buildPos, targetFace
  isCanPlace, buildPos, targetFace = findBuildPos(player, initPos, 1)
  return PlaceBlockHelper:tryPlaceBlock(player, buildPos, targetFace, "screen")
end

function PlaceBlockHelper:onClickFrontBuildButton()
  local player = PlayerManager:getClientPlayer()
  if not player then
    return
  end
  local dir = SceneManager.Instance():getMainCamera():getDirection()
  local isCanPlace, buildPos, targetFace
  isCanPlace, buildPos, targetFace = findFrontBlock(player, dir)
  PlaceBlockHelper:tryPlaceBlock(player, buildPos, targetFace, "button")
end

function PlaceBlockHelper:tryPlaceBlock(player, buildPos, targetFace, source)
  if not isGameStart then
    return
  end
  if not buildPos or not targetFace then
    return false
  end
  local inv = player.Player:getInventory()
  local itemStack = inv:getRealCurrentItem()
  if not itemStack then
    return false
  end
  local item = itemStack:getItem()
  if not item then
    return false
  end
  source = source or "screen"
  local place = item:onItemUse(itemStack, Blockman.Instance():getPlayer(), Blockman.Instance():getWorld(), buildPos, targetFace, buildPos)
  if place then
    if itemStack:getItemStackSize() == 0 then
      inv:decrStackSize(inv:findItemStack(itemStack), 0)
    end
    player.Player:swingItem()
    GamePacketSender:sendPlaceBlock(buildPos, targetFace, source)
    return true
  end
  return false
end

GamePacketSender = {}

function GamePacketSender:sendBedWarLotteryRefresh()
  PacketSender:sendLuaCommonData("LotteryRefresh")
end

function GamePacketSender:sendBedWarLottery(seq)
  local data = DataBuilder.new():addParam("seq", seq):getData()
  PacketSender:sendLuaCommonData("Lottery", data)
end

function GamePacketSender:sendBackHall()
  PacketSender:sendLuaCommonData("BackHall")
end

function GamePacketSender:sendPlayAgain(data)
  PacketSender:sendLuaCommonData("PlayAgain", tostring(data))
end

function GamePacketSender:sendWatchAdvertFinished(type, params, code)
  local param = {
    type = type,
    params = params,
    code = code
  }
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData("WatchAdvertFinished", data)
end

function GamePacketSender:sendShortCommand(CommandId)
  PacketSender:sendLuaCommonData("ShortMessage", tostring(CommandId))
end

function GamePacketSender:sendChatMessage(type, text)
  local param = {type = type, text = text}
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData("Chat", data)
end

function GamePacketSender:sendSettlementGood(toUserId)
  PacketSender:sendLuaCommonData("SettlementGood", tostring(toUserId))
end

function GamePacketSender:sendBuyKeepItem(isBuy)
  PacketSender:sendLuaCommonData("BuyKeepItem", tostring(isBuy))
end

function GamePacketSender:sendBuyRespawn(isBuy)
  PacketSender:sendLuaCommonData("BuyRespawn", tostring(isBuy))
end

function GamePacketSender:sendBuyCommandGoods(messageId)
  PacketSender:sendLuaCommonData("BuyCommandGoods", tostring(messageId))
end

function GamePacketSender:sendLotteryReplace(isReplace)
  local param = {isReplace = isReplace}
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData("LotteryReplace", data)
end

function GamePacketSender:sendLotteryEffectEnd()
  PacketSender:sendLuaCommonData("LotteryEffectEnd")
end

function GamePacketSender:sendIntoTeamResource(x, z)
  local param = {x = x, z = z}
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData("IntoTeamResource", data)
end

function GamePacketSender:sendBedWarLicenseGetReward(rewardId, Lv, rewardType, season, getAll)
  local data = DataBuilder.new():addParam("rewardId", rewardId):addParam("getAll", getAll):addParam("rewardType", rewardType):addParam("season", season):addParam("Lv", Lv):getData()
  PacketSender:sendLuaCommonData("LicenseReceiveReward", data)
end

function GamePacketSender:sendBedWarLicenseBuyLevel(season, level, free)
  local data = DataBuilder.new():addParam("season", season):addParam("level", level):addParam("free", free):getData()
  PacketSender:sendLuaCommonData("LicenseBuyLevel", data)
end

function GamePacketSender:sendBedWarLicenseBuyLicense(season, buyType)
  local data = DataBuilder.new():addParam("season", season):addParam("buyType", buyType):getData()
  PacketSender:sendLuaCommonData("LicenseBuyLicense", data)
end

function GamePacketSender:sendBedWarLicenseExchange(season, itemId, rewardNum)
  local data = DataBuilder.new():addParam("season", season):addParam("itemId", itemId):addParam("rewardNum", rewardNum):getData()
  PacketSender:sendLuaCommonData("LicenseExchangeReward", data)
end

function GamePacketSender:sendBedWarLicenseReceiveTaskReward(taskId)
  local data = DataBuilder.new():addParam("taskId", taskId):getData()
  PacketSender:sendLuaCommonData("LicenseReceiveTaskReward", data)
end

function GamePacketSender:sendBedWarPlayerClickMainControl()
  PacketSender:sendLuaCommonData("ClickMainControl", "")
end

function GamePacketSender:sendPushSurveySuccess()
  PacketSender:sendLuaCommonData("PushSurveySuccess")
end

function GamePacketSender:sendSettlementShare()
  PacketSender:sendLuaCommonData("SettlementShare", "")
end

function GamePacketSender:sendPlaceBlock(selectedBlockPos, face, source)
  local param = {
    posX = selectedBlockPos.x,
    posY = selectedBlockPos.y,
    posZ = selectedBlockPos.z,
    face = face,
    source = source
  }
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData("placeBlock", data)
end

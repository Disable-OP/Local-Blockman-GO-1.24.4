ClientMonster = class("ClientMonster", IEntity)
ClientHelper.putBoolPrefs("IsCreatureCollision", false)
KnockStatus = {
  onClick = 1,
  onAir = 2,
  onDrop = 3
}
local TargetType = {
  Me = 1,
  Team = 2,
  Enemy = 3
}

local function checkTargetType(userId, teamId)
  local clientId = Game:getPlatformUserId()
  if tostring(clientId) == tostring(userId) then
    return TargetType.Me
  end
  local playerInfo = GameInfoManager:getPlayerInfo(clientId)
  if not playerInfo then
    return TargetType.Enemy
  end
  if teamId == playerInfo:getValue("teamId") then
    return TargetType.Team
  end
  return TargetType.Enemy
end

function ClientMonster:onCreate()
  self.speed = 2
  self.toPosList = {
    {
      position = self.entity.position,
      stepInAir = false
    }
  }
  self.timerKey = {}
  self.runTicks = 0
  self.runTime = 0
  self.runLock = false
  self.onKnock = KnockStatus.onDrop
  self.frameIntervalTimes = 1
  self.curHp = 0
  self.creatorRealName = ""
  self.teamId = 1
  self.entity:setCanFly(true)
  self.entity:setBoolProperty("banAutoFaceTarget", true)
  self.entity:setBoolProperty("ignoreWaterPush", true)
  self.config = {}
  local propertyTable = json.decode(self.properties)
  if type(propertyTable) == "table" then
    self:setCreator(propertyTable.userId)
    self.config = MonsterConfig:getConfigByType(propertyTable.type) or {}
    self.entity:setBoolProperty("banClicked", self.config.banClicked or false)
    self.entity:setBoolProperty("banAABBCheck", self.config.banAABBCheck or false)
    self:setCountdown(self.config.lifeTime)
    self.timerKey.create = LuaTimer:schedule(function()
      local actor = EntityRenderManager.Instance():getEntityActor(self.entity)
      if actor then
        local needHide = self.config.actorShowTarget[tostring(self.targetType)] == nil
        self.entity:setInvisible(needHide)
        actor:setActorHide(needHide)
        if self.config.itemId then
          self.entity:setInvisible(false)
          self.entityItemId = EngineWorld:addEntityItem(self.config.itemId, 1, 0, 0, self.entity:getPosition(), nil, false, true)
        end
      end
    end, 100)
  end
end

function ClientMonster:setHP(curHp)
  self.curHp = math.floor(tonumber(curHp) + 0.5)
  self:showHeadText()
end

function ClientMonster:onKnockBack(distance, yaw)
  if self.onKnock ~= KnockStatus.onDrop then
    return
  end
  self.onKnock = KnockStatus.onClick
  local xRatio = math.sin(yaw * MathUtil.DEG2RAD)
  local zRatio = -math.cos(yaw * MathUtil.DEG2RAD)
  local lenSqr = math.sqrt(xRatio * xRatio + zRatio * zRatio)
  self.xDis = xRatio / lenSqr * distance
  self.yDis = zRatio / lenSqr * distance
  self.dropPoint = self.entity.position
end

function ClientMonster:setCountdown(time)
  if time < 0 then
    return
  end
  self.Countdown = time - 1
  LuaTimer:cancel(self.timerKey.countdown or 0)
  self.timerKey.countdown = LuaTimer:scheduleTimer(function()
    if self.Countdown > 0 then
      self.Countdown = self.Countdown - 1
    end
    self:showHeadText()
  end, 1000, self.Countdown)
end

function ClientMonster:setCreator(userId)
  local playerInfo = GameInfoManager:getPlayerInfo(userId)
  if not playerInfo then
    return
  end
  self.teamId = playerInfo:getValue("teamId")
  self.creatorRealName = StringUtil.getRealName(playerInfo:getValue("userName"))
  self.targetType = checkTargetType(userId, self.teamId)
end

function ClientMonster:showHeadText()
  if not self.config.textShowTarget[tostring(self.targetType)] then
    return
  end
  if self.entity then
    if not self.offsetY then
      local actorSize = ActorSizeSetting.getActorSize(self.entity:getActorName())
      self.offsetY = (actorSize.height + 0.15) * actorSize.scale
    end
    local text = ""
    if self.Countdown and self.curHp < 0 then
      text = text .. self.Countdown .. "s" .. "\n"
    end
    text = text .. TeamColor[tonumber(self.teamId)] .. self.creatorRealName
    if self.curHp >= 0 then
      text = text .. "\n" .. self.curHp .. "\226\150\162FFFF1F1F  \226\153\165"
    end
    self.entity:addCustomText("Name", "text=" .. text .. "&offset=0:" .. tostring(self.offsetY) .. ":0", -1, 1)
  end
end

function ClientMonster:setSpeed(speed)
  self.speed = speed
end

function ClientMonster:setFrameInterval(frameInterval)
  self.frameIntervalTimes = 1000 / frameInterval
end

function ClientMonster:setPosition(position, stepInAir)
  table.insert(self.toPosList, {position = position, stepInAir = stepInAir})
  self:playAction("run")
end

function ClientMonster:playAction(action)
  if self.action == action then
    return
  end
  local actor = EntityRenderManager.Instance():getEntityActor(self.entity)
  if not actor then
    return
  end
  self.action = action
  actor:PlaySkill(self.action, false, false, 1, -1, -1, "", true)
  if self.action ~= "run" and self.action ~= "idle" then
    LuaTimer:cancel(self.timerKey.action)
    self.timerKey.action = LuaTimer:schedule(function()
      if action ~= "die" then
        if self.runTicks > 0 then
          self:playAction("run")
        else
          self:playAction("idle")
        end
      end
      self.timerKey.action = nil
    end, actor:GetSkillTimeLength(self.action))
  end
end

function ClientMonster:onKnockToPosition(frameTime)
  frameTime = frameTime * self.speed
  self.runTime = 100 / self.frameIntervalTimes
  local runTicks = math.ceil(60 / self.frameIntervalTimes / frameTime)
  if self.onKnock == KnockStatus.onClick then
    self.onKnock = KnockStatus.onAir
    self.dropPoint.y = self.dropPoint.y + 0.6
  elseif self.onKnock == KnockStatus.onAir then
    self.onKnock = KnockStatus.onDrop
    self.dropPoint.y = self.dropPoint.y - 0.6
  end
  if EngineWorld:getBlockId(self.dropPoint) ~= 0 then
    self.dropPoint.y = self.dropPoint.y + 0.5
  end
  self.dropPoint.x = self.entity.position.x - self.xDis
  self.dropPoint.z = self.entity.position.z - self.yDis
  self.entity:setPositionAndRotation2(self.dropPoint, self.entity.rotationYaw, 0, runTicks)
end

function ClientMonster:setToPosition(toPos, frameTime)
  local runTicks
  local position = toPos.position
  if self.entity.position.y ~= position.y and math.abs(self.entity.position.x - position.x) < 1 and 1 > math.abs(self.entity.position.z - position.z) then
    self.runTime = 500 / self.frameIntervalTimes
    runTicks = math.ceil(300 / self.frameIntervalTimes / frameTime)
  else
    self.runTime = 1000 / self.frameIntervalTimes
    runTicks = math.ceil(1500 / self.frameIntervalTimes / frameTime)
  end
  if EngineWorld:getBlockId(position) ~= 0 then
    position.y = position.y + 0.5
  elseif not toPos.stepInAir then
    local floorPos = TableUtil.copyTable(position)
    floorPos.x = floorPos.x - 0.5
    floorPos.y = floorPos.y - 1
    floorPos.z = floorPos.z - 0.5
    position.y = floorPos.y
    local blockBoundY = 1
    local blockId = EngineWorld:getBlockId(floorPos)
    if blockId ~= 0 then
      local block = BlockManager.getBlockById(blockId)
      if block then
        blockBoundY = block:getBlockBoundsMaxY() - block:getBlockBoundsMinY()
      end
    end
    position.y = position.y + blockBoundY
  end
  local toYaw
  if #self.toPosList < 5 and 0 < #self.toPosList then
    local endPos = self.toPosList[#self.toPosList].position
    toYaw = math.atan2(endPos.x - self.entity.position.x, endPos.z - self.entity.position.z) / math.pi * -180
  else
    toYaw = math.atan2(position.x - self.entity.position.x, position.z - self.entity.position.z) / math.pi * -180
  end
  self.entity:setPositionAndRotation2(position, toYaw, 0, runTicks)
end

function ClientMonster:onUpdate(frameTime)
  if self.runTime > 0 then
    self.runTime = self.runTime - frameTime
    if self.runTime > 0 then
      return
    end
  end
  if self.onKnock ~= KnockStatus.onDrop then
    self:onKnockToPosition(frameTime)
    return
  end
  if #self.toPosList == 0 then
    if not self.timerKey.action and not self.stopAction then
      self:playAction("idle")
    end
    return
  end
  local toPos = self.toPosList[1]
  if #self.toPosList > 1 then
    self.runLock = false
    table.remove(self.toPosList, 1)
  else
    local dis = math.max(math.min(1, 2 - self.speed), 0.3)
    if dis < VectorUtil.distance(toPos.position, self.entity.position) then
      if not self.runLock then
        self.runLock = true
        self:setToPosition(toPos, frameTime * self.speed)
      end
    else
      self.runLock = false
      table.remove(self.toPosList, 1)
    end
    return
  end
  self:setToPosition(toPos, frameTime * self.speed)
end

function ClientMonster:onDie()
  self:playAction("die")
  self.stopAction = true
end

function ClientMonster:onDestroy()
  if self.entityItemId then
    EngineWorld:removeEntity(self.entityItemId)
  end
  for _, key in pairs(self.timerKey) do
    LuaTimer:cancel(key)
  end
  self.timerKey = {}
end

EntityDefine:registerEntityType(EntityType.Creature, ClientMonster)

MessageDispatch = {}

local function registerCallBack()
  local observable = EventObservable.new()
  observable:registerDataCallBack("Message", function(data)
    MessageDispatch:onGetMessage(data)
  end, DataBuilderProcessor)
end

MessageDispatch.dispatchMapping = {
  ["1"] = require("game.dispatch.CommandBuilder")
}

function MessageDispatch:init()
  registerCallBack()
end

function MessageDispatch:onGetMessage(data)
  local sendId = data:getNumberParam("senderId")
  local messageId = data:getParam("Id")
  local content = data:getNumberParam("content")
  local messageConfig = CommandSettingConfig:getConfigById(messageId)
  self.dispatchMapping["1"]:onGetMessage(sendId, messageConfig, content)
end

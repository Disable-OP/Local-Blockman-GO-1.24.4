CommandBuilder = {}

function CommandBuilder:onGetMessage(sendId, config, connect)
  GUIBedWarGameTips:onGetCommand(sendId, config, connect)
end

return CommandBuilder

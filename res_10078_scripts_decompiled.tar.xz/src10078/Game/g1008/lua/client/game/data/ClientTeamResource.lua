TeamResourceMode = 1
ClientTeamResource = class("ClientTeamResource")

function ClientTeamResource:ctor(pointId)
  self.pointId = pointId
  self.resourceConfigs = {}
  self.curLevel = {}
  self.producePos = self.producePos or {}
  self.spawnKey = {}
  local pointConfig = ResourcePointConfig:getConfigById(pointId)
  self.producePos[1] = pointConfig.producePos1
  self.producePos[2] = pointConfig.producePos2
  for _, typeId in pairs(pointConfig.resourceList) do
    table.insert(self.resourceConfigs, ResourceTypeConfig:getConfigByType(typeId))
    self.curLevel[tostring(typeId)] = 0
  end
  self.clientPlayerInArea = false
  self:initPointRange()
  self.itemEntityInfo1 = {}
  self.itemEntityInfo2 = {}
  LuaTimer:scheduleTimer(function()
    self:cleanExpiredEntity()
  end, 1000)
  self.positionTags = {
    {
      pos = VectorUtil.newVector3(-0.5, 0, -0.5),
      tag = false
    },
    {
      pos = VectorUtil.newVector3(-0.5, 0, 0),
      tag = false
    },
    {
      pos = VectorUtil.newVector3(-0.5, 0, 0.5),
      tag = false
    },
    {
      pos = VectorUtil.newVector3(0, 0, -0.5),
      tag = false
    },
    {
      pos = VectorUtil.newVector3(0, 0, 0),
      tag = false
    },
    {
      pos = VectorUtil.newVector3(0, 0, 0.5),
      tag = false
    },
    {
      pos = VectorUtil.newVector3(0.5, 0, -0.5),
      tag = false
    },
    {
      pos = VectorUtil.newVector3(0.5, 0, 0),
      tag = false
    },
    {
      pos = VectorUtil.newVector3(0.5, 0, 0.5),
      tag = false
    }
  }
end

function ClientTeamResource:initPointRange()
  self.minX = math.min(self.producePos[1].x, self.producePos[2].x)
  self.maxX = math.max(self.producePos[1].x, self.producePos[2].x)
  self.minZ = math.min(self.producePos[1].z, self.producePos[2].z)
  self.maxZ = math.max(self.producePos[1].z, self.producePos[2].z)
end

function ClientTeamResource:getProducePos()
  if TeamResourceMode == 1 then
    local x = self.minX + (self.maxX - self.minX) / 2
    local y = self.producePos[1].y + 1
    local z = self.minZ + (self.maxZ - self.minZ) / 2
    local positionAdd
    local count = 0
    while count < 999 do
      count = count + 1
      local index = math.random(1, 9)
      local positionTag = self.positionTags[index]
      if positionTag and not positionTag.tag then
        local isNear = false
        for _, _positionTag in pairs(self.positionTags) do
          if _positionTag.tag and VectorUtil.distance(_positionTag.pos, positionTag.pos) <= 0.5 then
            isNear = true
            break
          end
        end
        if not isNear then
          positionTag.tag = true
          positionAdd = positionTag.pos
          break
        end
      end
    end
    if positionAdd then
      return VectorUtil.add3(VectorUtil.newVector3(x, y, z), positionAdd)
    else
      return VectorUtil.newVector3(x, y, z)
    end
  else
    local x = self.minX + (self.maxX - self.minX) * math.random()
    local y = self.producePos[1].y + 1
    local z = self.minZ + (self.maxZ - self.minZ) * math.random()
    return VectorUtil.newVector3(x, y, z)
  end
end

function ClientTeamResource:onUpgrade()
  for index, _ in pairs(self.curLevel) do
    self.curLevel[index] = self.curLevel[index] + 1
  end
  self:setSpawnLuaTimer()
end

function ClientTeamResource:setSpawnLuaTimer()
  for _, key in pairs(self.spawnKey) do
    LuaTimer:cancel(key)
  end
  for _, config in pairs(self.resourceConfigs) do
    local level = self.curLevel[tostring(config.type)]
    local key = LuaTimer:scheduleTimer(function()
      if self.clientPlayerInArea == false then
        if TeamResourceMode == 1 then
          local entityInfo = self.itemEntityInfo1[tostring(config.itemId)]
          if not entityInfo then
            local curProducePos = self:getProducePos()
            local entityId = EngineWorld:addEntityItem(config.itemId, config.output[level], 0, config.life[level], curProducePos)
            entityInfo = {
              entityId = entityId,
              itemId = config.itemId,
              items = {}
            }
            self.itemEntityInfo1[tostring(config.itemId)] = entityInfo
          end
          table.insert(entityInfo.items, {
            buildTime = os.time(),
            lifeTime = config.life[level]
          })
          local entity = EngineWorld:getEntity(entityInfo.entityId)
          if entity then
            local text = "text=" .. tostring(#entityInfo.items) .. "&offset=0:0.8:0"
            entity:addCustomText("Count", text, -1, 1)
          end
        else
          local curProducePos = self:getProducePos()
          local entityId = EngineWorld:addEntityItem(config.itemId, config.output[level], 0, config.life[level], curProducePos)
          local itemInfo = {
            entityId = entityId,
            buildTime = os.time(),
            lifeTime = config.life[level]
          }
          table.insert(self.itemEntityInfo2, itemInfo)
        end
      end
    end, tonumber(config.interval[level]) * 1000, 100000)
    table.insert(self.spawnKey, key)
  end
end

function ClientTeamResource:cleanExpiredEntity()
  if TeamResourceMode == 2 then
    for _, info in pairs(self.itemEntityInfo1) do
      EngineWorld:removeEntity(info.entityId)
    end
    self.itemEntityInfo1 = {}
  end
  for _, info in pairs(self.itemEntityInfo1) do
    for i = #info.items, 1, -1 do
      if info.items[i].lifeTime < os.time() - info.items[i].buildTime then
        table.remove(info.items, i)
      end
    end
  end
  for i = #self.itemEntityInfo2, 1, -1 do
    local info = self.itemEntityInfo2[i]
    if TeamResourceMode == 1 or info.lifeTime < os.time() - info.buildTime then
      EngineWorld:removeEntity(info.entityId)
      table.remove(self.itemEntityInfo2, i)
    end
  end
end

function ClientTeamResource:onPlayerIntoResource(playerEntityId)
  self.clientPlayerInArea = true
  local entityIds = {}
  for _, info in pairs(self.itemEntityInfo1) do
    table.insert(entityIds, info.entityId)
  end
  for _, info in pairs(self.itemEntityInfo2) do
    table.insert(entityIds, info.entityId)
  end
  for _, entityId in pairs(entityIds) do
    local entity = EngineWorld:getEntity(entityId)
    if entity then
      local itemEntity = DynamicCast.dynamicCastEntity(EntityType.Item, entity)
      if not itemEntity then
        return true
      end
      itemEntity.m_readyToDead = false
      itemEntity.m_isPickedUp = true
      itemEntity.m_pickerId = playerEntityId
      if PlayerManager:getClientPlayer():getEntityId() == playerEntityId then
        itemEntity.m_pickerIsCurrClient = true
      end
    end
  end
  self.itemEntityInfo1 = {}
  self.itemEntityInfo2 = {}
  for _, positionTag in pairs(self.positionTags) do
    positionTag.tag = false
  end
end

function ClientTeamResource:onNotPlayerIntoResource()
  self.clientPlayerInArea = false
end

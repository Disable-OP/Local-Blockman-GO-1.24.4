GMSetting:addTab("\232\181\183\229\186\138\230\136\152\228\186\137", 1)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\229\188\128\229\167\139\230\184\184\230\136\143", "startGame")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\233\129\147\229\133\183\229\149\134\229\186\151", "openGoodsShop")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\229\141\135\231\186\167\229\149\134\229\186\151", "openUpgradeShop")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\148\185\233\147\129\233\148\187\231\130\137\232\161\168\231\142\176", "changeTeamResourceMode")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "", "")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "+\233\147\129\229\174\154", "addGameItem", ItemID.INGOT_IRON)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "+\233\135\145\233\148\173", "addGameItem", ItemID.INGOT_GOLD)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "+\233\146\187\231\159\179", "addGameItem", ItemID.DIAMOND)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "+\231\187\191\229\174\157\231\159\179", "addGameItem", ItemID.EMERALD)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "", "")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\231\186\162\233\152\159\229\135\186\231\148\159\231\130\185", "teleTeamPos", 1)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\232\147\157\233\152\159\229\135\186\231\148\159\231\130\185", "teleTeamPos", 2)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\231\187\191\233\152\159\229\135\186\231\148\159\231\130\185", "teleTeamPos", 3)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\233\187\132\233\152\159\229\135\186\231\148\159\231\130\185", "teleTeamPos", 4)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "", "")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\233\157\146\233\152\159\229\135\186\231\148\159\231\130\185", "teleTeamPos", 5)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\231\153\189\233\152\159\229\135\186\231\148\159\231\130\185", "teleTeamPos", 6)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\231\178\137\233\152\159\229\135\186\231\148\159\231\130\185", "teleTeamPos", 7)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\233\187\145\233\152\159\229\135\186\231\148\159\231\130\185", "teleTeamPos", 8)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "", "")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\231\186\162\233\152\159\229\186\138", "destroyBed", 1)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\232\147\157\233\152\159\229\186\138", "destroyBed", 2)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\231\187\191\233\152\159\229\186\138", "destroyBed", 3)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\233\187\132\233\152\159\229\186\138", "destroyBed", 4)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "", "")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\233\157\146\233\152\159\229\186\138", "destroyBed", 5)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\231\153\189\233\152\159\229\186\138", "destroyBed", 6)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\231\178\137\233\152\159\229\186\138", "destroyBed", 7)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\233\187\145\233\152\159\229\186\138", "destroyBed", 8)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\175\129\230\142\137\230\137\128\230\156\137\229\186\138", "destroyAllBed")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\233\154\143\230\156\186\230\157\128\230\149\140\228\186\186", "killPlayer")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\232\135\170\230\157\128", "killSelf")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\157\128\230\173\187\230\137\128\230\156\137\230\149\140\228\186\186", "killAllPlayer")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "", "")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\141\162\229\164\180\231\155\148", "changeHelmet")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\141\162\230\136\144\231\148\183\230\168\161\229\158\139", "changePlayerActor", 1)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\141\162\230\136\144\229\165\179\230\168\161\229\158\139", "changePlayerActor", 2)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\184\133\233\153\164\233\146\165\229\140\153", "cleanYaoShi")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "+50\231\187\143\233\170\140", "addExp")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\183\187\229\138\160\229\159\186\231\161\128\230\128\170\231\137\169", "addMonster")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\184\133\233\153\164\230\128\170\231\137\169", "clearMonster")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\183\187\229\138\160\233\155\170\231\144\131\229\155\138\232\153\171", "SnowBallInsect")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\229\183\171\230\175\146\232\141\175\230\176\180Buff", "addBanCureBuff")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\229\155\158\229\159\142\229\141\183\232\189\180Buff", "addBackHomeBuff")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\229\138\160100\230\151\167\230\142\146\228\189\141\229\136\134", "addOldHorn100")
GMSetting:addTab("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", 2)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\232\163\133\229\164\135\230\186\156\229\134\176\233\158\139", "equipSkatingShoes")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\232\163\133\229\164\135\229\191\141\232\128\133\233\158\139", "equipNinjaShoes")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\232\142\183\229\190\151\233\177\188\233\146\169", "addFishHook")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\232\142\183\229\190\151\229\164\167\229\138\155\229\188\169", "addCrossbow")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\231\187\153\229\164\167\229\138\155\229\188\169\229\138\160\229\173\144\229\188\185(4\229\143\145)", "addCrossbowArrow", 3576)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\230\176\180\231\144\131", "addWaterBall")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\229\155\158\230\186\175\231\143\141\231\143\160", "addBackPearl")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\230\144\173\230\161\165\232\155\139(\230\150\176)", "addBridgeEgg")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\230\156\171\229\189\177\233\190\153\229\141\183\232\189\180", "addEnderDragon")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\233\170\145\228\185\152\229\135\139\233\155\182\229\141\183\232\189\180", "addWithered")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\232\153\154\231\169\186\230\150\185\229\157\151", "addHollowBlock")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\230\155\191\232\186\171\229\130\128\229\132\161", "addDoubleDummy")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\228\188\170\232\163\133\229\156\176\233\155\183", "add585")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\229\134\176\229\134\187\229\164\185\229\173\144", "add584")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\230\138\165\232\173\166\229\153\168", "add583")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\232\176\131\230\159\165\233\151\174\229\141\183", "openSurvey")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\232\176\131\230\159\165\233\151\174\229\141\183\228\187\139\231\187\141", "openSurveyDesc")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137\230\150\176\233\129\147\229\133\183", "\232\176\131\230\159\165\233\151\174\229\141\183\233\135\141\231\189\174\230\149\176\230\141\174", "resetSurvey")
GMSetting:addTab("\233\149\156\229\164\180\232\176\131\230\149\180", 3)
GMSetting:addItem("\233\149\156\229\164\180\232\176\131\230\149\180", "\229\188\128\229\144\175\233\128\143\232\167\134", "switchCameraAlpha")
GMSetting:addItem("\233\149\156\229\164\180\232\176\131\230\149\180", "\233\128\143\232\167\134\233\128\143\230\152\142\229\186\166+", "addCameraAlpha")
GMSetting:addItem("\233\149\156\229\164\180\232\176\131\230\149\180", "\233\128\143\232\167\134\233\128\143\230\152\142\229\186\166-", "subCameraAlpha")

function GMHelper:openGoodsShop()
  GUIGMControlPanel:hide()
  GUIStore:show(StoreId.GoodsStore)
end

function GMHelper:openUpgradeShop()
  GUIGMControlPanel:hide()
  GUIUpgradeStore:show(true)
end

function GMHelper:changePlayerActor(sex)
  if isGameStart then
    if sex == 1 then
      ClientHelper.putStringPrefs("BoyActorName", "boy.actor")
      ClientHelper.putStringPrefs("GirlActorName", "boy.actor")
    else
      ClientHelper.putStringPrefs("BoyActorName", "girl.actor")
      ClientHelper.putStringPrefs("GirlActorName", "girl.actor")
    end
  elseif sex == 1 then
    ClientHelper.putStringPrefs("BoyActorName", "boy.actor")
    ClientHelper.putStringPrefs("GirlActorName", "boy.actor")
  else
    ClientHelper.putStringPrefs("BoyActorName", "girl.actor")
    ClientHelper.putStringPrefs("GirlActorName", "girl.actor")
  end
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    if player.Player then
      player.Player.m_isPeopleActor = false
      EngineWorld:restorePlayerActor(player)
    end
  end
end

function GMHelper:changeTeamResourceMode()
  if TeamResourceMode == 1 then
    TeamResourceMode = 2
  else
    TeamResourceMode = 1
  end
end

function GMHelper:openSurvey()
  GUIBedWarSurvey:show(true)
end

function GMHelper:openSurveyDesc()
  GUIBedWarSurveyDesc:show(true)
end

function GMHelper:switchCameraAlpha()
  GameConfig.useTransparentCamera = not GameConfig.useTransparentCamera
  print("IsTransparentCamera =", ClientHelper.getBoolPrefs("IsTransparentCamera"))
  ClientHelper.putBoolPrefs("IsTransparentCamera", GameConfig.useTransparentCamera)
  print("IsTransparentCamera =", GameConfig.useTransparentCamera)
end

function GMHelper:addCameraAlpha()
  GameConfig.specialTransparentAlpha = GameConfig.specialTransparentAlpha + 0.05
  Blockman.Instance():setBlockSpecialTransparentAlpha(GameConfig.specialTransparentAlpha)
  print("SpecialTransparentAlpha =", GameConfig.specialTransparentAlpha)
end

function GMHelper:subCameraAlpha()
  GameConfig.specialTransparentAlpha = GameConfig.specialTransparentAlpha - 0.05
  Blockman.Instance():setBlockSpecialTransparentAlpha(GameConfig.specialTransparentAlpha)
  print("SpecialTransparentAlpha =", GameConfig.specialTransparentAlpha)
end

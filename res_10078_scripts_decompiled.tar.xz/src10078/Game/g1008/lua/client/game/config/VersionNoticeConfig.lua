local config_list = {}
local VersionNoticeConfig = {}

function VersionNoticeConfig:loadConfig()
  local configs = FileUtil.getConfigFromCsv("setting/VersionNotice.csv", nil, true)
  for _, config in pairs(configs) do
    local data = {
      version_code = config.version_code,
      tab_lang = config.tab_lang,
      title_lang = config.title_lang,
      detail_lang = config.detail_lang,
      line_count = tonumber(config.line_count) or 1,
      sort = tonumber(config.sort) or 0,
      is_show = config.is_show == "1",
      is_current = config.is_current == "1"
    }
    table.insert(config_list, data)
  end
  table.sort(config_list, function(a, b)
    return a.sort < b.sort
  end)
end

function VersionNoticeConfig:getAllConfig()
  return config_list
end

VersionNoticeConfig:loadConfig()
return VersionNoticeConfig

local config_list = {}
local QuestionnaireConfig = {}

function QuestionnaireConfig:loadConfig()
  local configs = FileUtil.getConfigFromCsv("setting/Questionnaire.csv")
  for _, config in pairs(configs) do
    local data = {
      id = tonumber(config.id),
      reportKey = config.reportKey,
      showImage = config.showImage,
      mainLang = config.mainLang,
      goodLang = config.goodLang,
      badLang = config.badLang
    }
    table.insert(config_list, data)
  end
  table.sort(config_list, function(a, b)
    return a.id < b.id
  end)
end

function QuestionnaireConfig:getConfigByKey(reportKey)
  for _, config in pairs(config_list) do
    if tostring(reportKey) == config.reportKey then
      return config
    end
  end
end

function QuestionnaireConfig:getAllConfig()
  return config_list
end

QuestionnaireConfig:loadConfig()
return QuestionnaireConfig

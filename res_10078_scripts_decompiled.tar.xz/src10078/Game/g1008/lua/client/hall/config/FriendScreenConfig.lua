local FriendScreenConfig = T(Global, "FriendScreenConfig")
local Items = {}

function FriendScreenConfig:loadConfig()
  local items = FileUtil.getConfigFromCsv("setting/FriendScreen.csv")
  for _, setting in pairs(items) do
    local item = {
      index = tonumber(setting.index),
      mainType = tonumber(setting.mainType),
      subType = tonumber(setting.subType),
      key = setting.key,
      name = setting.name
    }
    if not Items[item.mainType] then
      Items[item.mainType] = {}
    end
    table.insert(Items[item.mainType], item)
  end
  for type, list in pairs(Items) do
    table.sort(list, function(a, b)
      return a.subType < b.subType
    end)
  end
end

function FriendScreenConfig:getListByType(type)
  if Items[type] then
    return TableUtil.copyTable(Items[type])
  end
  return {}
end

local function loadConfig()
  FriendScreenConfig:loadConfig()
end

loadConfig()

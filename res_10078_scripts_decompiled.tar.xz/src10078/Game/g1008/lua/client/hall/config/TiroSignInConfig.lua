local Items = MemoryPool.newTable()
TiroSignInStatus = {
  RECEIVED = 1,
  WAIT_RECEIVE = 2,
  CANT_RECEIVE = 3
}
TiroSignInConfig = {}

function TiroSignInConfig.loadConfig()
  local items = FileUtil.getConfigFromCsv("setting/TiroSignInItemSetting.csv", 3)
  for _, item in pairs(items) do
    table.insert(Items, {
      Id = tonumber(item.Id),
      RewardId = tonumber(item.RewardId),
      Background = item.Background,
      Title = item.Title,
      Size = math.min(tonumber(item.Size), 4),
      Status = TiroSignInStatus.CANT_RECEIVE
    })
  end
  table.sort(Items, function(a, b)
    return a.Id < b.Id
  end)
end

function TiroSignInConfig.updateStatus(id, status)
  for _, item in pairs(Items) do
    if item.Id == id then
      item.Status = status
      break
    end
  end
end

function TiroSignInConfig.getItems()
  return Items
end

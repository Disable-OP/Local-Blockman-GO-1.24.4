local Items = MemoryPool.newTable()
DailySignInStatus = {
  FINISHED = 1,
  SIGN_IN_AGAIN = 2,
  WAIT_SIGN_IN_AGAIN = 3,
  SIGN_IN = 4,
  WAIT_SIGN_IN = 5
}
DailySignInConfig = {}

function DailySignInConfig.loadConfig()
  local items = FileUtil.getConfigFromCsv("setting/DailySignInItemSetting.csv", 3)
  for _, item in pairs(items) do
    table.insert(Items, {
      Id = tonumber(item.Id),
      RewardId = tonumber(item.RewardId),
      Background = item.Background,
      Title = item.Title,
      Size = math.min(tonumber(item.Size), 4),
      Status = DailySignInStatus.WAIT_SIGN_IN
    })
  end
  table.sort(Items, function(a, b)
    return a.Id < b.Id
  end)
end

function DailySignInConfig.updateStatus(id, status)
  for _, item in pairs(Items) do
    if item.Id == id then
      item.Status = status
      break
    end
  end
end

function DailySignInConfig.getItems()
  return Items
end

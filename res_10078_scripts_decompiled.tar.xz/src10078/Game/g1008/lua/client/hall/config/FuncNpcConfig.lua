EntityDefine:registerEntityType(EntityType.ActorNpc, GameActorNpc)
local FuncNpcMap = {}

local function initConfig()
  local config = FileUtil.getConfigFromCsv("setting/FuncNpc.csv")
  for _, item in pairs(config) do
    local pos = VectorUtil.newVector3(item.x, item.y, item.z)
    local entityId = EngineWorld:addActorNpc(pos, tonumber(item.yaw), item.actor, function(entity)
      entity:setSkillName("idle")
      local text = "text=" .. item.name .. "&offset=0:" .. entity:getHeight() + 0.2 .. ":0"
      entity:addCustomText("Name", text, -1, 3.5)
      if item.effect ~= "#" then
        entity:setHaloEffectName(item.effect or "")
      end
    end)
    local entity = EntityCache:getEntity(entityId)
    entity:initConfig(item)
    FuncNpcMap[tostring(entity.entityId)] = entity
  end
end

initConfig()
FuncNpcConfig = {}

function FuncNpcConfig:onPlayerMove(position)
  for _, npc in pairs(FuncNpcMap) do
    npc:onPlayerMove(position)
  end
end

function FuncNpcConfig:getFuncNpc(key, value)
  for _, npc in pairs(FuncNpcMap) do
    if npc[key] == value then
      return npc
    end
  end
end

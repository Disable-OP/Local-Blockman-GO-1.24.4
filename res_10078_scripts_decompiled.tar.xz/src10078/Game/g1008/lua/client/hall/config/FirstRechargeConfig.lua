local Rewards = MemoryPool.newTable()
FirstRechargeConfig = {}

function FirstRechargeConfig.loadConfig()
  local rewards = FileUtil.getConfigFromCsv("setting/FirstRechargeRewardSetting.csv", 3)
  for _, reward in pairs(rewards) do
    table.insert(Rewards, {
      Id = tonumber(reward.Id),
      RewardId = tonumber(reward.RewardId)
    })
  end
  table.sort(Rewards, function(a, b)
    return a.Id < b.Id
  end)
end

function FirstRechargeConfig.getRewards()
  return Rewards
end

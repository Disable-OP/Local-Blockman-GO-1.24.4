local Rewards = MemoryPool.newTable()
SuperPlayerConfig = {}

function SuperPlayerConfig.loadConfig()
  local rewards = FileUtil.getConfigFromCsv("setting/SuperPlayerRewardSetting.csv", 3)
  for _, reward in pairs(rewards) do
    table.insert(Rewards, {
      Id = tonumber(reward.Id),
      RewardId = tonumber(reward.RewardId),
      Type = tonumber(reward.Type)
    })
  end
  table.sort(Rewards, function(a, b)
    return a.Id < b.Id
  end)
end

function SuperPlayerConfig.getRewardsByType(type)
  local result = {}
  for _, reward in pairs(Rewards) do
    if reward.Type == type then
      table.insert(result, reward)
    end
  end
  return result
end

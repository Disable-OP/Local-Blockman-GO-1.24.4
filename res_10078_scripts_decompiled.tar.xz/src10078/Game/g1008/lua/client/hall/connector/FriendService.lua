local FriendService = T(Global, "FriendService")

function FriendService:onPrivateMsg(_, _, data)
  Events.FriendOperationClientEvent:invoke(data.data.operation, data.sendId)
  local user = UserManager.Instance():findUser(data.sendId)
  if not user then
    return
  end
  local operation = data.data.operation
  if operation == Define.FriendOperationType.Agree then
    user.isSend = false
    user.isFriend = true
    user.isFriendRequest = false
  elseif operation == Define.FriendOperationType.Refuse then
    user.isSend = false
    user.isFriend = false
    user.isFriendRequest = false
  elseif operation == Define.FriendOperationType.Delete then
    user.isSend = false
    user.isFriend = false
    user.isFriendRequest = false
  elseif operation == Define.FriendOperationType.Request then
    user.isSend = false
    user.isFriendRequest = true
  end
  UserManager.Instance():updateUserList(3)
end

function FriendService:onTeamMsg(_, _, data)
end

function FriendService:onGameMsg(_, _, data)
end

function FriendService:onWorldMsg(_, _, data)
end

function FriendService:sendFriendOperation(targetId, operation)
  if Platform.isWindow() then
    local MessageService = T(Global, "MessageService")
    MessageService:sendMsgToPrivate(targetId, Define.FriendMsgType.FriendMsg, {operation = operation})
  end
end

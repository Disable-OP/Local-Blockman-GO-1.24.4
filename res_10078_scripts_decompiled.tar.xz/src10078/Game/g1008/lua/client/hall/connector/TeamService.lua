local TeamService = class("TeamService", require("engine_base.connector.IConnectorMsgHandler"))
local ConnectorCenter = T(Global, "ConnectorCenter")
local ConnectorDispatch = T(Global, "ConnectorDispatch")
local UIUtils = T(Global, "UIUtils")
local Game2ConnectorMsgType = {
  CreateTeam = 20001,
  JoinTeam = 20002,
  LeaveTeam = 20003,
  TeamInvite = 20004,
  RejectionInvite = 20005,
  KickOutTeam = 20006,
  TeammateInviteStatus = 20007,
  StartGame = 20008,
  CancelStartGame = 20009,
  UpdateTeamMemberInfo = 20101
}
local Connector2GameMsgType = {
  TeamInvite = 20011,
  RejectionInvite = 20012,
  CreateTeam = 20013,
  JoinTeamFailed = 20014,
  UserJoinTeam = 20015,
  JoinTeam = 20016,
  UserLeaveTeam = 20017,
  LeaveTeam = 20018,
  TeammateInviteStatus = 20019,
  OwnerChange = 20020,
  StartGame = 20021,
  CancelStartGame = 20022,
  UpdateTeamMemberInfo = 20201
}

local function buildTeamUserInfo()
  local clientInfo = json.decode(HostApi.getClientInfo())
  local cache = UserInfoCache:GetCache(Game:getPlatformUserId())
  local user = UserManager.Instance():findUser(Game:getPlatformUserId())
  local info = {
    userId = Game:getPlatformUserId(),
    name = StringUtil.getRealName(cache and cache.name or CGame.Instance():getPlayerName()),
    colorfulNickName = cache and cache.colorfulNickName,
    picUrl = cache and cache.picUrl or CGame.Instance():getPicUrl(),
    country = cache and cache.country or user and user.country or "US",
    language = cache and cache.language or user and user.language or "en",
    sex = cache and cache.sex or user and user.sex or 1,
    curHeadFrame = cache and cache.curHeadFrame or 0,
    status = Define.UserStatus.InTeam,
    packageName = clientInfo.package_name,
    appVersion = clientInfo.app_version,
    platform = clientInfo.platform,
    regionId = Game:getRegionId()
  }
  return json.encode(info)
end

function TeamService:init()
  self.range = {20000, 29999}
  self.joinTeamCd = self.joinTeamCd or {}
  self.token = nil
  self.teamId = 0
  self.regionId = 0
  self.ownerId = 0
  self.infoList = {}
  self.gameType = nil
  self.engineVersion = 0
  self.gameMode = 0
  self.maxMember = 4
  self.isMatching = false
  self.applyList = {}
  self.inviteList = self.inviteList or {}
  self.teammateInviteSwitch = false
end

function TeamService:initMsgFunc()
  self:registerMsgFunc(Connector2GameMsgType.TeamInvite, self.onTeamInvite)
  self:registerMsgFunc(Connector2GameMsgType.RejectionInvite, self.onRejectionInvite)
  self:registerMsgFunc(Connector2GameMsgType.CreateTeam, self.onCreateTeam)
  self:registerMsgFunc(Connector2GameMsgType.JoinTeamFailed, self.onJoinTeamFailed)
  self:registerMsgFunc(Connector2GameMsgType.UserJoinTeam, self.onUserJoinTeam)
  self:registerMsgFunc(Connector2GameMsgType.JoinTeam, self.onJoinTeam)
  self:registerMsgFunc(Connector2GameMsgType.UserLeaveTeam, self.onUserLeaveTeam)
  self:registerMsgFunc(Connector2GameMsgType.LeaveTeam, self.onLeaveTeam)
  self:registerMsgFunc(Connector2GameMsgType.TeammateInviteStatus, self.onTeammateInviteStatus)
  self:registerMsgFunc(Connector2GameMsgType.OwnerChange, self.onOwnerChange)
  self:registerMsgFunc(Connector2GameMsgType.StartGame, self.onStartGame)
  self:registerMsgFunc(Connector2GameMsgType.CancelStartGame, self.onCancelStartGame)
  self:registerMsgFunc(Connector2GameMsgType.UpdateTeamMemberInfo, self.onUpdateTeamMemberInfo)
end

function TeamService:isOwner()
  return self.ownerId == Game:getPlatformUserId()
end

function TeamService:isInTeam(userId)
  for _, info in pairs(self.infoList) do
    if info.userId == userId then
      return true
    end
  end
  return false
end

function TeamService:removeTeammate(userId)
  for pos, info in pairs(self.infoList) do
    if info.userId == userId then
      table.remove(self.infoList, pos)
      break
    end
  end
end

function TeamService:getOwnerInfo()
  return UserInfoCache:GetCache(self.ownerId)
end

function TeamService:getTeammateCount()
  return #self.infoList
end

function TeamService:getMaxMember()
  return self.maxMember
end

function TeamService:getTeammateInfo(index)
  local info = self.infoList[index]
  if not info then
    return nil
  end
  return UserInfoCache:GetCache(info.userId)
end

function TeamService:getApplyList()
  local infoList = {}
  for _, userId in pairs(self.applyList) do
    table.insert(infoList, UserInfoCache:GetCache(userId))
  end
  return infoList
end

function TeamService:getInviteList(isAll)
  if isAll then
    return self.inviteList
  end
  local list = {}
  for _, inviteItem in pairs(self.inviteList) do
    if inviteItem.operate == Define.TeamInviteOperate.None then
      table.insert(list, inviteItem)
    end
  end
  return list
end

function TeamService:changeTeamInviteOperate(inviteData, operate)
  inviteData.operate = operate
  local count = 0
  for _, data in pairs(self.inviteList) do
    if data.operate == nil then
      count = count + 1
    end
  end
  UIUtils.updateRedDotCount(Define.RedDotKey.TeamInvite, count)
end

function TeamService:onCreateTeam(_, _, data)
  self:onJoinTeam(_, _, data)
end

function TeamService:onJoinTeamFailed(_, _, data)
  if data.code then
    CustomDialog.builder().setContentText(Lang:getString("gui.join.team.failed." .. data.code)).setHideLeftButton().show()
  end
end

function TeamService:onJoinTeam(_, _, data)
  self.teamId = data.teamId
  self.ownerId = data.ownerId
  for _, info in pairs(data.infoList or {}) do
    info = json.decode(info)
    table.insert(self.infoList, info)
  end
  UserInfoCache:UpdateUserInfos(self.infoList)
  self.gameType = data.gameType
  self.engineVersion = data.engineVersion
  self.gameMode = data.gameMode
  self.maxMember = data.maxMember or 4
  self.teammateInviteSwitch = data.switch or false
  self.token = data.token
  self.regionId = data.regionId
  Events.JoinTeamEvent:invoke()
end

function TeamService:onLeaveTeam(_, _, data)
  self:init()
  local ChatClient = T(Global, "ChatClient")
  ChatClient:clearMsgCache("team")
  Events.LeaveTeamEvent:invoke()
end

function TeamService:onUserJoinTeam(_, _, data)
  local info = json.decode(data.info)
  table.insert(self.infoList, info)
  UserInfoCache:UpdateUserInfos({info})
  Events.UserJoinTeamEvent:invoke(info.userId)
end

function TeamService:onUserLeaveTeam(_, _, data)
  self:removeTeammate(data.userId)
  Events.UserLeaveTeamEvent:invoke(data.userId)
end

function TeamService:onTeammateInviteStatus(_, _, data)
  self.teammateInviteSwitch = data.switch
  Events.TeammateInviteStatusEvent:invoke(self.teammateInviteSwitch)
end

function TeamService:onOwnerChange(_, _, data)
  self.ownerId = data.ownerId
  Events.TeamOwnerChangeEvent:invoke()
end

function TeamService:onStartGame(_, _, data)
  if Game.EnableIndie then
    if ClientHelper.getBoolForKey("isNewEquipment", false) and ClientHelper.getStringForKey("NewEquipmentStep", "4") == Define.NewEquipmentStep.CreateTeam then
      ClientHelper.dataReport("bw_funnel_3_" .. Define.FunnelPathMap[self.gameType], "")
      ClientHelper.putStringForKey("NewEquipmentStep", Define.NewEquipmentStep.StartGame)
    end
    if self:isOwner() and ClientHelper.getStringForKey("CreateTeamFunnelStep", "0") == Define.CreateTeamFunnelStep.SendStart then
      if ClientHelper.getBoolForKey("isNewEquipment", false) then
        ClientHelper.dataReport("bw_start_game", "")
      else
        ClientHelper.dataReport("bw_old_start_game", "")
      end
      ClientHelper.putStringForKey("CreateTeamFunnelStep", Define.CreateTeamFunnelStep.StartGame)
    end
  end
  CustomDialog.builder().setContentText(Lang:getString("gui.start.game.tip")).setHideRightButton().setLeftClickListener(function()
    self:sendCancelStartGame()
  end).setCloseVisible(false).show()
end

function TeamService:onCancelStartGame(_, _, data)
  self.isMatching = false
  CustomDialog.hide()
  Events.TeamCancelStartGameEvent:invoke(data.userId or self.ownerId)
end

function TeamService:onTeamInvite(_, _, data)
  if ClientHelper.getBoolForKey("NotReceiveTeamInvite") then
    return
  end
  table.insert(self.inviteList, 1, data)
  UserInfoCache:UpdateUserInfos({
    json.decode(data.info)
  })
  data.info = UserInfoCache:GetCache(data.userId)
  self:changeTeamInviteOperate(data, Define.TeamInviteOperate.None)
  if ClientHelper.getBoolForKey("NotTipTeamInvite") then
    return
  end
  Events.ReceiveTeamInviteEvent:invoke(data)
end

function TeamService:isHasInvite()
  return #self.inviteList > 0
end

function TeamService:onRejectionInvite(_, _, data)
  Events.RejectionTeamInviteEvent:invoke(data.userId)
end

function TeamService:onTeamApply(_, _, data)
  if TableUtil.tableContain(self.applyList, data.userId) then
    return
  end
  table.insert(self.applyList, data.userId)
  UserInfoCache:GetCacheByUserIds({
    data.userId
  }, function()
    Events.ReceiveTeamApplyEvent:invoke(data)
  end)
end

function TeamService:onUpdateTeamMemberInfo(_, _, data)
  local info = json.decode(data.info)
  info.userId = data.userId
  UserInfoCache:UpdateUserInfos({info})
  Events.HeadFrameChangeEvent:invoke(data.userId)
end

function TeamService:sendCreateTeam(gameType)
  if self:isInTeam(Game:getPlatformUserId()) then
    return
  end
  gameType = gameType or "g1008"
  local data = {
    ownerId = Game:getPlatformUserId(),
    info = buildTeamUserInfo(),
    gameType = gameType,
    engineVersion = EngineVersionSetting.getEngineVersion(),
    gameMode = nil,
    regionId = Game:getRegionId()
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.CreateTeam, data)
  if ClientHelper.getStringForKey("CreateTeamFunnelStep", "0") == "0" then
    if ClientHelper.getBoolForKey("isNewEquipment", false) then
      ClientHelper.dataReport("bw_click_start", "")
    else
      ClientHelper.dataReport("bw_old_click_start", "")
    end
    ClientHelper.putStringForKey("CreateTeamFunnelStep", Define.CreateTeamFunnelStep.ClickStart)
  end
end

function TeamService:sendJoinTeam(teamId, token, regionId, engineVersion)
  engineVersion = engineVersion or EngineVersionSetting.getEngineVersion()
  if EngineVersionSetting.getEngineVersion() ~= engineVersion then
    CustomDialog.builder().setContentText(Lang:getString("gui.loading.page.check.version.failure")).setHideLeftButton().show()
    return true
  end
  if self.teamId == teamId then
    UIHelper.showToast(Lang:getString("gui.join.in.team.tip"))
    return false
  end
  if self.joinTeamCd[teamId] and os.time() - self.joinTeamCd[teamId] < 30 then
    UIHelper.showToast(Lang:getString("gui.join.team.cd"))
    return false
  end
  self.joinTeamCd[teamId] = os.time()
  local data = {
    userId = Game:getPlatformUserId(),
    teamId = teamId,
    token = token,
    info = buildTeamUserInfo(),
    regionId = regionId
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.JoinTeam, data)
  return true
end

function TeamService:sendLeaveTeam()
  if not self:isInTeam(Game:getPlatformUserId()) then
    return
  end
  local data = {
    userId = Game:getPlatformUserId(),
    teamId = self.teamId,
    regionId = self.regionId
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.LeaveTeam, data)
end

function TeamService:sendTeammateInviteStatus()
  if not self:isOwner() then
    return
  end
  local data = {
    teamId = self.teamId,
    regionId = self.regionId,
    switch = not self.teammateInviteSwitch
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.TeammateInviteStatus, data)
end

function TeamService:sendTeamInvite(userId)
  if not self:canSendInvite() then
    return
  end
  local data = {
    userId = userId,
    teamId = self.teamId,
    regionId = self.regionId
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.TeamInvite, data)
end

function TeamService:sendRejectionInvite(userId, teamId, regionId)
  local data = {
    userId = userId,
    teamId = teamId,
    regionId = regionId
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.RejectionInvite, data)
end

function TeamService:canSendInvite()
  if self:isOwner() then
    return true
  end
  return self.teammateInviteSwitch
end

function TeamService:buildTeamInviteContentData(msg)
  local result = {
    gameType = self.gameType,
    teamId = self.teamId,
    memberCount = #self.infoList .. "/" .. self.maxMember,
    msg = msg,
    token = self.token,
    regionId = self.regionId,
    engineVersion = self.engineVersion
  }
  return result
end

function TeamService:setStartMatch()
  self.isMatching = true
end

function TeamService:sendStartGame()
  if not self:isOwner() then
    return
  end
  if not self.isMatching then
    return
  end
  local data = {
    teamId = self.teamId,
    regionId = self.regionId
  }
  if Game.EnableIndie and ClientHelper.getStringForKey("CreateTeamFunnelStep", "0") == Define.CreateTeamFunnelStep.CreateTeam then
    if ClientHelper.getBoolForKey("isNewEquipment", false) then
      ClientHelper.dataReport("bw_send_start", "")
    else
      ClientHelper.dataReport("bw_old_send_start", "")
    end
    ClientHelper.putStringForKey("CreateTeamFunnelStep", Define.CreateTeamFunnelStep.SendStart)
  end
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.StartGame, data)
end

function TeamService:sendCancelStartGame()
  local data = {
    teamId = self.teamId,
    regionId = self.regionId
  }
  self.isMatching = false
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.CancelStartGame, data)
end

function TeamService:agreeApply(userId)
  if not self:isOwner() then
    return
  end
  TableUtil.tableRemove(self.applyList, userId)
  local info = {userId = userId}
  local data = {
    userId = userId,
    teamId = self.teamId,
    info = json.encode(info),
    regionId = self.regionId
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.JoinTeam, data)
end

function TeamService:rejectionApply(userId)
  if not self:isOwner() then
    return
  end
  TableUtil.tableRemove(self.applyList, userId)
end

function TeamService:kickOutTeammate(userId)
  if not self:isOwner() then
    return
  end
  local data = {
    userId = userId,
    teamId = self.teamId,
    regionId = self.regionId
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.KickOutTeam, data)
end

function TeamService:setNotTipInvite(notTip)
  ClientHelper.putBoolForKey("NotTipTeamInvite", notTip)
end

function TeamService:setNotReceiveInvite(notReceive)
  ClientHelper.putBoolForKey("NotReceiveTeamInvite", notReceive)
end

function TeamService:updateTeamMemberInfo()
  local data = {
    teamId = self.teamId,
    regionId = self.regionId,
    info = buildTeamUserInfo()
  }
  ConnectorCenter:sendMsg(Game2ConnectorMsgType.UpdateTeamMemberInfo, data)
end

ConnectorDispatch:registerHandler(T(Global, "TeamService", TeamService.new()))

local GameService = class("GameService", require("engine_base.connector.IConnectorMsgHandler"))
local ConnectorDispatch = T(Global, "ConnectorDispatch")
local Connector2GameMsgType = {TeamStartGameSuccess = 40103, TeamStartGameFailed = 40113}

function GameService:init()
  self.range = {40000, 49999}
end

function GameService:initMsgFunc()
  self:registerMsgFunc(Connector2GameMsgType.TeamStartGameSuccess, self.onTeamStartGameSuccess)
  self:registerMsgFunc(Connector2GameMsgType.TeamStartGameFailed, self.onTeamStartGameFailed)
end

function GameService:onTeamStartGameSuccess(_, _, data)
  local TeamService = T(Global, "TeamService")
  local ip = isLocalWin and "127.0.0.1" or StringUtil.split(data.gaddr, ":")[1]
  local port = StringUtil.split(data.gaddr, ":")[2]
  local gameType = TeamService.gameType or "g1008"
  local builder = DataBuilder.new()
  builder:addParam("ip", ip)
  builder:addParam("port", port)
  builder:addParam("mapId", data.mid)
  builder:addParam("mapUrl", data.downurl)
  builder:addParam("requestId", data.requestId)
  builder:addParam("gameType", gameType)
  GamePacketSender:sendBedWarStartGame(gameType)
  CGame.Instance():resetGame2(builder:getData())
end

function GameService:onTeamStartGameFailed(_, _, data)
  local TeamService = T(Global, "TeamService")
  TeamService:sendStartGame()
end

ConnectorDispatch:registerHandler(T(Global, "GameService", GameService.new()))

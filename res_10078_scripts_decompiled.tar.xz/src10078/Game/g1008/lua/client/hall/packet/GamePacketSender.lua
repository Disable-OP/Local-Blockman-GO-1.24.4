GamePacketSender = {}

function GamePacketSender:sendReceiveFirstRecharge()
  PacketSender:sendLuaCommonData("ReceiveFirstRecharge", "")
end

function GamePacketSender:sendReceiveTiroSignIn()
  PacketSender:sendLuaCommonData("ReceiveTiroSignIn", "")
end

function GamePacketSender:sendReceiveSuperPlayer()
  PacketSender:sendLuaCommonData("ReceiveSuperPlayer", "")
end

function GamePacketSender:sendReceiveDailySignIn(id)
  local data = DataBuilder.new():addParam("Id", id):getData()
  PacketSender:sendLuaCommonData("ReceiveDailySignIn", data)
end

function GamePacketSender:sendBedWarStartGame(gameType)
  PacketSender:sendLuaCommonData("StartGame", gameType)
end

function GamePacketSender:sendBedWarLicenseGetReward(rewardId, Lv, rewardType, season, getAll)
  local data = DataBuilder.new():addParam("rewardId", rewardId):addParam("getAll", getAll):addParam("rewardType", rewardType):addParam("season", season):addParam("Lv", Lv):getData()
  PacketSender:sendLuaCommonData("LicenseReceiveReward", data)
end

function GamePacketSender:sendBedWarLicenseBuyLevel(season, level, free)
  local data = DataBuilder.new():addParam("season", season):addParam("level", level):addParam("free", free):getData()
  PacketSender:sendLuaCommonData("LicenseBuyLevel", data)
end

function GamePacketSender:sendBedWarLicenseBuyLicense(season, buyType)
  local data = DataBuilder.new():addParam("season", season):addParam("buyType", buyType):getData()
  PacketSender:sendLuaCommonData("LicenseBuyLicense", data)
end

function GamePacketSender:sendBedWarLicenseExchange(season, itemId, rewardNum)
  local data = DataBuilder.new():addParam("season", season):addParam("itemId", itemId):addParam("rewardNum", rewardNum):getData()
  PacketSender:sendLuaCommonData("LicenseExchangeReward", data)
end

function GamePacketSender:sendBedWarLicenseReceiveTaskReward(taskId)
  local data = DataBuilder.new():addParam("taskId", taskId):getData()
  PacketSender:sendLuaCommonData("LicenseReceiveTaskReward", data)
end

function GamePacketSender:sendChatMessage(text)
  local param = {text = text}
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData("Chat", data)
end

function GamePacketSender:sendConfirmSignInAgainByTicket(id, useTicket)
  local data = DataBuilder.new():addParam("id", id):addParam("useTicket", useTicket):getData()
  PacketSender:sendLuaCommonData("SignInAgain", data)
end

function GamePacketSender:sendBuyHeadFrame(goodsId)
  PacketSender:sendLuaCommonData("BuyHeadFrame", tostring(goodsId))
end

function GamePacketSender:sendEquipHeadFrame(goodsId)
  PacketSender:sendLuaCommonData("EquipHeadFrame", tostring(goodsId))
end

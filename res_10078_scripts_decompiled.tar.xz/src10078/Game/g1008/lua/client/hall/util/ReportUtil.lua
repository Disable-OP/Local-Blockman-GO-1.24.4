ReportUtil = {}

function ReportUtil.getPlayerLevelInterval()
  local level = GUIBedWarHallToolBar:getPlayerLevel()
  if level == 1 then
    return "1"
  elseif level == 2 then
    return "2"
  elseif 3 <= level and level <= 7 then
    return "3_7"
  elseif 8 <= level and level <= 15 then
    return "8_15"
  elseif 16 <= level then
    return "16"
  end
end

function ReportUtil.reportClickFirstRecharge(currentId)
  GameAnalytics:design(1, {
    "H_first_recharge",
    tostring(currentId)
  })
end

function ReportUtil.reportBuyFirstRecharge(currentId)
  GameAnalytics:design(1, {
    "H_first_recharge_buy",
    tostring(currentId)
  })
end

function ReportUtil.reportGetFirstRecharge(currentId)
  GameAnalytics:design(1, {
    "H_first_recharge_get",
    tostring(currentId)
  })
end

function ReportUtil.reportCustomShopPage(tabId)
  GameAnalytics:design(1, {
    "H_custom_shop_page",
    tostring(tabId)
  })
end

function ReportUtil.reportCustomShopSelect(goodsId)
  GameAnalytics:design(1, {
    "H_custom_shop_sel",
    tostring(goodsId)
  })
end

function ReportUtil.reportCustomShopBuy(buttonName, goodsId)
  GameAnalytics:design(1, {
    "H_custom_shop_buy",
    buttonName,
    tostring(goodsId)
  })
end

function ReportUtil.reportCustomShopEquip(goodsId)
  GameAnalytics:design(1, {
    "H_custom_shop_equip",
    tostring(goodsId)
  })
end

function ReportUtil.reportCustomShopUnload(goodsId)
  GameAnalytics:design(1, {
    "H_custom_shop_unload",
    tostring(goodsId)
  })
end

function ReportUtil.reportBlockShopPage(tabId)
  GameAnalytics:design(1, {
    "H_block_shop_page",
    tostring(tabId)
  })
end

function ReportUtil.reportBlockShopSelect(goodsId)
  GameAnalytics:design(1, {
    "H_block_shop_sel",
    tostring(goodsId)
  })
end

function ReportUtil.reportBlockShopBuy(buttonName, goodsId)
  GameAnalytics:design(1, {
    "H_block_shop_buy",
    buttonName,
    tostring(goodsId)
  })
end

function ReportUtil.reportBlockShopEquip(goodsId)
  GameAnalytics:design(1, {
    "H_block_shop_equip",
    tostring(goodsId)
  })
end

function ReportUtil.reportBlockShopUnload(goodsId)
  GameAnalytics:design(1, {
    "H_block_shop_unload",
    tostring(goodsId)
  })
end

function ReportUtil.reportIndieClick(seq)
  GameAnalytics:design(1, {
    "BedWar_Indie_Click",
    tostring(seq)
  })
end

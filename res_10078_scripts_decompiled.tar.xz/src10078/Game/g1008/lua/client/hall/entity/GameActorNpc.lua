GameActorNpc = class("GameFuncNpc", IEntity)
local CHEST_LOTTERY = 15
local BED_WAR_SEASON_RANK = 20
local PERSONAL_MAIN_PAGE = 21
local BED_WAR_RUNE = 22
local MODEL_SELECT = 23

function GameActorNpc:initConfig(config)
  self.type = tonumber(config.type)
  local params = StringUtil.split(config.extra, "#")
  self.param1 = params[1] or ""
  self.param2 = tonumber(params[2]) or 0
  self.hint = tostring(config.hint)
  self.isUserIn = false
  self:initArea(tonumber(config.range) or 1)
end

function GameActorNpc:initArea(range)
  local pos = self.entity.position
  self.minX = pos.x - range
  self.maxX = pos.x + range
  self.minY = pos.y - range
  self.maxY = pos.y + range
  self.minZ = pos.z - range
  self.maxZ = pos.z + range
end

function GameActorNpc:inArea(position)
  return position.x >= self.minX and position.x <= self.maxX and position.y >= self.minY and position.y <= self.maxY and position.z >= self.minZ and position.z <= self.maxZ
end

function GameActorNpc:onPlayerMove(position)
  if self:inArea(position) then
    if not self.isUserIn then
      self.isUserIn = true
      self:onPlayerEnter()
    end
  else
    self.isUserIn = false
  end
end

function GameActorNpc:onPlayerEnter()
  self:onCallFunc()
end

function GameActorNpc:onPlayerClick()
  self:onCallFunc()
end

function GameActorNpc:onCallFunc()
  if self.type == MODEL_SELECT then
    if GUIBedWarHallToolBar:getPlayerLevel() >= self.param2 then
      GUICustomDialog:showStartGame(self.hint, self.param1)
    else
      GUICustomDialog:showLevelLimit(self.param2)
    end
  elseif self.type == CHEST_LOTTERY then
    GUIBoxLottery:show()
  elseif self.type == BED_WAR_SEASON_RANK then
    GUIManager:showWindowByName("BedWarSeasonRank.json")
  elseif self.type == PERSONAL_MAIN_PAGE then
    GUIPersonalHomePageLayout:openPersonalHomePageByUserId(Game:getPlatformUserId())
  elseif self.type == BED_WAR_RUNE then
    GUIManager:showWindowByName("BedWarRune.json")
  end
end

local HeadFrameShop = T(Global, "HeadFrameShop")
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
local HeadFrameShopConfig = T(Global, "HeadFrameShopConfig")
local ownHeadFrame = {}
local TeamService = T(Global, "TeamService")

function HeadFrameShop:init()
  self.curHeadFrame = 0
  EventObservable:registerDataCallBack("HeadFrameDataData", function(data)
    HeadFrameShop:updateData(data)
  end, JsonBuilderProcessor)
  EventObservable:registerDataCallBack("BuyHeadFrameSuccess", function(data)
    HeadFrameShop:updateData(data)
  end, JsonBuilderProcessor)
  EventObservable:registerDataCallBack("EquipHeadFrameSuccess", function(data)
    HeadFrameShop:updateEquipData(data)
  end, DataBuilderProcessor)
  PlayerCustomInfoUtil:getPlayerAllCustomInfo(Game:getPlatformUserId(), function()
    local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
    if userInfo and userInfo[Define.PlayerCustomInfo.CurHeadFrame] then
      self.curHeadFrame = userInfo[Define.PlayerCustomInfo.CurHeadFrame]
      Events.HeadFrameChangeEvent:invoke(Game:getPlatformUserId())
    end
  end)
end

HeadFrameShop:init()

function HeadFrameShop:onBuyGoods(goods)
  if not HeadFrameShopConfig:getShopConfigById(goods.Id) then
    return
  end
  PayHelper.checkMoney(goods.CoinId, goods.Price, function(canBuy)
  end)
  GamePacketSender:sendBuyHeadFrame(goods.Id)
end

function HeadFrameShop:onEquipGoods(goods)
  if not HeadFrameShopConfig:getShopConfigById(goods.Id) then
    return
  end
  local id = 0
  if not goods.Default then
    local reward = RewardConfig.findRewardById(tonumber(goods.RewardId))
    if not reward or not ownHeadFrame[tostring(reward.RewardId)] then
      return
    end
    id = reward.RewardId
  end
  if self.curHeadFrame == id then
    return
  end
  GamePacketSender:sendEquipHeadFrame(goods.Id)
  HeadFrameShop:updateShopView()
end

function HeadFrameShop:updateData(data)
  for _, id in pairs(data) do
    ownHeadFrame[tostring(id)] = true
    Events.HeadFrameItemStatusEvent:invoke(id)
  end
  HeadFrameShop:updateShopView()
end

function HeadFrameShop:checkHeadFrameStatus(id)
  return ownHeadFrame[tostring(id)] or false
end

function HeadFrameShop:updateShopView()
  if GUIBedWarPictureFrameShopLayout then
    GUIBedWarPictureFrameShopLayout:updateListUI()
  end
end

function HeadFrameShop:updateEquipData(data)
  local id = data:getNumberParam("id")
  if id ~= 0 and not ownHeadFrame[tostring(id)] then
    return
  end
  self.curHeadFrame = id
  HeadFrameShop:updateShopView()
  local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
  if userInfo then
    userInfo[Define.PlayerCustomInfo.CurHeadFrame] = self.curHeadFrame
  end
  if TeamService:isInTeam(Game:getPlatformUserId()) then
    TeamService:updateTeamMemberInfo()
  end
  Events.HeadFrameChangeEvent:invoke(Game:getPlatformUserId())
end

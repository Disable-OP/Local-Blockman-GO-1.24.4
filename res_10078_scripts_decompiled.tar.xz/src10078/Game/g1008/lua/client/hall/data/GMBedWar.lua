local TeamService = T(Global, "TeamService")
local ChatClient = T(Global, "ChatClient")
GMSetting:addTab("\232\181\183\229\186\138\230\136\152\228\186\137", 1)
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\184\133\233\153\164\233\146\165\229\140\153", "cleanYaoShi")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\137\147\229\188\128\229\174\154\229\136\182\229\149\134\229\186\151", "openCustomShop")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\232\167\130\229\189\177\229\136\184+1000", "addMovieTicket")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\233\135\141\231\189\174\229\185\191\229\145\138\230\172\161\230\149\176", "resetADTimes")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\233\128\154\231\148\168\231\162\142\231\137\135+10000", "addCommonChip")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\233\128\154\231\148\168\231\162\142\231\137\135\230\184\133\231\169\186", "clearCommonChip")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\137\147\229\188\128\228\184\170\228\186\186\228\184\187\233\161\181", "openPersonalHomePage")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\230\137\147\229\188\128\230\151\167\231\137\136\232\129\138\229\164\169\231\149\140\233\157\162", "openChatPage")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "+50\231\187\143\233\170\140", "addExp")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\232\174\190\231\189\174\228\184\186\230\150\176\232\174\190\229\164\135\231\142\169\229\174\182", "setNewPlayer")
GMSetting:addItem("\232\181\183\229\186\138\230\136\152\228\186\137", "\232\174\190\231\189\174\228\184\186\232\128\129\231\142\169\229\174\182", "setOldPlayer")
GMSetting:addTab("\231\187\132\233\152\159\231\155\184\229\133\179")
GMSetting:addItem("\231\187\132\233\152\159\231\155\184\229\133\179", "\229\136\155\229\187\186\231\187\132\233\152\159", "createTeam")
GMSetting:addItem("\231\187\132\233\152\159\231\155\184\229\133\179", "\230\137\147\229\188\128\231\187\132\233\152\159\233\161\181\233\157\162", "openCreateTeam")
GMSetting:addItem("\231\187\132\233\152\159\231\155\184\229\133\179", "\230\181\139\232\175\149\233\130\128\232\175\183UI", "sendTestInvite")
GMSetting:addItem("\231\187\132\233\152\159\231\155\184\229\133\179", "\230\137\147\229\188\128\233\130\128\232\175\183\229\136\151\232\161\168", "openInviteList")
GMSetting:addTab("\232\129\138\229\164\169\230\181\139\232\175\149")
GMSetting:addItem("\232\129\138\229\164\169\230\181\139\232\175\149", "\229\143\145\233\128\129\230\181\139\232\175\149\232\129\138\229\164\169", "sendTestChat")
GMSetting:addItem("\232\129\138\229\164\169\230\181\139\232\175\149", "\229\143\145\233\128\129\229\144\140\230\156\141\232\129\138\229\164\169", "sendSameServerChat")
GMSetting:addItem("\232\129\138\229\164\169\230\181\139\232\175\149", "\230\137\147\229\188\128\232\129\138\229\164\169", "openChatWin")
GMSetting:addItem("\232\129\138\229\164\169\230\181\139\232\175\149", "\232\129\138\229\164\169\232\174\176\229\189\149(112)", "showChatRecord", 112)
GMSetting:addItem("\232\129\138\229\164\169\230\181\139\232\175\149", "\232\129\138\229\164\169\232\174\176\229\189\149(144)", "showChatRecord", 144)
GMSetting:addTab("\229\185\191\229\145\138\230\181\139\232\175\149")
GMSetting:addItem("\229\185\191\229\145\138\230\181\139\232\175\149", "\233\162\134\229\143\150\229\174\157\231\174\177\229\185\191\229\145\138", "receiveAdReward", 104601)

function GMHelper:openCustomShop()
  GUIGMControlPanel:hide()
  GUICustomShop:show(true)
end

function GMHelper:createTeam()
  GUIGMControlPanel:hide()
  TeamService:sendCreateTeam()
end

function GMHelper:openCreateTeam()
  GUIGMControlPanel:hide()
  GUIHallCreateTeamLayout:show()
end

function GMHelper:sendTestInvite()
  TeamService:onTeamInvite(nil, nil, {
    ownerId = Game:getPlatformUserId(),
    userId = Game:getPlatformUserId()
  })
end

function GMHelper:openInviteList()
  GUICreateTeamInviteListLayout:show()
end

function GMHelper:sendTestChat()
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    if player.userId ~= Game:getPlatformUserId() then
      ChatClient:sendTextMsgToTarget(player.userId, "This is test msg.")
    end
  end
end

function GMHelper:sendSameServerChat()
  ChatClient:sendTextMsgToSameServer("This is test msg.")
end

function GMHelper:openChatWin()
  GUIBedWarHallChatLayout:show()
end

function GMHelper:openPersonalHomePage()
  GUIPersonalHomePageLayout:show()
end

function GMHelper:showChatRecord(chatId)
  ChatClient:getPrivateMsgCache(chatId, nil, function(chatMsgList)
    LogUtil.pv(chatMsgList)
  end)
end

function GMHelper:openChatPage()
  GUIManager:showWindowByName("Chat.json")
end

function GMHelper:setNewPlayer()
  GameListener.onGameActionTriggerEvent(CDefine.GameActionType.GAME_ACTION_REPORT_NEW_PLAYER, "true")
end

function GMHelper:setOldPlayer()
  GameListener.onGameActionTriggerEvent(CDefine.GameActionType.GAME_ACTION_REPORT_NEW_PLAYER, "false")
end

require("common.web.BedWarWeb")
BaseListener.registerCallBack(CEvents.GameInitEvent, function(config)
  if BaseMain:getGameType() == "g1046" then
    require("hall.BedWarClient")
  else
    require("game.BedWarClient")
  end
  BedWarClient.onGameInit()
  local deviation = 3
  local intensity = 2.6
  local saturation = 1
  Blockman.Instance():setBlockBloomOption(deviation, intensity, saturation)
  Blockman.Instance():setBloomEnable(false)
  ClientHelper.putStringPrefs("RechargeGameType", "g1008")
  ClientHelper.putBoolPrefs("IsShowItemDurability", true)
end)

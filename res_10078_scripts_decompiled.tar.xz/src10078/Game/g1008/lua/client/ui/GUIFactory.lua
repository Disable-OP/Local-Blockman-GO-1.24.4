local winId = 0

local function allowId()
  winId = winId + 1
  return winId
end

local UIUtils = T(Global, "UIUtils")

function UIUtils.addRedPoint(node, params)
  params = params or {}
  local redPoint = GUIManager:createGUIWindow(GUIType.StaticImage, "UIUtils-RedPoint" .. allowId())
  local img = params.img or "set:bed_war_3_common_part.json image:img_0_red_dot02"
  redPoint:SetTouchable(false)
  redPoint:SetProperty("Material", "CullBackLinear")
  redPoint:SetHorizontalAlignment(2)
  node:AddChildWindow(redPoint)
  UIHelper:setImageAdjustSize(redPoint, img, 50, 50)
  local size_rp = redPoint:GetPixelSize()
  redPoint:SetXPosition({
    0,
    params.x or size_rp.x / 4
  })
  redPoint:SetYPosition({
    0,
    params.y or -size_rp.y / 4
  })
  return redPoint
end

function UIUtils.addRedDot(node, rdKey, parentKey, params)
  Plugins.CallPluginFunc("redDotBuild", node, rdKey, parentKey, params)
end

function UIUtils.updateRedDotCount(rdKey, count)
  Plugins.CallPluginFunc("resetRedDotState", rdKey, count)
end

function UIUtils.GetLogoutTimeText(time)
  if time < 3600 then
    return string.format(Lang:getString("gui_user_logout_time_text_min"), math.max(1, math.floor(time / 60)))
  elseif time < DateUtil.getDaySeconds() then
    return string.format(Lang:getString("gui_user_logout_time_text_hour"), math.floor(time / 3600))
  elseif time < DateUtil.getWeekSeconds() then
    return string.format(Lang:getString("gui_user_logout_time_text_day"), math.floor(time / DateUtil.getDaySeconds()))
  elseif time < 2626560 then
    return string.format(Lang:getString("gui_user_logout_time_text_week"), math.floor(time / DateUtil.getWeekSeconds()))
  else
    return string.format(Lang:getString("gui_user_logout_time_text_month"), math.floor(time / 2626560))
  end
end

function UIUtils.setNumberToLayout(number, parent)
  number = math.floor(number)
  local Spacing = 10
  parent:CleanupChildren()
  local numberHeight = parent:GetPixelSize().y
  local numberWidth = numberHeight / 167 * 110
  local numberList = {}
  while number ~= 0 do
    table.insert(numberList, number % 10)
    number = math.floor(number / 10)
  end
  local PosX = (numberWidth + Spacing) * (#numberList - 1) / -2
  for i = #numberList, 1, -1 do
    local item = UIHelper.newGameGUIWindow("GUINumberItem", numberList[i])
    item:setArea({0, PosX}, {0, 0}, {0, numberWidth}, {0, numberHeight})
    item.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    parent:AddChildWindow(item.root)
    PosX = PosX + numberWidth + Spacing
  end
end

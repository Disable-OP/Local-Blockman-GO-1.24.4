RadioBoxGroup = class()

local function setTouchable(window, touchable)
  window:SetTouchable(touchable)
  local count = window:GetChildCount()
  if count == 0 then
    return
  end
  for index = 1, count do
    setTouchable(window:GetChildByIndex(index - 1), touchable)
  end
end

function RadioBoxGroup:ctor(soundType)
  self.soundType = soundType or -1
  self.boxList = {}
  self.callback = {}
end

function RadioBoxGroup:addCheckBox(boxWindow, selectCallback)
  if not boxWindow then
    return
  end
  setTouchable(boxWindow, true)
  table.insert(self.boxList, boxWindow)
  table.insert(self.callback, selectCallback)
  boxWindow:registerEvent(GUIEvent.CheckStateChanged, function()
    if boxWindow:GetChecked() then
      for index, tabCheckBox in pairs(self.boxList) do
        if tabCheckBox:GetChecked() and tabCheckBox ~= boxWindow then
          tabCheckBox:SetChecked(false)
          setTouchable(tabCheckBox, true)
          if self.callback[index] then
            self.callback[index](false)
          end
        end
      end
      setTouchable(boxWindow, false)
      if selectCallback then
        selectCallback(true)
      end
    end
  end)
  boxWindow:registerEvent(GUIEvent.Click, function()
    SoundUtil.playSound(self.soundType)
  end)
end

function RadioBoxGroup:selectIndex(index)
  local curTab = self.boxList[index]
  if curTab then
    curTab:SetChecked(true)
  end
end

function RadioBoxGroup:getCurIndex()
  for index, tabCheckBox in pairs(self.boxList) do
    if tabCheckBox:GetChecked() then
      return index
    end
  end
  return 0
end

return RadioBoxGroup

local GUIUpgradeGoodsDesc = class("GUIStoreGoods", IGUIWindow)

function GUIUpgradeGoodsDesc:onLoad()
  self.llBack = self:getChildWindowByName("BedWarUpgradeGoodsDesc", GUIType.Layout)
  self.tvLevel = self:getChildWindowByName("BedWarUpgradeGoodsDesc-Level-Text", GUIType.StaticText)
  self.tvDesc = self:getChildWindowByName("BedWarUpgradeGoodsDesc-Desc-Text", GUIType.StaticText)
end

function GUIUpgradeGoodsDesc:onDataChanged(data)
  self.data = data
  self.tvLevel:SetText(string.format("LV.%d", data.Level))
  self.tvDesc:SetText(Lang:getString(data.Desc))
  local info = GameInfoManager:getTeamInfo(Game:getPlayer():getTeamId())
  if not info then
    return
  end
  local level = tonumber(info:getValue(tostring(data.ItemId)))
  if level >= data.Level then
    self.llBack:SetBackImage("set:bed_war_upgrade_store.json image:item_bg2")
  else
    self.llBack:SetBackImage("set:bed_war_upgrade_store.json image:item_bg1")
  end
end

return GUIUpgradeGoodsDesc

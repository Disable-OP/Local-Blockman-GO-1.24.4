local GUIBedWarHeadFrameItem = class("GUIBedWarHeadFrameItem", IGUIWindow)
local HeadFrameConfig = T(Global, "HeadFrameConfig")
local HeadFrameShop = T(Global, "HeadFrameShop")

function GUIBedWarHeadFrameItem:ctor(...)
  self.super.ctor(self, "BedWarHeadFrameShopItem.json", ...)
end

function GUIBedWarHeadFrameItem:onLoad()
  self.siHead = self:getChildWindowByName("BedWarHeadFrameShopItem-Head", GUIType.StaticImage)
  self.llTouch = self:getChildWindowByName("BedWarHeadFrameShopItem-Touch", GUIType.Layout)
  self.siFrame = self:getChildWindowByName("BedWarHeadFrameShopItem-Frame", GUIType.StaticImage)
  self.siSelect = self:getChildWindowByName("BedWarHeadFrameShopItem-Select", GUIType.StaticImage)
  self.siFrameEffect = self:getChildWindowByName("BedWarHeadFrameShopItem-Frame-Effect", GUIType.StaticImage)
  self.siLock = self:getChildWindowByName("BedWarHeadFrameShopItem-Lock", GUIType.StaticImage)
  self.siUse = self:getChildWindowByName("BedWarHeadFrameShopItem-Use", GUIType.StaticImage)
  self.siLock:SetVisible(true)
  self.siUse:SetVisible(false)
  self.llTouch:SetTouchable(true)
  self.siSelect:SetVisible(false)
  self:initEvent()
end

function GUIBedWarHeadFrameItem:initEvent()
  self.llTouch:registerEvent(GUIEvent.Click, function()
    Events.HeadFrameItemSelectEvent:invoke(self.id)
  end)
  self:registerEvent(Events.HeadFrameItemSelectEvent, function(id)
    if not self.cantBeSelect then
      self.siSelect:SetVisible(self.id == id)
    end
  end)
  self:registerEvent(Events.HeadFrameChangeEvent, function(userId)
    if userId ~= Game:getPlatformUserId() then
      return
    end
    if self.cantBeSelect or not self.data then
      return
    end
    local reward = RewardConfig.findRewardById(self.data.RewardId)
    if reward and reward.RewardId then
      self.siUse:SetVisible(reward.RewardId == HeadFrameShop.curHeadFrame)
    else
      self.siUse:SetVisible(HeadFrameShop.curHeadFrame == 0)
    end
  end)
  self:registerEvent(Events.HeadFrameItemStatusEvent, function(id)
    if not self.data then
      return
    end
    if not self.siLock:IsVisible() or self.cantBeSelect or self.data.Default then
      if self.data.Default and not self.cantBeSelect then
        self.siUse:SetVisible(id == 0)
      end
      return
    end
    local reward = RewardConfig.findRewardById(self.data.RewardId)
    if reward and reward.RewardId then
      self.siLock:SetVisible(reward.RewardId ~= tonumber(id))
    else
      self.siLock:SetVisible(false)
    end
  end)
end

function GUIBedWarHeadFrameItem:onDataChanged(data)
  self.id = data.Id
  self.data = data
  local reward = RewardConfig.findRewardById(data.RewardId)
  self.siFrame:SetImage("")
  self.siFrameEffect:SetEffectName("")
  self.siFrameEffect:SetVisible(false)
  local config = HeadFrameConfig.getDefaultFrame()
  if reward and reward.RewardId and not data.Default then
    config = HeadFrameConfig.getConfigById(reward.RewardId) or config
    local isOwn = HeadFrameShop:checkHeadFrameStatus(reward.RewardId)
    self.siLock:SetVisible(not isOwn)
    self.siUse:SetVisible(reward.RewardId == HeadFrameShop.curHeadFrame)
  else
    self.siLock:SetVisible(false)
    self.siUse:SetVisible(HeadFrameShop.curHeadFrame == 0)
    local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
    config = userInfo and (not userInfo[Define.PlayerCustomInfo.CurHeadFrame] or userInfo[Define.PlayerCustomInfo.CurHeadFrame] == 0) and HeadFrameConfig.getConfigBySvga(userInfo.avatarFrame) or config
  end
  if config then
    if config.Frame and config.Frame ~= "#" then
      self.siFrame:SetImage(config.Frame)
    end
    if config.FrameEffect and config.FrameEffect ~= "#" then
      self.siFrameEffect:SetVisible(true)
      self.siFrameEffect:SetEffectName(config.FrameEffect)
    end
  end
  if self.cantBeSelect then
    self.siUse:SetVisible(false)
    self.siLock:SetVisible(false)
    self.siSelect:SetVisible(false)
  end
  if not self.cantBeSelect and GUIBedWarPictureFrameShopLayout then
    self.siSelect:SetVisible(self.id == GUIBedWarPictureFrameShopLayout:getCurSelectId())
  end
end

function GUIBedWarHeadFrameItem:setCanNotBeSelect()
  self.cantBeSelect = true
end

return GUIBedWarHeadFrameItem

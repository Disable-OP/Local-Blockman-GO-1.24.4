local GUIFreeGiftItem = class("GUIFreeGiftItem", IGUIWindow)

function GUIFreeGiftItem:onLoad()
  self.siGiftIcon = self:getChildWindowByName("BedWarFreeGiftItem-Icon", GUIType.StaticImage)
  self.stTimesTip = self:getChildWindowByName("BedWarFreeGiftItem-Times-Tip", GUIType.StaticText)
  self.stGiftNum = self:getChildWindowByName("BedWarFreeGiftItem-Icon-Num", GUIType.StaticText)
  self.btnGetGift = self:getChildWindowByName("BedWarFreeGiftItem-Get-Gift-Bg", GUIType.Button)
  self.btnQuestion = self:getChildWindowByName("BedWarFreeGiftItem-Question", GUIType.Button)
  self.btnIconWatchAD = self:getChildWindowByName("BedWarFreeGiftItem-Icon-btn", GUIType.Button)
  self.siGetAllGift = self:getChildWindowByName("BedWarFreeGiftItem-Get-All-Gift-Bg", GUIType.StaticImage)
  self.stCDTime = self:getChildWindowByName("BedWarFreeGiftItem-Get-Gift-Text", GUIType.StaticText)
  self:getChildWindowByName("BedWarFreeGiftItem-Get-All-Gift-Text", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_free_reward_get_all"))
  self:register()
end

function GUIFreeGiftItem:register()
  self.btnGetGift:registerEvent(GUIEvent.ButtonClick, function()
    local freeGiftConfig = FreeGiftConfig:getGiftById(self.Id)
    local config = RewardConfig.findRewardById(freeGiftConfig.RewardId)
    FreeGiftWatchADTipContent:setInfo(config.Image, "\195\151 " .. config.Count, config.Desc)
    FreeGiftWatchADTipContent:setTextColor("1 1 1 1")
    WatchAdTip.init().setContentView(FreeGiftWatchADTipContent).setTitle("gui_bed_war_free_gift_tip_title").show(Define.AdType.FreeGift, self.Id)
    self.btnGetGift:SetTouchable(false)
  end)
  self.btnIconWatchAD:registerEvent(GUIEvent.ButtonClick, function()
    local freeGiftConfig = FreeGiftConfig:getGiftById(self.Id)
    local config = RewardConfig.findRewardById(freeGiftConfig.RewardId)
    FreeGiftWatchADTipContent:setInfo(config.Image, "\195\151 " .. config.Count, config.Desc)
    FreeGiftWatchADTipContent:setTextColor("1 1 1 1")
    WatchAdTip.init().setContentView(FreeGiftWatchADTipContent).setTitle("gui_bed_war_free_gift_tip_title").show(Define.AdType.FreeGift, self.Id)
    self.btnIconWatchAD:SetTouchable(false)
  end)
  self.btnQuestion:registerEvent(GUIEvent.ButtonClick, function()
    GUIBoxDetail:showDetail(self.boxType)
  end)
end

function GUIFreeGiftItem:onDataChanged(data)
  self.Id = data.Id
  local config = RewardConfig.findRewardById(data.RewardId)
  if not config then
    return
  end
  if tonumber(config.RewardType) == Define.RewardType.CHEST then
    self.btnQuestion:SetVisible(true)
    self.boxType = config.RewardId
  else
    self.btnQuestion:SetVisible(false)
  end
  self.stGiftNum:SetText(config.Count)
  self.siGiftIcon:SetImage(config.Image)
  self.stTimesTip:SetText(string.format(Lang:getString("gui_bed_war_free_gift_times_tip"), data.Times or 0))
  if not data.CD or data.CD == 0 then
    self.stCDTime:SetText(Lang:getString("gui_bed_war_free_gift_free"))
    self.btnGetGift:SetTouchable(true)
    self.btnGetGift:SetNormalImage("set:free_gift.json image:btn_get_gift")
    self.btnIconWatchAD:SetTouchable(true)
  else
    local h = math.floor(data.CD / 3600)
    local m = math.floor(data.CD / 60) - h * 60
    local s = data.CD % 60
    local refreshTime = h .. ":" .. m .. ":" .. s
    self.stCDTime:SetText(refreshTime)
    self.btnGetGift:SetTouchable(false)
    self.btnGetGift:SetNormalImage("set:free_gift.json image:btn_get_gift_gray")
    self.btnIconWatchAD:SetTouchable(false)
  end
  if tonumber(data.Times) == 0 then
    self.btnIconWatchAD:SetTouchable(false)
    self.btnGetGift:SetVisible(false)
    self.siGetAllGift:SetVisible(true)
  else
    self.btnIconWatchAD:SetTouchable(true)
    self.btnGetGift:SetVisible(true)
    self.siGetAllGift:SetVisible(false)
  end
end

return GUIFreeGiftItem

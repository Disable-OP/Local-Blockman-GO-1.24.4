local GUICustomShopSubTab = class("GUICustomShopSubTab", IGUIWindow)

function GUICustomShopSubTab:onLoad()
  self.cbTab = self:getChildWindowByName("BedWarCustomShopSubTab", GUIType.CheckBox)
  self.tvName = self:getChildWindowByName("BedWarCustomShopSubTab-Name", GUIType.StaticText)
  self.cbTab:registerEvent(GUIEvent.Click, function()
    SoundUtil.playSound(SoundConfig.selectTabStore)
  end)
end

function GUICustomShopSubTab:onDataChanged(data)
  if #data == 1 then
    self.type = data[1].Type
    self.tabId = data[1].TabId
    self.pageId = data[1].PageId
    self.tvName:SetText(Lang:getString(data[1].TypeLang))
  else
    self.type = data[1].Type
    self.pageId = data[1].PageId
    self.tvName:SetText(Lang:getString(data[1].TypeLang))
    self.tabId = {}
    self.tagLang = {}
    for _, tag in pairs(data) do
      table.insert(self.tabId, tag.TabId)
      table.insert(self.tagLang, tag.Lang)
    end
  end
end

function GUICustomShopSubTab:setChecked(check)
  self.cbTab:SetChecked(check)
  self.cbTab:SetTouchable(not check)
end

return GUICustomShopSubTab

local GUISelectItem = class("GUISelectItem", IGUIWindow)

function GUISelectItem:onLoad()
  self.type = 0
  self.stName = self:getChildWindow(0, GUIType.StaticText)
  self:initEvent()
end

function GUISelectItem:initEvent()
  self.stName:registerEvent(GUIEvent.Click, function()
    Events.ScreenBeSelectedEvent:invoke(self.data)
  end)
end

function GUISelectItem:initData(data)
  self.data = data
  self.type = data.mainType
  self.stName:SetText(Lang:getString(data.name))
end

return GUISelectItem

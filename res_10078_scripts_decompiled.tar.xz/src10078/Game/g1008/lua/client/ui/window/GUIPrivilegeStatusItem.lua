local GUIPrivilegeStatusItem = class("GUIPrivilegeStatusItem", IGUIWindow)

function GUIPrivilegeStatusItem:onLoad()
  self.ivIcon = self:getChildWindow(0, GUIType.StaticImage)
  self.ivTimeBg = self:getChildWindow(1, GUIType.StaticImage)
  self.tvTimeText = self:getChildWindow(0, GUIType.StaticText, self.ivTimeBg)
end

function GUIPrivilegeStatusItem:initPrivilegeStatus(icon, time, id)
  self.id = id
  self.time = time
  self.ivIcon:SetImage(icon)
  self.ivIcon:SetEnabled(true)
  self.ivTimeBg:SetVisible(true)
  self.tvTimeText:SetVisible(true)
  self:updateTimeText()
end

function GUIPrivilegeStatusItem:updateTimeText()
  if self.time > 0 then
    self.tvTimeText:SetText(DateUtil.getFormatTime(self.time, "HH:mm"))
  else
    self.ivIcon:SetEnabled(false)
    self.ivTimeBg:SetVisible(false)
    self.tvTimeText:SetVisible(false)
  end
end

return GUIPrivilegeStatusItem

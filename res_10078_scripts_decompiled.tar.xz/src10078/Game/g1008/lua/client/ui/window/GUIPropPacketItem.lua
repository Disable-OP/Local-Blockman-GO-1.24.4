local GUIPropPacketItemWindow = class("GUIPropPacketItemWindow", IGUIWindow)

function GUIPropPacketItemWindow:ctor(...)
  self.super.ctor(self, "PropPacketItem.json", ...)
end

function GUIPropPacketItemWindow:onLoad()
  self.siIcon = self:getChildWindowByName("PropPacketItem-Icon", GUIType.StaticImage)
  self.stCount = self:getChildWindowByName("PropPacketItem-Count", GUIType.StaticText)
  self.siEnchantmentIndicator = self:getChildWindowByName("PropPacketItem-EnchantmentIndicator", GUIType.StaticImage)
  self.pbSkillDurationValue = self:getChildWindowByName("PropPacketItem-Skill-Duration-Value", GUIType.ProgressBar)
  self:initView()
  self:initEvent()
end

function GUIPropPacketItemWindow:initView()
  self.stCount:SetText()
end

function GUIPropPacketItemWindow:initEvent()
end

local function showItemIcon(siIcon, itemId, damage)
  if not GuiItemStack.showItemIcon(siIcon, itemId, damage, "") then
    LuaTimer:schedule(function()
      showItemIcon(siIcon, itemId, damage)
    end, 100)
  end
end

function GUIPropPacketItemWindow:onDataChanged(data)
  if data == nil and self.propData == nil then
    return
  end
  self.propData = data
  self.pbSkillDurationValue:SetVisible(false)
  self.siEnchantmentIndicator:SetVisible(false)
  if not data then
    self.stCount:SetText("")
    showItemIcon(self.siIcon, 0, 0)
    self.siIcon:SetVisible(false)
    return
  end
  self.siIcon:SetVisible(true)
  self.stCount:SetText(data.count)
  self.stCount:SetVisible(data.count ~= 1)
  if Item.getItemById(data.itemId) then
    showItemIcon(self.siIcon, data.itemId, 0)
  else
    showItemIcon(self.siIcon, BlockManager.getItemBlockId(data.itemId), 0)
  end
  local item = Item.getItemById(data.itemId)
  if item then
    local maxDamage = item:getMaxDamage()
    if 0 < maxDamage then
      local curValue = maxDamage - (data.damage or 0)
      local progress = curValue / maxDamage
      self.pbSkillDurationValue:SetVisible(progress < 1)
      self.pbSkillDurationValue:SetProgress(progress)
      if 0.5 <= progress then
        self.pbSkillDurationValue:SetProgressImage("set:item_duration_progress.json image:itemduration_grid_green")
      elseif 0.2 < progress then
        self.pbSkillDurationValue:SetProgressImage("set:item_duration_progress.json image:itemduration_grid_yellow")
      else
        self.pbSkillDurationValue:SetProgressImage("set:item_duration_progress.json image:itemduration_grid_red")
      end
    end
    self.siEnchantmentIndicator:SetVisible(data.itemId == ItemID.BLAZE_ROD)
  end
end

return GUIPropPacketItemWindow

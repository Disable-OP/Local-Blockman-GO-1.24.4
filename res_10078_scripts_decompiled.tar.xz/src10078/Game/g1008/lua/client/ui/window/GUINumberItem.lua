local GUINumberItem = class("GUINumberItem", IGUIWindow)
local numberPng = {
  [0] = "set:bed_war_number.json image:0",
  [1] = "set:bed_war_number.json image:1",
  [2] = "set:bed_war_number.json image:2",
  [3] = "set:bed_war_number.json image:3",
  [4] = "set:bed_war_number.json image:4",
  [5] = "set:bed_war_number.json image:5",
  [6] = "set:bed_war_number.json image:6",
  [7] = "set:bed_war_number.json image:7",
  [8] = "set:bed_war_number.json image:8",
  [9] = "set:bed_war_number.json image:9"
}

function GUINumberItem:ctor(number)
  self.number = number
  self.super.ctor(self, "NumberItem.json")
end

function GUINumberItem:onLoad()
  self.ivNumber = DynamicCast.dynamicCastWindow(GUIType.StaticImage, self.root)
  self.ivNumber:setMaterial(20001)
  self.ivNumber:SetImage(numberPng[tonumber(self.number)])
end

return GUINumberItem

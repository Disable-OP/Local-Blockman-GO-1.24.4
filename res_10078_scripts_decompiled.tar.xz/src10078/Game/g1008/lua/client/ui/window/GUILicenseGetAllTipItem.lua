local GUILicenseGetAllTipItem = class("UILicenseGetAllTipItem", IGUIWindow)

function GUILicenseGetAllTipItem:onLoad()
  self.stNum = self:getChildWindowByName("BedWarLicenseGetAllItem-Num", GUIType.StaticText)
  self.siIcon = self:getChildWindowByName("BedWarLicenseGetAllItem-Icon", GUIType.StaticImage)
  self.stName = self:getChildWindowByName("BedWarLicenseGetAllItem-Name", GUIType.StaticText)
end

function GUILicenseGetAllTipItem:onDataChanged(data)
  local rewardConfig = RewardConfig.findRewardById(data.rewardId)
  if rewardConfig then
    self.siIcon:SetImage(rewardConfig.Image)
    self.stName:SetText(Lang:getString(rewardConfig.Name) .. "\195\151" .. data.Num)
  else
    local rewardType = math.floor(data.rewardId / 1000)
    local goods = CustomShopConfig:getGoodsListByType(rewardType)
    if not goods then
      return
    end
    for i, good in pairs(goods[1].GoodsList) do
      if good.Id == data.rewardId then
        self.siIcon:SetImage(good.Image)
        self.stNum:SetText("\195\151 " .. 1)
      end
    end
  end
end

return GUILicenseGetAllTipItem

local GUIChatRecordItem = class("GUIChatRecordItem", IGUIWindow)

function GUIChatRecordItem:onLoad()
  self.stText = self:getChildWindow(0, GUIType.StaticText)
end

function GUIChatRecordItem:onGetChat(color, name, text)
  self.stText:SetText(string.format("%s<%s>\226\150\162FFCCCCCC %s", color, name, tostring(text)))
  return self.stText:GetTextStringHigh()
end

function GUIChatRecordItem:onGetSystemTip(text)
  self.stText:SetText(string.format("\226\150\162FFCCCCCC %s", tostring(text)))
  return self.stText:GetTextStringHigh()
end

function GUIChatRecordItem:getHeight()
  return self.stText:GetTextStringHigh()
end

return GUIChatRecordItem

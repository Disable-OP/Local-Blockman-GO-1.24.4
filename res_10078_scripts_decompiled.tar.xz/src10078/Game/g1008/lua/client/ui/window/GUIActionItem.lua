local GUIActionItem = class("GUIActionItem", IGUIWindow)

function GUIActionItem:onLoad()
  self.siIcon = self:getChildWindowByName("ActionItem-icon", GUIType.StaticImage)
  self.siLock = self:getChildWindowByName("ActionItem-lock", GUIType.StaticImage)
  self.btClick = self:getChildWindowByName("ActionItem-bt", GUIType.Button)
  self:registerEvent()
  self.windowPosRecord = {}
end

function GUIActionItem:onDataChanged(data)
  self.goodsId = data.goodsId
  self.actionId = data.actionId
  self.image = data.image
  self.action = data.Action
  self.isLock = data.isLock
  self.price = data.price
  self.siIcon:SetImage(data.image)
  self.siLock:SetVisible(self.isLock)
end

function GUIActionItem:registerEvent()
  self.btClick:registerEvent(GUIEvent.ButtonClick, function()
    self:onClick()
  end)
end

function GUIActionItem:onClick()
  if self.isLock == true then
    CustomShopConfig:getGoodsConfig(self.actionId)
    CustomDialog.builder().setContentText(Lang:getString("gui_dialog_tip_buy_action")).setExtraInfo("set:bed_war_store.json image:cube", tostring(self.price)).setTitleText("gui_dialog_tip_title_tip").setRightText("gui_dialog_tip_btn_sure").setRightClickListener(function()
      LuaTimer:schedule(function()
        PayHelper.checkMoney(Define.Money.DIAMOND, self.price, function(canBuy)
          if canBuy then
            CommonPacketSender:sendBuyCustomGoods(self.goodsId)
          end
        end)
      end, 100)
    end).setLeftText("gui_dialog_tip_btn_cancel").show()
  else
    GUIBedWarToolBar.cbAction:SetChecked(false)
    ActionEmojiConfig:playAction(self.actionId, self.action)
  end
end

return GUIActionItem

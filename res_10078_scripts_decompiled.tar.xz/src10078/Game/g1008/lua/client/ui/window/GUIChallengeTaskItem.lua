local GUIChallengeTaskItem = class("GUIChallengeTaskItem", IGUIWindow)

function GUIChallengeTaskItem:onLoad()
  self.btTask = self:getChildWindowByName("ChallengeTaskItem-bt", GUIType.Button)
  self.btTask:registerEvent(GUIEvent.ButtonClick, function()
    self:onClickBtn()
  end)
  self.stPointsNum = self:getChildWindowByName("ChallengeTaskItem-points_num", GUIType.StaticText)
  self.stTaskText = self:getChildWindowByName("ChallengeTaskItem-text_task", GUIType.StaticText)
  self.siReceived = self:getChildWindowByName("ChallengeTaskItem-bt_icon", GUIType.StaticImage)
  self.stButtonText = self:getChildWindowByName("ChallengeTaskItem-bt_text", GUIType.StaticText)
  self.siReceived:SetVisible(false)
end

function GUIChallengeTaskItem:onDataChanged(data)
  self.stPointsNum:SetText(data.reward)
  self.stTaskText:SetText(Lang:getTipString(tonumber(data.desc), "\226\150\162FFFFFF00" .. tostring(data.progress .. "/" .. data.GoalNum) .. "\226\150\162FFFFFFFF"))
  self.taskStatus = data.status
  self.taskId = data.taskId
  if data.status == Define.TaskStatus.UNACCEPTED then
    self.btTask:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_gray")
    self.btTask:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_gray")
    self.btTask:SetText(Lang:getString("gui_bed_war_hall_task_unopened"))
    self.btTask:SetTouchable(false)
    self.siReceived:SetVisible(false)
  elseif data.status == Define.TaskStatus.PROGRESSING then
    self.siReceived:SetVisible(false)
    local taskConfig = TaskConfig:getTaskById(self.taskId)
    if taskConfig.TaskTypeId == 101 or BaseMain:getGameType() ~= "g1046" then
      self.btTask:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_no_click")
      self.btTask:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_no_click")
      self.btTask:SetText(Lang:getString("gui_bed_war_task_not_Complete"))
      self.btTask:SetTouchable(false)
    else
      self.btTask:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_blue")
      self.btTask:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_blue")
      self.btTask:SetText(Lang:getString("gui_bed_war_task_toComplete"))
      self.btTask:SetTouchable(true)
    end
  elseif data.status == Define.TaskStatus.FINISHED then
    self.btTask:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_green")
    self.btTask:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_green")
    self.btTask:SetText(Lang:getString("gui_bed_war_hall_task_complete"))
    self.btTask:SetTouchable(true)
    self.siReceived:SetVisible(false)
  elseif data.status == Define.TaskStatus.RECEIVED then
    self.btTask:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_no_click")
    self.btTask:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_no_click")
    self.btTask:SetTouchable(false)
    self.btTask:SetText("")
    self.siReceived:SetVisible(true)
    self.stButtonText:SetVisible(true)
    self.stButtonText:SetText(Lang:getString("gui_bed_war_hall_task_over"))
  end
end

function GUIChallengeTaskItem:onClickBtn()
  if self.taskStatus == Define.TaskStatus.FINISHED then
    TreasureChallenge:onFinishTask(self.taskId)
    return
  end
  if BaseMain:getGameType() ~= "g1046" or self.taskStatus ~= Define.TaskStatus.PROGRESSING then
    return
  end
  local taskConfig = TaskConfig:getTaskById(self.taskId)
  if taskConfig.TaskTypeId > 200 then
    if TableUtil.isEmpty(taskConfig.GameTypes) then
      GUICustomDialog:showStartGame("Func_hint_5", "g1008")
    else
      GUICustomDialog:showStartGame("Func_hint_5", taskConfig.GameTypes[1])
    end
  elseif taskConfig.TaskTypeId == 102 then
    GUIChallengeTask:hide()
    GUIBoxLottery:show()
  elseif taskConfig.TaskTypeId == 103 then
    if TableUtil.isEmpty(taskConfig.Remarks) then
      return
    end
    if taskConfig.Remarks[1] == 5 then
      GUIChallengeTask:hide()
      GUIStore:show(StoreId.CubeStore)
    end
  end
end

return GUIChallengeTaskItem

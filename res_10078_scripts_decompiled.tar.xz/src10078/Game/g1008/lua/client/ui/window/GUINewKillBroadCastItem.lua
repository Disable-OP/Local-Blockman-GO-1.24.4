local GUINewKillBroadCastItem = class("GUINewKillBroadCastItem", IGUIWindow)

function GUINewKillBroadCastItem:onLoad()
  self.stKillerName = self:getChildWindowByName("NewKillBroadCast-kill_name", GUIType.StaticText)
  self.stDeadName = self:getChildWindowByName("NewKillBroadCast-dier_name", GUIType.StaticText)
  self.root:SetVisible(false)
end

function GUINewKillBroadCastItem:showKillBroadCast(data)
  self.root:SetVisible(true)
  local killerInfo = GameInfoManager:getPlayerInfo(data.killerId)
  local deadInfo = GameInfoManager:getPlayerInfo(data.deadId)
  if killerInfo then
    self.stKillerName:SetText(TeamConfig:getTeamColor(killerInfo:getValue("teamId")) .. killerInfo:getValue("userName"))
  end
  if deadInfo then
    self.stDeadName:SetText(TeamConfig:getTeamColor(deadInfo:getValue("teamId")) .. deadInfo:getValue("userName"))
  end
  local selfTeamId = GameInfoManager:getPlayerInfo(PlayerManager:getClientPlayer().userId):getValue("teamId")
  if killerInfo:getValue("teamId") == selfTeamId then
    SoundUtil.playSound(SoundConfig.teamMateKillOther)
  elseif deadInfo:getValue("teamId") == selfTeamId then
    SoundUtil.playSound(SoundConfig.otherKillTeamMate)
  else
    SoundUtil.playSound(SoundConfig.otherKillOther)
  end
  self:animTimer()
end

function GUINewKillBroadCastItem:animTimer()
  local XPos = -1
  self.key1 = LuaTimer:schedule(function()
    self.key2 = LuaTimer:scheduleTimer(function()
      XPos = XPos + 0.04
      self.root:SetXPosition({XPos, 0})
    end, 10, 25)
  end, 0)
  self.key3 = LuaTimer:schedule(function()
    self.key4 = LuaTimer:scheduleTimer(function()
      XPos = XPos - 0.04
      self.root:SetXPosition({XPos, 0})
    end, 5, 25)
  end, 2500)
  self.key5 = LuaTimer:schedule(function()
    self:onBroadCastEnd()
  end, 3000)
end

function GUINewKillBroadCastItem:onBroadCastEnd()
  LuaTimer:cancel(self.key1)
  LuaTimer:cancel(self.key2)
  LuaTimer:cancel(self.key3)
  LuaTimer:cancel(self.key4)
  LuaTimer:cancel(self.key5)
  self.root:SetVisible(false)
end

return GUINewKillBroadCastItem

GUICustomShopGoods = class("GUICustomShopGoods", IGUIWindow)

function GUICustomShopGoods:onLoad()
  self.root:registerEvent(GUIEvent.Click, function()
    SoundUtil.playSound(SoundConfig.selectGoodsStore)
    GUICustomShop:onSelectGoods(self.data)
    ReportUtil.reportCustomShopSelect(self.data.Id)
  end)
  self.ivImage = self:getChildWindowByName("BedWarCustomShopGoods-Image", GUIType.StaticImage)
  self.tvName = self:getChildWindowByName("BedWarCustomShopGoods-Name", GUIType.StaticText)
  self.ivUseIcon = self:getChildWindowByName("BedWarCustomShopGoods-Use-Icon", GUIType.StaticImage)
  self.llLock = self:getChildWindowByName("BedWarCustomShopGoods-Lock-Mask")
  self.ivSelect = self:getChildWindowByName("BedWarCustomShopGoods-Select", GUIType.StaticImage)
  self.llPriceBox1 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Box-1", GUIType.Layout)
  self.ivPriceOffBg1 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Off-Bg-1", GUIType.StaticImage)
  self.ivPriceIcon1 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Icon-1", GUIType.StaticImage)
  self.tvPrice1 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Text-1", GUIType.StaticText)
  self.tvPriceOff1 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Off-Text-1", GUIType.StaticText)
  self.llPriceBox2 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Box-2", GUIType.Layout)
  self.ivPriceOffBg2 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Off-Bg-2", GUIType.StaticImage)
  self.ivPriceIcon2 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Icon-2", GUIType.StaticImage)
  self.tvPrice2 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Text-2", GUIType.StaticText)
  self.tvPriceOff2 = self:getChildWindowByName("BedWarCustomShopGoods-Price-Off-Text-2", GUIType.StaticText)
  self.ivCounter = self:getChildWindowByName("BedWarCustomShopGoods-Counter", GUIType.StaticImage)
end

function GUICustomShopGoods:onDataChanged(data)
  self.Id = data.Id
  self.data = data
  if data.Time == -1 or data.Time > 0 then
    self.llLock:SetVisible(false)
    self.llPriceBox1:SetVisible(false)
    self.llPriceBox2:SetVisible(false)
  else
    self.llLock:SetVisible(true)
    self.llPriceBox2:SetVisible(true)
    self.llPriceBox1:SetVisible(true)
  end
  if data.DiscountPrices1 == data.Price1 then
    self.ivPriceOffBg1:SetVisible(false)
    self.tvPrice1:SetText(tostring(data.Price1))
  else
    self.ivPriceOffBg1:SetVisible(true)
    self.tvPrice1:SetText(tostring(data.DiscountPrices1))
    self.tvPriceOff1:SetText(tostring(data.Price1))
  end
  self.ivPriceIcon1:SetImage(PayHelper.getMoneyIcon(data.CoinId1))
  if data.CoinId2 and data.CoinId2 ~= "#" and 0 < data.Price2 then
    self.llPriceBox1:SetArea({0.25, 4}, {0, 50}, {0.5, 8}, {0, 50})
    self.llPriceBox2:SetArea({-0.25, -4}, {0, 50}, {0.5, 8}, {0, 50})
    self.ivPriceIcon2:SetImage(PayHelper.getMoneyIcon(data.CoinId2))
    if data.DiscountPrices2 == data.Price2 then
      self.ivPriceOffBg2:SetVisible(false)
      self.tvPrice2:SetText(tostring(data.Price2))
    else
      self.ivPriceOffBg2:SetVisible(true)
      self.tvPrice2:SetText(tostring(data.DiscountPrices1))
      self.tvPriceOff2:SetText(tostring(data.Price2))
    end
  else
    self.llPriceBox2:SetVisible(false)
    self.llPriceBox1:SetArea({0, 0}, {0, 50}, {0.5, 8}, {0, 50})
  end
  local width, height = UIHelper:getImageSize(data.Image, 131, 143)
  self.ivImage:SetImage(data.Image)
  self.ivImage:SetWidth(width)
  self.ivImage:SetHeight(height)
  self.tvName:SetText(Lang:getString(data.Name))
  self.ivSelect:SetVisible(GUICustomShop.curSelectGoods == data)
  self.ivUseIcon:SetVisible(data.Status == CustomShopGoodsStatus.Equiped)
  if GUICustomShop.goodsAdapter:getItemPosition(self, "Id") % 3 == 1 then
    self.ivCounter:SetVisible(true)
  else
    self.ivCounter:SetVisible(false)
  end
end

return GUICustomShopGoods

local GUIBedWarUIReturnControlWindow = class("GUIBedWarUIReturnControlWindow", IGUIWindow)

function GUIBedWarUIReturnControlWindow:ctor(...)
  self.super.ctor(self, "BedWarUIReturnControl.json", ...)
end

function GUIBedWarUIReturnControlWindow:onLoad(text, callback)
  self.siBg = self:getChildWindowByName("BedWarUIReturnControl-Bg", GUIType.StaticImage)
  self.siIcon = self:getChildWindowByName("BedWarUIReturnControl-Icon", GUIType.StaticImage)
  self.stText = self:getChildWindowByName("BedWarUIReturnControl-Text", GUIType.StaticText)
  self.btnBtn = self:getChildWindowByName("BedWarUIReturnControl-Btn", GUIType.Button)
  self:initView(text)
  self:initEvent(callback)
end

function GUIBedWarUIReturnControlWindow:initView(text)
  self.stText:SetText(Lang:getString(text))
  self:setWidth({
    0,
    self.stText:GetTextWidth() + 130
  })
end

function GUIBedWarUIReturnControlWindow:initEvent(callback)
  self.btnBtn:registerEvent(GUIEvent.ButtonClick, function()
    callback()
  end)
end

return GUIBedWarUIReturnControlWindow

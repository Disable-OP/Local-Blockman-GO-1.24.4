local GUIStoreGoods = class("GUIStoreGoods", IGUIWindow)

function GUIStoreGoods:onLoad()
  self.tvName = self:getChildWindowByName("BedWarStoreGoods-Title-Text", GUIType.StaticText)
  self.ivImage = self:getChildWindowByName("BedWarStoreGoods-Image", GUIType.StaticImage)
  self.tvCount = self:getChildWindowByName("BedWarStoreGoods-Count", GUIType.StaticText)
  self.btnBuy = self:getChildWindowByName("BedWarStoreGoods-Buy", GUIType.Button)
  self.ivMoney = self:getChildWindowByName("BedWarStoreGoods-Money-Icon", GUIType.StaticImage)
  self.tvMoney = self:getChildWindowByName("BedWarStoreGoods-Money-Text", GUIType.StaticText)
  self.llLimit = self:getChildWindowByName("BedWarStoreGoods-Limit", GUIType.Layout)
  self.tvLimit = self:getChildWindowByName("BedWarStoreGoods-Limit-Text", GUIType.StaticText)
  self.tvTime = self:getChildWindowByName("BedWarStoreGoods-Time", GUIType.StaticText)
  self.btnSkin = self:getChildWindowByName("BedWarStoreGoods-Skin", GUIType.Button)
  self.btnSkin:SetVisible(false)
  self.llSelected = self:getChildWindowByName("BedWarStoreGoods-Selected")
  self.root:registerEvent(GUIEvent.Click, function()
    GUIStore:showGoodsDetail(self.data)
    SoundUtil.playSound(SoundConfig.selectGoodsStore)
  end)
  self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
    if self.data.GetWay == 2 then
      GUIStore:showGoodsDetail(self.data)
      if self.data.Price > 0 then
        ClientHelper.onWatchAd(Define.AdType.CubeStoreFreeTicket, self.data.Id)
      end
    else
      GUIStore:onBuyGoods(self.data)
      SoundUtil.playSound(SoundConfig.buyGoodsStore)
    end
  end)
end

function GUIStoreGoods:onDataChanged(data)
  self.data = data
  if self.data.GetWay == 2 then
    if GUIStore.getFreeTicketTimes ~= -1 then
      self.data.Price = GUIStore.getFreeTicketTimes
    end
    self.tvMoney:SetText(self.data.Price)
    if GameType == "g1046" and self.data.Price ~= 0 then
      self.btnBuy:SetNormalImage("set:free_gift.json image:btn_get_gift")
      self.btnBuy:SetPushedImage("set:free_gift.json image:btn_get_gift")
    else
      self.btnBuy:SetNormalImage("set:free_gift.json image:btn_get_gift_gray")
      self.btnBuy:SetPushedImage("set:free_gift.json image:btn_get_gift_gray")
      self.btnBuy:SetTouchable(false)
    end
    self.tvName:SetText(Lang:getString(data.Name))
    self.ivImage:SetImage(data.Image)
    self.ivMoney:SetImage("")
    self.btnBuy:SetProperty("StretchOffset", "40 0 0 0")
  else
    self.btnBuy:SetNormalImage("set:bed_war_store.json image:btn_blue")
    self.btnBuy:SetPushedImage("set:bed_war_store.json image:btn_blue")
    self.btnBuy:SetProperty("StretchOffset", "40 60 8 20")
    ClientStore:setGoodsUI(self.tvName, self.ivImage, self.ivMoney, self.tvMoney, self.btnBuy, data)
  end
  if data.CountText ~= "#" then
    self.tvCount:SetText(Lang:getString(data.CountText))
  else
    self.tvCount:SetText(string.format("x%d", data.Count))
  end
  self.llSelected:SetVisible(GUIStore:getCurrentGoodsId() == data.Id)
  self.llLimit:SetVisible(data.LimitCount ~= -1)
  if data.LimitCount == 0 then
    self.tvLimit:SetText(string.format("\226\150\162FFFF0000%d\226\150\162FFFFFFFF/%d", data.LimitCount, data.LimitMax))
  else
    self.tvLimit:SetText(string.format("%d/%d", data.LimitCount, data.LimitMax))
  end
  if self.data.Type == GoodsType.Privilege then
    local time = Privilege.getPrivilegeTime(self.data.ItemId)
    self.tvTime:SetVisible(0 < time)
    self.tvTime:SetText(DateUtil.getFormatTime(time, "HH:mm"))
  else
    self.tvTime:SetVisible(false)
  end
  self.btnSkin:SetVisible(data.BlockShopTabId ~= nil)
end

return GUIStoreGoods

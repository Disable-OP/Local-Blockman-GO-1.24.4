local GUILicenseGrandPriceItem = class("UILicenseGrandPriceItem", IGUIWindow)

function GUILicenseGrandPriceItem:onLoad()
  self.siIcon = self:getChildWindowByName("BedWarLicenseGrandItem-Icon", GUIType.StaticImage)
  self.btnIcon = self:getChildWindowByName("BedWarLicenseGrandItem-Icon-Button", GUIType.Button)
  self.siIconBg = self:getChildWindowByName("BedWarLicenseGrandItem-Icon-bg", GUIType.StaticImage)
  self.stNum = self:getChildWindowByName("BedWarLicenseGrandItem-Num", GUIType.StaticText)
  self.btnIcon:registerEvent(GUIEvent.ButtonClick, function()
    GUILicenseGrandPriceDisplay:onLongClick(self.Index, self.RewardType, self.Desc)
  end)
  self.btnIcon:registerEvent(GUIEvent.LongTouchStart, function()
    GUILicenseGrandPriceDisplay:onLongClick(self.Index, self.RewardType, self.Desc)
  end)
  self.btnIcon:registerEvent(GUIEvent.LongTouchEnd, function()
    GUILicenseGrandPriceDisplay:onLongClickEnd()
  end)
end

function GUILicenseGrandPriceItem:onDataChanged(data)
  self.Index = data.Index
  self.RewardType = data.RewardType or ""
  self.RewardId = data.RewardId
  local rewardConfig = RewardConfig.findRewardById(self.RewardId)
  if rewardConfig then
    self.siIcon:SetImage(rewardConfig.Image)
    self.Desc = rewardConfig.Desc
  else
    local good = CustomShopConfig:getGoodsConfig(self.RewardId)
    if not good then
      return
    end
    self.siIcon:SetImage(good.Image)
    self.Desc = good.Name
  end
  self.stNum:SetText("\195\151 " .. data.RewardNum)
end

return GUILicenseGrandPriceItem

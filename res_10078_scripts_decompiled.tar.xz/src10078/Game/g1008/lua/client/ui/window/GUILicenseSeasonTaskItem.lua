local GUILicenseSeasonTaskItem = class("GUILicenseSeasonTaskItem", IGUIWindow)

function GUILicenseSeasonTaskItem:onLoad()
  self.stEXPText = self:getChildWindowByName("BedWarLicenseSeasonTaskItem-EXP-Text", GUIType.StaticText)
  self.stDescribe = self:getChildWindowByName("BedWarLicenseSeasonTaskItem-Describe", GUIType.StaticText)
  self.btnBtn = self:getChildWindowByName("BedWarLicenseSeasonTaskItem-Btn", GUIType.Button)
  self.btnBtn:registerEvent(GUIEvent.ButtonClick, function()
    if self.status == 2 then
    elseif self.status == 3 then
      GamePacketSender:sendBedWarLicenseReceiveTaskReward(self.taskId)
    end
  end)
end

function GUILicenseSeasonTaskItem:onDataChanged(data)
  self.status = data.status
  self.taskId = data.taskId
  self.taskConfig = TaskConfig:getTaskById(data.taskId)
  if not self.taskConfig then
    return
  end
  local describe = string.format(Lang:getString(self.taskConfig.Desc), data.progress, self.taskConfig.GoalNum)
  if data.progress > self.taskConfig.GoalNum then
    local text = "\226\150\162FFF4EA54" .. self.taskConfig.GoalNum .. "\226\150\162FFFFFFFF / " .. self.taskConfig.GoalNum
    self.stDescribe:SetText(describe .. "\n" .. text)
  else
    local text = "\226\150\162FFF4EA54" .. data.progress .. "\226\150\162FFFFFFFF / " .. self.taskConfig.GoalNum
    self.stDescribe:SetText(describe .. "\n" .. text)
  end
  self.stEXPText:SetText(Lang:getString(self.taskConfig.Reward))
  if data.status == 2 then
    self.btnBtn:SetText(Lang:getString("gui_bed_war_license_season_task_progressing"))
    self.btnBtn:SetNormalImage("set:bedwar_license.json image:btn_yello")
    self.btnBtn:SetPushedImage("set:bedwar_license.json image:btn_yello")
    self.btnBtn:SetTouchable(false)
  elseif data.status == 3 then
    self.btnBtn:SetText(Lang:getString("gui_bed_war_license_season_task_receive"))
    self.btnBtn:SetNormalImage("set:bedwar_license.json image:btn_green")
    self.btnBtn:SetPushedImage("set:bedwar_license.json image:btn_green")
    self.btnBtn:SetTouchable(true)
  elseif data.status == 4 and self.taskConfig.NextTaskId == 0 then
    self.btnBtn:SetText(Lang:getString("gui_bed_war_license_season_task_finish"))
    self.btnBtn:SetNormalImage("set:bedwar_licenseexchange.json image:cannot_exchange")
    self.btnBtn:SetPushedImage("set:bedwar_licenseexchange.json image:cannot_exchange")
    self.btnBtn:SetTouchable(false)
  end
end

return GUILicenseSeasonTaskItem

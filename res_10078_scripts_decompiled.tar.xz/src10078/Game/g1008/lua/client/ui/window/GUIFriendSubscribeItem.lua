local GUIFriendSubscribeItem = class("GUISubscribeItem", IGUIWindow)
local FollowIcon = {
  [Define.FollowStatus.Follow] = "set:bed_war_3_button.json image:btn_0_friends03",
  [Define.FollowStatus.Fan] = "set:bed_war_3_button.json image:btn_0_friends02",
  [Define.FollowStatus.EachFollow] = "set:bed_war_3_button.json image:btn_0_friends01"
}
local FollowTipText = {
  [Define.FollowStatus.Follow] = {
    title = "gui_cancel_follow_tip_title",
    text = "gui_cancel_follow_tip_text"
  },
  [Define.FollowStatus.Fan] = {
    title = "gui_follow_tip_title",
    text = "gui_follow_tip_text"
  },
  [Define.FollowStatus.EachFollow] = {
    title = "gui_cancel_follow_tip_title",
    text = "gui_cancel_follow_tip_text"
  }
}

function GUIFriendSubscribeItem:onLoad()
  self.userId = 0
  self.data = {}
  self.lytHeadItem = self:getChildWindowByName("BedWarSubscribeItem-Head-Item", GUIType.Layout)
  self.stLv = self:getChildWindowByName("BedWarSubscribeItem-Lv", GUIType.StaticText)
  self.stName = self:getChildWindowByName("BedWarSubscribeItem-Name", GUIType.StaticText)
  self.siSex = self:getChildWindowByName("BedWarSubscribeItem-Sex", GUIType.StaticImage)
  self.siSegment = self:getChildWindowByName("BedWarSubscribeItem-Segment", GUIType.StaticImage)
  self.siVip = self:getChildWindowByName("BedWarSubscribeItem-Vip", GUIType.StaticImage)
  self.btnStatus = self:getChildWindowByName("BedWarSubscribeItem-Status", GUIType.Button)
  self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.lytHeadItem:GetPixelSize().x)
  self.lytHeadItem:AddChildWindow(self.winHead.root)
  self:initEvent()
end

function GUIFriendSubscribeItem:initEvent()
  self.btnStatus:registerEvent(GUIEvent.ButtonClick, function()
    if not self.userId or self.userId == 0 then
      return
    end
    if self.data.followStatus == Define.FollowStatus.Fan then
      WebService:FollowOtherPlayer(Game:getPlatformUserId(), self.userId, function(code, data)
        if code == 1 then
          Events.PlayerFollowEvent:invoke(self.userId, Define.FollowOperationType.Follow)
          UIHelper.showToast(Lang:getString("gui_follow_tip_text"))
        end
      end)
    else
      CustomDialog.builder().setTitleText(FollowTipText[self.data.followStatus].title).setContentText(Lang:getString(FollowTipText[self.data.followStatus].text)).setRightText("gui_dialog_tip_btn_sure").setLeftText("gui_dialog_tip_btn_cancel").setRightClickListener(function()
        WebService:CancelFollowOtherPlayer(Game:getPlatformUserId(), self.userId, function(code, data)
          if code == 1 then
            Events.PlayerFollowEvent:invoke(self.userId, Define.FollowOperationType.CancelFollow)
          end
        end)
      end).show()
    end
  end)
end

function GUIFriendSubscribeItem:onDataChanged(data)
  if not self.fit then
    local width = self.root:GetPixelSize().y / 124 * 85
    self.lytHeadItem:SetWidth({0, width})
    self.lytHeadItem:SetHeight({0, width})
    self.winHead:setSize(width)
    self.fit = true
  end
  if not data.userId then
    return
  end
  self.data = data
  self.userId = data.userId
  self.winHead:setUserInfo(data)
  self.siSex:SetImage(Define.SexIcon[data.sex])
  local vipIcon = Define.VipIcon[data.vip or 0] or ""
  self.siVip:SetVisible(0 < string.len(vipIcon))
  self.siVip:SetImage(vipIcon)
  self.stName:SetText(data.nickName)
  self.btnStatus:SetNormalImage(FollowIcon[data.followStatus] or "")
  self.btnStatus:SetPushedImage(FollowIcon[data.followStatus] or "")
end

function GUIFriendSubscribeItem:onDestroy()
  if self.winHead then
    self.winHead:destroy()
  end
end

return GUIFriendSubscribeItem

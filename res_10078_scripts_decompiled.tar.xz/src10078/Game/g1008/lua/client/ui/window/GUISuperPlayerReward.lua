local GUISuperPlayerReward = class("GUISuperPlayerReward", IGUIWindow)

function GUISuperPlayerReward:onLoad()
  self.llContent = self:getChildWindow(0)
  self.ivIcon = self:getChildWindow(0, GUIType.StaticImage, self.llContent)
  self.ivStatus = self:getChildWindow(1, nil, self.llContent)
  self.tvName = self:getChildWindow(2, GUIType.StaticText, self.llContent)
end

function GUISuperPlayerReward:setReward(rewardId)
  local reward = RewardConfig.findRewardById(rewardId)
  if not reward then
    return
  end
  self.ivIcon:SetImage(reward.Image)
  self.tvName:SetText(Lang:getString(reward.Name))
  self.ivStatus:SetVisible(false)
end

function GUISuperPlayerReward:setReceived(received)
  self.ivStatus:SetVisible(received)
end

return GUISuperPlayerReward

local GUIDailySignInItem = class("GUIDailySignInItem", IGUIWindow)

function GUIDailySignInItem:onLoad()
  self.id = nil
  self.item = nil
  self.status = DailySignInStatus.WAIT_SIGN_IN
  self.llContent = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
  self.llContent:registerEvent(GUIEvent.TouchUp, function()
    self:onItemClick()
  end)
  self.tvTitle = self:getChildWindow(0, GUIType.StaticText, self.llContent)
  self.tvName = self:getChildWindow(1, GUIType.StaticText, self.llContent)
  self.tvHint = self:getChildWindow(2, GUIType.StaticText, self.llContent)
  self.llMask = self:getChildWindow(3, GUIType.Layout, self.llContent)
  self.ivEffect = self:getChildWindow(0, GUIType.StaticImage, self.tvName)
  self.ivIcon = self:getChildWindow(1, GUIType.StaticImage, self.tvName)
end

function GUIDailySignInItem:setSignInItem(item)
  if not item then
    return
  end
  self.id = item.Id
  self.item = item
  local reward = RewardConfig.findRewardById(item.RewardId)
  if not reward then
    self:setVisible(false)
    return
  end
  self.tvTitle:SetText(Lang:getString(item.Title))
  self.ivIcon:SetImage(reward.Image)
  self.tvName:SetText(Lang:getString(reward.Name))
  self:setStatus(item.Status)
end

function GUIDailySignInItem:setStatus(status)
  self.status = status
  if not self.item then
    return
  end
  if self.status == DailySignInStatus.FINISHED then
    self.llContent:SetBackImage(self.item.Background)
    self.ivEffect:SetVisible(false)
    self.tvHint:SetVisible(false)
    self.llMask:SetVisible(true)
  elseif self.status == DailySignInStatus.SIGN_IN_AGAIN then
    self.llContent:SetBackImage(self.item.Background)
    self.ivEffect:SetVisible(true)
    self.tvHint:SetVisible(true)
    self.llMask:SetVisible(false)
    self.tvHint:SetText(Lang:getString("bed.war.daily.sign.in.again"))
  elseif self.status == DailySignInStatus.WAIT_SIGN_IN_AGAIN then
    self.llContent:SetBackImage(self.item.Background)
    self.ivEffect:SetVisible(false)
    self.tvHint:SetVisible(true)
    self.llMask:SetVisible(false)
    self.tvHint:SetText(Lang:getString("bed.war.daily.wait.sign.in.again"))
  elseif self.status == DailySignInStatus.SIGN_IN then
    self.llContent:SetBackImage("set:bed_war_daily_sign_in.json image:item_receive")
    self.ivEffect:SetVisible(true)
    self.tvHint:SetVisible(true)
    self.llMask:SetVisible(false)
    self.tvHint:SetText(Lang:getString("bed.war.daily.sign.in"))
  elseif self.status == DailySignInStatus.WAIT_SIGN_IN then
    self.llContent:SetBackImage(self.item.Background)
    self.ivEffect:SetVisible(false)
    self.tvHint:SetVisible(true)
    self.llMask:SetVisible(false)
    self.tvHint:SetText(Lang:getString("bed.war.daily.wait.sign.in"))
  end
end

function GUIDailySignInItem:onItemClick()
  if self.status == DailySignInStatus.SIGN_IN or self.status == DailySignInStatus.SIGN_IN_AGAIN then
    SoundUtil.clickUI()
    GamePacketSender:sendReceiveDailySignIn(self.id)
    if self.status == DailySignInStatus.SIGN_IN then
      local key = "g1008DailyReward" .. tostring(PlayerManager:getClientPlayer().userId)
      ClientHelper.putStringForKey(key, DateUtil.getYearDay())
      Events.UpdateDailySignInRedPointEvent:invoke(false)
    end
  end
end

return GUIDailySignInItem

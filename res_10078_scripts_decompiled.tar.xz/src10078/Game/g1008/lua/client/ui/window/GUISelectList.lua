local FriendScreenConfig = T(Global, "FriendScreenConfig")
local GUISelectList = class("GUISelectList", IGUIWindow)

function GUISelectList:onLoad()
  self.type = 0
  self.curSelect = 0
  self.lstList = self:getChildWindowByName("BedWarSelectList-Item-List", GUIType.List)
  self.stText = self:getChildWindowByName("BedWarSelectList-Content", GUIType.StaticText)
  self.btnClick = self:getChildWindowByName("BedWarSelectList-Click", GUIType.Button)
  self.stText:SetText(Lang:getString("gui_select_list_default_text"))
  self.lstList:SetVisible(false)
  self:initEvent()
end

function GUISelectList:initEvent()
  self.btnClick:registerEvent(GUIEvent.ButtonClick, function()
    local status = self.lstList:IsVisible()
    self.lstList:SetVisible(not status)
  end)
  self:registerEvent(Events.ScreenBeSelectedEvent, function(data)
    if data.mainType == self.type then
      self.stText:SetText(Lang:getString(data.name))
      self.lstList:SetVisible(false)
    end
  end)
end

function GUISelectList:initList(type)
  self.type = type
  self.stText:SetText(Lang:getString(Define.SelectTypeName[type] or ""))
  local setting = FriendScreenConfig:getListByType(self.type)
  if TableUtil.getTableSize(setting) > 6 then
    self.lstList:SetHeight({5.5, 0})
  end
  for i, v in pairs(setting) do
    if self.type == Define.SelectType.Lang and v.subType ~= 0 then
      v.name = CGame.Instance():getShellInterface():getLanguageDetail(v.name)
    end
    local item = UIHelper.newGameGUIWindow("GUISelectItem", "BedWarSelectItem.json")
    self.lstList:AddItem(item.root)
    item:setWidth({1, 0})
    item:initData(v)
  end
end

function GUISelectList:hideList()
  self.lstList:SetVisible(false)
end

return GUISelectList

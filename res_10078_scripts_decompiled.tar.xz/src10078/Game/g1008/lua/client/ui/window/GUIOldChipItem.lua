local GUIOldChipItemWindow = class("GUIOldChipItemWindow", IGUIWindow)

function GUIOldChipItemWindow:ctor(...)
  self.super.ctor(self, "OldChipItem.json", ...)
end

function GUIOldChipItemWindow:onLoad()
  self.siIcon = self:getChildWindowByName("OldChipItem-Icon", GUIType.StaticImage)
  self.stCount = self:getChildWindowByName("OldChipItem-Count", GUIType.StaticText)
end

function GUIOldChipItemWindow:onDataChanged(data)
  self.siIcon:SetImage(data.image)
  self.stCount:SetText(data.count)
end

return GUIOldChipItemWindow

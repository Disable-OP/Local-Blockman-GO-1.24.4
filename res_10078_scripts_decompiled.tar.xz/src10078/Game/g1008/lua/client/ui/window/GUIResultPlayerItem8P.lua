local cupIcon = {
  ["1"] = "set:result.json image:cup_kill_2",
  ["2"] = "set:result.json image:cup_kill_3",
  ["3"] = "set:result.json image:cup_kill_4",
  ["4"] = "set:result.json image:cup_kill_5",
  ["5"] = "set:result.json image:cup_kill_10",
  ["6"] = "set:result.json image:cup_gold_kill",
  ["7"] = "set:result.json image:cup_silver_kill",
  ["8"] = "set:result.json image:cup_gold_assist",
  ["9"] = "set:result.json image:cup_silver_assist",
  ["10"] = "set:result.json image:cup_gold_build",
  ["11"] = "set:result.json image:cup_silver_build",
  ["12"] = "set:result.json image:cup_diamonds",
  ["13"] = "set:result.json image:cup_gem"
}
local GUIResultPlayerItem8P = class("GUIResultPlayerItem8P", IGUIWindow)

function GUIResultPlayerItem8P:onLoad()
  self.llContent = self:getChildWindowByName("ResultPlayerItem", GUIType.Layout)
  self.tvRank = self:getChildWindowByName("ResultPlayerItem-Rank", GUIType.StaticText)
  self.ivHeadBorder = self:getChildWindowByName("ResultPlayerItem-Icon-Border", GUIType.StaticImage)
  self.uivHeadIcon = self:getChildWindowByName("ResultPlayerItem-Icon", GUIType.UrlImage)
  self.uivHeadIcon:setChildMaterial(0)
  self.ivSex = self:getChildWindowByName("ResultPlayerItem-Sex", GUIType.StaticImage)
  self.tvName = self:getChildWindowByName("ResultPlayerItem-Name", GUIType.StaticText)
  self.tvKill = self:getChildWindowByName("ResultPlayerItem-Kill-Text", GUIType.StaticText)
  self.tvDie = self:getChildWindowByName("ResultPlayerItem-Die-Text", GUIType.StaticText)
  self.tvKDA = self:getChildWindowByName("ResultPlayerItem-KDA-Text", GUIType.StaticText)
  self.ivKDABg = self:getChildWindowByName("ResultPlayerItem-KDA-Bg", GUIType.StaticImage)
  self.btnFriendButton = self:getChildWindowByName("ResultPlayerItem-Friend-Button", GUIType.Button)
  self.ivGoodBg = self:getChildWindowByName("ResultPlayerItem-Good-Bg", GUIType.StaticImage)
  self.ivGood = self:getChildWindowByName("ResultPlayerItem-Good", GUIType.StaticImage)
  self.llBed = self:getChildWindowByName("ResultPlayerItem-Beds", GUIType.Layout)
  self.llCup = self:getChildWindowByName("ResultPlayerItem-Cups", GUIType.Layout)
  self.btnFriendButton:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.addFriendSettlement)
    self.curInfo:setValue("show_add_friend", "0")
    ClientHttpRequest.friendOperation(4, self.data.userId)
  end)
  self.ivGoodBg:registerEvent(GUIEvent.TouchDown, function()
    SoundUtil.playSound(SoundConfig.sendGoodSettlement)
    local hadSend = self.curInfo:getValue("send_good") == "1"
    if not hadSend then
      self.curInfo:setValue("send_good", "1")
      GamePacketSender:sendSettlementGood(self.curInfo.infoKey)
    end
  end)
end

function GUIResultPlayerItem8P:onDataChanged(data)
  self.curInfo = data.info
  self.data = data
  self.btnFriendButton:SetVisible(false)
  self.tvRank:SetText(tostring(data.rank))
  self.tvKill:SetText(data.info:getValue("kill"))
  self.tvDie:SetText(data.info:getValue("die"))
  self.ivGood:SetVisible(true)
  self.ivGoodBg:SetVisible(tostring(data.userId) ~= tostring(Game:getPlatformUserId()))
  local config = TeamGUIInfo[data.info:getValue("teamId")]
  if tostring(data.userId) ~= tostring(Game:getPlatformUserId()) then
    self.llContent:SetBackImage("set:result.json image:bg_item_2")
  else
    self.llContent:SetBackImage("set:result.json image:bg_item_2_pre")
  end
  self.ivHeadBorder:SetImage(config.header_border2)
  self.uivHeadIcon:setDefaultImage(config.header)
  self.uivHeadIcon:setUrl(data.info:getValue("picUrl"))
  self.tvName:SetText(data.info:getValue("userName"))
  self.tvName:SetTextColor(config.name_color)
  self.tvKDA:SetText(data.info:getKDA())
  if data.info:getValue("send_good") == "1" then
    self:getChildWindowByName("ResultPlayerItem-Good-Text", GUIType.StaticText):SetText(data.info:getValue("be_good_times"))
    self.ivGood:SetVisible(false)
  end
  if self.llBed:GetChildCount() == 1 then
    local bed = data.info:getValue("destroy_bed")
    local index = 0
    for i = 1, #bed do
      local bedId = string.sub(bed, i, i)
      config = TeamGUIInfo[bedId]
      if config then
        local column = math.fmod(index, 4)
        local row = math.floor(index / 4)
        local ivBed = GUIManager:createGUIWindow(GUIType.StaticImage, "BattlePlayerInfo-Bed-" .. GUIManager:applyWindowId())
        ivBed:SetWidth({0, 28})
        ivBed:SetHeight({0, 28})
        ivBed:SetXPosition({
          0,
          column * 26
        })
        ivBed:SetYPosition({
          0,
          row * 26
        })
        ivBed:SetImage(config.bed)
        ivBed:setMaterial(20001)
        self.llBed:AddChildWindow(ivBed)
        index = index + 1
      end
    end
  end
  if self.llCup:GetChildCount() == 0 then
    local cupIds = data.info:getCupIds()
    local index = 0
    for _, cupId in pairs(cupIds) do
      local image = cupIcon[cupId]
      if image then
        local row = math.floor(index / 4)
        local column = math.fmod(index, 4)
        local ivCup = GUIManager:createGUIWindow(GUIType.StaticImage, "BattlePlayerInfo-Cup-" .. GUIManager:applyWindowId())
        ivCup:SetWidth({0, 28})
        ivCup:SetHeight({0, 28})
        ivCup:SetXPosition({
          0,
          column * 26
        })
        ivCup:SetYPosition({
          0,
          row * 26
        })
        ivCup:SetImage(image)
        ivCup:setMaterial(20001)
        self.llCup:AddChildWindow(ivCup)
        index = index + 1
      end
    end
  end
  if tonumber(data.info:getValue("sex")) == 1 then
    self.ivSex:SetImage("set:result.json image:sex_man")
  else
    self.ivSex:SetImage("set:result.json image:sex_woman")
  end
  if tonumber(data.info:getValue("show_add_friend")) == 1 and tostring(data.userId) ~= tostring(Game:getPlatformUserId()) then
    self.btnFriendButton:SetVisible(true)
    self.btnFriendButton:SetNormalImage("set:result.json image:friend_add")
    self.btnFriendButton:SetPushedImage("set:result.json image:friend_add")
  else
    self.btnFriendButton:SetVisible(false)
  end
  local isMvp = tonumber(self.curInfo:getValue("isMvp")) == 1
  local teamId = data.info:getValue("teamId")
  self:updateStatus(isMvp, teamId)
end

function GUIResultPlayerItem8P:updateStatus(isMvp, teamId)
  if isMvp then
    local teamInfo = GameInfoManager:getTeamInfo(teamId)
    if teamInfo and teamInfo:getValue("isWin") == "0" then
      self.ivKDABg:SetImage("set:result.json image:kda_mvp_failed")
    else
      self.ivKDABg:SetImage("set:result.json image:kda_mvp_victory")
    end
  else
    self.ivKDABg:SetImage("set:result.json image:kda_bg")
  end
end

return GUIResultPlayerItem8P

local GUIFirstRechargeReward = class("GUIFirstRechargeReward", IGUIWindow)

function GUIFirstRechargeReward:onLoad()
  self.ivIcon = self:getChildWindow(0, GUIType.StaticImage)
  self.tvCount = self:getChildWindow(1, GUIType.StaticText)
end

function GUIFirstRechargeReward:setReward(rewardId)
  local reward = RewardConfig.findRewardById(rewardId)
  if not reward then
    return
  end
  self.ivIcon:SetImage(reward.Image)
  self.tvCount:SetText(tostring(reward.Count))
end

return GUIFirstRechargeReward

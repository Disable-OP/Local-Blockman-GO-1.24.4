local GUIUpgradeGoods = class("GUIStoreGoods", IGUIWindow)

function GUIUpgradeGoods:onLoad()
  self.ivImage = self:getChildWindowByName("BedWarUpgradeGoods-Image", GUIType.StaticImage)
  self.tvLevel = self:getChildWindowByName("BedWarUpgradeGoods-Level-Text", GUIType.StaticText)
  self.llSelected = self:getChildWindowByName("BedWarUpgradeGoods-Select")
  self.root:registerEvent(GUIEvent.Click, function()
    GUIUpgradeStore:showGoodsDetail(self.data)
    SoundUtil.playSound(SoundConfig.selectGoodsStore)
  end)
end

function GUIUpgradeGoods:onDataChanged(data)
  self.data = data
  if self.data.Id == nil then
    self.root:SetVisible(false)
    return
  end
  self.root:SetVisible(true)
  self.ivImage:SetImage(data.Image)
  self.tvLevel:SetText(string.format("LV.%d", data.Level))
  self.llSelected:SetVisible(GUIUpgradeStore:getCurrentGoodsId() == data.Id)
end

return GUIUpgradeGoods

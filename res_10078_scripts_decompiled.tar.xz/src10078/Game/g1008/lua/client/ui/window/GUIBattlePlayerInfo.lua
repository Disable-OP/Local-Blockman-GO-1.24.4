local ArmorKeys = {
  "ItemSword",
  "ItemBow",
  "ItemArmor101",
  "ItemArmor102",
  "ItemArmor103"
}
local GUIBattlePlayerInfo = class("GUIBattlePlayerInfo", IGUIWindow)

function GUIBattlePlayerInfo:onLoad()
  self.llContent = self:getChildWindowByName("BedWarBattlePlayerInfo-Item-Bg", GUIType.StaticImage)
  self.ivMeHint = self:getChildWindowByName("BedWarBattlePlayerInfo-Me-Item-Hint", GUIType.StaticImage)
  self.ivHeadBorder = self:getChildWindowByName("BedWarBattlePlayerInfo-Icon-Border", GUIType.StaticImage)
  self.uivHeadIcon = self:getChildWindowByName("BedWarBattlePlayerInfo-Icon", GUIType.UrlImage)
  self.uivHeadIcon:setChildMaterial(0)
  self.tvName = self:getChildWindowByName("BedWarBattlePlayerInfo-Name", GUIType.StaticText)
  self.tvKill = self:getChildWindowByName("BedWarBattlePlayerInfo-Kill", GUIType.StaticText)
  self.tvDie = self:getChildWindowByName("BedWarBattlePlayerInfo-Die", GUIType.StaticText)
  self.tvAssist = self:getChildWindowByName("BedWarBattlePlayerInfo-Assist", GUIType.StaticText)
  self.btnFriendButton = self:getChildWindowByName("BedWarBattlePlayerInfo-Friend-Button", GUIType.Button)
  self.btnFriendNo = self:getChildWindowByName("BedWarBattlePlayerInfo-Friend-No", GUIType.Button)
  self.ivFriendStatus = self:getChildWindowByName("BedWarBattlePlayerInfo-Friend-Status", GUIType.StaticImage)
  self.cbMuteVoice = self:getChildWindowByName("BedWarBattlePlayerInfo-Mute-Voice", GUIType.CheckBox)
  self.cbMuteVoice:registerEvent(GUIEvent.CheckStateChanged, function()
    SoundUtil.playSound(SoundConfig.banChatBattle)
    if self.cbMuteVoice:GetChecked() then
      self.data.info:setValue("mute_voice", "1")
    else
      self.data.info:setValue("mute_voice", "0")
    end
  end)
  self.llBed = self:getChildWindowByName("BedWarBattlePlayerInfo-Bed", GUIType.Layout)
  self.ivArmors = {}
  for i = 1, 5 do
    table.insert(self.ivArmors, self:getChildWindowByName("BedWarBattlePlayerInfo-Armor" .. i, GUIType.StaticImage))
  end
  self.btnFriendButton:registerEvent(GUIEvent.ButtonClick, function()
    local user = UserManager.Instance():findUser(self.data.userId)
    if user then
      if user.isFriend then
        return
      end
      if user.isRobot then
        SoundUtil.playSound(SoundConfig.addFriendSettlement)
        user.isSend = true
        self.data.isSend = true
        self:onDataChanged(self.data)
        return
      end
      if user.isFriendRequest then
        SoundUtil.playSound(SoundConfig.agreeFriendBattle)
        ClientHttpRequest.friendOperation(1, self.data.userId)
      else
        if user.isSend then
          return
        end
        SoundUtil.playSound(SoundConfig.addFriendSettlement)
        self.data.isSend = true
        ClientHttpRequest.friendOperation(4, self.data.userId)
      end
    else
      SoundUtil.playSound(SoundConfig.addFriendSettlement)
      self.data.isSend = true
      self:onDataChanged(self.data)
      ClientHttpRequest.friendOperation(4, self.data.userId)
    end
  end)
  self.btnFriendNo:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.refuseFriendBattle)
    local user = UserManager.Instance():findUser(self.data.userId)
    if user then
      user.isFriendRequest = false
    end
    self.btnFriendNo:SetVisible(false)
    self.btnFriendButton:SetVisible(false)
  end)
end

function GUIBattlePlayerInfo:onDataChanged(data)
  self.data = data
  self.llBed:CleanupChildren()
  self.btnFriendButton:SetVisible(false)
  self.btnFriendNo:SetVisible(false)
  self.ivFriendStatus:SetVisible(false)
  self.tvKill:SetText(data.info:getValue("kill"))
  self.tvDie:SetText(data.info:getValue("die"))
  self.tvAssist:SetText(data.info:getValue("assist"))
  self.ivMeHint:SetVisible(tostring(data.userId) == tostring(Game:getPlatformUserId()))
  self.cbMuteVoice:SetVisible(tostring(data.userId) ~= tostring(Game:getPlatformUserId()))
  local config = TeamGUIInfo[data.info:getValue("teamId")]
  self.ivMeHint:SetImage(config.me_item_color)
  self.llContent:SetImage(config.item_color)
  self.ivHeadBorder:SetImage(config.header_border)
  self.uivHeadIcon:setDefaultImage(config.header)
  self.uivHeadIcon:setUrl(data.info:getValue("picUrl"))
  self.tvName:SetText(data.info:getValue("userName"))
  self.tvName:SetTextColor(config.name_color)
  self.cbMuteVoice:SetChecked(data.info:getValue("mute_voice") == "1")
  local bed = data.info:getValue("destroy_bed")
  for i = 1, #bed do
    local bedId = string.sub(bed, i, i)
    config = TeamGUIInfo[bedId]
    if config then
      local ivBed = GUIManager:createGUIWindow(GUIType.StaticImage, "BattlePlayerInfo-Bed-" .. GUIManager:applyWindowId())
      ivBed:SetWidth({0, 21})
      ivBed:SetHeight({0, 20})
      ivBed:SetYPosition({
        0,
        (i - 1) * 22
      })
      ivBed:SetImage(config.bed)
      ivBed:setMaterial(20001)
      self.llBed:AddChildWindow(ivBed)
    end
  end
  for index, key in pairs(ArmorKeys) do
    local armorId = tonumber(data.info:getValue(key))
    if armorId == 0 then
      self.ivArmors[index]:SetImage("")
    else
      GuiItemStack.showItemIcon(self.ivArmors[index], armorId, 0, "")
    end
  end
  local user = UserManager.Instance():findUser(data.userId)
  if not user then
    if self.data.isSend then
      self.ivFriendStatus:SetVisible(true)
      self.ivFriendStatus:SetImage("set:bed_war_battle_info.json image:friend_send")
    else
      self.btnFriendButton:SetVisible(true)
      self.btnFriendButton:SetNormalImage("set:bed_war_battle_info.json image:friend_add")
      self.btnFriendButton:SetPushedImage("set:bed_war_battle_info.json image:friend_add")
    end
    return
  end
  data.info:setValue("sex", tostring(user.sex))
  if tostring(data.userId) == tostring(Game:getPlatformUserId()) then
    return
  end
  if user.isFriend then
    self.ivFriendStatus:SetVisible(true)
    self.ivFriendStatus:SetImage("set:bed_war_battle_info.json image:friend_request")
    data.info:setValue("show_add_friend", "0")
    return
  end
  if user.isFriendRequest then
    self.btnFriendButton:SetVisible(true)
    self.btnFriendButton:SetNormalImage("set:bed_war_battle_info.json image:friend_yes")
    self.btnFriendButton:SetPushedImage("set:bed_war_battle_info.json image:friend_yes")
    self.btnFriendNo:SetVisible(true)
    data.info:setValue("show_add_friend", "0")
    return
  end
  if user.isSend then
    self.ivFriendStatus:SetVisible(true)
    self.ivFriendStatus:SetImage("set:bed_war_battle_info.json image:friend_send")
    data.info:setValue("show_add_friend", "0")
    return
  end
  self.btnFriendButton:SetVisible(true)
  self.btnFriendButton:SetNormalImage("set:bed_war_battle_info.json image:friend_add")
  self.btnFriendButton:SetPushedImage("set:bed_war_battle_info.json image:friend_add")
end

function GUIBattlePlayerInfo:setRightLayout()
  self.llContent:SetHorizontalAlignment(HorizontalAlignment.Left)
  local ontSize = self:getChildWindowByName("BedWarBattlePlayerInfo-OutSize")
  ontSize:SetXPosition({1, 0})
  local btn1 = ontSize:GetChildByIndex(0)
  btn1:SetHorizontalAlignment(HorizontalAlignment.Left)
  btn1:SetXPosition({0, 10})
  local btn2 = ontSize:GetChildByIndex(1)
  btn2:SetHorizontalAlignment(HorizontalAlignment.Left)
  btn2:SetXPosition({0, 55})
  local btn3 = ontSize:GetChildByIndex(2)
  btn3:SetHorizontalAlignment(HorizontalAlignment.Left)
  btn3:SetXPosition({0, 55})
  local btn4 = ontSize:GetChildByIndex(3)
  btn4:SetHorizontalAlignment(HorizontalAlignment.Left)
  btn4:SetXPosition({0, 100})
end

return GUIBattlePlayerInfo

local GUIBedWarSurveyDescItem = class("GUIBedWarSurveyDescItem", IGUIWindow)
local tipType1 = 1046052
local tipType2 = 1046053

function GUIBedWarSurveyDescItem:onLoad()
  self.tvName = self:getChildWindowByName("BedWarSurveyDescItem-Name", GUIType.StaticText)
  self.tvTimes = self:getChildWindowByName("BedWarSurveyDescItem-Times", GUIType.StaticText)
  self.siIcon = self:getChildWindowByName("BedWarSurveyDescItem-Icon", GUIType.StaticImage)
  self.siBg = self:getChildWindowByName("BedWarSurveyDescItem-Bg", GUIType.StaticImage)
end

function GUIBedWarSurveyDescItem:init(index, data)
  self.index = index
  self.itemId = data.itemId
  self.useTimes = 0
  self.siIcon:SetImage(data.icon)
  self.tvName:SetText(Lang:getString(data.name))
  self.tvTimes:SetText(Lang:getTipString(tipType1))
end

function GUIBedWarSurveyDescItem:onUseTimesChange(useTimes)
  self.useTimes = useTimes
  if 0 < useTimes then
    self.tvTimes:SetText(Lang:getTipString(tipType2, useTimes))
    self.siBg:SetImage("set:bed_war_survey.json image:had_use")
  else
    self.tvTimes:SetText(Lang:getTipString(tipType1))
    self.siBg:SetImage("set:bed_war_store.json image:item_bg")
  end
end

return GUIBedWarSurveyDescItem

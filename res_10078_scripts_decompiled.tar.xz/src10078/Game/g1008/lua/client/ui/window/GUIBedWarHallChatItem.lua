local GUIBedWarHallChatItemWindow = class("GUIBedWarHallChatItemWindow", IGUIWindow)
local TeamService = T(Global, "TeamService")
local ChatClient = T(Global, "ChatClient")

function GUIBedWarHallChatItemWindow:ctor(...)
  self.super.ctor(self, "BedWarHallChatItem.json", ...)
end

function GUIBedWarHallChatItemWindow:onLoad()
  self.llHeadImg = self:getChildWindowByName("BedWarHallChatItem-HeadImg", GUIType.Layout)
  self.siSex = self:getChildWindowByName("BedWarHallChatItem-Sex", GUIType.StaticImage)
  self.siDan = self:getChildWindowByName("BedWarHallChatItem-Dan", GUIType.StaticImage)
  self.stName = self:getChildWindowByName("BedWarHallChatItem-Name", GUIType.StaticText)
  self.stLv = self:getChildWindowByName("BedWarHallChatItem-Lv", GUIType.StaticText)
  self.siBubble = self:getChildWindowByName("BedWarHallChatItem-Bubble", GUIType.StaticImage)
  self.siBubbleHead = self:getChildWindowByName("BedWarHallChatItem-Bubble-Head", GUIType.StaticImage)
  self.stMsg = self:getChildWindowByName("BedWarHallChatItem-Msg", GUIType.StaticText)
  self.llTeam = self:getChildWindowByName("BedWarHallChatItem-Team", GUIType.Layout)
  self.stTeamMode = self:getChildWindowByName("BedWarHallChatItem-Team-Mode", GUIType.StaticText)
  self.stTeamDan = self:getChildWindowByName("BedWarHallChatItem-Team-Dan", GUIType.StaticText)
  self.siTeamModeIcon = self:getChildWindowByName("BedWarHallChatItem-Team-Mode-Icon", GUIType.StaticImage)
  self.stTeamMsg = self:getChildWindowByName("BedWarHallChatItem-Team-Msg", GUIType.StaticText)
  self.btnJoinTeamBtn = self:getChildWindowByName("BedWarHallChatItem-Join-Team-Btn", GUIType.Button)
  self.stJoinTeamText = self:getChildWindowByName("BedWarHallChatItem-Join-Text", GUIType.StaticText)
  self.siJoinTeamIcon = self:getChildWindowByName("BedWarHallChatItem-Join-Icon", GUIType.StaticImage)
  self.siVoice = self:getChildWindowByName("BedWarHallChatItem-Voice", GUIType.StaticImage)
  self.siGameEmoji = self:getChildWindowByName("BedWarHallChatItem-GameEmoji", GUIType.StaticImage)
  self.uivImage = self:getChildWindowByName("BedWarHallChatItem-UrlImage", GUIType.UrlImage)
  self:initView()
  self:initEvent()
end

function GUIBedWarHallChatItemWindow:initView()
  self.stJoinTeamText:SetText(Lang:getString("gui_chat_item_join_team_text"))
  self.stMsg:SetVisible(false)
  self.llTeam:SetVisible(false)
  self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeadImg:GetPixelSize().x)
  self.llHeadImg:AddChildWindow(self.winHead.root)
  self.winHead:setCanOpenPersonalHome(false)
  self.stLv:SetVisible(false)
end

function GUIBedWarHallChatItemWindow:initEvent()
  self.btnJoinTeamBtn:registerEvent(GUIEvent.ButtonClick, function()
    if TeamService:sendJoinTeam(self.data.data.teamId, self.data.data.token, self.data.data.regionId, self.data.data.engineVersion) then
      GUIBedWarHallChatLayout:hide()
    end
  end)
  self.llHeadImg:registerEvent(GUIEvent.Click, function()
    Events.ChatShowPlayerInfoEvent:invoke(self.playerInfo)
  end)
  self.siBubble:registerEvent(GUIEvent.Click, function()
    if self.data.type ~= Define.ChatMsgType.VoiceMsg then
      return
    end
    self:playVoice()
  end)
end

function GUIBedWarHallChatItemWindow:onDataChanged(data)
  self.data = data
  self:setSide(data.sendId == Game:getPlatformUserId())
  self.playerInfo = UserInfoCache:GetCache(data.sendId)
  if self.playerInfo then
    self.winHead:setUserInfo(self.playerInfo)
    self.stName:SetText(self.playerInfo.name)
    self.stLv:SetText("Lv." .. (self.playerInfo.playerLevel or 1))
    self.siDan:SetImage()
    self.siSex:SetImage(Define.SexIcon[self.playerInfo.sex] or Define.SexIcon[Define.SexType.Boy])
  end
  local msgData = data.data
  self:hideAll()
  self.siBubble:SetVisible(true)
  if data.type == Define.ChatMsgType.TextMsg then
    self.stMsg:SetVisible(true)
    self.stMsg:SetText(msgData.content)
    self:autoBarSize()
  elseif data.type == Define.ChatMsgType.TeamInviteMsg then
    self.llTeam:SetVisible(true)
    self.stTeamMode:SetText(Lang:getString(Define.GameModeName[data.data.gameType]) .. "( " .. data.data.memberCount .. " )")
    self.stTeamDan:SetText()
    self.stTeamMsg:SetText(data.data.msg or "")
    self.siTeamModeIcon:SetImage()
    self.root:SetHeight({0, 134})
    self.siBubble:SetHeight({0, 76})
    self.siBubble:SetWidth({1, -150})
  elseif data.type == Define.ChatMsgType.VoiceMsg then
    self.siVoice:SetVisible(true)
    self.root:SetHeight({0, 116})
    self.siBubble:SetHeight({0, 46})
    self.siBubble:SetWidth({0, 100})
  elseif data.type == Define.ChatMsgType.ImageMsg then
    self.siBubble:SetVisible(false)
    self.uivImage:SetVisible(true)
    self.uivImage:setUrl(msgData.uri)
    self.root:SetHeight({0, 120})
  elseif data.type == Define.ChatMsgType.CustomMsg and msgData.content.type == Define.CustomChatMsgType.EmojiMsg then
    self.siBubble:SetVisible(false)
    self.siGameEmoji:SetVisible(true)
    self.siGameEmoji:SetImage(msgData.content.emojiData)
    self.root:SetHeight({0, 120})
  end
end

function GUIBedWarHallChatItemWindow:hideAll()
  self.stMsg:SetVisible(false)
  self.llTeam:SetVisible(false)
  self.siVoice:SetVisible(false)
  self.siGameEmoji:SetVisible(false)
  self.uivImage:SetVisible(false)
end

function GUIBedWarHallChatItemWindow:autoBarSize()
  local strW = self.stMsg:GetTextWidth()
  local uiYOffset = self.siBubble:GetYPosition()[2]
  local uiW = self.root:GetPixelSize().x - 125
  local strH = math.max(self.stMsg:GetTextHeight() + 16, 46)
  if strW > uiW then
    self.siBubble:SetWidth({0, uiW})
    self.siBubble:SetHeight({0, strH})
  else
    self.siBubble:SetHeight({0, strH})
    self.siBubble:SetWidth({
      0,
      math.max(strW + 35, 55)
    })
  end
  self.root:SetHeight({
    0,
    math.max(uiYOffset + strH + 25, 106)
  })
end

local function getNewPosition(pos, offset)
  return {
    pos[1] * offset,
    pos[2] * offset
  }
end

function GUIBedWarHallChatItemWindow:setSide(isSelf)
  local HA = isSelf and HorizontalAlignment.Right or HorizontalAlignment.Left
  local offset = isSelf and -1 or 1
  local rotate = isSelf and 180 or 0
  self.llHeadImg:SetHorizontalAlignment(HA)
  self.siSex:SetHorizontalAlignment(HA)
  self.siDan:SetHorizontalAlignment(HA)
  self.siBubble:SetHorizontalAlignment(HA)
  self.siBubbleHead:SetHorizontalAlignment(HA)
  self.siVoice:SetHorizontalAlignment(HA)
  self.siGameEmoji:SetHorizontalAlignment(HA)
  self.uivImage:SetHorizontalAlignment(HA)
  self.stName:SetHorizontalAlignment(HA)
  self.stName:SetTextHorzAlign(HA)
  self.llHeadImg:SetXPosition(getNewPosition(self.llHeadImg:GetXPosition(), offset))
  self.siSex:SetXPosition(getNewPosition(self.siSex:GetXPosition(), offset))
  self.siDan:SetXPosition(getNewPosition(self.siDan:GetXPosition(), offset))
  self.stName:SetXPosition(getNewPosition(self.stName:GetXPosition(), offset))
  self.siBubble:SetXPosition(getNewPosition(self.siBubble:GetXPosition(), offset))
  self.siBubbleHead:SetXPosition(getNewPosition(self.siBubbleHead:GetXPosition(), offset))
  self.siVoice:SetXPosition(getNewPosition(self.siVoice:GetXPosition(), offset))
  self.siGameEmoji:SetXPosition(getNewPosition(self.siGameEmoji:GetXPosition(), offset))
  self.uivImage:SetXPosition(getNewPosition(self.uivImage:GetXPosition(), offset))
  self.siBubbleHead:SetRotate(rotate)
  self.siVoice:SetRotate(rotate)
end

function GUIBedWarHallChatItemWindow:playVoice()
  local msgData = self.data.data
  if not msgData.uri then
    return
  end
  ChatClient:playVoice(msgData.uri)
end

function GUIBedWarHallChatItemWindow:onDestroy()
  if self.winHead then
    self.winHead:destroy()
  end
end

return GUIBedWarHallChatItemWindow

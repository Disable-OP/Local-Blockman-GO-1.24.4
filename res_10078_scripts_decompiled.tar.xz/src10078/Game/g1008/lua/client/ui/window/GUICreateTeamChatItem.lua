local GUICreateTeamChatItemWindow = class("GUICreateTeamChatItemWindow", IGUIWindow)
local ChatClient = T(Global, "ChatClient")

function GUICreateTeamChatItemWindow:ctor(width, ...)
  self.super.ctor(self, "CreateTeamChatItem.json", ...)
  self.width = width
  self:setWidth({0, width})
end

function GUICreateTeamChatItemWindow:onLoad()
  self.tvText = self:getChildWindowByName("CreateTeamChatItem", GUIType.StaticText)
end

function GUICreateTeamChatItemWindow:onDataChanged(data)
  local text = ChatClient:chatMsgToString(data)
  self.tvText:SetText(text)
  local high = self.tvText:GetTextHeight()
  self.tvText:SetHeight({0, high})
end

return GUICreateTeamChatItemWindow

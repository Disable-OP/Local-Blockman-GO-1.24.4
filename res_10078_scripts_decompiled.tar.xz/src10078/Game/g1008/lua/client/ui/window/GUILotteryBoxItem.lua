local GUILotteryBoxItem = class("GUILotteryBoxItem", IGUIWindow)

function GUILotteryBoxItem:onLoad()
  self.bg = self:getChildWindow(0, GUIType.StaticImage)
  self.btnLotteryBox = self:getChildWindow(1, GUIType.Button)
  self.siLotteryBoxBg = self:getChildWindow(0, GUIType.StaticImage, self.btnLotteryBox)
end

function GUILotteryBoxItem:registerClick(id)
  self.btnLotteryBox:registerEvent(GUIEvent.ButtonClick, function()
    local config = RewardConfig.findRewardById(id)
    GUIBoxRewardDetail:show(config)
  end)
end

function GUILotteryBoxItem:onSetImage(img)
  self.siLotteryBoxBg:SetImage(img)
end

return GUILotteryBoxItem

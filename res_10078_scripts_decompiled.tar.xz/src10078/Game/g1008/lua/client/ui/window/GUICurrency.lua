local GUICurrency = class("GUICurrency", IGUIWindow)

function GUICurrency:onLoad()
  self.ivIcon = self:getChildWindowByName("BedWarCurrency-Icon", GUIType.StaticImage)
  self.tvMoney = self:getChildWindowByName("BedWarCurrency-Money", GUIType.StaticText)
  self.btnAdd = self:getChildWindowByName("BedWarCurrency-Add", GUIType.Button)
  self.btnAdd:SetVisible(PayHelper.isEnableRecharge())
  self.btnAdd:registerEvent(GUIEvent.ButtonClick, function()
    ClientHelper.onRecharge(1)
    SoundUtil.playSound(SoundConfig.rechargeCubeStore)
  end)
  self:registerEvent(CEvents.HideRechargeEvent, function()
    self.btnAdd:SetVisible(false)
  end)
end

function GUICurrency:onDataChanged(data)
  self.data = data
  self.btnAdd:SetVisible(data.RealId == 1)
  if data.ItemId > 0 then
    GuiItemStack.showItemIcon(self.ivIcon, data.ItemId, 0, "")
  elseif data.RealId > 0 then
    self.ivIcon:SetImage(PayHelper.getMoneyIcon(data.RealId))
  else
    self.ivIcon:SetImage("")
  end
end

function GUICurrency:onTick()
  local count = 0
  if 0 < self.data.ItemId then
    count = PlayerWallet.getCoinNum(self.data.Id)
  elseif 0 < self.data.RealId then
    count = PlayerWallet.getMoneyByCoinId(self.data.RealId)
  end
  self.tvMoney:SetText(tostring(count))
end

return GUICurrency

local GUILevelUpReward = class("GUILevelUpReward", IGUIWindow)

function GUILevelUpReward:onLoad()
  self.ivImage = self:getChildWindowByName("BedWarLevelUpReward-Image", GUIType.StaticImage)
  self.tvCount = self:getChildWindowByName("BedWarLevelUpReward-Count", GUIType.StaticText)
end

function GUILevelUpReward:onDataChanged(data)
  self.ivImage:SetImage(data.img)
  self.tvCount:SetText(string.format("+%d", tonumber(data.num)))
end

return GUILevelUpReward

local GUIFriendItem = class("GUIFriendItem", IGUIWindow)
local FriendManager = T(Global, "FriendManager")
local UIUtils = T(Global, "UIUtils")

function GUIFriendItem:onLoad()
  self.userId = 0
  self.data = {}
  self.lytHeadItem = self:getChildWindow(0, GUIType.Layout)
  self.stLv = self:getChildWindow(0, GUIType.StaticText, self.lytHeadItem)
  self.stName = self:getChildWindow(0, GUIType.StaticText, self.stLv)
  self.stStatus = self:getChildWindow(1, GUIType.StaticText, self.lytHeadItem)
  self.siSex = self:getChildWindow(2, GUIType.StaticImage, self.lytHeadItem)
  self.siSegment = self:getChildWindow(3, GUIType.StaticImage, self.lytHeadItem)
  self.siVip = self:getChildWindow(4, GUIType.StaticImage, self.lytHeadItem)
  self.btnChat = self:getChildWindow(1, GUIType.Button)
  self.btnDelete = self:getChildWindow(2, GUIType.Button)
  self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.lytHeadItem:GetPixelSize().x)
  self.lytHeadItem:AddChildWindow(self.winHead.root)
  self:initEvent()
end

function GUIFriendItem:initEvent()
  self.btnChat:registerEvent(GUIEvent.ButtonClick, function()
    GUIFriends:hide()
    GUIBedWarHallChatLayout:show(Define.ChatTabType.Friend, self.userId)
  end)
  self.btnDelete:registerEvent(GUIEvent.ButtonClick, function()
    if not self.userId or self.userId == 0 then
      return
    end
    CustomDialog.builder().setTitleText("gui_friend_delete_friend_tip_title").setContentText(Lang:getString("gui_friend_delete_friend_tip_text")).setRightText("gui_dialog_tip_btn_sure").setLeftText("gui_dialog_tip_btn_cancel").setRightClickListener(function()
      FriendManager.FriendOperation(Define.FriendOperationType.Delete, self.userId)
    end).show()
  end)
end

function GUIFriendItem:onDataChanged(data)
  if not self.fit then
    local width = self.root:GetPixelSize().y / 150 * 110
    self.lytHeadItem:SetWidth({0, width})
    self.lytHeadItem:SetHeight({0, width})
    self.winHead:setSize(width)
    self.fit = true
  end
  if not data.userId then
    return
  end
  self.data = data
  self.userId = data.userId
  self.winHead:setUserInfo(data)
  self.siSex:SetImage(Define.SexIcon[data.sex])
  local vipIcon = Define.VipIcon[data.vip or 0] or ""
  self.siVip:SetVisible(0 < string.len(vipIcon))
  self.siVip:SetImage(vipIcon)
  self.stName:SetText(data.nickName)
  self.stStatus:SetText(Lang:getString(Define.UserStatusLang[data.status] or "gui.user.status.offline"))
  if data.status == Define.UserStatus.Offline and data.logoutTime and 0 < data.logoutTime then
    local time = os.time() - data.logoutTime / 1000
    self.stStatus:SetText(UIUtils.GetLogoutTimeText(time))
  end
end

function GUIFriendItem:onDestroy()
  if self.winHead then
    self.winHead:destroy()
  end
end

return GUIFriendItem

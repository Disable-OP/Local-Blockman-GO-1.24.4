local GUIQuestionnaireItem = class("GUIStoreGoods", IGUIWindow)
local Color = {
  Select = {
    0.13725490196078433,
    3.9411764705882355,
    0.11372549019607843,
    1
  },
  Normal = {
    1,
    1,
    1,
    1
  }
}

function GUIQuestionnaireItem:ctor(...)
  self.super.ctor(self, "QuestionnaireItem.json", ...)
end

function GUIQuestionnaireItem:onLoad()
  self.old_choice_index = 0
  self.imgContentImage = self:getChildWindowByName("QuestionnaireItem-Content-Img", GUIType.StaticImage)
  self.tvContentText = self:getChildWindowByName("QuestionnaireItem-Content-Text", GUIType.StaticText)
  self.cbChoiceGood = self:getChildWindowByName("QuestionnaireItem-Choice-Good", GUIType.CheckBox)
  self.imgChoiceGoodHook = self:getChildWindowByName("QuestionnaireItem-Choice-Good-Hook", GUIType.StaticImage)
  self.tvChoiceGoodText = self:getChildWindowByName("QuestionnaireItem-Choice-Good-Text", GUIType.StaticText)
  self.cbChoiceNotGood = self:getChildWindowByName("QuestionnaireItem-Choice-NotGood", GUIType.CheckBox)
  self.imgChoiceNotGoodHook = self:getChildWindowByName("QuestionnaireItem-Choice-NotGood-Hook", GUIType.StaticImage)
  self.tvChoiceNotGoodText = self:getChildWindowByName("QuestionnaireItem-Choice-NotGood-Text", GUIType.StaticText)
  self.choiceGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
  self:initRegister()
end

function GUIQuestionnaireItem:initRegister()
  self.choiceGroup:addCheckBox(self.cbChoiceGood, function(checked)
    if checked then
      self.tvChoiceGoodText:SetTextColor(Color.Select)
      self.imgChoiceGoodHook:SetVisible(true)
    else
      self.tvChoiceGoodText:SetTextColor(Color.Normal)
      self.imgChoiceGoodHook:SetVisible(false)
    end
  end)
  self.choiceGroup:addCheckBox(self.cbChoiceNotGood, function(checked)
    if checked then
      self.tvChoiceNotGoodText:SetTextColor(Color.Select)
      self.imgChoiceNotGoodHook:SetVisible(true)
    else
      self.tvChoiceNotGoodText:SetTextColor(Color.Normal)
      self.imgChoiceNotGoodHook:SetVisible(false)
    end
  end)
end

function GUIQuestionnaireItem:setData(config)
  self.reportKey = config.reportKey
  self.tvChoiceGoodText:SetText(Lang:getString(config.goodLang))
  self.tvChoiceNotGoodText:SetText(Lang:getString(config.badLang))
  self.tvContentText:SetText(Lang:getString(config.mainLang))
  self.imgContentImage:SetImage(config.showImage)
  self.old_choice_index = tonumber(ClientHelper.getStringForKey("g1008_Questionnaire_Choice_" .. self.reportKey, "0"))
  self.choiceGroup:selectIndex(self.old_choice_index)
end

function GUIQuestionnaireItem:checkReport()
  local new_choice_index = self.choiceGroup:getCurIndex()
  if new_choice_index == 0 then
    return
  end
  if self.old_choice_index ~= new_choice_index then
    PlayerManager:getClientPlayer():sendPacket({
      pid = "GameAnalytics",
      event = "Questionnaire_Choice",
      pushData = json.encode({
        report_key = self.reportKey,
        choice_index = new_choice_index,
        old_index = self.old_choice_index
      })
    })
    ClientHelper.putStringForKey("g1008_Questionnaire_Choice_" .. self.reportKey, tostring(new_choice_index))
    self.old_choice_index = new_choice_index
  end
end

function GUIQuestionnaireItem:reset()
  self.choiceGroup:selectIndex(self.old_choice_index)
end

return GUIQuestionnaireItem

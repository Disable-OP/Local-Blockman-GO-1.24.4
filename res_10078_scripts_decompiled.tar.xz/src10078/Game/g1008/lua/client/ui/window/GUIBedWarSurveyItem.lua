local GUIBedWarSurveyItem = class("GUIBedWarSurveyItem", IGUIWindow)
local chooseTypeStr = {
  "Survey_Choose_one"
}
local ItemOptions = {
  "Survey_Item_1",
  "Survey_Item_2",
  "Survey_Item_3",
  "Survey_Item_4",
  "Survey_Item_5",
  "Survey_Item_6"
}
local TimeOptions = {
  "Survey_Time_1",
  "Survey_Time_2",
  "Survey_Time_3",
  "Survey_Time_4"
}

function GUIBedWarSurveyItem:onLoad()
  self.siItem = self:getChildWindowByName("BedWarSurveyItem-Item", GUIType.StaticImage)
  self.siFlash = self:getChildWindowByName("BedWarSurveyItem-Flash", GUIType.StaticImage)
  self.tvName = self:getChildWindowByName("BedWarSurveyItem-Name", GUIType.StaticText)
  self.tvDesc = self:getChildWindowByName("BedWarSurveyItem-Desc", GUIType.StaticText)
  self.tvType = self:getChildWindowByName("BedWarSurveyItem-Type-Text", GUIType.StaticText)
  self.tvCheckBox1 = self:getChildWindowByName("BedWarSurveyItem-CheckBox1-Name", GUIType.StaticText)
  self.tvCheckBox2 = self:getChildWindowByName("BedWarSurveyItem-CheckBox2-Name", GUIType.StaticText)
  self.tvCheckBox3 = self:getChildWindowByName("BedWarSurveyItem-CheckBox3-Name", GUIType.StaticText)
  self.tvCheckBox4 = self:getChildWindowByName("BedWarSurveyItem-CheckBox4-Name", GUIType.StaticText)
  self.tvCheckBox5 = self:getChildWindowByName("BedWarSurveyItem-CheckBox5-Name", GUIType.StaticText)
  self.tvCheckBox6 = self:getChildWindowByName("BedWarSurveyItem-CheckBox6-Name", GUIType.StaticText)
  self.cbCheckBox1 = self:getChildWindowByName("BedWarSurveyItem-CheckBox1", GUIType.CheckBox)
  self.cbCheckBox2 = self:getChildWindowByName("BedWarSurveyItem-CheckBox2", GUIType.CheckBox)
  self.cbCheckBox3 = self:getChildWindowByName("BedWarSurveyItem-CheckBox3", GUIType.CheckBox)
  self.cbCheckBox4 = self:getChildWindowByName("BedWarSurveyItem-CheckBox4", GUIType.CheckBox)
  self.cbCheckBox5 = self:getChildWindowByName("BedWarSurveyItem-CheckBox5", GUIType.CheckBox)
  self.cbCheckBox6 = self:getChildWindowByName("BedWarSurveyItem-CheckBox6", GUIType.CheckBox)
  self.cbCheckBox1:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbCheckBox1:GetChecked() then
      self:onClickCheckBox(self.select, 1)
    end
  end)
  self.cbCheckBox2:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbCheckBox2:GetChecked() then
      self:onClickCheckBox(self.select, 2)
    end
  end)
  self.cbCheckBox3:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbCheckBox3:GetChecked() then
      self:onClickCheckBox(self.select, 3)
    end
  end)
  self.cbCheckBox4:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbCheckBox4:GetChecked() then
      self:onClickCheckBox(self.select, 4)
    end
  end)
  self.cbCheckBox5:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbCheckBox5:GetChecked() then
      self:onClickCheckBox(self.select, 5)
    end
  end)
  self.cbCheckBox6:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbCheckBox6:GetChecked() then
      self:onClickCheckBox(self.select, 6)
    end
  end)
  self.select = 0
end

function GUIBedWarSurveyItem:init(index, data)
  self.index = index
  self.questionId = data.questionId
  self.siItem:SetImage(data.icon)
  self.tvName:SetText(Lang:getString(data.name))
  self.tvDesc:SetText(Lang:getString(data.desc))
  self.tvType:SetText(Lang:getString(chooseTypeStr[data.chooseType]))
  self.cbCheckBox1:SetVisible(true)
  self.cbCheckBox2:SetVisible(true)
  self.cbCheckBox3:SetVisible(true)
  self.cbCheckBox4:SetVisible(true)
  self.cbCheckBox5:SetVisible(true)
  self.cbCheckBox6:SetVisible(true)
  if data.type == Define.SurveyTaskType.UseItem then
    self.tvCheckBox1:SetText(Lang:getString(ItemOptions[1]))
    self.tvCheckBox2:SetText(Lang:getString(ItemOptions[2]))
    self.tvCheckBox3:SetText(Lang:getString(ItemOptions[3]))
    self.tvCheckBox4:SetText(Lang:getString(ItemOptions[4]))
    self.tvCheckBox5:SetText(Lang:getString(ItemOptions[5]))
    self.tvCheckBox6:SetText(Lang:getString(ItemOptions[6]))
  elseif data.type == Define.SurveyTaskType.PlayTime then
    self.tvCheckBox1:SetText(Lang:getString(TimeOptions[1]))
    self.tvCheckBox2:SetText(Lang:getString(TimeOptions[2]))
    self.tvCheckBox3:SetText(Lang:getString(TimeOptions[3]))
    self.tvCheckBox4:SetText(Lang:getString(TimeOptions[4]))
    self.cbCheckBox5:SetVisible(false)
    self.cbCheckBox6:SetVisible(false)
  end
end

function GUIBedWarSurveyItem:onClickCheckBox(oldIndex, newIndex)
  self.select = newIndex
  if self["cbCheckBox" .. oldIndex] then
    self["cbCheckBox" .. oldIndex]:SetChecked(false)
    self["cbCheckBox" .. oldIndex]:SetTouchable(true)
  end
  self["cbCheckBox" .. newIndex]:SetTouchable(false)
  GUIBedWarSurvey:onSelectNewItem()
end

function GUIBedWarSurveyItem:checkIsSelect()
  return self.select ~= 0
end

function GUIBedWarSurveyItem:showFlash()
  LuaTimer:cancel(self.flashKey)
  local curAlpha = 0
  local changeAlpha = 1
  self.siFlash:SetAlpha(curAlpha)
  self.flashKey = LuaTimer:scheduleTimer(function()
    curAlpha = curAlpha + changeAlpha
    if curAlpha == 10 then
      changeAlpha = -1
    end
    self.siFlash:SetAlpha(curAlpha / 10)
  end, 35, 20)
end

function GUIBedWarSurveyItem:onDoReport()
  return self.questionId, self.select
end

return GUIBedWarSurveyItem

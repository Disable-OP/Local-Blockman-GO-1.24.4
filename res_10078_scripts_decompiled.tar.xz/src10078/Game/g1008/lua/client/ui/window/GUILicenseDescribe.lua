local GUILicenseDescribe = class("GUIDescribe", IGUIWindow)

function GUILicenseDescribe:onLoad()
  self.stText = self:getChildWindowByName("BedWarLicenseGrandDescribe-Text")
end

function GUILicenseDescribe:onDataChange(data)
  self.stText:SetText(Lang:getString(data), true)
  local line = math.floor(self.stText:GetTextWidth() / 156) + 1
  self.root:SetHeight({
    0,
    math.max(self.stText:GetFont():GetFontHeight() * line + 44, 96)
  })
end

return GUILicenseDescribe

local GUIFriendRecommendItem = class("GUIFriendRecommendItem", IGUIWindow)
local FriendManager = T(Global, "FriendManager")

function GUIFriendRecommendItem:onLoad()
  self.userId = 0
  self.data = {}
  self.lytHeadItem = self:getChildWindow(0, GUIType.Layout)
  self.stLv = self:getChildWindow(0, GUIType.StaticText, self.lytHeadItem)
  self.stName = self:getChildWindow(0, GUIType.StaticText, self.stLv)
  self.stCountry = self:getChildWindow(1, GUIType.StaticText, self.lytHeadItem)
  self.stLang = self:getChildWindow(2, GUIType.StaticText, self.lytHeadItem)
  self.siSex = self:getChildWindow(3, GUIType.StaticImage, self.lytHeadItem)
  self.siSegment = self:getChildWindow(4, GUIType.StaticImage, self.lytHeadItem)
  self.siVip = self:getChildWindow(5, GUIType.StaticImage, self.lytHeadItem)
  self.btnAdd = self:getChildWindow(1, GUIType.Button)
  self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.lytHeadItem:GetPixelSize().x)
  self.lytHeadItem:AddChildWindow(self.winHead.root)
  self:initEvent()
end

function GUIFriendRecommendItem:initEvent()
  self.btnAdd:registerEvent(GUIEvent.ButtonClick, function()
    if not self.userId or self.userId == 0 then
      return
    end
    local msg = Lang:getString("gui_friend_request_default_msg")
    GUICustomInputContentLayout:setTipText(Lang:getString("gui_add_friend_msg_text"))
    GUICustomInputContentLayout:setDefaultContentText(msg)
    GUICustomInputContentLayout:setContentChangeListener(function(content)
      msg = content
    end)
    CustomDialog.builder().setTitleText("gui_add_friend_msg_title").setContentView(GUICustomInputContentLayout).setRightClickListener(function()
      FriendManager.FriendOperation(Define.FriendOperationType.Request, self.userId, msg)
      UIHelper.showToast(Lang:getString("gui.send.success"))
    end).show()
  end)
end

function GUIFriendRecommendItem:onDataChanged(data)
  if not self.fit then
    local width = self.root:GetPixelSize().y / 153 * 95
    self.lytHeadItem:SetWidth({0, width})
    self.lytHeadItem:SetHeight({0, width})
    self.winHead:setSize(width)
    self.fit = true
  end
  if not data.userId then
    return
  end
  self.data = data
  self.userId = data.userId
  self.winHead:setUserInfo(data)
  self.siSex:SetImage(Define.SexIcon[data.sex])
  local vipIcon = Define.VipIcon[data.vip or 0] or ""
  self.siVip:SetVisible(0 < string.len(vipIcon))
  self.siVip:SetImage(vipIcon)
  self.stName:SetText(data.nickName)
  local country = data.country and CGame.Instance():getShellInterface():getCountryDetail(data.country) or Lang:getString("gui_unknown_country")
  self.stCountry:SetText(Lang:getString("gui_friend_request_country_txt") .. country)
  self.stLang:SetText(Lang:getString("gui_friend_request_language_txt") .. CGame.Instance():getShellInterface():getLanguageDetail(data.language or "us"))
end

function GUIFriendRecommendItem:onDestroy()
  if self.winHead then
    self.winHead:destroy()
  end
end

return GUIFriendRecommendItem

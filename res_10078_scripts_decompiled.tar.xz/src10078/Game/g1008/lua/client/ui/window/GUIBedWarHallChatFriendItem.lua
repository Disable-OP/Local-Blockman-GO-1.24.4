local GUIBedWarHallChatFriendItemWindow = class("GUIBedWarHallChatFriendItemWindow", IGUIWindow)
local UIUtils = T(Global, "UIUtils")

function GUIBedWarHallChatFriendItemWindow:ctor(...)
  self.super.ctor(self, "BedWarHallChatFriendItem.json", ...)
end

function GUIBedWarHallChatFriendItemWindow:onLoad()
  self.siBg = self:getChildWindowByName("BedWarHallChatFriendItem-Bg", GUIType.StaticImage)
  self.llBottomLine = self:getChildWindowByName("BedWarHallChatFriendItem-Bottom-Line", GUIType.Layout)
  self.llHeader = self:getChildWindowByName("BedWarHallChatFriendItem-Header", GUIType.Layout)
  self.stName = self:getChildWindowByName("BedWarHallChatFriendItem-Name", GUIType.StaticText)
  self.siSex = self:getChildWindowByName("BedWarHallChatFriendItem-Sex", GUIType.StaticImage)
  self.stHonor = self:getChildWindowByName("BedWarHallChatFriendItem-Honor", GUIType.StaticText)
  self.stStatus = self:getChildWindowByName("BedWarHallChatFriendItem-Status", GUIType.StaticText)
  self.siGoChat = self:getChildWindowByName("BedWarHallChatFriendItem-Go-Chat", GUIType.StaticImage)
  self:initView()
  self:initEvent()
end

function GUIBedWarHallChatFriendItemWindow:initView()
  self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
  self.llHeader:AddChildWindow(self.winHead.root)
  self.redPoint = UIUtils.addRedPoint(self.root, {
    x = 0,
    y = 3,
    img = "set:bed_war_3_common_part.json image:img_0_red_dot01"
  })
  self.txtNum = GUIManager:createGUIWindow(GUIType.StaticText, self.redPoint:GetName() .. "Num-Text")
  self.txtNum:SetHorizontalAlignment(HorizontalAlignment.Center)
  self.txtNum:SetVerticalAlignment(VerticalAlignment.Center)
  self.txtNum:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.txtNum:SetTextVertAlign(VerticalAlignment.Center)
  self.txtNum:SetTextHorzAlign(HorizontalAlignment.Center)
  self.txtNum:SetProperty("Font", "HT10")
  self.redPoint:AddChildWindow(self.txtNum)
  self.redPoint:SetVisible(false)
end

function GUIBedWarHallChatFriendItemWindow:initEvent()
  self.root:registerEvent(GUIEvent.Click, function()
    if self.data.userId == Game:getPlatformUserId() or self.data.isTeamMember then
      return
    end
    Events.ChatSelectFriendEvent:invoke(self.data.userId)
  end)
  self:registerEvent(Events.ChatSelectFriendEvent, function(userId)
    if userId ~= self.data.userId then
      self.siBg:SetImage("")
    else
      self.siBg:SetImage("set:bed_war_3_chat.json image:img_0_current_friends")
      GUIBedWarHallChatLayout:clearRedDot()
    end
  end)
  self:registerEvent(Events.ChatPrivateNewMsgEvent, function(userId, count)
    if not self.data.isTeamMember and userId == self.data.userId then
      self.redPoint:SetVisible(0 < count)
      self.txtNum:SetText(count)
    end
  end)
end

function GUIBedWarHallChatFriendItemWindow:onDataChanged(data)
  self.data = data
  self.winHead:setUserInfo(data)
  self.stName:SetText(data.name)
  self.siSex:SetImage(Define.SexIcon[data.sex] or Define.SexIcon[Define.SexType.Boy])
  self.stHonor:SetText("")
  self.stStatus:SetText(Lang:getString(Define.UserStatusLang[data.status] or "gui.user.status.offline"))
  self.stStatus:SetTextColor(Define.UserStatusColor[data.status] or Color.WHITE)
  local curFriendChatId = GUIBedWarHallChatLayout:getCurSelectFriend()
  self.siBg:SetImage("")
  if not data.isTeamMember and curFriendChatId == data.userId then
    self.siBg:SetImage("set:bed_war_3_chat.json image:img_0_current_friends")
  end
  self.siGoChat:SetVisible(not data.isTeamMember)
  if not self.data.isTeamMember then
    local newMsgCount = GUIBedWarHallChatLayout:getNewMsgCount(data.userId)
    self.redPoint:SetVisible(0 < newMsgCount)
    self.txtNum:SetText(newMsgCount)
  else
    self.stStatus:SetText(Lang:getString(Define.UserStatusLang[Define.UserStatus.InTeam]))
    return
  end
  if data.status == Define.UserStatus.Offline and data.logoutTime and 0 < data.logoutTime then
    local time = os.time() - data.logoutTime / 1000
    self.stStatus:SetText(UIUtils.GetLogoutTimeText(time))
  end
end

function GUIBedWarHallChatFriendItemWindow:onDestroy()
  if self.winHead then
    self.winHead:destroy()
  end
end

return GUIBedWarHallChatFriendItemWindow

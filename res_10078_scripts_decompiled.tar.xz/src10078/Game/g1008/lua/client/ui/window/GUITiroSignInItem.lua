local GUITiroSignInItem = class("GUITiroSignInItem", IGUIWindow)

function GUITiroSignInItem:onLoad()
  self.id = nil
  self.item = nil
  self.status = TiroSignInStatus.CANT_RECEIVE
  self.ivContent = self:getChildWindow(0, GUIType.StaticImage)
  self.ivContent:registerEvent(GUIEvent.TouchUp, function()
    self:onItemClick()
  end)
  self.tvTitle = self:getChildWindow(0, GUIType.StaticText, self.ivContent)
  self.ivIcon = self:getChildWindow(1, GUIType.StaticImage, self.ivContent)
  self.tvName = self:getChildWindow(2, GUIType.StaticText, self.ivContent)
  self.ivMask = self:getChildWindow(3, GUIType.StaticImage, self.ivContent)
  self.ivReceived = self:getChildWindow(4, GUIType.StaticImage, self.ivContent)
end

function GUITiroSignInItem:setSignInItem(item)
  if not item then
    return
  end
  self.id = item.Id
  self.item = item
  local reward = RewardConfig.findRewardById(item.RewardId)
  if not reward then
    self:setVisible(false)
    return
  end
  self.tvTitle:SetText(Lang:getString(item.Title))
  self.ivIcon:SetImage(reward.Image)
  self.tvName:SetText(Lang:getString(reward.Name))
  self:setStatus(item.Status)
end

function GUITiroSignInItem:setStatus(status)
  self.status = status
  if not self.item then
    return
  end
  if self.status == TiroSignInStatus.RECEIVED then
    self.ivContent:SetImage(self.item.Background)
    self.ivMask:SetVisible(true)
    self.ivReceived:SetVisible(true)
  elseif self.status == TiroSignInStatus.WAIT_RECEIVE then
    self.ivContent:SetImage("set:bed_war_tiro_sign_in.json image:bg_item_pre")
    self.ivMask:SetVisible(false)
    self.ivReceived:SetVisible(false)
  else
    self.ivContent:SetImage(self.item.Background)
    self.ivMask:SetVisible(false)
    self.ivReceived:SetVisible(false)
  end
end

function GUITiroSignInItem:onItemClick()
  if self.status ~= TiroSignInStatus.WAIT_RECEIVE then
    return
  end
  SoundUtil.clickUI()
  GamePacketSender:sendReceiveTiroSignIn()
  Events.UpdateActivityRedPointEvent:invoke(2, false)
end

return GUITiroSignInItem

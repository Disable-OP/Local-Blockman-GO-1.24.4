local GUIBedWarHallChatEmojiItemWindow = class("GUIBedWarHallChatEmojiItemWindow", IGUIWindow)

function GUIBedWarHallChatEmojiItemWindow:ctor(...)
  self.super.ctor(self, "BedWarHallChatEmojiItem.json", ...)
end

function GUIBedWarHallChatEmojiItemWindow:onLoad()
  self:initView()
  self:initEvent()
end

function GUIBedWarHallChatEmojiItemWindow:initView()
  self.root = self:getChildWindowByName("BedWarHallChatEmojiItem", GUIType.StaticImage)
end

function GUIBedWarHallChatEmojiItemWindow:initEvent()
  self.root:registerEvent(GUIEvent.Click, function()
    GUIBedWarHallChatLayout:sendGameEmojiMsg(self.data.icon)
  end)
end

function GUIBedWarHallChatEmojiItemWindow:onDataChanged(data)
  self.data = data
  self.root:SetImage(data.icon)
end

return GUIBedWarHallChatEmojiItemWindow

local GUIBattleTeamInfo = class("GUIBattleTeamInfo", IGUIWindow)

function GUIBattleTeamInfo:onLoad()
  self.siLeftBg = self:getChildWindowByName("BedWarBattleTeamInfo-Team-Left", GUIType.StaticImage)
  self.siRightBg = self:getChildWindowByName("BedWarBattleTeamInfo-Team-Right", GUIType.StaticImage)
  self.llTeamColor = self:getChildWindowByName("BedWarBattleTeamInfo-Team-Color", GUIType.Layout)
  self.tvTeamKill = self:getChildWindowByName("BedWarBattleTeamInfo-Team-Kill-Text", GUIType.StaticText)
  self.tvTeamDie = self:getChildWindowByName("BedWarBattleTeamInfo-Team-Die-Text", GUIType.StaticText)
  self.tvTeamAssist = self:getChildWindowByName("BedWarBattleTeamInfo-Team-Assist-Text", GUIType.StaticText)
  self.tvTeamBed = self:getChildWindowByName("BedWarBattleTeamInfo-Team-Bed-Text", GUIType.StaticText)
  self.llPlayers = self:getChildWindowByName("BedWarBattleTeamInfo-Players", GUIType.Layout)
end

function GUIBattleTeamInfo:initPlayers()
  self.gvPlayers = IGUIGridView.new("BattleInfo-Players-" .. self.windowId, self.llPlayers)
  self.gvPlayers:setConfig(0, 3, 1)
  self.gvPlayers.root:SetClipChild(false)
  self.gvPlayers.root:SetItemAlignment(HorizontalAlignment.Right)
  self.adapter = UIHelper.newGameAdapter("BattleInfoPlayerAdapter")
  local itemWidth = self.gvPlayers:getWidth()
  local itemHeight = (self.gvPlayers:getHeight() - 32) / 4
  self.adapter:setItemSize(itemWidth, itemHeight)
  self.gvPlayers:setAdapter(self.adapter)
end

function GUIBattleTeamInfo:setTeamInfo(battleInfo)
  if not battleInfo then
    return
  end
  if self.teamId == battleInfo.teamId then
    return
  end
  self.teamId = battleInfo.teamId
  self.players = battleInfo.players
  self.siLeftBg:SetImage("set:bed_war_battle_info.json image:title_left_" .. tostring(self.teamId))
  self.siRightBg:SetImage("set:bed_war_battle_info.json image:title_right_" .. tostring(self.teamId))
  self:getChildWindowByName("BedWarBattleTeamInfo-Team-Kill-Icon", GUIType.StaticImage):SetImage("set:bed_war_battle_info.json image:team_kill_" .. tostring(self.teamId))
  self:getChildWindowByName("BedWarBattleTeamInfo-Team-Die-Icon", GUIType.StaticImage):SetImage("set:bed_war_battle_info.json image:team_die_" .. tostring(self.teamId))
  self:getChildWindowByName("BedWarBattleTeamInfo-Team-Assist-Icon", GUIType.StaticImage):SetImage("set:bed_war_battle_info.json image:team_assist_" .. tostring(self.teamId))
  self:getChildWindowByName("BedWarBattleTeamInfo-Team-Bed-Icon", GUIType.StaticImage):SetImage("set:bed_war_battle_info.json image:team_bed_" .. tostring(self.teamId))
  self.adapter:setData(self.players)
  self:updateTeamInfo()
  if self.isRight then
    for _, uiPlayerInfo in pairs(self.gvPlayers.items) do
      uiPlayerInfo:setRightLayout()
    end
  end
end

function GUIBattleTeamInfo:updateTeamInfo()
  if not self.players then
    return
  end
  local kill, die, assist, bed = 0, 0, 0, 0
  for _, player in pairs(self.players) do
    kill = kill + tonumber(player.info:getValue("kill"))
    die = die + tonumber(player.info:getValue("die"))
    assist = assist + tonumber(player.info:getValue("assist"))
    bed = bed + #player.info:getValue("destroy_bed")
  end
  self.tvTeamKill:SetText(tostring(kill))
  self.tvTeamDie:SetText(tostring(die))
  self.tvTeamAssist:SetText(tostring(assist))
  self.tvTeamBed:SetText(tostring(bed))
end

function GUIBattleTeamInfo:setRightLayout()
  self.isRight = true
  self.siRightBg:SetVisible(true)
  self.siLeftBg:SetVisible(false)
  self.llPlayers:SetHorizontalAlignment(HorizontalAlignment.Left)
  self.gvPlayers.root:SetItemAlignment(HorizontalAlignment.Left)
end

return GUIBattleTeamInfo

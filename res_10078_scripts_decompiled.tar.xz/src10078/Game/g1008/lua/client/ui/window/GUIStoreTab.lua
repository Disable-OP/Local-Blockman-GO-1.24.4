local GUIStoreTab = class("GUIStoreTab", IGUIWindow)

function GUIStoreTab:onLoad()
  self.cbTab = self:getChildWindowByName("BedWarStoreTab-Tab", GUIType.CheckBox)
  self.ivIcon = self:getChildWindowByName("BedWarStoreTab-Icon", GUIType.StaticImage)
  self.tvName = self:getChildWindowByName("BedWarStoreTab-Name", GUIType.StaticText)
  self.cbTab:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbTab:GetChecked() then
      self.cbTab:SetTouchable(false)
      GUIStore:onSelectTab(self)
    else
    end
  end)
  self.cbTab:registerEvent(GUIEvent.Click, function()
    SoundUtil.playSound(SoundConfig.selectTabStore)
  end)
end

function GUIStoreTab:onDataChanged(data)
  self.tabId = data.Id
  self.ivIcon:SetImage(data.Icon)
  self.tvName:SetText(Lang:getString(data.Lang))
end

function GUIStoreTab:setChecked(check)
  self.cbTab:SetChecked(check)
  self.cbTab:SetTouchable(not check)
end

return GUIStoreTab

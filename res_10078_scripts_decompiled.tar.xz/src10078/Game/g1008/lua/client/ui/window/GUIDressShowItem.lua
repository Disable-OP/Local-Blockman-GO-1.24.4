local GUIDressShowItemWindow = class("GUIDressShowItemWindow", IGUIWindow)

function GUIDressShowItemWindow:ctor(...)
  self.super.ctor(self, "DressShowItem.json", ...)
end

function GUIDressShowItemWindow:onLoad()
  self.siIcon = self:getChildWindowByName("DressShowItem-Icon", GUIType.StaticImage)
end

function GUIDressShowItemWindow:onDataChanged(dressId)
  local goods = CustomShopConfig:getGoodsConfig(dressId)
  if goods then
    self.siIcon:SetImage(goods.Image)
  end
end

return GUIDressShowItemWindow

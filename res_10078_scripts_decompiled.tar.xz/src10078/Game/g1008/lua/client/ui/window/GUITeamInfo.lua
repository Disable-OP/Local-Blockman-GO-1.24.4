local GUITeamInfo = class("GUITeamInfo", IGUIWindow)

function GUITeamInfo:ctor()
  self.super.ctor(self, "BedWarTeamInfo.json")
end

function GUITeamInfo:onLoad()
  self.root = self:getChildWindowByName("BedWarTeamInfo", GUIType.Layout)
  self.siIcon = self:getChildWindowByName("BedWarTeamInfo-TeamIcon", GUIType.StaticImage)
  self.siDestroy = self:getChildWindowByName("BedWarTeamInfo-Destroy", GUIType.StaticImage)
  self.siSelf = self:getChildWindowByName("BedWarTeamInfo-Self", GUIType.StaticImage)
  self.stMsg = self:getChildWindowByName("BedWarTeamInfo-TeamMsg", GUIType.StaticText)
  self.stNum = self:getChildWindowByName("BedWarTeamInfo-TeamMsgNum", GUIType.StaticText)
  self.stCount = self:getChildWindowByName("BedWarTeamInfo-Count", GUIType.StaticText)
  self.stCount:SetVisible(GameType ~= "g1008")
end

function GUITeamInfo:initTeam(teamId, selfTeam)
  local info = TeamGUIInfo[tostring(teamId)]
  if info then
    self.siIcon:SetImage(info.icon)
    self.siSelf:SetImage(info.iconSelf)
  end
  self.siSelf:SetVisible(selfTeam)
  GameInfoManager:registerObserver(teamId, function(teamInfo)
    self:updateInfo(teamInfo)
  end)
end

function GUITeamInfo:updateInfo(teamInfo)
  self.siDestroy:SetVisible(teamInfo:getValue("isHaveBed") == "0")
  local liveCount = teamInfo:getValue("liveCount")
  local totalCount = teamInfo:getValue("totalCount")
  if liveCount < totalCount then
    self.stNum:SetText(TextFormat.colorRed .. liveCount .. TextFormat.colorWrite .. "/" .. totalCount)
    self.stCount:SetText(TextFormat.colorPink .. liveCount)
  else
    self.stNum:SetText(liveCount .. "/" .. totalCount)
    self.stCount:SetText(liveCount)
  end
end

return GUITeamInfo

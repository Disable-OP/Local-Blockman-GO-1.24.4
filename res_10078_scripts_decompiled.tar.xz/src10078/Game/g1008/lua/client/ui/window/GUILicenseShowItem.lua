local GUILicenseShowItem = class("GUILicenseShowItem", IGUIWindow)

function GUILicenseShowItem:onLoad()
  self.siImage = self:getChildWindowByName("BedWarLicenseShowItem-image", GUIType.StaticImage)
  self.stPriceNum = self:getChildWindowByName("BedWarLicenseShowItem-price", GUIType.StaticText)
end

function GUILicenseShowItem:onDataChanged(data)
  self.data = data
  if not data.RewardValue then
    self:getChildWindowByName("BedWarLicenseShowItem-cube", GUIType.StaticImage):SetVisible(false)
  else
    self.stPriceNum:SetText(data.RewardValue)
  end
  local rewardConfig = RewardConfig.findRewardById(data.RewardId)
  if rewardConfig then
    self.siImage:SetImage(rewardConfig.Image)
  else
    local good = CustomShopConfig:getGoodsConfig(rewardConfig.RewardId)
    if not good then
      return
    end
    self.siImage:SetImage(good.Image)
  end
end

return GUILicenseShowItem

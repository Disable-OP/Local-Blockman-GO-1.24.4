local cupIcon = {
  ["1"] = "set:result.json image:cup_kill_2",
  ["2"] = "set:result.json image:cup_kill_3",
  ["3"] = "set:result.json image:cup_kill_4",
  ["4"] = "set:result.json image:cup_kill_5",
  ["5"] = "set:result.json image:cup_kill_10",
  ["6"] = "set:result.json image:cup_gold_kill",
  ["7"] = "set:result.json image:cup_silver_kill",
  ["8"] = "set:result.json image:cup_gold_assist",
  ["9"] = "set:result.json image:cup_silver_assist",
  ["10"] = "set:result.json image:cup_gold_build",
  ["11"] = "set:result.json image:cup_silver_build",
  ["12"] = "set:result.json image:cup_diamonds",
  ["13"] = "set:result.json image:cup_gem"
}
local GUIResultPlayerItem = class("GUIResultPlayerItem", IGUIWindow)

function GUIResultPlayerItem:onLoad()
  self.llContent = self:getChildWindowByName("ResultPlayerItem", GUIType.Layout)
  self.ivMeHint = self:getChildWindowByName("ResultPlayerItem-Me-Item-Hint", GUIType.StaticImage)
  self.ivHeadBorder = self:getChildWindowByName("ResultPlayerItem-Icon-Border", GUIType.StaticImage)
  self.uivHeadIcon = self:getChildWindowByName("ResultPlayerItem-Icon", GUIType.UrlImage)
  self.uivHeadIcon:setChildMaterial(0)
  self.tvName = self:getChildWindowByName("ResultPlayerItem-Name", GUIType.StaticText)
  self.tvOutput = self:getChildWindowByName("ResultPlayerItem-Output-Count", GUIType.StaticText)
  self.tvHurt = self:getChildWindowByName("ResultPlayerItem-Hurt-Count", GUIType.StaticText)
  self.tvKill = self:getChildWindowByName("ResultPlayerItem-Kill", GUIType.StaticText)
  self.tvDie = self:getChildWindowByName("ResultPlayerItem-Die", GUIType.StaticText)
  self.tvAssist = self:getChildWindowByName("ResultPlayerItem-Assist", GUIType.StaticText)
  self.tvKDA = self:getChildWindowByName("ResultPlayerItem-KDA-Text", GUIType.StaticText)
  self.ivKDABg = self:getChildWindowByName("ResultPlayerItem-KDA-Bg", GUIType.StaticImage)
  self.btnFriendButton = self:getChildWindowByName("ResultPlayerItem-Friend-Button", GUIType.Button)
  self.ivGoodBg = self:getChildWindowByName("ResultPlayerItem-Good-Bg", GUIType.StaticImage)
  self.ivGood = self:getChildWindowByName("ResultPlayerItem-Good", GUIType.StaticImage)
  self.llBed = self:getChildWindowByName("ResultPlayerItem-Bed", GUIType.Layout)
  self.llCup = self:getChildWindowByName("ResultPlayerItem-Cup-Layout", GUIType.Layout)
  self.btnFriendButton:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.addFriendSettlement)
    self.curInfo:setValue("show_add_friend", "0")
    ClientHttpRequest.friendOperation(4, self.data.userId)
  end)
  self.ivGoodBg:registerEvent(GUIEvent.TouchDown, function()
    SoundUtil.playSound(SoundConfig.sendGoodSettlement)
    local hadSend = self.curInfo:getValue("send_good") == "1"
    if not hadSend then
      self.curInfo:setValue("send_good", "1")
      GamePacketSender:sendSettlementGood(self.curInfo.infoKey)
    end
  end)
end

function GUIResultPlayerItem:onDataChanged(data)
  self.curInfo = data.info
  self.data = data
  self.llBed:CleanupChildren()
  self.llCup:CleanupChildren()
  self.btnFriendButton:SetVisible(false)
  self.tvKill:SetText(data.info:getValue("kill"))
  self.tvDie:SetText(data.info:getValue("die"))
  self.tvAssist:SetText(data.info:getValue("assist"))
  self.tvOutput:SetText(data.info:getValue("attack_damage"))
  self.tvHurt:SetText(data.info:getValue("build_score"))
  self.ivGood:SetVisible(true)
  self.ivGoodBg:SetVisible(tostring(data.userId) ~= tostring(Game:getPlatformUserId()))
  self.ivMeHint:SetVisible(tostring(data.userId) == tostring(Game:getPlatformUserId()))
  local config = TeamGUIInfo[data.info:getValue("teamId")]
  self.ivMeHint:SetImage(config.me_item_color)
  self.llContent:SetBackImage(config.item_color)
  self.ivHeadBorder:SetImage(config.header_border2)
  self.uivHeadIcon:setDefaultImage(config.header)
  self.uivHeadIcon:setUrl(data.info:getValue("picUrl"))
  self.tvName:SetText(data.info:getValue("userName"))
  self.tvName:SetTextColor(config.name_color)
  self.tvKDA:SetText(data.info:getKDA())
  if data.info:getValue("send_good") == "1" then
    self:getChildWindowByName("ResultPlayerItem-Good-Text", GUIType.StaticText):SetText(data.info:getValue("be_good_times"))
    self.ivGood:SetVisible(false)
  end
  local bed = data.info:getValue("destroy_bed")
  for i = 1, #bed do
    local bedId = string.sub(bed, i, i)
    config = TeamGUIInfo[bedId]
    if config then
      local ivBed = GUIManager:createGUIWindow(GUIType.StaticImage, "BattlePlayerInfo-Bed-" .. GUIManager:applyWindowId())
      ivBed:SetWidth({0, 21})
      ivBed:SetHeight({0, 20})
      ivBed:SetXPosition({
        0,
        (i - 1) * 22
      })
      ivBed:SetImage(config.bed)
      ivBed:setMaterial(20001)
      self.llBed:AddChildWindow(ivBed)
    end
  end
  local cupIds = data.info:getCupIds()
  local index = 0
  for _, cupId in pairs(cupIds) do
    local image = cupIcon[cupId]
    if image then
      local row = math.fmod(index, 3)
      local column = math.floor(index / 3)
      local ivCup = GUIManager:createGUIWindow(GUIType.StaticImage, "BattlePlayerInfo-Cup-" .. GUIManager:applyWindowId())
      ivCup:SetWidth({0, 28})
      ivCup:SetHeight({0, 28})
      ivCup:SetXPosition({
        0,
        column * 26
      })
      ivCup:SetYPosition({
        0,
        row * 26
      })
      ivCup:SetImage(image)
      ivCup:setMaterial(20001)
      self.llCup:AddChildWindow(ivCup)
      index = index + 1
    end
  end
  if tonumber(data.info:getValue("sex")) == 1 then
    self:getChildWindowByName("ResultPlayerItem-Sex", GUIType.StaticImage):SetImage("set:result.json image:sex_man")
  else
    self:getChildWindowByName("ResultPlayerItem-Sex", GUIType.StaticImage):SetImage("set:result.json image:sex_woman")
  end
  if tonumber(data.info:getValue("show_add_friend")) == 1 and tostring(data.userId) ~= tostring(Game:getPlatformUserId()) then
    self.btnFriendButton:SetVisible(true)
    self.btnFriendButton:SetNormalImage("set:result.json image:friend_add")
    self.btnFriendButton:SetPushedImage("set:result.json image:friend_add")
  else
    self.btnFriendButton:SetVisible(false)
  end
end

function GUIResultPlayerItem:setRightLayout()
  self:getChildWindowByName("ResultPlayerItem-Content"):SetHorizontalAlignment(HorizontalAlignment.Left)
  local ontSize = self:getChildWindowByName("ResultPlayerItem-OutSize")
  ontSize:SetXPosition({1, 0})
  local btn1 = ontSize:GetChildByIndex(0)
  btn1:SetHorizontalAlignment(HorizontalAlignment.Left)
  btn1:SetXPosition({0, 0})
  local btn2 = ontSize:GetChildByIndex(1)
  btn2:SetHorizontalAlignment(HorizontalAlignment.Left)
  btn2:SetXPosition({0, 55})
end

function GUIResultPlayerItem:updateStatus(isMvp, totalKill, totalOutput, totalHurt, teamId)
  if isMvp then
    local teamInfo = GameInfoManager:getTeamInfo(teamId)
    if teamInfo and teamInfo:getValue("isWin") == "0" then
      self.ivKDABg:SetImage("set:result.json image:kda_mvp_failed")
    else
      self.ivKDABg:SetImage("set:result.json image:kda_mvp_victory")
    end
  else
    self.ivKDABg:SetImage("set:result.json image:kda_bg")
  end
  local battlePercent = 1
  if totalKill ~= 0 then
    battlePercent = (tonumber(self.tvKill:GetText()) + tonumber(self.tvAssist:GetText())) / totalKill
  end
  battlePercent = math.floor(battlePercent * 1000) / 1000
  self:getChildWindowByName("ResultPlayerItem-Battle-Bar", GUIType.ProgressBar):SetProgress(battlePercent)
  self:getChildWindowByName("ResultPlayerItem-Battle-Percent", GUIType.StaticText):SetText(battlePercent * 100 .. "%")
  local outputPercent = 1
  if totalOutput ~= 0 then
    outputPercent = tonumber(self.tvOutput:GetText()) / totalOutput
  end
  outputPercent = math.floor(outputPercent * 1000) / 1000
  self:getChildWindowByName("ResultPlayerItem-Output-Bar", GUIType.ProgressBar):SetProgress(outputPercent)
  self:getChildWindowByName("ResultPlayerItem-Output-Percent", GUIType.StaticText):SetText(outputPercent * 100 .. "%")
  local hurtPercent = 1
  if totalHurt ~= 0 then
    hurtPercent = tonumber(self.tvHurt:GetText()) / totalHurt
  end
  hurtPercent = math.floor(hurtPercent * 1000) / 1000
  self:getChildWindowByName("ResultPlayerItem-Hurt-Bar", GUIType.ProgressBar):SetProgress(hurtPercent)
  self:getChildWindowByName("ResultPlayerItem-Hurt-Percent", GUIType.StaticText):SetText(hurtPercent * 100 .. "%")
end

return GUIResultPlayerItem

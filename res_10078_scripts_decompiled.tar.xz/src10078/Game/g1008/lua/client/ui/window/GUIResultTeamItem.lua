local GUIResultTeamItem = class("GUIResultTeamItem", IGUIWindow)

function GUIResultTeamItem:onLoad()
  self:getChildWindowByName("ResultTeamItem-Output-Title", GUIType.StaticText):SetText(Lang:getString("gui.title.output"))
  self:getChildWindowByName("ResultTeamItem-Hurt-Title", GUIType.StaticText):SetText(Lang:getString("gui.title.hurt"))
  self:getChildWindowByName("ResultTeamItem-Battle-Title", GUIType.StaticText):SetText(Lang:getString("gui.title.battle"))
  self.llTeamColor = self:getChildWindowByName("ResultTeamItem-Title-Bg", GUIType.StaticImage)
  self.llPlayers = self:getChildWindowByName("ResultTeamItem-Players", GUIType.Layout)
end

function GUIResultTeamItem:initItemPlayers()
  self.gvPlayers = IGUIGridView.new("Result-Players-" .. self.windowId, self.llPlayers)
  self.gvPlayers:setConfig(0, 0, 1)
  self.gvPlayers.root:SetClipChild(false)
  self.gvPlayers.root:SetItemAlignment(HorizontalAlignment.Right)
  self.adapter = UIHelper.newGameAdapter("ResultPlayerAdapter")
  local itemWidth = self.gvPlayers:getWidth()
  local itemHeight = (self.gvPlayers:getHeight() - 30) / 4
  self.adapter:setItemSize(itemWidth, itemHeight)
  self.gvPlayers:setAdapter(self.adapter)
end

function GUIResultTeamItem:setTeamInfo(teamInfo)
  if not teamInfo then
    return false
  end
  if self.teamId == teamInfo.teamId then
    return true
  end
  self.teamId = teamInfo.teamId
  self.players = teamInfo.players
  local ui_config = TeamGUIInfo[tostring(self.teamId)]
  self.llTeamColor:SetImage(ui_config.color)
  self.adapter:setData(self.players)
  if self.isRight then
    for _, uiPlayerItem in pairs(self.gvPlayers.items) do
      uiPlayerItem:setRightLayout()
    end
  end
  local totalKill = 0
  local totalOutput = 0
  local totalHurt = 0
  for _, uiPlayerItem in pairs(self.gvPlayers.items) do
    totalKill = totalKill + tonumber(uiPlayerItem.tvKill:GetText())
    totalOutput = totalOutput + tonumber(uiPlayerItem.tvOutput:GetText())
    totalHurt = totalHurt + tonumber(uiPlayerItem.tvHurt:GetText())
  end
  for _, uiPlayerItem in pairs(self.gvPlayers.items) do
    uiPlayerItem:updateStatus(tonumber(uiPlayerItem.curInfo:getValue("isMvp")) == 1, totalKill, totalOutput, totalHurt, self.teamId)
  end
  return true
end

function GUIResultTeamItem:setRightLayout()
  self.isRight = true
  self:getChildWindowByName("ResultTeamItem-Info-Title"):SetHorizontalAlignment(HorizontalAlignment.Left)
  self.gvPlayers.root:SetItemAlignment(HorizontalAlignment.Left)
  self.gvPlayers.root:SetItemAlignment(HorizontalAlignment.Left)
end

return GUIResultTeamItem

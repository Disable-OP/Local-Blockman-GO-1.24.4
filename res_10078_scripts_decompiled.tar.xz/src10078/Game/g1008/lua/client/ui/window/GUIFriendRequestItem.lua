local GUIFriendRequestItem = class("GUIFriendRequestItem", IGUIWindow)
local FriendManager = T(Global, "FriendManager")
local RequestStatus = {
  unDeal = 0,
  alreadyAgree = 1,
  alreadyRefuse = 2
}
local RequestStatusBgColor = {
  [RequestStatus.alreadyRefuse] = {
    0.3803921568627451,
    0.5019607843137255,
    0.5647058823529412,
    1
  },
  [RequestStatus.alreadyAgree] = {
    0.29411764705882354,
    0.8627450980392157,
    0.8823529411764706,
    1
  }
}

function GUIFriendRequestItem:onLoad()
  self.userId = 0
  self.data = {}
  self.lytHeadItem = self:getChildWindowByName("BedWarFriendRequest-Head-Item", GUIType.Layout)
  self.stLv = self:getChildWindowByName("BedWarFriendRequest-Lv", GUIType.StaticText)
  self.stName = self:getChildWindowByName("BedWarFriendRequest-Name", GUIType.StaticText)
  self.stCountry = self:getChildWindowByName("BedWarFriendRequest-Country", GUIType.StaticText)
  self.stLang = self:getChildWindowByName("BedWarFriendRequest-Lang", GUIType.StaticText)
  self.siSex = self:getChildWindowByName("BedWarFriendRequest-Sex", GUIType.StaticImage)
  self.siSegment = self:getChildWindowByName("BedWarFriendRequest-Segment", GUIType.StaticImage)
  self.siVip = self:getChildWindowByName("BedWarFriendRequest-Vip", GUIType.StaticImage)
  self.stMsg = self:getChildWindowByName("BedWarFriendRequest-Msg", GUIType.StaticText)
  self.lytBtns = self:getChildWindowByName("BedWarFriendRequest-Btns", GUIType.Layout)
  self.btnAgree = self:getChildWindowByName("BedWarFriendRequest-Agree-Btn", GUIType.Button)
  self.btnRefuse = self:getChildWindowByName("BedWarFriendRequest-Refuse-Btn", GUIType.Button)
  self.stStatus = self:getChildWindowByName("BedWarFriendRequest-Status", GUIType.StaticText)
  self.siStatusBg = self:getChildWindowByName("BedWarFriendRequest-Status-Bg", GUIType.StaticImage)
  self.siStatusBg:SetVisible(false)
  self.lytBtns:SetVisible(true)
  self.btnAgree:SetText(Lang:getString("gui_friend_agree"))
  self.btnRefuse:SetText(Lang:getString("gui_friend_refuse"))
  self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.lytHeadItem:GetPixelSize().x)
  self.lytHeadItem:AddChildWindow(self.winHead.root)
  self:initEvent()
end

function GUIFriendRequestItem:initEvent()
  self.btnAgree:registerEvent(GUIEvent.ButtonClick, function()
    if not self.userId or self.userId == 0 then
      return
    end
    FriendManager.FriendOperation(Define.FriendOperationType.Agree, self.userId)
  end)
  self.btnRefuse:registerEvent(GUIEvent.ButtonClick, function()
    if not self.userId or self.userId == 0 then
      return
    end
    FriendManager.FriendOperation(Define.FriendOperationType.Refuse, self.userId)
  end)
end

function GUIFriendRequestItem:onDataChanged(data)
  if not self.fit then
    local width = self.root:GetPixelSize().y / 185 * 100
    self.lytHeadItem:SetWidth({0, width})
    self.lytHeadItem:SetHeight({0, width})
    self.winHead:setSize(width)
    self.fit = true
  end
  if not data.userId then
    return
  end
  self.data = data
  self.userId = data.userId
  local msg = Lang:getString("gui_friend_request_default_msg")
  if data.msg and 0 < string.len(data.msg) then
    msg = data.msg
  end
  self.stMsg:SetText(msg)
  local country = data.country and CGame.Instance():getShellInterface():getCountryDetail(data.country) or Lang:getString("gui_unknown_country")
  self.stCountry:SetText(Lang:getString("gui_friend_request_country_txt") .. country)
  self.stLang:SetText(Lang:getString("gui_friend_request_language_txt") .. CGame.Instance():getShellInterface():getLanguageDetail(data.language or "us"))
  self.winHead:setUserInfo(data)
  self.siSex:SetImage(Define.SexIcon[data.sex])
  local vipIcon = Define.VipIcon[data.vip or 0] or ""
  self.siVip:SetVisible(0 < string.len(vipIcon))
  self.siVip:SetImage(vipIcon)
  self.stName:SetText(data.nickName)
  local needDeal = data.requestStatus == RequestStatus.unDeal
  self.lytBtns:SetVisible(needDeal)
  self.siStatusBg:SetVisible(not needDeal)
  if data.requestStatus == RequestStatus.alreadyAgree then
    self.siStatusBg:SetDrawColor(RequestStatusBgColor[RequestStatus.alreadyAgree])
    self.stStatus:SetText(Lang:getString("gui_friend_already_agree"))
  elseif data.requestStatus == RequestStatus.alreadyRefuse then
    self.siStatusBg:SetDrawColor(RequestStatusBgColor[RequestStatus.alreadyRefuse])
    self.stStatus:SetText(Lang:getString("gui_friend_already_refuse"))
  end
end

function GUIFriendRequestItem:onDestroy()
  if self.winHead then
    self.winHead:destroy()
  end
end

return GUIFriendRequestItem

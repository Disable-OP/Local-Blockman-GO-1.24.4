local GUILicenseRewardListItem = class("UILicenseRewardListItem", IGUIWindow)

function GUILicenseRewardListItem:onLoad()
  self.siFreeIcon = self:getChildWindowByName("BedWarLicenseRewardListItem-Free-Reward-Icon", GUIType.StaticImage)
  self.siPayIcon = self:getChildWindowByName("BedWarLicenseRewardListItem-Pay-Reward-Icon", GUIType.StaticImage)
  self.siFreeBg = self:getChildWindowByName("BedWarLicenseRewardListItem-Free-Reward-bg", GUIType.StaticImage)
  self.siPayBg = self:getChildWindowByName("BedWarLicenseRewardListItem-Pay-Reward-bg", GUIType.StaticImage)
  self.siPayEffect = self:getChildWindowByName("BedWarLicenseRewardListItem-Pay-Reward-Effect", GUIType.StaticImage)
  self.siPayEffect2 = self:getChildWindowByName("BedWarLicenseRewardListItem-Pay-Reward-Effect2", GUIType.StaticImage)
  self.siFreeEffect = self:getChildWindowByName("BedWarLicenseRewardListItem-Free-Reward-Effect", GUIType.StaticImage)
  self.siFreeEffect2 = self:getChildWindowByName("BedWarLicenseRewardListItem-Free-Reward-Effect2", GUIType.StaticImage)
  self.siFreeHadGet = self:getChildWindowByName("BedWarLicenseRewardListItem-Free-Reward-HadGet", GUIType.StaticImage)
  self.siPayHadGet = self:getChildWindowByName("BedWarLicenseRewardListItem-Pay-Reward-HadGet", GUIType.StaticImage)
  self.siExtraLine = self:getChildWindowByName("BedWarLicenseRewardListItem-Extra-Line", GUIType.StaticImage)
  self.siFreeCannot = self:getChildWindowByName("BedWarLicenseRewardListItem-Free-Reward-Not", GUIType.StaticImage)
  self.siPayCannot = self:getChildWindowByName("BedWarLicenseRewardListItem-Pay-Reward-Not", GUIType.StaticImage)
  self.btnFree = self:getChildWindowByName("BedWarLicenseRewardListItem-Free-Reward-Select", GUIType.Button)
  self.btnPay = self:getChildWindowByName("BedWarLicenseRewardListItem-Pay-Reward-Select", GUIType.Button)
  self.btnBuyLevel = self:getChildWindowByName("BedWarLicenseRewardListItem-Buy-Level", GUIType.Button)
  self.btnBuyLevel:registerEvent(GUIEvent.ButtonClick, function()
    if BaseMain:getGameType() == "g1046" then
      GameAnalytics:design(1, {
        "H_License_selectLv",
        self.Lv - 1
      })
    else
      GameAnalytics:design(1, {
        "G_License_selectLv",
        self.Lv - 1
      })
    end
    if GUILicense.seasonDate ~= -1 then
      if tonumber(GUILicense.freeUpgradeTime) ~= tonumber(DateUtil.getYearDay()) and WatchADSwitch:getSwitchBoolByType(1) then
        local tip
        if GameType == "g1046" then
          tip = "gui_bed_war_license_watch_ad_hall"
        else
          tip = "gui_bed_war_license_watch_ad_game"
        end
        FreeGiftWatchADTipContent:setInfo("set:advertisement_system.json image:up_level_icon", "\195\151 " .. 1, "gui_bed_war_license_free_upgrade")
        WatchAdTip.init().setContentView(FreeGiftWatchADTipContent).setTitle("gui_bed_war_free_gift_tip_title").setTipText(Lang:getString(tip)).show(Define.AdType.License)
        return
      end
      PayHelper.checkMoney(MoneyType.Diamonds, self.BuyLevelPrice, function(enough)
        if enough then
          GUILicenseTip:show("buyLevel", self.BuyLevelPrice)
        end
      end)
    end
  end)
  self.siEXPLine = self:getChildWindowByName("BedWarLicenseRewardListItem-EXP-Line", GUIType.StaticImage)
  self.siNotEXPLine = self:getChildWindowByName("BedWarLicenseRewardListItem-not-EXP-Line", GUIType.StaticImage)
  self.stEXPLevel = self:getChildWindowByName("BedWarLicenseRewardListItem-EXE-level-Text", GUIType.StaticText)
  self.stNotEXPLevel = self:getChildWindowByName("BedWarLicenseRewardListItem-not-EXP-level-Text", GUIType.StaticText)
  self.stFreeNum = self:getChildWindowByName("BedWarLicenseRewardListItem-Free-Reward-Num", GUIType.StaticText)
  self.stPayNum = self:getChildWindowByName("BedWarLicenseRewardListItem-Pay-Reward-Num", GUIType.StaticText)
  self.btnFree:registerEvent(GUIEvent.ButtonClick, function()
    GUILicense:showDescribe(self.FreeRewardImage, self.FreeDesc, self.FreeShowType, self.FreeActor, self.FreeActorSkillName)
    GUILicense:onRewardSelectChange(self.Index, 1)
    if self.FreeStatue == 1 then
      GamePacketSender:sendBedWarLicenseGetReward(self.FreeReward, self.Lv, "free", 1, nil)
    end
  end)
  self.btnPay:registerEvent(GUIEvent.ButtonClick, function()
    GUILicense:showDescribe(self.PayRewardImage, self.PayDesc, self.PayShowType, self.PayActor, self.PayActorSkillName)
    GUILicense:onRewardSelectChange(self.Index, 2)
    if self.PayStatue == 1 then
      GamePacketSender:sendBedWarLicenseGetReward(self.PayReward, self.Lv, "pay", 1, nil)
    end
  end)
end

function GUILicenseRewardListItem:isGameCannotGet(type)
  if BaseMain:getGameType() == "g1008" and (type == Define.RewardType.CHEST or type == Define.RewardType.DRESS_CHIP or type == Define.RewardType.DRESS or type == Define.RewardType.PRIVILEGE_CARD) then
    return true
  end
  return false
end

function GUILicenseRewardListItem:onDataChanged(data)
  local playerHadBuy = GUILicense.hadBuy
  self.FreeActor = data.FreeActor
  self.PayActor = data.PayActor
  self.FreeActorSkillName = data.FreeActorSkillName
  self.PayActorSkillName = data.PayActorSkillName
  self.FreeShowType = data.FreeShowType
  self.PayShowType = data.PayShowType
  self.Lv = data.Lv
  self.Index = data.Index
  self.FreeRewardImage = data.FreeRewardImage
  self.FreeNum = data.FreeNum
  self.FreeDesc = data.FreeDesc
  self.PayRewardImage = data.PayRewardImage
  self.PayDesc = data.PayDesc
  self.PayNum = data.PayNum
  self.FreeStatue = data.FreeStatue
  self.PayStatue = data.PayStatue
  self.FreeReward = data.FreeReward
  self.PayReward = data.PayReward
  local playerLevel = GUILicense.playerLevel
  local rewardConfig = LicenseConfig:getLevelRewardBySeason(GUILicense.seasonDate)
  if not rewardConfig then
    return
  end
  for i, reward in pairs(rewardConfig) do
    if reward.Lv == playerLevel then
      self.BuyLevelPrice = reward.BuyLevel
    end
  end
  if self.Lv == 1 then
    self.siExtraLine:SetVisible(true)
  else
    self.siExtraLine:SetVisible(false)
  end
  if self.FreeReward == "#" then
    self.siFreeBg:SetVisible(false)
  else
    self.siFreeBg:SetVisible(true)
    self.siFreeEffect:SetVisible(self.FreeShowType == 2)
    self.siFreeEffect2:SetVisible(data.StageReward == 1)
    if self.FreeStatue == 0 then
      self.siFreeBg:SetImage("set:bedwar_licensereward.json image:bg_momal")
      self.siFreeHadGet:SetVisible(false)
      self.siFreeCannot:SetVisible(true)
    elseif self.FreeStatue == 1 then
      self.siFreeBg:SetImage("set:bedwar_licensereward.json image:bg_can")
      self.siFreeHadGet:SetVisible(false)
      self.siFreeCannot:SetVisible(false)
    elseif self.FreeStatue == 2 then
      self.siFreeBg:SetImage("set:bedwar_licensereward.json image:bg_momal")
      self.siFreeHadGet:SetVisible(true)
      self.siFreeCannot:SetVisible(false)
    end
    self.siFreeIcon:SetImage(self.FreeRewardImage)
    self.stFreeNum:SetText("\195\151" .. self.FreeNum)
    if GUILicense:isSelect(self.Index, 1) then
      self.btnFree:SetNormalImage("set:bedwar_licensereward.json image:item_selected")
      self.btnFree:SetPushedImage("set:bedwar_licensereward.json image:item_selected")
    else
      self.btnFree:SetNormalImage("")
      self.btnFree:SetPushedImage("")
    end
  end
  if self.PayReward == "#" then
    self.siPayBg:SetVisible(false)
  else
    self.siPayBg:SetVisible(true)
    self.siPayEffect:SetVisible(self.PayShowType == 2)
    self.siPayEffect2:SetVisible(data.StageReward == 1)
    if self.PayStatue == 0 or playerHadBuy == 0 then
      self.siPayBg:SetImage("set:bedwar_licensereward.json image:bg_momal")
      self.siPayHadGet:SetVisible(false)
      self.siPayCannot:SetVisible(true)
    elseif self.PayStatue == 1 then
      self.siPayBg:SetImage("set:bedwar_licensereward.json image:bg_can")
      self.siPayHadGet:SetVisible(false)
      self.siPayCannot:SetVisible(false)
    elseif self.PayStatue == 2 then
      self.siPayBg:SetImage("set:bedwar_licensereward.json image:bg_momal")
      self.siPayHadGet:SetVisible(true)
      self.siPayCannot:SetVisible(false)
    end
    self.siPayIcon:SetImage(self.PayRewardImage)
    self.stPayNum:SetText("\195\151" .. self.PayNum)
    if GUILicense:isSelect(self.Index, 2) then
      self.btnPay:SetNormalImage("set:bedwar_licensereward.json image:item_selected")
      self.btnPay:SetPushedImage("set:bedwar_licensereward.json image:item_selected")
    else
      self.btnPay:SetNormalImage("")
      self.btnPay:SetPushedImage("")
    end
  end
  self.stEXPLevel:SetText(self.Lv)
  self.stNotEXPLevel:SetText(self.Lv)
  if GUILicense:isShowEXP(self.Lv) then
    self.siNotEXPLine:SetVisible(false)
    self.siEXPLine:SetVisible(true)
  else
    self.siNotEXPLine:SetVisible(true)
    self.siEXPLine:SetVisible(false)
  end
  if GUILicense:isShowBuyLevel(self.Lv) then
    self.btnBuyLevel:SetVisible(true)
    if tonumber(GUILicense.freeUpgradeTime) ~= tonumber(DateUtil.getYearDay()) and WatchADSwitch:getSwitchBoolByType(1) then
      self:getChildWindowByName("BedWarLicenseRewardListItem-Buy-Level-Icon", GUIType.StaticImage):SetImage("set:bedwar_licensereward.json image:buylevel_ad")
    else
      self:getChildWindowByName("BedWarLicenseRewardListItem-Buy-Level-Icon", GUIType.StaticImage):SetImage("set:app_shop.json image:Diamond-icon-gold")
    end
  else
    self.btnBuyLevel:SetVisible(false)
  end
end

return GUILicenseRewardListItem

local GUIChallengeRewardItem = class("GUIChallengeRewardItem", IGUIWindow)

function GUIChallengeRewardItem:onLoad()
  self.siImage = self:getChildWindowByName("ChallengeRewardItem-image", GUIType.StaticImage)
  self.siItemIcon = self:getChildWindowByName("ChallengeRewardItem-item_icon", GUIType.StaticImage)
  self.siItem = self:getChildWindowByName("ChallengeRewardItem-item", GUIType.StaticImage)
  self.siExperience = self:getChildWindowByName("ChallengeRewardItem-experience", GUIType.StaticImage)
  self.siRedPoint = self:getChildWindowByName("ChallengeRewardItem-red_point", GUIType.StaticImage)
  self.siMask = self:getChildWindowByName("ChallengeRewardItem-mask", GUIType.StaticImage)
  self.awvItem = self:getChildWindowByName("ChallengeRewardItem-actor", GUIType.ActorWindow)
  self.btView = self:getChildWindowByName("ChallengeRewardItem-bt", GUIType.Button)
  self.btView:registerEvent(GUIEvent.ButtonClick, function()
    self:onClickBtn()
  end)
  self:getChildWindowByName("ChallengeRewardItem-extra_bt", GUIType.Button):registerEvent(GUIEvent.ButtonClick, function()
    self:onClickBtn()
  end)
  self:getChildWindowByName("ChallengeRewardItem-question", GUIType.Button):registerEvent(GUIEvent.ButtonClick, function()
    self:onClickQuestion()
  end)
  self.stItemName = self:getChildWindowByName("ChallengeRewardItem-name", GUIType.StaticText)
  self:getChildWindowByName("ChallengeRewardItem-ex_text", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_experience"))
end

function GUIChallengeRewardItem:onDataChanged(data)
  self.rewardId = data.rewardId
  self.stItemName:SetText(Lang:getString(data.name))
  self.awvItem:SetWidth({
    data.scale1,
    0
  })
  self.awvItem:SetYPosition({
    0,
    data.offset1
  })
  self.siImage:SetArea({0, 0}, {
    0,
    data.offset1
  }, {
    0,
    data.scale1 * 120
  }, {
    0,
    data.scale1 * 120
  })
  if data.isRecommend == 1 then
    self.siExperience:SetVisible(true)
  else
    self.siExperience:SetVisible(false)
  end
  if data.type == 1 then
    self.awvItem:SetVisible(false)
    self.siItem:SetImage("")
    self.siItemIcon:SetImage("")
    self.siImage:SetImage(data.image)
  elseif data.type == 2 then
    self.awvItem:SetVisible(true)
    self.siItem:SetImage("")
    self.siItemIcon:SetImage("")
    self.siImage:SetImage("")
    self.awvItem:SetActor1(data.actorName, data.uiSkillName, 0)
  elseif data.type == 3 then
    self.awvItem:SetVisible(false)
    self.siItem:SetImage("set:bedwar_treasurechallenge.json image:box")
    self.siItemIcon:SetImage(data.image)
    self.siImage:SetImage("")
  end
  self.siRedPoint:SetVisible(false)
  if data.status == Define.ChallengeStatus.NotAccepted then
    self.btView:SetText(Lang:getString("gui_bed_war_hall_view_challenge"))
    self.btView:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_blue")
    self.btView:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_blue")
    self.btView:SetTouchable(true)
    self.siMask:SetVisible(false)
  elseif data.status == Define.ChallengeStatus.Experiencing then
    self.btView:SetText(Lang:getString("gui_bed_war_hall_processing"))
    self.btView:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_yellow")
    self.btView:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_yellow")
    self.btView:SetTouchable(true)
    self.siMask:SetVisible(false)
    for _, item in pairs(TreasureChallenge.rewardData) do
      if item.rewardId == self.rewardId then
        for _, task in pairs(item.taskGroup) do
          if task.status == Define.TaskStatus.FINISHED then
            self.siRedPoint:SetVisible(true)
            break
          end
        end
        break
      end
    end
  elseif data.status == Define.ChallengeStatus.Completed then
    self:getChildWindowByName("ChallengeRewardItem-extra_bt", GUIType.Button):SetTouchable(false)
    self.btView:SetText(Lang:getString("gui_bed_war_hall_completed"))
    self.btView:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_light_blue")
    self.btView:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_light_blue")
    self.btView:SetTouchable(false)
    self.siMask:SetVisible(true)
    self.siExperience:SetVisible(false)
  end
end

function GUIChallengeRewardItem:onClickBtn()
  if BaseMain:getGameType() == "g1046" then
    GameAnalytics:design(1, {
      "H_Treasure_view",
      tostring(self.rewardId),
      ReportUtil.getPlayerLevelInterval()
    })
  else
    GameAnalytics:design(1, {
      "G_Treasure_view",
      tostring(self.rewardId),
      ReportUtil.getPlayerLevelInterval()
    })
  end
  GUITreasureChallenge:hide()
  GUIChallengeTask:refreshUI(self.rewardId)
  GUIChallengeTask:show()
end

function GUIChallengeRewardItem:onClickQuestion()
  local reward = TreasureChallenge:getRewardData(self.rewardId)
  ChallengeRewardIntroduce:setRewardIntroduce(reward.image, reward.name, reward.introduce)
  CustomDialog.builder().setContentView(ChallengeRewardIntroduce).setHideLeftButton().setTitleText("gui_challenge_reward_introduce").setRightText(Lang:getString("gui_dialog_tip_btn_sure")).show()
end

return GUIChallengeRewardItem

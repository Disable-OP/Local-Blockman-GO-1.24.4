local GUICustomShopTab = class("GUICustomShopTab", IGUIWindow)

function GUICustomShopTab:onLoad()
  self.cbTab = self:getChildWindowByName("BedWarCustomShopTab-Tab", GUIType.CheckBox)
  self.ivIcon = self:getChildWindowByName("BedWarCustomShopTab-Icon", GUIType.StaticImage)
  self.tvName = self:getChildWindowByName("BedWarCustomShopTab-Name", GUIType.StaticText)
  self.llTabs = self:getChildWindowByName("BedWarCustomShopTab-SubTabs", GUIType.Layout)
  self.ivIcon:SetVisible(false)
  self.tabs = {}
  self.curIndex = 1
  self.cbTab:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbTab:GetChecked() then
      GUICustomShop:onSelectTab(self)
      self.cbTab:SetTouchable(#self.tabs > 0)
      if #self.tabs > 0 then
        self:changeHeight(self.contentHeight + self.closeHeight)
        self.tabs[self.curIndex]:setChecked(true)
        self:onSelectSubTab(self.tabs[self.curIndex])
      end
    else
      self.ivIcon:SetProperty("Rotate", 0)
      if #self.tabs > 0 then
        self:changeHeight(self.closeHeight)
      end
    end
  end)
  self.cbTab:registerEvent(GUIEvent.Click, function()
    SoundUtil.playSound(SoundConfig.selectTabStore)
  end)
end

function GUICustomShopTab:onDataChanged(pages)
  local types = pages.types
  self.pageId = pages.pageId
  local typeNum = 0
  for _, v in pairs(types) do
    typeNum = typeNum + 1
  end
  if 0 < typeNum then
    self:initTabs(types, typeNum)
    self.ivIcon:SetVisible(true)
  end
  for _, type in pairs(types) do
    self.tabId = type.tabId
    self.tvName:SetText(Lang:getString(type[1].PageLang))
    break
  end
end

function GUICustomShopTab:initTabs(types, typeNum)
  self.closeHeight = self.root:GetPixelSize().y
  self.contentHeight = 55 * typeNum
  self.llTabs:SetArea({0, 0}, {
    0,
    self.closeHeight
  }, {1, 0}, {
    0,
    self.contentHeight
  })
  local startY = 0
  for _, tabs in pairs(types) do
    local tab = UIHelper.newGameGUIWindow("GUICustomShopSubTab", "BedWarCustomShopSubTab.json")
    tab.root:registerEvent(GUIEvent.CheckStateChanged, function()
      if tab.cbTab:GetChecked() then
        tab.root:SetTouchable(false)
        self:onSelectSubTab(tab)
      end
    end)
    tab:setArea({0, 0}, {0, startY}, {1, 0}, {0, 55})
    tab:onDataChanged(tabs)
    self.llTabs:AddChildWindow(tab.root)
    table.insert(self.tabs, tab)
    startY = startY + 55
  end
end

function GUICustomShopTab:setChecked(check)
  self.cbTab:SetChecked(check)
  self.cbTab:SetTouchable(not check)
  if check then
    self.ivIcon:SetProperty("Rotate", 180)
    self.tvName:SetTextColor({
      0.15294117647058825,
      0.17647058823529413,
      0.3607843137254902,
      1
    })
  else
    self.ivIcon:SetProperty("Rotate", 0)
    self.tvName:SetTextColor({
      0.7843137254901961,
      0.8666666666666667,
      0.9490196078431372,
      1
    })
  end
  if #self.tabs == 0 then
    return
  end
  self.cbTab:SetTouchable(true)
  if GUICustomShop.curSelectTab and GUICustomShop.curSelectTab.pageId == self.pageId then
    self.tvName:SetTextColor({
      0.15294117647058825,
      0.17647058823529413,
      0.3607843137254902,
      1
    })
    self.cbTab:SetNormalImage("set:bed_war_3_button.json image:btn_0_current05")
  else
    self.tvName:SetTextColor({
      0.7843137254901961,
      0.8666666666666667,
      0.9490196078431372,
      1
    })
    self.cbTab:SetNormalImage("set:bed_war_3_button.json image:btn_0_non_current05")
  end
end

function GUICustomShopTab:onSelectSubTab(tab)
  for index, _tab in pairs(self.tabs) do
    if _tab.tabId == tab.tabId then
      _tab:setChecked(true)
      self.curIndex = index
    else
      _tab:setChecked(false)
    end
  end
  GUICustomShop:onSelectSubTab(tab)
end

function GUICustomShopTab:changeHeight(targetHeight)
  local curHeight = self.root:GetHeight()
  local speed = 0
  if 0 < targetHeight - curHeight[2] then
    speed = 1
  else
    speed = -1
  end
  LuaTimer:cancel(self.changeHeightTime)
  self.changeHeightTime = LuaTimer:scheduleTimer(function()
    curHeight = self.root:GetHeight()
    self.root:SetArea({0, 0}, self.root:GetYPosition(), {1, 0}, {
      0,
      curHeight[2] + speed
    })
    GUICustomShop:updateTabsLayout(self)
  end, 1, math.abs(targetHeight - curHeight[2]))
end

return GUICustomShopTab

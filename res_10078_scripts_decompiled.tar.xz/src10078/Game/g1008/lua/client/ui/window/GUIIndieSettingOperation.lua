local GUIIndieSettingOperation = class("GUIIndieSettingOperation", IGUIWindow)
local CheckTextColor = {
  Normal = {
    0.15294117647058825,
    0.17647058823529413,
    0.3607843137254902,
    1
  },
  Select = {
    0.5058823529411764,
    0.9529411764705882,
    0.9176470588235294,
    1
  }
}
local GUI_MIN_SIZE = 0.5
local GUI_MAX_SIZE = 1
local ControlType = {
  Button = 1,
  Flexed = 2,
  Flexible = 3,
  Jump = 4
}

function GUIIndieSettingOperation:ctor()
  self.super.ctor(self, "BedWarIndieSettingOperation.json")
end

function GUIIndieSettingOperation:onLoad()
  self.poleMove = GUIManager:getWindowByName("Main-PoleControl-Move")
  self.poleControl = GUIManager:getWindowByName("Main-PoleControl")
  self.poleBG = GUIManager:getWindowByName("Main-PoleControl-BG", GUIType.StaticImage)
  self.llControl = GUIManager:getWindowByName("Main-Control")
  self.llJumpControl = GUIManager:getWindowByName("Main-Jump-Control")
  self.poleWidth = self.poleControl:GetPixelSize().x
  self.poleHeight = self.poleControl:GetPixelSize().y
  self.size = self:getChildWindowByName("BedWarIndieSettingOperation-Size-Slider", GUIType.Slider)
  self.sizeText = self:getChildWindowByName("BedWarIndieSettingOperation-Size-Slider-Text", GUIType.StaticText)
  self.siControlIcon = self:getChildWindowByName("BedWarIndieSettingOperation-Control", GUIType.StaticImage)
  self.siJumpIcon = self:getChildWindowByName("BedWarIndieSettingOperation-Jump", GUIType.StaticImage)
  self:getChildWindowByName("BedWarIndieSettingOperation-Detail", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.toggle"))
  self:getChildWindowByName("BedWarIndieSettingOperation-Button-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.button"))
  self:getChildWindowByName("BedWarIndieSettingOperation-Jump-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.Jump"))
  self:getChildWindowByName("BedWarIndieSettingOperation-Flexed-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.flexed"))
  self:getChildWindowByName("BedWarIndieSettingOperation-Flexible-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.flexible"))
  self:getChildWindowByName("BedWarIndieSettingOperation-Size", GUIType.StaticText):SetText(Lang:getString("gui.setting.gui.size"))
  self.opGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
  self:register()
  LuaTimer:schedule(function()
    local ivButton = self:getChildWindowByName("BedWarIndieSettingOperation-Button-Img")
    local width = math.min(ivButton:GetPixelSize().x, 156)
    ivButton:SetWidth({0, width})
    ivButton:SetHeight({0, width})
    local ivFlexible = self:getChildWindowByName("BedWarIndieSettingOperation-Flexible-Img")
    width = math.min(ivFlexible:GetPixelSize().x, 166)
    ivFlexible:SetWidth({0, width})
    ivFlexible:SetHeight({0, width})
    local ivFlexed = self:getChildWindowByName("BedWarIndieSettingOperation-Flexed-Img")
    width = math.min(ivFlexed:GetPixelSize().x, 168)
    ivFlexed:SetWidth({0, width})
    ivFlexed:SetHeight({0, width})
  end, 100)
end

function GUIIndieSettingOperation:register()
  self.opGroup:addCheckBox(self:getChildWindowByName("BedWarIndieSettingOperation-Button-Box", GUIType.CheckBox), function(checked)
    local check = self:getChildWindowByName("BedWarIndieSettingOperation-Button-Check", GUIType.StaticImage)
    local text = self:getChildWindowByName("BedWarIndieSettingOperation-Button-Text", GUIType.StaticText)
    if checked then
      if ClientNewReportUtil then
        ClientNewReportUtil:onPlayerChangeControlModel(SystemSettingRecord.defaultOperation, 0)
      end
      self.curControl = ControlType.Button
      Blockman.Instance().m_gameSettings.usePole = 0
      ClientHelper.putBoolPrefs("UseCenterJumpButton", false)
      self.siControlIcon:SetImage("set:bedwar_setting.json image:operation_type1")
      self:refreshSize(self.size:GetProgress())
      check:SetImage("set:bed_war_3_setting.json image:img_0_selected04")
      text:SetTextColor(CheckTextColor.Select)
      LuaTimer:schedule(function()
        SystemSettingRecord.defaultOperation = self.opGroup:getCurIndex()
        onSaveSetting()
      end, 0)
    else
      check:SetImage("set:bed_war_3_setting.json image:img_0_selected03")
      text:SetTextColor(CheckTextColor.Normal)
    end
  end)
  self.opGroup:addCheckBox(self:getChildWindowByName("BedWarIndieSettingOperation-Flexed-Box", GUIType.CheckBox), function(checked)
    local check = self:getChildWindowByName("BedWarIndieSettingOperation-Flexed-Check", GUIType.StaticImage)
    local text = self:getChildWindowByName("BedWarIndieSettingOperation-Flexed-Text", GUIType.StaticText)
    if checked then
      if ClientNewReportUtil then
        ClientNewReportUtil:onPlayerChangeControlModel(SystemSettingRecord.defaultOperation, 1)
      end
      self.curControl = ControlType.Flexed
      self.poleMove:SetArea({0, 50}, {0, -70}, {
        0,
        self.poleWidth
      }, {
        0,
        self.poleHeight
      })
      self.poleBG:SetImage("set:pole.json image:pole_bg")
      self.siControlIcon:SetImage("set:bedwar_setting.json image:operation_type5")
      self.siControlIcon:SetHeight({
        0,
        self.poleHeight
      })
      self.siControlIcon:SetWidth({
        0,
        self.poleWidth
      })
      Blockman.Instance().m_gameSettings.usePole = 1
      check:SetImage("set:bed_war_3_setting.json image:img_0_selected04")
      text:SetTextColor(CheckTextColor.Select)
      LuaTimer:schedule(function()
        SystemSettingRecord.defaultOperation = self.opGroup:getCurIndex()
        onSaveSetting()
      end, 0)
    else
      check:SetImage("set:bed_war_3_setting.json image:img_0_selected03")
      text:SetTextColor(CheckTextColor.Normal)
    end
  end)
  self.opGroup:addCheckBox(self:getChildWindowByName("BedWarIndieSettingOperation-Flexible-Box", GUIType.CheckBox), function(checked)
    local check = self:getChildWindowByName("BedWarIndieSettingOperation-Flexible-Check", GUIType.StaticImage)
    local text = self:getChildWindowByName("BedWarIndieSettingOperation-Flexible-Text", GUIType.StaticText)
    if checked then
      if ClientNewReportUtil then
        ClientNewReportUtil:onPlayerChangeControlModel(SystemSettingRecord.defaultOperation, 2)
      end
      self.curControl = ControlType.Flexible
      self.poleMove:SetArea({0, 0}, {0, 0}, {
        0,
        self.poleWidth * 1.8
      }, {
        0,
        self.poleHeight * 2
      })
      self.poleBG:SetImage("set:pole.json image:pole_bg_2")
      Blockman.Instance().m_gameSettings.usePole = 2
      self.siControlIcon:SetImage("set:bedwar_setting.json image:operation_type4")
      self.siControlIcon:SetHeight({
        0,
        self.poleHeight
      })
      self.siControlIcon:SetWidth({
        0,
        self.poleWidth
      })
      check:SetImage("set:bed_war_3_setting.json image:img_0_selected04")
      text:SetTextColor(CheckTextColor.Select)
      LuaTimer:schedule(function()
        SystemSettingRecord.defaultOperation = self.opGroup:getCurIndex()
        onSaveSetting()
      end, 0)
    else
      check:SetImage("set:bed_war_3_setting.json image:img_0_selected03")
      text:SetTextColor(CheckTextColor.Normal)
    end
  end)
  self.opGroup:addCheckBox(self:getChildWindowByName("BedWarIndieSettingOperation-Jump-Box", GUIType.CheckBox), function(checked)
    local check = self:getChildWindowByName("BedWarIndieSettingOperation-Jump-Check", GUIType.StaticImage)
    local text = self:getChildWindowByName("BedWarIndieSettingOperation-Jump-Text", GUIType.StaticText)
    if checked then
      if ClientNewReportUtil then
        ClientNewReportUtil:onPlayerChangeControlModel(SystemSettingRecord.defaultOperation, 3)
      end
      self.curControl = ControlType.Jump
      Blockman.Instance().m_gameSettings.usePole = 0
      ClientHelper.putBoolPrefs("UseCenterJumpButton", true)
      self.siControlIcon:SetImage("set:bedwar_setting.json image:operation_type2")
      self:refreshSize(self.size:GetProgress())
      check:SetImage("set:bed_war_3_setting.json image:img_0_selected04")
      text:SetTextColor(CheckTextColor.Select)
      LuaTimer:schedule(function()
        SystemSettingRecord.defaultOperation = self.opGroup:getCurIndex()
        onSaveSetting()
      end, 0)
    else
      check:SetImage("set:bed_war_3_setting.json image:img_0_selected03")
      text:SetTextColor(CheckTextColor.Normal)
    end
  end)
  self.size:registerEvent(GUIEvent.TouchDown, function()
    self:refreshSize()
  end)
  self.size:registerEvent(GUIEvent.TouchMove, function()
    self:refreshSize()
  end)
end

function GUIIndieSettingOperation:refreshSize(progress)
  local curProgress = progress or self.size:GetProgress()
  if progress then
    self.size:SetProgress(progress)
  end
  local size = GUI_MIN_SIZE + (GUI_MAX_SIZE - GUI_MIN_SIZE) * curProgress
  if self.curControl == ControlType.Button or self.curControl == ControlType.Jump then
    self.siControlIcon:SetHeight({
      0,
      300 * size
    })
    self.siControlIcon:SetWidth({
      0,
      300 * size
    })
  end
  self.siJumpIcon:SetHeight({
    0,
    114.60000000000001 * size
  })
  self.siJumpIcon:SetWidth({
    0,
    114.60000000000001 * size
  })
  local rat = math.floor(curProgress * 10) / 10
  self.sizeText:SetText(rat)
  self.size:SetHeaderImage(rat == GUIBedWarIndieSettingLayout.defaultSetting.defaultButtonSize and "set:bed_war_3_button.json image:btn_0_settings01" or "set:bed_war_3_button.json image:btn_0_settings")
  self.sizeText:SetXPosition({curProgress, -25})
  Blockman.Instance().m_gameSettings.playerActivityGuiSize = size
  SystemSettingRecord.defaultButtonSize = curProgress
  onSaveSetting()
end

return GUIIndieSettingOperation

local GUILicenseExchangeItem = class("GUILicenseExchangeItem", IGUIWindow)

function GUILicenseExchangeItem:onLoad()
  self.siBg = self:getChildWindowByName("BedWarLicenseExchangeItem-Bg", GUIType.StaticImage)
  self.btnExchange = self:getChildWindowByName("BedWarLicenseExchangeItem-Btn", GUIType.Button)
  self.siIcon = self:getChildWindowByName("BedWarLicenseExchangeItem-Icon", GUIType.StaticImage)
  self.stText = self:getChildWindowByName("BedWarLicenseExchangeItem-Text", GUIType.StaticText)
  self.stName = self:getChildWindowByName("BedWarLicenseExchangeItem-Name", GUIType.StaticText)
  self.siLock = self:getChildWindowByName("BedWarLicenseExchangeItem-Lock", GUIType.StaticImage)
  self.stNum = self:getChildWindowByName("BedWarLicenseExchangeItem-Num", GUIType.StaticText)
  self.btnExchange:registerEvent(GUIEvent.ButtonClick, function()
    GUILicense:onExchangeItemChange(self.data)
  end)
end

function GUILicenseExchangeItem:onDataChanged(data)
  self.data = data
  if self.data.Statue == 0 then
    self.stName:SetText(Lang:getString("gui_bed_war_license_exchange_had_get"))
    self.stText:SetVisible(false)
    self.siLock:SetVisible(false)
    self.stName:SetVisible(true)
    self.stNum:SetVisible(false)
  elseif GUILicense.playerLevel >= self.data.LVLimit then
    self.stName:SetText(Lang:getString(self.data.Name))
    self.stName:SetVisible(true)
    self.stText:SetVisible(false)
    self.stNum:SetText(self.data.hadExchange .. "/" .. self.data.BuyLimit)
    self.siLock:SetVisible(false)
    self.stNum:SetVisible(true)
  else
    self.stName:SetVisible(false)
    self.stText:SetText("LV. " .. self.data.LVLimit)
    self.stText:SetVisible(true)
    self.siLock:SetVisible(true)
    self.stNum:SetVisible(false)
  end
  self.siIcon:SetImage(self.data.Image)
  if GUILicense:isExchangeSelect(self.data.ItemId) then
    GUILicense:onExchangeItemChange(self.data)
    self.siBg:SetImage("set:bedwar_licenseexchange.json image:item_can")
  else
    self.siBg:SetImage("set:bedwar_licenseexchange.json image:item_normal")
  end
  local width = self.stText:GetTextWidth()
  self.siLock:SetXPosition({
    0,
    -(5 + width / 2)
  })
end

return GUILicenseExchangeItem

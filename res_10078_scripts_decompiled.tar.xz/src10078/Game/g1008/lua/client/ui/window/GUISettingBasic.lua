local GUI_MIN_SIZE = 0.5
local GUI_MAX_SIZE = 1
local Color = {
  Select = {
    0.41568627450980394,
    0.23529411764705882,
    0.11372549019607843,
    1
  },
  Normal = {
    0.41568627450980394,
    0.23529411764705882,
    0.11372549019607843,
    1
  }
}
local CheckTextColor = {
  Normal = {
    0.15294117647058825,
    0.17647058823529413,
    0.3607843137254902,
    1
  },
  Select = {
    0.5058823529411764,
    0.9529411764705882,
    0.9176470588235294,
    1
  }
}
local isEnableIndie = Game:isEnableIndie()
local GUISettingBasic = class("GUISettingBasic", IGUIWindow)

function GUISettingBasic:ctor()
  self.super.ctor(self, isEnableIndie and "BedWarIndieSettingBasic.json" or "BedWarSettingBasic.json")
end

function GUISettingBasic:onLoad()
  self.btnLogout = self:getChildWindowByName("BedWarSettingBasic-Logout", GUIType.Button)
  self.sensitive = self:getChildWindowByName("BedWarSettingBasic-Sensitivity-Slider", GUIType.Slider)
  self.luminance = self:getChildWindowByName("BedWarSettingBasic-Luminance-Slider", GUIType.Slider)
  self.horizon = self:getChildWindowByName("BedWarSettingBasic-Horizon-Slider", GUIType.Slider)
  self.size = self:getChildWindowByName("BedWarSettingBasic-Size-Slider", GUIType.Slider)
  if isEnableIndie then
    self.sensitiveText = self:getChildWindowByName("BedWarSettingBasic-Sensitivity-Slider-Text", GUIType.StaticText)
    self.luminanceText = self:getChildWindowByName("BedWarSettingBasic-Luminance-Slider-Text", GUIType.StaticText)
    self.horizonText = self:getChildWindowByName("BedWarSettingBasic-Horizon-Slider-Text", GUIType.StaticText)
  end
  self:getChildWindowByName("BedWarSettingBasic-Title", GUIType.StaticText):SetText(Lang:getString("gui.setting.basic"))
  self:getChildWindowByName("BedWarSettingBasic-Fps-Title", GUIType.StaticText):SetText(Lang:getString("gui.setting.fps"))
  self:getChildWindowByName("BedWarSettingBasic-Fps30-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.fps.30"))
  self:getChildWindowByName("BedWarSettingBasic-Fps45-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.fps.45"))
  self:getChildWindowByName("BedWarSettingBasic-Fps60-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.fps.60"))
  self:getChildWindowByName("BedWarSettingBasic-Camera-Title", GUIType.StaticText):SetText(Lang:getString("gui.setting.camera"))
  self:getChildWindowByName("BedWarSettingBasic-Fpp-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.camera.fpp"))
  self:getChildWindowByName("BedWarSettingBasic-Third-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.camera.third"))
  self:getChildWindowByName("BedWarSettingBasic-Second-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.camera.second"))
  self:getChildWindowByName("BedWarSettingBasic-Luminance", GUIType.StaticText):SetText(Lang:getString("gui.setting.luminance"))
  self:getChildWindowByName("BedWarSettingBasic-Size", GUIType.StaticText):SetText(Lang:getString("gui.setting.gui.size"))
  self:getChildWindowByName("BedWarSettingBasic-Sensitivity", GUIType.StaticText):SetText(Lang:getString("gui.setting.camera.sensitive"))
  self:getChildWindowByName("BedWarSettingBasic-Horizon", GUIType.StaticText):SetText(Lang:getString("gui.setting.horizon"))
  if self:getChildWindowByName("BedWarSettingBasic-Screen-Title", GUIType.StaticText) then
    self:getChildWindowByName("BedWarSettingBasic-Screen-Title", GUIType.StaticText):SetText(Lang:getString("gui.setting.screen.title"))
  end
  self.fpsGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
  self.cameraGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
  self:register()
end

function GUISettingBasic:register()
  self.fpsGroup:addCheckBox(self:getChildWindowByName("BedWarSettingBasic-Fps30-Box", GUIType.CheckBox), function(checked)
    local text = self:getChildWindowByName("BedWarSettingBasic-Fps30-Text", GUIType.StaticText)
    if isEnableIndie then
      text:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
    end
    if checked then
      CGame.Instance():SetMaxFps(30)
      LuaTimer:schedule(function()
        SystemSettingRecord.defaultFPS = self.fpsGroup:getCurIndex()
        onSaveSetting()
      end, 0)
    end
  end)
  self.fpsGroup:addCheckBox(self:getChildWindowByName("BedWarSettingBasic-Fps45-Box", GUIType.CheckBox), function(checked)
    local text = self:getChildWindowByName("BedWarSettingBasic-Fps45-Text", GUIType.StaticText)
    if isEnableIndie then
      text:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
    end
    if checked then
      CGame.Instance():SetMaxFps(45)
      LuaTimer:schedule(function()
        SystemSettingRecord.defaultFPS = self.fpsGroup:getCurIndex()
        onSaveSetting()
      end, 0)
    end
  end)
  self.fpsGroup:addCheckBox(self:getChildWindowByName("BedWarSettingBasic-Fps60-Box", GUIType.CheckBox), function(checked)
    local text = self:getChildWindowByName("BedWarSettingBasic-Fps60-Text", GUIType.StaticText)
    if isEnableIndie then
      text:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
    end
    if checked then
      CGame.Instance():SetMaxFps(60)
      LuaTimer:schedule(function()
        SystemSettingRecord.defaultFPS = self.fpsGroup:getCurIndex()
        onSaveSetting()
      end, 0)
    end
  end)
  self.cameraGroup:addCheckBox(self:getChildWindowByName("BedWarSettingBasic-Fpp-Box", GUIType.CheckBox), function(checked)
    local text = self:getChildWindowByName("BedWarSettingBasic-Fpp-Text", GUIType.StaticText)
    if checked then
      local function func()
        Blockman.Instance():setPersonView(0)
        
        GUIBedWarToolBar:cameraChange()
        GUIMain:cameraChange()
        LuaTimer:schedule(function()
          SystemSettingRecord.defaultCamera = self.cameraGroup:getCurIndex()
          onSaveSetting()
        end, 0)
      end
      
      if GUIBedWarToolBar and GUIMain then
        func()
      else
        GUIManager:registerQueue(func)
      end
    end
  end)
  self.cameraGroup:addCheckBox(self:getChildWindowByName("BedWarSettingBasic-Third-Box", GUIType.CheckBox), function(checked)
    local text = self:getChildWindowByName("BedWarSettingBasic-Third-Text", GUIType.StaticText)
    if checked then
      local function func()
        Blockman.Instance():setPersonView(1)
        
        GUIBedWarToolBar:cameraChange()
        GUIMain:cameraChange()
        LuaTimer:schedule(function()
          SystemSettingRecord.defaultCamera = self.cameraGroup:getCurIndex()
          onSaveSetting()
        end, 0)
      end
      
      if GUIBedWarToolBar and GUIMain then
        func()
      else
        GUIManager:registerQueue(func)
      end
    end
  end)
  self.cameraGroup:addCheckBox(self:getChildWindowByName("BedWarSettingBasic-Second-Box", GUIType.CheckBox), function(checked)
    local text = self:getChildWindowByName("BedWarSettingBasic-Second-Text", GUIType.StaticText)
    if checked then
      local function func()
        Blockman.Instance():setPersonView(2)
        
        GUIBedWarToolBar:cameraChange()
        GUIMain:cameraChange()
        LuaTimer:schedule(function()
          SystemSettingRecord.defaultCamera = self.cameraGroup:getCurIndex()
          onSaveSetting()
        end, 0)
      end
      
      if GUIBedWarToolBar and GUIMain then
        func()
      else
        GUIManager:registerQueue(func)
      end
    end
  end)
  self.sensitive:registerEvent(GUIEvent.TouchDown, function()
    self:refreshSensitive()
  end)
  self.sensitive:registerEvent(GUIEvent.TouchMove, function()
    self:refreshSensitive()
  end)
  self.luminance:registerEvent(GUIEvent.TouchDown, function()
    self:refreshLuminance()
  end)
  self.luminance:registerEvent(GUIEvent.TouchMove, function()
    self:refreshLuminance()
  end)
  self.horizon:registerEvent(GUIEvent.TouchDown, function()
    self:refreshHorizon()
  end)
  self.horizon:registerEvent(GUIEvent.TouchMove, function()
    self:refreshHorizon()
  end)
  self.size:registerEvent(GUIEvent.TouchDown, function()
    self:refreshSize()
  end)
  self.size:registerEvent(GUIEvent.TouchMove, function()
    self:refreshSize()
  end)
end

function GUISettingBasic:refreshSensitive(progress)
  local curProgress = progress or self.sensitive:GetProgress()
  if progress then
    self.sensitive:SetProgress(progress)
  end
  local minSize = 1
  local maxSize = 9
  local size = minSize + (maxSize - minSize) * curProgress
  if self.sensitiveText then
    self.sensitiveText:SetText(math.floor(curProgress * 10))
    self.sensitiveText:SetXPosition({curProgress, -25})
    self.sensitive:SetHeaderImage(math.floor(curProgress * 10) / 10 == GUIBedWarIndieSettingLayout.defaultSetting.defaultSensitivity and "set:bed_war_3_button.json image:btn_0_settings01" or "set:bed_war_3_button.json image:btn_0_settings")
  end
  Blockman.Instance().m_gameSettings:setCameraSensitive(size)
  SystemSettingRecord.defaultSensitivity = curProgress
  onSaveSetting()
end

function GUISettingBasic:refreshLuminance(progress)
  local curProgress = progress or self.luminance:GetProgress()
  if progress then
    self.luminance:SetProgress(progress)
  end
  if self.luminanceText then
    self.luminanceText:SetText(math.floor(curProgress * 10))
    self.luminanceText:SetXPosition({curProgress, -25})
    self.luminance:SetHeaderImage(math.floor(curProgress * 10) / 10 == GUIBedWarIndieSettingLayout.defaultSetting.defaultLuminance and "set:bed_war_3_button.json image:btn_0_settings01" or "set:bed_war_3_button.json image:btn_0_settings")
  end
  Blockman.Instance().m_gameSettings.gammaSetting = curProgress
  SystemSettingRecord.defaultLuminance = curProgress
  onSaveSetting()
end

function GUISettingBasic:refreshHorizon(progress)
  local curProgress = progress or self.horizon:GetProgress()
  if progress then
    self.horizon:SetProgress(progress)
  end
  if self.horizonText then
    self.horizonText:SetText(math.floor(curProgress * 10))
    self.horizonText:SetXPosition({curProgress, -25})
    self.horizon:SetHeaderImage(math.floor(curProgress * 10) / 10 == GUIBedWarIndieSettingLayout.defaultSetting.defaultHorizon and "set:bed_war_3_button.json image:btn_0_settings01" or "set:bed_war_3_button.json image:btn_0_settings")
  end
  Blockman.Instance().m_gameSettings:setFovSetting(curProgress)
  SystemSettingRecord.defaultHorizon = curProgress
  onSaveSetting()
end

function GUISettingBasic:refreshSize(progress)
  if progress then
    self.size:SetProgress(progress)
  end
  local size = GUI_MIN_SIZE + (GUI_MAX_SIZE - GUI_MIN_SIZE) * self.size:GetProgress()
  Blockman.Instance().m_gameSettings.playerActivityGuiSize = size
  SystemSettingRecord.defaultButtonSize = self.size:GetProgress()
  onSaveSetting()
end

function GUISettingBasic:getCurCamera()
end

return GUISettingBasic

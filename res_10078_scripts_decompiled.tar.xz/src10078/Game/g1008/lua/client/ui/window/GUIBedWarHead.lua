local DefaultIcon = "default_headshot.png"
local GUIBedWarHead = class("GUIBedWarHead", IGUIWindow)
local HeadFrameConfig = T(Global, "HeadFrameConfig")

function GUIBedWarHead:ctor(size, ...)
  self.super.ctor(self, "BedWarHead.json", ...)
  self:setSize(size or 50)
end

function GUIBedWarHead:onLoad()
  self.uivHead = self:getChildWindowByName("BedWarHead-Head", GUIType.UrlImage)
  self.llTouch = self:getChildWindowByName("BedWarHead-Touch", GUIType.Layout)
  self.siFrame = self:getChildWindowByName("BedWarHead-Frame", GUIType.StaticImage)
  self.siFrameEffect = self:getChildWindowByName("BedWarHead-Frame-Effect", GUIType.StaticImage)
  self.uivHead:setChildMaterial(0)
  self.uivHead:setDefaultImage(DefaultIcon)
  self.llTouch:SetTouchable(true)
  self.showHomePage = true
  self:initEvent()
end

function GUIBedWarHead:initEvent()
  self.llTouch:registerEvent(GUIEvent.Click, function()
    if not self.userId or not self.showHomePage then
      return
    end
    
    local function openPersonalHomePage(userId)
      PopUpWindows.hide()
      CustomDialog.hide()
      GUIPersonalHomePageLayout:openPersonalHomePageByUserId(userId)
    end
    
    if UserInfoCache:GetCache(self.userId) then
      openPersonalHomePage(self.userId)
    else
      UserInfoCache:GetCacheByUserIds({
        self.userId
      }, function()
        openPersonalHomePage(self.userId)
      end)
    end
    if self.reportKey then
      ClientReportEvent.click_main_button(self.reportKey)
    end
  end)
  self:registerEvent(Events.HeadFrameChangeEvent, function(userId)
    if userId == self.userId then
      local userInfo = UserInfoCache:GetCache(self.userId)
      if not userInfo then
        return
      end
      self:setUserInfo(userInfo)
    end
  end)
end

function GUIBedWarHead:setSize(size)
  self.root:SetWidth({0, size})
  self.root:SetHeight({0, size})
end

function GUIBedWarHead:setUserInfo(data)
  if data.picUrl then
    self.uivHead:setUrl(data.picUrl)
  end
  self.siFrame:SetImage("")
  self.siFrameEffect:SetEffectName("")
  self.siFrameEffect:SetVisible(false)
  local id = data[Define.PlayerCustomInfo.CurHeadFrame] or 0
  local config = HeadFrameConfig.getDefaultFrame()
  if id == 0 and data.avatarFrame then
    config = HeadFrameConfig.getConfigBySvga(data.avatarFrame) or config
  else
    config = id ~= 0 and HeadFrameConfig.getConfigById(id) or config
  end
  if config then
    if config.Frame and config.Frame ~= "#" then
      self.siFrame:SetImage(config.Frame)
    end
    if config.FrameEffect and config.FrameEffect ~= "#" then
      self.siFrameEffect:SetEffectName(config.FrameEffect)
      self.siFrameEffect:SetVisible(true)
    end
  end
  self.userId = data.userId
end

function GUIBedWarHead:setCanOpenPersonalHome(canOpen)
  self.showHomePage = canOpen or false
end

function GUIBedWarHead:setReportKey(reportKey)
  self.reportKey = reportKey
end

return GUIBedWarHead

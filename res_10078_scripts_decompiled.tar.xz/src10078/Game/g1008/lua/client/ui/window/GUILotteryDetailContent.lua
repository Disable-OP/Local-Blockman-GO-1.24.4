local GUILotteryDetailContent = class("GUILotteryDetailContent", IGUIWindow)

function GUILotteryDetailContent:onLoad()
  self.stCore = self:getChildWindowByName("LotteryDetailContent-core_title", GUIType.StaticText)
  self.stCommon = self:getChildWindowByName("LotteryDetailContent-common_title", GUIType.StaticText)
  self.llCore = self:getChildWindowByName("LotteryDetailContent-core_layout", GUIType.Layout)
  self.llCommon = self:getChildWindowByName("LotteryDetailContent-common_layout", GUIType.Layout)
  self.stCore:SetText(Lang:getString("bed_war_lottery_core"))
  self.stCommon:SetText(Lang:getString("bed_war_lottery_common"))
end

function GUILotteryDetailContent:setLotteryDetailInfo(coreItem, commonItem)
  table.sort(coreItem, function(a1, a2)
    return a1.SortWeight < a2.SortWeight
  end)
  table.sort(commonItem, function(a1, a2)
    return a1.SortWeight < a2.SortWeight
  end)
  local height = 50
  self.gvCoreList = IGUIGridView.new("BedWarLottery-core-List", self.llCore)
  self.gvCoreList:setArea({0, 30}, {0, 0}, {1, 0}, {1, 0})
  self.gvCoreList:setConfig(30, 15, 5)
  self.coreAdapter = UIHelper.newGameAdapter("LotteryDetailAdapter")
  local itemWidth = (self.gvCoreList:getWidth() - 180) / 5
  local itemHeight = itemWidth
  local coreLayoutHeight = math.ceil(TableUtil.getTableSize(coreItem) / 5) * (itemHeight + 15)
  self.coreAdapter:setItemSize(itemWidth, itemHeight)
  self.llCore:SetHeight({0, coreLayoutHeight})
  self.gvCoreList:setAdapter(self.coreAdapter)
  self.coreAdapter:setData(coreItem)
  self.gvCoreList.root:SetTouchable(false)
  height = height + coreLayoutHeight + 10
  self.stCommon:SetYPosition({0, height})
  height = height + 50
  self.llCommon:SetYPosition({0, height})
  self.gvCommonList = IGUIGridView.new("BedWarLottery-common-List", self.llCommon)
  self.gvCommonList:setArea({0, 30}, {0, 0}, {1, 0}, {1, 0})
  self.gvCommonList:setConfig(30, 15, 5)
  self.commonAdapter = UIHelper.newGameAdapter("LotteryDetailAdapter")
  itemWidth = (self.gvCommonList:getWidth() - 180) / 5
  itemHeight = itemWidth
  local commonLayoutHeight = math.ceil(TableUtil.getTableSize(commonItem) / 5) * (itemHeight + 15)
  self.commonAdapter:setItemSize(itemWidth, itemHeight)
  self.llCommon:SetHeight({0, commonLayoutHeight})
  self.gvCommonList:setAdapter(self.commonAdapter)
  self.commonAdapter:setData(commonItem)
  self.gvCommonList.root:SetTouchable(false)
  height = height + commonLayoutHeight
  self.root:SetHeight({0, height})
end

return GUILotteryDetailContent

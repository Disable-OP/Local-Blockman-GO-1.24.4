local GUILicenseTab = class("GUILicenseTab", IGUIWindow)

function GUILicenseTab:onLoad()
  self.cbTab = self:getChildWindowByName("LicenseTab-Tab", GUIType.Button)
  self.tvName = self:getChildWindowByName("LicenseTab-Name", GUIType.StaticText)
  self.siRedPoint = self:getChildWindowByName("LicenseTab-RedPoint", GUIType.StaticImage)
  self.cbTab:registerEvent(GUIEvent.ButtonClick, function()
    if self.tabId == 2 then
      self.siRedPoint:SetVisible(false)
    end
    if BaseMain:getGameType() == "g1046" then
      GameAnalytics:design(1, {
        "H_License_page",
        self.tabId
      })
    else
      GameAnalytics:design(1, {
        "G_License_page",
        self.tabId
      })
    end
    GUILicense:onSelectChange(self.tabId)
    if self.tabId == 3 and GUILicense.exchangeSelect == -1 then
      GUILicense.btnExchange:SetVisible(false)
    end
  end)
end

function GUILicenseTab:checkRedPoint()
  if self.tabId == 2 then
    local finishTask = GUILicense.showEffectTask or {}
    if 1 <= #finishTask then
      self.siRedPoint:SetVisible(true)
      GUILicense.showEffectTask = {}
      return
    end
  end
  self.siRedPoint:SetVisible(false)
end

function GUILicenseTab:setChecked(check)
  if check then
    self.cbTab:SetNormalImage("set:bedwar_license.json image:btn_select")
    self.cbTab:SetPushedImage("set:bedwar_license.json image:btn_select")
  else
    self.cbTab:SetNormalImage("set:bedwar_license.json image:btn_notselect")
    self.cbTab:SetPushedImage("set:bedwar_license.json image:btn_notselect")
  end
  self.cbTab:SetTouchable(not check)
end

function GUILicenseTab:onDataChanged(data)
  self.tabId = data.Id
  self:checkRedPoint()
  self.tvName:SetText(Lang:getString(data.Lang))
end

return GUILicenseTab

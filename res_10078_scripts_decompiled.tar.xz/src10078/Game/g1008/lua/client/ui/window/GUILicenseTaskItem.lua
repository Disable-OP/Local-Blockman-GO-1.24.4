local GUILicenseTaskItem = class("GUILicenseTaskItem", IGUIWindow)

function GUILicenseTaskItem:onLoad()
  self.stFinishTimes = self:getChildWindowByName("BedWarLicenseTaskItem-Times", GUIType.StaticText)
  self.stEXPText = self:getChildWindowByName("BedWarLicenseTaskItem-EXP-Text", GUIType.StaticText)
  self.stDescribe = self:getChildWindowByName("BedWarLicenseTaskItem-Describe", GUIType.StaticText)
  self.stProgressText = self:getChildWindowByName("BedWarLicenseTaskItem-Progress-Text", GUIType.StaticText)
  self.pbProgressBar = self:getChildWindowByName("BedWarLicenseTaskItem-Progress-bar", GUIType.ProgressBar)
  self.btnTaskStatue = self:getChildWindowByName("BedWarLicenseTaskItem-Statue", GUIType.Button)
  self.stTaskStatueText = self:getChildWindowByName("BedWarLicenseTaskItem-Statue-Text", GUIType.StaticText)
  self.siEffect = self:getChildWindowByName("BedWarLicenseTaskItem-Effect", GUIType.StaticImage)
  self.siProgressBg = self:getChildWindowByName("BedWarLicenseTaskItem-Progress-bg", GUIType.StaticImage)
end

function GUILicenseTaskItem:onDataChange(data)
  if GameType == "g1046" then
    local finishText = "\226\150\162FFF4EA54" .. data.finishNum .. "  " .. "\226\150\162FFFFFFFF" .. Lang:getString("gui_bed_war_license_task_times")
    self.stFinishTimes:SetText(finishText)
    self.siProgressBg:SetVisible(false)
    self.stFinishTimes:SetVisible(true)
    self.btnTaskStatue:SetVisible(false)
  elseif data.status == 2 then
    self.stTaskStatueText:SetText(Lang:getString("bed_war_license_task_progressing"))
    self.btnTaskStatue:SetNormalImage("set:bedwar_license.json image:btn_select")
    self.btnTaskStatue:SetPushedImage("set:bedwar_license.json image:btn_select")
    self.siProgressBg:SetVisible(true)
    self.stFinishTimes:SetVisible(false)
    self.btnTaskStatue:SetVisible(true)
  elseif data.status == 3 or data.status == 4 then
    self.stTaskStatueText:SetText(Lang:getString("bed_war_license_task_finish"))
    self.btnTaskStatue:SetNormalImage("set:bedwar_license.json image:btn_green")
    self.btnTaskStatue:SetPushedImage("set:bedwar_license.json image:btn_green")
    self.siProgressBg:SetVisible(true)
    self.stFinishTimes:SetVisible(false)
    self.btnTaskStatue:SetVisible(true)
  end
  self.taskId = data.taskId
  local taskConfig = TaskConfig:getTaskById(self.taskId)
  if taskConfig then
    local GoalNum = taskConfig.GoalNum
    if taskConfig then
      self.stDescribe:SetText(Lang:getString(taskConfig.Desc))
      self.stEXPText:SetText(taskConfig.Reward)
    end
    self.stProgressText:SetText(data.progress .. "/" .. GoalNum)
    self.pbProgressBar:SetProgress(data.progress / GoalNum)
  end
  local showEffect = GUILicense.showEffectTask
  if showEffect == nil then
    return
  end
  self.siEffect:SetVisible(false)
  for index, task in pairs(showEffect) do
    if task == self.taskId then
      self.siEffect:SetVisible(true)
      break
    end
  end
end

return GUILicenseTaskItem

local DefaultIcon = "default_headshot.png"
local BigFrame = {
  ["1"] = "set:bedwar_headshotbox.json image:hsb_red_big",
  ["2"] = "set:bedwar_headshotbox.json image:hsb_blue_big",
  ["3"] = "set:bedwar_headshotbox.json image:hsb_green_big",
  ["4"] = "set:bedwar_headshotbox.json image:hsb_yellow_big"
}
local SmallFrame = {
  ["1"] = "set:bedwar_headshotbox.json image:hsb_red_small",
  ["2"] = "set:bedwar_headshotbox.json image:hsb_blue_small",
  ["3"] = "set:bedwar_headshotbox.json image:hsb_green_small",
  ["4"] = "set:bedwar_headshotbox.json image:hsb_yellow_small"
}
GUIHeadIcon = class("GUIHeadIcon", IGUIWindow)

function GUIHeadIcon:onLoad()
  self.uivHead = self:getChildWindowByName("BedWarHeadIcon-icon", GUIType.UrlImage)
  self.siFrame = self:getChildWindowByName("BedWarHeadIcon-frame", GUIType.StaticImage)
  self.siPet = self:getChildWindowByName("BedWarHeadIcon-pet", GUIType.StaticImage)
  self.siMask = self:getChildWindowByName("BedWarHeadIcon-mask", GUIType.StaticImage)
end

function GUIHeadIcon:initHeadIcon(userId, teamId, type)
  self.uivHead:setDefaultImage(DefaultIcon)
  local info = GameInfoManager:getPlayerInfo(userId)
  if info then
    self.uivHead:setUrl(info:getValue("picUrl"))
  else
    local user = UserManager.Instance():findUser(userId)
    if user then
      self.uivHead:setUrl(user.picUrl)
    end
  end
  if teamId == "0" then
    teamId = "1"
  end
  if type == "circle_big" then
    self.siFrame:SetImage(BigFrame[tostring(teamId)])
  elseif type == "circle_small" then
    self.siFrame:SetImage(SmallFrame[tostring(teamId)])
  elseif type == "square" then
    self.uivHead:setChildMaterial(0)
  end
end

function GUIHeadIcon:showMask(isMask)
  self.siMask:SetVisible(isMask)
end

function GUIHeadIcon:setUrlEnable(enabled)
  self.siMask:SetVisible(not enabled)
end

return GUIHeadIcon

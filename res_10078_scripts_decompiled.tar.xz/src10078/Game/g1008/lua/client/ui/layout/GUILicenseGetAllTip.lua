local UILicenseGetAllTip = class("UILicenseGetAllTip", IGUILayout)

function UILicenseGetAllTip:onLoad()
  self.llList = self:getChildWindow("BedWarLicenseGetAllTip-List", GUIType.Layout)
  self.gvList = IGUIGridView.new("BedWarLicenseGetAllTip-List-Grid", self.llList)
  self.gvList:setConfig(16, 20, 4)
  self.getAllListAdapt = UIHelper.newGameAdapter("LicenseGetAllTipAdapt")
  local With = self.gvList:getWidth()
  local High = self.gvList:getHeight()
  self.itemWith = (With - 48) / 4
  self.getAllListAdapt:setItemSize(self.itemWith, self.itemWith)
  self.gvList:setAdapter(self.getAllListAdapt)
  local btnClose = self:getChildWindow("BedWarLicenseGetAllTip-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local btnBack = self:getChildWindow("BedWarLicenseGetAllTip-Back", GUIType.Button)
  btnBack:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local stTitle = self:getChildWindow("BedWarLicenseGetAllTip-Title", GUIType.StaticText)
  stTitle:SetText(Lang:getString("gui_bed_war_license_get_all_title"))
  local stBtn = self:getChildWindow("BedWarLicenseGetAllTip-Back-Text", GUIType.StaticText)
  stBtn:SetText(Lang:getString("gui_bed_war_license_get_all_btn"))
end

function UILicenseGetAllTip:onShow(data)
  local rewards = {}
  for _, reward in pairs(data) do
    local rewardConfig = LicenseConfig:getRewardByLV(GUILicense.seasonDate, reward.Lv)
    if rewardConfig then
      local haveReward = false
      for _, rewardsItem in pairs(rewards) do
        if reward.rewardId == rewardsItem.rewardId then
          haveReward = rewardsItem
          break
        end
      end
      if haveReward then
        if reward.rewardType == "pay" then
          haveReward.Num = haveReward.Num + rewardConfig.PayNum
        elseif reward.rewardType == "free" then
          haveReward.Num = haveReward.Num + rewardConfig.FreeNum
        end
      else
        local temp = {}
        if reward.rewardType == "pay" then
          temp = {
            rewardId = reward.rewardId,
            Num = rewardConfig.PayNum
          }
        elseif reward.rewardType == "free" then
          temp = {
            rewardId = reward.rewardId,
            Num = rewardConfig.FreeNum
          }
        end
        table.insert(rewards, temp)
      end
    else
      local temp = {
        rewardId = reward.rewardId,
        Num = rewardConfig.PayNum
      }
      table.insert(rewards, temp)
    end
  end
  if #rewards < 4 then
    local width = #rewards * self.itemWith + 16 * #rewards - 1
    self.llList:SetArea({0, 0}, {-0.0315126, 0}, {0, width}, {
      0,
      self.itemWith
    })
  else
    self.llList:SetArea({0, 0}, {-0.0315126, 0}, {0.802395, 0}, {0.502101, 0})
  end
  self.getAllListAdapt:setData(rewards)
end

return UILicenseGetAllTip

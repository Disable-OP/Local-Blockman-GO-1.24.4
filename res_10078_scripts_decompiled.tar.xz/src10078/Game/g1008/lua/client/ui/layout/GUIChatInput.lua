local UIChatInput = class("UIChatInput", IGUILayout)

function UIChatInput:onLoad()
  self.etInput = self:getChildWindow("BedWarChatInput-input", GUIType.Edit)
  self.btnClose = self:getChildWindow("BedWarChatInput-close", GUIType.Button)
  self.btnSend = self:getChildWindow("BedWarChatInput-send", GUIType.Button)
  self.llChatRecord = self:getChildWindow("BedWarChatInput-record", GUIType.Layout)
  self.chatType = Define.MessageType.AllChat
  self:initRegister()
  self.etInput:SetMaxLength(40)
  self.btnSend:SetText(Lang:getString("gui_bedwar_send"))
  self:initChatList()
end

function UIChatInput:isShowAnim()
  return false
end

function UIChatInput:initRegister()
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    GUIBedWarToolBar.cbChat:SetChecked(false)
  end)
  self.btnSend:registerEvent(GUIEvent.ButtonClick, function()
    self:send()
  end)
end

function UIChatInput:send()
  local string = self.etInput:GetText()
  if string == nil or string == "" then
    GUIBedWarToolBar.cbChat:SetChecked(false)
    GUICommandList:hide()
    return
  end
  string = FilterWord.getReplaceContent(string)
  SoundUtil.playSound(SoundConfig.sendMessage)
  GamePacketSender:sendChatMessage(self.chatType, string)
  self.etInput:SetText("")
  GUIBedWarToolBar.cbChat:SetChecked(false)
  GUICommandList:hide()
end

function UIChatInput:onSendTypeChange(type)
  self.chatType = type
end

function UIChatInput:initChatList()
  if self.gvChatItems ~= nil then
    self.gvChatItems:destroy()
  end
  self.gvChatItems = IGUIGridView.new("BedWarChatRecordList", self.llChatRecord)
  self.gvChatItems:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvChatItems:setConfig(0, 0, 1)
  self.ContentSize = self.llChatRecord:GetPixelSize().x
  self.ScrollOffset = self.llChatRecord:GetPixelSize().y
end

function UIChatInput:addChatItem(sendId, text)
  local chatItem = UIHelper.newGameGUIWindow("GUIChatRecordItem", "BedWarChatRecordItem.json")
  chatItem:setWidth({
    0,
    self.ContentSize
  })
  local name
  local height = 0
  local teamId
  if sendId == 0 then
    height = chatItem:onGetSystemTip(text)
  else
    local info = BaseInfoManager:getPlayerInfo(sendId)
    if info then
      name = info:getValue("userName")
      teamId = info:getValue("teamId")
      if tostring(teamId) == "0" then
        height = chatItem:onGetChat("", name, text)
      else
        height = chatItem:onGetChat(TeamConfig:getTeamColor(teamId), name, text)
      end
    end
  end
  self.ScrollOffset = self.ScrollOffset - height
  if 0 > self.ScrollOffset then
    LuaTimer:schedule(function()
      self.gvChatItems.root:SetScrollOffset(self.ScrollOffset)
    end, 1)
  end
  chatItem:setHeight({0, height})
  BaseMessage:addChatRecord(name, text)
  self.gvChatItems:addItem(chatItem)
end

return UIChatInput

local UIBedWarLottery = class("GUIBedWarLottery", IGUILayout)

function UIBedWarLottery:onLoad()
  local llTabs = self:getChildWindow("BedWarLottery-Tabs", GUIType.Layout)
  self.lvTabs = IGUIListView.new("BedWarLottery-Tabs-List", llTabs)
  self.lvTabs:setArea({0, 4}, {0, 15}, {1, -8}, {1, -15})
  self.lvTabs:setItemSpace(8)
  local llMoney = self:getChildWindow("BedWarLottery-Money", GUIType.Layout)
  self.lvMoney = IGUIListView.new("BedWarLottery-Money-List", llMoney, nil, Orientation.Horizontal)
  self.lvMoney:setItemSpace(30)
  self.money = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
  self.money:onDataChanged({
    ItemId = 0,
    RealId = Define.Money.KEY
  })
  self.lvMoney:addItem(self.money)
  local llCardsList = self:getChildWindow("BedWarLottery-cards", GUIType.Layout)
  self.gvCardList = IGUIGridView.new("BedWarLottery-cards-List-Gird", llCardsList)
  self.gvCardList:setArea({0, 10}, {0, 60}, {1, 0}, {1, 0})
  self.gvCardList:setConfig(13, 8, 3)
  self.cardAdapter = UIHelper.newGameAdapter("LotteryCardAdapter")
  local itemWidth = (self.gvCardList:getWidth() - 45) / 3
  local itemHeight = (self.gvCardList:getHeight() - 80) / 2
  self.cardAdapter:setItemSize(itemWidth, itemHeight)
  self.gvCardList:setAdapter(self.cardAdapter)
  local btnClose = self:getChildWindow("BedWarLottery-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.closeLottery)
    self:hide()
  end)
  local btnCloseMask = self:getChildWindow("BedWarLottery-Close-Mask", GUIType.Button)
  btnCloseMask:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.closeLottery)
    self:hide()
  end)
  self.stRefreshPrice = self:getChildWindow("BedWarLottery-refresh_price", GUIType.StaticText)
  local btnRefresh = self:getChildWindow("BedWarLottery-refresh", GUIType.Button)
  btnRefresh:registerEvent(GUIEvent.ButtonClick, function()
    PayHelper.checkMoney(Define.Money.KEY, self.refreshPrice or 0, function(canBuy)
      if canBuy then
        SoundUtil.playSound(SoundConfig.refreshReward)
        GamePacketSender:sendBedWarLotteryRefresh()
      else
        CustomDialog.hide()
        GUIStore:show(StoreId.CubeStore, 8)
      end
    end)
  end)
  self.btnPrice = self:getChildWindow("BedWarLottery-lottery_bt", GUIType.Button)
  self.stLotteryPrice = self:getChildWindow("BedWarLottery-price", GUIType.StaticText)
  self.siKey = self:getChildWindow("BedWarLottery-key_icon", GUIType.StaticImage)
  self.btnPrice:registerEvent(GUIEvent.ButtonClick, function()
    self:onClickBuy()
  end)
  local btnDetails = self:getChildWindow("BedWarLottery-machine_bt", GUIType.Button)
  btnDetails:registerEvent(GUIEvent.ButtonClick, function()
    self:onClickMore()
  end)
  self:registerDataCallBack("ReplaceTip", function(data)
    self:onShowLotteryReplace(data)
  end, DataBuilderProcessor)
  self:registerDataCallBack("FreeRefresh", function()
    self:onCanFreeRefresh()
  end)
  self.cardData = {}
  self.canFreeRefresh = false
  self.llEffectMask = self:getChildWindow("BedWarLottery-effect_mask", GUIType.Layout)
  self.llEffect = self:getChildWindow("BedWarLottery-effect", GUIType.StaticImage)
  self.llEffectBg = self:getChildWindow("BedWarLottery-effect_bg", GUIType.StaticImage)
  self.llEffectItem = self:getChildWindow("BedWarLottery-item", GUIType.StaticImage)
  self.llEffectName = self:getChildWindow("BedWarLottery-item_name", GUIType.StaticText)
  self.llEffectNum = self:getChildWindow("BedWarLottery-item_num", GUIType.StaticText)
  self.llEffectBg:SetVisible(false)
  self.llEffectMask:SetVisible(false)
  self.llEffectMask:registerEvent(GUIEvent.Click, function()
    self:onClickEffectMask()
  end)
  self.btnProbability = self:getChildWindow("BedWarLottery-Probability", GUIType.Button)
  if Game:isChina() then
    self.btnProbability:SetVisible(true)
    self.btnProbability:registerEvent(GUIEvent.ButtonClick, function()
      ProbabilityDialog.show("g1008_2")
    end)
  else
    self.btnProbability:SetVisible(false)
  end
end

function UIBedWarLottery:onStart()
  self:initLanguage()
end

function UIBedWarLottery:initLanguage()
  self:getChildWindow("BedWarLottery-Title-Text1", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_lottery_title"))
  self:getChildWindow("BedWarLottery-explain", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_lottery_explain"))
  self:getChildWindow("BedWarLottery-machine_title", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_lottery_lick_detail"))
  self.btnPrice:SetText(Lang:getString("gui_bed_war_lottery_free"))
end

function UIBedWarLottery:onTick()
  self.money:onTick()
end

function UIBedWarLottery:close()
  self:hide()
end

function UIBedWarLottery:onGetReward(rewardId, price)
  for _, data in pairs(self.cardData) do
    if data.Id == rewardId then
      data.isGet = true
    end
  end
  self.cardAdapter:setData(self.cardData)
  if price == 0 then
    self.btnPrice:SetText(Lang:getString("gui_bed_war_lottery_free"))
    self.stLotteryPrice:SetVisible(false)
    self.siKey:SetVisible(false)
  else
    self.stLotteryPrice:SetVisible(true)
    self.siKey:SetVisible(true)
    self.stLotteryPrice:SetText("x" .. tostring(price))
    self.btnPrice:SetText("")
  end
  self.nowPrice = price
  if self.nowPrice == 0 then
    self.canFreeRefresh = true
  end
  local config = LotteryConfig.findRewardById(rewardId)
  self.llEffectMask:SetVisible(true)
  self.llEffectBg:SetVisible(false)
  self.llEffect:SetVisible(true)
  self.llEffect:SetEffectName("g1008_niudan_01.effect")
  self.llEffectItem:SetVisible(false)
  self.llEffectItem:SetImage(config.Image)
  self.llEffectName:SetText(Lang:getString(config.Name))
  self.llEffectNum:SetText("x" .. tostring(config.CountText))
  self.llEffectItem:SetArea({0, 0}, {0, -5}, {0, 8}, {0, 8})
  self.llEffectItem:SetAlpha(0)
  self.effectShowing = true
  self.lotterySoundId = SoundUtil.playSound(SoundConfig.startLottery)
  LuaTimer:cancel(self.key1)
  self.key1 = LuaTimer:schedule(function()
    if self.effectShowing == true then
      self.effectShowing = false
      self:onShowReward()
    end
  end, 2000)
end

function UIBedWarLottery:onGetRefreshResult(result, refreshPrice, lotteryPrice)
  if not result then
    return
  end
  self.canFreeRefresh = false
  local rewardIds = StringUtil.split(tostring(result), "#")
  self.cardData = {}
  for _, rewardId in pairs(rewardIds) do
    local config = LotteryConfig.findRewardById(rewardId)
    config.isGet = false
    table.insert(self.cardData, config)
  end
  self.cardAdapter:setData(self.cardData)
  self.stRefreshPrice:SetText("x" .. tostring(refreshPrice))
  if lotteryPrice == 0 then
    self.btnPrice:SetText(Lang:getString("gui_bed_war_lottery_free"))
    self.stLotteryPrice:SetVisible(false)
    self.siKey:SetVisible(false)
  else
    self.stLotteryPrice:SetVisible(true)
    self.siKey:SetVisible(true)
    self.stLotteryPrice:SetText("x" .. tostring(lotteryPrice))
    self.btnPrice:SetText("")
  end
  self.refreshPrice = refreshPrice
  self.nowPrice = lotteryPrice
end

function UIBedWarLottery:onClickBuy()
  if self.canFreeRefresh == true then
    SoundUtil.playSound(SoundConfig.refreshReward)
    GamePacketSender:sendBedWarLotteryRefresh()
    self.canFreeRefresh = false
    return
  end
  PayHelper.checkMoney(Define.Money.KEY, tonumber(self.nowPrice or 0), function(canBuy)
    if canBuy then
      SoundUtil.playSound(SoundConfig.clickLottery)
      GamePacketSender:sendBedWarLottery()
    else
      CustomDialog.hide()
      GUIStore:show(StoreId.CubeStore, 8)
    end
  end)
end

function UIBedWarLottery:onClickMore()
  SoundUtil.playSound(SoundConfig.showRewardDetail)
  GUILotteryDetailWindow:setLotteryInfo(LotteryConfig.rewards())
  GUILotteryDetailWindow:show()
end

function UIBedWarLottery:onShowLotteryReplace(data)
  local oldId = data:getNumberParam("oldId")
  local newId = data:getNumberParam("newId")
  LotteryReplaceContent:setGoodsInfo(oldId, newId)
  CustomDialog.builder().setContentView(LotteryReplaceContent).setTitleText("gui_dialog_tip_title_tip").setRightText("gui_dialog_tip_btn_sure").setRightClickListener(function()
    GamePacketSender:sendLotteryReplace(true)
  end).setLeftText("gui_dialog_tip_btn_cancel").setLeftClickListener(function()
    GamePacketSender:sendLotteryReplace(false)
  end).show()
end

function UIBedWarLottery:onClickEffectMask()
  if self.effectShowing == true then
    SoundUtil.stopSoundById(self.lotterySoundId)
    self.llEffect:SetVisible(false)
    self.llEffectBg:SetVisible(true)
    self.llEffectBg:SetEffectName("g1008_niudan_03.effect")
    self.effectShowing = false
    LuaTimer:cancel(self.key1)
    self:onShowReward()
  else
    self.llEffectMask:SetVisible(false)
    self.llEffectBg:SetVisible(false)
    LuaTimer:cancel(self.key1)
    LuaTimer:cancel(self.key2)
    LuaTimer:cancel(self.key3)
    LuaTimer:cancel(self.key4)
    GamePacketSender:sendLotteryEffectEnd()
  end
end

function UIBedWarLottery:onCanFreeRefresh()
  self.stRefreshPrice:SetText("x0")
  self.btnPrice:SetText(Lang:getString("gui_bed_war_refresh_free"))
  self.stLotteryPrice:SetVisible(false)
  self.siKey:SetVisible(false)
  self.canFreeRefresh = true
  self.refreshPrice = 0
end

function UIBedWarLottery:onShowReward()
  self.llEffectItem:SetVisible(true)
  local i = 0
  LuaTimer:cancel(self.key2)
  LuaTimer:cancel(self.key3)
  LuaTimer:cancel(self.key4)
  SoundUtil.playSound(SoundConfig.getLotteryReward)
  self.key2 = LuaTimer:scheduleTimer(function()
    i = i + 1
    self.llEffectItem:SetArea({0, 0}, {0, -5}, {
      0,
      8 + 6 * i
    }, {
      0,
      8 + 6 * i
    })
    self.llEffectItem:SetAlpha(0.05 * i)
  end, 25, 20)
  self.key3 = LuaTimer:schedule(function()
    local float = 0
    local offset = 0
    local dir = 1
    self.key4 = LuaTimer:scheduleTimer(function()
      float = float + 0.5
      if float % 10 == 0 then
        dir = -dir
      end
      offset = offset + dir * 1
      self.llEffectItem:SetArea({0, 0}, {
        0,
        -5 + offset
      }, {0, 128}, {0, 128})
    end, 50)
  end, 600)
end

return UIBedWarLottery

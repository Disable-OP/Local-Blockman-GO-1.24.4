local UIPersonalHomePageLayout = class("UIPersonalHomePageLayout", IGUILayout)
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
local pageRecord = {
  selfPage = {
    userId = 0,
    page = 1,
    isOpen = false
  },
  otherPlayerPage = {
    userId = 0,
    page = 1,
    isOpen = false
  }
}

function UIPersonalHomePageLayout:ctor(parent)
  self.super.ctor(self, "PersonalHomePage.json", parent)
end

function UIPersonalHomePageLayout:onLoad()
  self.llBg = self:getChildWindow("PersonalHomePage-Bg", GUIType.Layout)
  self.llInfo = self:getChildWindow("PersonalHomePage-Info", GUIType.Layout)
  self.llTabs = self:getChildWindow("PersonalHomePage-Tabs", GUIType.Layout)
  self.cbHome = self:getChildWindow("PersonalHomePage-Home", GUIType.CheckBox)
  self.cbBattleResults = self:getChildWindow("PersonalHomePage-Battle-Results", GUIType.CheckBox)
  self.cbSkin = self:getChildWindow("PersonalHomePage-Skin", GUIType.CheckBox)
  self.cbPersonality = self:getChildWindow("PersonalHomePage-Personality", GUIType.CheckBox)
  self:initView()
  self:initEvent()
  self.curUserIds = {}
end

function UIPersonalHomePageLayout:initView()
  local llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.bed_war.back.btn.txt", function()
    Events.ClosePersonalHomePageEvent:invoke()
  end)
  self.root:AddChildWindow(llReturn.root)
  self.cbHome:SetText(Lang:getString("gui.personal.home"))
  self.cbBattleResults:SetText(Lang:getString("gui.personal.battle.results"))
  self.cbSkin:SetText(Lang:getString("gui.personal.skin"))
  self.cbPersonality:SetText(Lang:getString("gui.personal.personality"))
  self.llTabs:SetVisible(false)
end

function UIPersonalHomePageLayout:initEvent()
  self:registerEvent(Events.ClosePersonalHomePageEvent, function()
    self:closePersonalHomePage()
  end)
  self.tapGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
  self.tapGroup:addCheckBox(self.cbHome, function(checked)
    if checked then
      self.cbHome:SetTextColor({
        0.15294117647058825,
        0.17647058823529413,
        0.3607843137254902,
        1
      })
      if self.playerInfo == nil then
        self.playerInfo = UIHelper.newGameGUIWindow("GUIPersonalHomePlayerInfo")
        self.llInfo:AddChildWindow(self.playerInfo.root)
      end
      self:onChangePage(1)
      self.playerInfo.root:SetVisible(true)
    else
      self.playerInfo.root:SetVisible(false)
      self.cbHome:SetTextColor({
        0.7843137254901961,
        0.8666666666666667,
        0.9490196078431372,
        1
      })
    end
  end)
  self.tapGroup:addCheckBox(self.cbBattleResults, function(checked)
    if checked then
      self:onChangePage(2)
      self.cbBattleResults:SetTextColor({
        0.15294117647058825,
        0.17647058823529413,
        0.3607843137254902,
        1
      })
    else
      self.cbBattleResults:SetTextColor({
        0.7843137254901961,
        0.8666666666666667,
        0.9490196078431372,
        1
      })
    end
  end)
  self.tapGroup:addCheckBox(self.cbSkin, function(checked)
    if checked then
      self:onChangePage(3)
      self.cbSkin:SetTextColor({
        0.15294117647058825,
        0.17647058823529413,
        0.3607843137254902,
        1
      })
    else
      self.cbSkin:SetTextColor({
        0.7843137254901961,
        0.8666666666666667,
        0.9490196078431372,
        1
      })
    end
  end)
  self.tapGroup:addCheckBox(self.cbPersonality, function(checked)
    if checked then
      self:onChangePage(4)
      self.cbPersonality:SetTextColor({
        0.15294117647058825,
        0.17647058823529413,
        0.3607843137254902,
        1
      })
    else
      self.cbPersonality:SetTextColor({
        0.7843137254901961,
        0.8666666666666667,
        0.9490196078431372,
        1
      })
    end
  end)
end

function UIPersonalHomePageLayout:openPersonalHomePageByUserId(userId)
  local info = {
    userId = userId,
    curPage = 1,
    isOpen = true
  }
  if userId == Game:getPlatformUserId() then
    pageRecord.selfPage = info
  else
    pageRecord.otherPlayerPage = info
    WebService:UploadVisitorInfo(Game:getPlatformUserId(), userId)
  end
  self:updatePersonalPageInfo(info)
  self:show()
end

function UIPersonalHomePageLayout:closePersonalHomePage(closeAll)
  closeAll = closeAll or false
  if pageRecord.otherPlayerPage and pageRecord.otherPlayerPage.isOpen == true then
    pageRecord.otherPlayerPage = {
      userId = 0,
      page = 1,
      isOpen = false
    }
    if pageRecord.selfPage.isOpen and not closeAll then
      self:updatePersonalPageInfo(pageRecord.selfPage)
    else
      self:hide()
    end
  else
    pageRecord.selfPage.isOpen = false
    self:hide()
  end
end

function UIPersonalHomePageLayout:onChangePage(pageId)
  if pageRecord.otherPlayerPage and pageRecord.otherPlayerPage.isOpen == true then
    pageRecord.otherPlayerPage.page = pageId
  else
    pageRecord.selfPage.page = pageId
  end
end

function UIPersonalHomePageLayout:updatePersonalPageInfo(pageInfo)
  local function flashPage(code, data)
    self.playerInfo:setShowPlayerUserId(pageInfo.userId)
  end
  
  PlayerCustomInfoUtil:getPlayerAllCustomInfo(pageInfo.userId, flashPage)
  self.tapGroup:selectIndex(pageInfo.curPage)
end

function UIPersonalHomePageLayout:onShow()
  if pageRecord.otherPlayerPage.userId == 0 then
    self:openPersonalHomePageByUserId(Game:getPlatformUserId())
  end
end

return UIPersonalHomePageLayout

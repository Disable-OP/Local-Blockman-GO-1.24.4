local UILicenseSeasonTask = class("UILicenseSeasonTask", IGUILayout)

function UILicenseSeasonTask:onLoad()
  local close = self:getChildWindow("BedWarLicenseSeasonTask-Close", GUIType.Button)
  close:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
    GUILicense:show(2)
  end)
  self.stLevel = self:getChildWindow("BedWarLicenseSeasonTask-Level-Text", GUIType.StaticText)
  self.pbLevelProgress = self:getChildWindow("BedWarLicenseSeasonTask-Progress-bar", GUIType.ProgressBar)
  self.stLevelProgress = self:getChildWindow("BedWarLicenseSeasonTask-Progress-Text", GUIType.StaticText)
  self.stChallengeText = self:getChildWindow("BedWarLicenseSeasonTask-Chellenge-Text", GUIType.StaticText)
  local llTaskList = self:getChildWindow("BedWarLicenseSeasonTask-List", GUIType.Layout)
  self.lvTaskList = IGUIListView.new("BedWarLicenseSeasonTask-Season-Task-List-Grid", llTaskList, nil, Orientation.Horizontal)
  self.lvTaskList:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.lvTaskList:setItemSpace(38)
  self.taskListAdapt = UIHelper.newGameAdapter("LicenseSeasonTaskAdapt")
  local taskParentWith = self.lvTaskList:getWidth()
  local taskParentHigh = self.lvTaskList:getHeight()
  local itemWidth = (taskParentWith - 76) / 3.5
  self.taskListAdapt:setItemSize(itemWidth, taskParentHigh)
  self.lvTaskList:setAdapter(self.taskListAdapt)
  local llMoney = self:getChildWindow("BedWarLicenseSeasonTask-Money", GUIType.Layout)
  self.lvMoney = IGUIListView.new("BedWarLicenseSeasonTask-Money-List", llMoney, nil, Orientation.Horizontal)
  self.lvMoney:setItemSpace(30)
  self.llHorn = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
  self.llHorn:onDataChanged({
    ItemId = 0,
    RealId = Define.Money.HORN
  })
  self.lvMoney:addItem(self.llHorn)
  self.llDiamond = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
  self.llDiamond:onDataChanged({
    ItemId = 0,
    RealId = Define.Money.DIAMOND
  })
  self.lvMoney:addItem(self.llDiamond)
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(GUILicense.seasonDate)
  local stTitle = self:getChildWindow("BedWarLicenseSeasonTask-Season-Task", GUIType.StaticText)
  local stTitle2 = self:getChildWindow("BedWarLicenseSeasonTask-Season-Task2", GUIType.StaticText)
  self.stLicenseText1 = self:getChildWindow("BedWarLicenseSeasonTask-Season-Text1", GUIType.StaticText)
  self.stLicenseText2 = self:getChildWindow("BedWarLicenseSeasonTask-Season-Text2", GUIType.StaticText)
  stTitle:SetText(Lang:getString("gui_bed_war_license_title"))
  stTitle2:SetText(Lang:getString("gui_bed_war_license_title"))
  if seasonConfig then
    local text = Lang:getString("gui_bed_war_license_title") .. "/"
    stTitle:SetText(text)
    stTitle2:SetText(text)
    local width = stTitle:GetTextWidth()
    stTitle:SetWidth({0, width})
    stTitle2:SetWidth({0, width})
    self.stLicenseText1:SetText(Lang:getString(seasonConfig.SeasonLang))
    self.stLicenseText2:SetText(Lang:getString(seasonConfig.SeasonLang))
  end
end

function UILicenseSeasonTask:onShow()
  self.taskList = GUILicense.seasonTaskList
  self.lvTaskList:clearItems()
  self.taskListAdapt:setData(self.taskList)
end

function UILicenseSeasonTask:updateData()
  self.taskList = GUILicense.seasonTaskList
  self.taskListAdapt:setData(self.taskList)
  local taskNum = 0
  local finishNum = 0
  for _, task in pairs(self.taskList) do
    local taskConfig = TaskConfig:getTaskById(task.taskId)
    if taskConfig then
      if taskConfig.NextTaskId == 0 and task.status == 4 then
        finishNum = finishNum + 1
      end
      taskNum = taskNum + 1
    end
  end
  local text = "\226\150\162FFF4EA54" .. finishNum .. "\226\150\162FFFFFFFF/" .. taskNum
  GUILicense.stTaskChallengeNum:SetText(text)
  self.stChallengeText:SetText(Lang:getString("gui_bed_war_license_season_task_chellenge") .. ": " .. text)
end

function UILicenseSeasonTask:onTick()
  self.llDiamond:onTick()
  self.llHorn:onTick()
end

function UILicenseSeasonTask:showRedPoint()
  for _, task in pairs(self.taskList) do
    if task.status == 3 or task.status == 4 then
      local taskConfig = TaskConfig:getTaskById(task.taskId)
      if taskConfig and taskConfig.NextTaskId ~= 0 then
        GUILicense.siRedPoint:SetVisible(true)
        return
      end
    end
  end
  GUILicense.siRedPoint:SetVisible(false)
  return
end

return UILicenseSeasonTask

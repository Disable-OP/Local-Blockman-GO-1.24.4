local GUIBlockDetailContent = class("GUIBlockDetailContent", IGUILayout)

function GUIBlockDetailContent:onLoad()
  self.ivContent = self:getChildWindow("BlockDetailContent-Content", GUIType.StaticImage)
  self.ivImage = self:getChildWindow("BlockDetailContent-Image", GUIType.StaticImage)
end

BlockDetailContent = buildCustomDialogContent(GUIBlockDetailContent, "BlockDetailContent.json")

function BlockDetailContent:setGoodsInfo(image)
  self.ivImage:SetImage(image)
end

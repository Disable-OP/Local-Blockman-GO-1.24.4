local UILicenseBigPrice = class("UILicenseBigPrice", IGUILayout)

function UILicenseBigPrice:onLoad()
  self.stTitle = self:getChildWindow("BedWarLicenseBigPrice-Title", GUIType.StaticText)
  self.stPriceTitle = self:getChildWindow("BedWarLicenseBigPrice-Price-Title-Text", GUIType.StaticText)
  self.btnLuxuryBuy = self:getChildWindow("BedWarLicenseBigPrice-Luxury-Buy", GUIType.Button)
  self.btnCommonBuy = self:getChildWindow("BedWarLicenseBigPrice-Buy", GUIType.Button)
  local llPriceList = self:getChildWindow("BedWarLicenseBigPrice-Price-List-Layout", GUIType.Layout)
  self.gvPriceList = IGUIGridView.new("BedWarLicenseBigPrice-Price-List-Layout-Items", llPriceList)
  self.gvPriceList:setConfig(32, 18, 7)
  self.ListAdapt = UIHelper.newGameAdapter("LicenseBigPriceAdapt")
  local ParentWith = self.gvPriceList:getWidth()
  local itemWith = (ParentWith - 192) / 7
  self.ListAdapt:setItemSize(itemWith, itemWith)
  self.gvPriceList:setAdapter(self.ListAdapt)
  local btnClose = self:getChildWindow("BedWarLicenseBigPrice-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local stTitle = self:getChildWindow("BedWarLicenseBigPrice-Title", GUIType.StaticText)
  stTitle:SetText(Lang:getString("gui_license_big_price_title"))
  local stPriceTitle = self:getChildWindow("BedWarLicenseBigPrice-Price-Title-Text", GUIType.StaticText)
  stPriceTitle:SetText(Lang:getString("gui_license-big_price_price_title"))
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(GUILicense.seasonDate)
  if not seasonConfig then
    return
  end
  local stLuxuryText = self:getChildWindow("BedWarLicenseBigPrice-Luxury-Text", GUIType.StaticText)
  stLuxuryText:SetText(Lang:getString(seasonConfig.Luxury_Info))
  local stCommonText = self:getChildWindow("BedWarLicenseBigPrice-Buy-Text", GUIType.StaticText)
  stCommonText:SetText(Lang:getString(seasonConfig.License_Info))
  self.btnLuxuryBuy:SetText(seasonConfig.LuxuryPrice)
  self.btnLuxuryBuy:registerEvent(GUIEvent.ButtonClick, function()
    if GUILicense.hadBuy == 0 then
      local Interval = GUILicense:calculateLevelInterval(GUILicense.playerLevel)
      local playerInterval = ReportUtil.getPlayerLevelInterval()
      if BaseMain:getGameType() == "g1046" then
        GameAnalytics:design(1, {
          "H_License_ClickBuy",
          "Luxury",
          playerInterval,
          Interval
        })
      else
        GameAnalytics:design(1, {
          "G_License_ClickBuy",
          "Luxury",
          playerInterval,
          Interval
        })
      end
      if GUILicense.seasonDate ~= -1 then
        PayHelper.checkMoney(MoneyType.Diamonds, seasonConfig.LuxuryPrice, function(isSuccess)
          if isSuccess then
            GamePacketSender:sendBedWarLicenseBuyLicense(GUILicense.seasonDate, 2)
          else
            self.isCardOpen = true
          end
        end)
        self:hide()
      end
    end
  end)
  self.btnCommonBuy:SetText(seasonConfig.LicensePrice)
  self.btnCommonBuy:registerEvent(GUIEvent.ButtonClick, function()
    if GUILicense.hadBuy == 0 then
      local Interval = GUILicense:calculateLevelInterval(GUILicense.playerLevel)
      local playerInterval = ReportUtil.getPlayerLevelInterval()
      if BaseMain:getGameType() == "g1046" then
        GameAnalytics:design(1, {
          "H_License_ClickBuy",
          "common",
          playerInterval,
          Interval
        })
      else
        GameAnalytics:design(1, {
          "G_License_ClickBuy",
          "common",
          playerInterval,
          Interval
        })
      end
      if GUILicense.seasonDate ~= -1 then
        PayHelper.checkMoney(MoneyType.Diamonds, seasonConfig.LicensePrice, function(isSuccess)
          if isSuccess then
            GamePacketSender:sendBedWarLicenseBuyLicense(GUILicense.seasonDate, 1)
          else
            self.isCardOpen = true
          end
        end)
      end
      self:hide()
    end
  end)
end

function UILicenseBigPrice:onShow()
  local rewardConfig = LicenseConfig:getGrandPriceConfigBySeason(GUILicense.seasonDate, 2)
  self.ListAdapt:setData(rewardConfig)
end

function UILicenseGrandPriceDisplay:onLongClick(index, rewardType, describe)
  self.gvDescribe:setVisible(true)
  local curFreeOffset = self.lvFreeList.root:GetScrollOffset()
  local curPayOffset = self.lvPayList.root:GetScrollOffset()
  local height = self.lvFreeList:getHeight()
  if rewardType == 2 then
    self.gvDescribe:onDataChange(describe)
    local area = self.llPayList:GetArea()
    local describeX = index * height + 94 - height + (index - 1) * 28 + curPayOffset
    self.gvDescribe.root:SetXPosition({0, describeX})
    self.gvDescribe.root:SetYPosition({
      area.min.y[1],
      -self.gvDescribe.root:GetPixelSize().y
    })
  else
    self.gvDescribe:onDataChange(describe)
    local area = self.llFreeList:GetArea()
    local describeX = index * height + 94 - height + (index - 1) * 28 + curFreeOffset
    self.gvDescribe.root:SetXPosition({0, describeX})
    self.gvDescribe.root:SetYPosition({
      area.min.y[1],
      -self.gvDescribe.root:GetPixelSize().y
    })
  end
end

function UILicenseGrandPriceDisplay:onLongClickEnd()
  self.gvDescribe:setVisible(false)
end

return UILicenseBigPrice

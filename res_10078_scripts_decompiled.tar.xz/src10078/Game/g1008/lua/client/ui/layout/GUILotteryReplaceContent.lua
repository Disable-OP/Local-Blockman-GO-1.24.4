local GUILotteryReplaceContent = class("GUILotteryReplaceContent", IGUILayout)

function GUILotteryReplaceContent:onLoad()
  self.llOld = self:getChildWindow("LotteryReplaceContent-old", GUIType.Layout)
  self.llNew = self:getChildWindow("LotteryReplaceContent-new", GUIType.Layout)
  self.tvPriceText = self:getChildWindow("LotteryReplaceContent-tip", GUIType.StaticText)
  self.oldItem = UIHelper.newGameGUIWindow("GUILotteryDetailItem", "BedWarLotteryDetailItem.json")
  self.newItem = UIHelper.newGameGUIWindow("GUILotteryDetailItem", "BedWarLotteryDetailItem.json")
  self.llOld:AddChildWindow(self.oldItem.root)
  self.llNew:AddChildWindow(self.newItem.root)
end

function GUILotteryReplaceContent:onStart()
  self.tvPriceText:SetText(Lang:getString("lottery_reward_replace"))
end

LotteryReplaceContent = buildCustomDialogContent(GUILotteryReplaceContent, "LotteryReplaceContent.json")

function LotteryReplaceContent:setGoodsInfo(oldItemId, newItemId)
  self.oldItem:onDataChanged(LotteryConfig.findRewardByRewardId(oldItemId))
  self.newItem:onDataChanged(LotteryConfig.findRewardByRewardId(newItemId))
end

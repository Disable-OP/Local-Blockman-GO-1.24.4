local UILicenseRewardBuy = class("UILicenseRewardBuy", IGUILayout)

function UILicenseRewardBuy:onLoad()
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(GUILicense.seasonDate)
  local btnBuy = self:getChildWindow("BedWarLicenseBuy-Buy", GUIType.Button)
  btnBuy:registerEvent(GUIEvent.ButtonClick, function()
    if GUILicense.hadBuy == 0 then
      local Interval = GUILicense:calculateLevelInterval(GUILicense.playerLevel)
      local playerInterval = ReportUtil.getPlayerLevelInterval()
      if BaseMain:getGameType() == "g1046" then
        GameAnalytics:design(1, {
          "H_License_ClickBuy",
          "common",
          playerInterval,
          Interval
        })
      else
        GameAnalytics:design(1, {
          "G_License_ClickBuy",
          "common",
          playerInterval,
          Interval
        })
      end
      if GUILicense.seasonDate ~= -1 then
        PayHelper.checkMoney(MoneyType.Diamonds, seasonConfig.LicensePrice, function(isSuccess)
          if isSuccess then
            GamePacketSender:sendBedWarLicenseBuyLicense(GUILicense.seasonDate, 1)
          else
            self.isCardOpen = true
          end
        end)
      end
      self:hide()
    end
  end)
  local btnBuyLuxury = self:getChildWindow("BedWarLicenseBuy-Buy-Luxury", GUIType.Button)
  btnBuyLuxury:registerEvent(GUIEvent.ButtonClick, function()
    if GUILicense.hadBuy == 0 then
      local Interval = GUILicense:calculateLevelInterval(GUILicense.playerLevel)
      local playerInterval = ReportUtil.getPlayerLevelInterval()
      if BaseMain:getGameType() == "g1046" then
        GameAnalytics:design(1, {
          "H_License_ClickBuy",
          "Luxury",
          playerInterval,
          Interval
        })
      else
        GameAnalytics:design(1, {
          "G_License_ClickBuy",
          "Luxury",
          playerInterval,
          Interval
        })
      end
      if GUILicense.seasonDate ~= -1 then
        PayHelper.checkMoney(MoneyType.Diamonds, seasonConfig.LuxuryPrice, function(isSuccess)
          if isSuccess then
            GamePacketSender:sendBedWarLicenseBuyLicense(GUILicense.seasonDate, 2)
          else
            self.isCardOpen = true
          end
        end)
        self:hide()
      end
    end
  end)
  local btnClose = self:getChildWindow("BedWarLicenseBuy-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  self.stBuy = self:getChildWindow("BedWarLicenseBuy-Buy-Text", GUIType.StaticText)
  self.stBuyLuxury = self:getChildWindow("BedWarLicenseBuy-Buy-Luxury-Text", GUIType.StaticText)
  self.stName1 = self:getChildWindow("BedWarLicenseBuy-name1", GUIType.StaticText)
  self.stInfo1 = self:getChildWindow("BedWarLicenseBuy-info1", GUIType.StaticText)
  self.stName2 = self:getChildWindow("BedWarLicenseBuy-name2", GUIType.StaticText)
  self.stInfo2 = self:getChildWindow("BedWarLicenseBuy-info2", GUIType.StaticText)
  self.llShowList = self:getChildWindow("BedWarLicenseBuy-show", GUIType.Layout)
  self.lvShowItemList = IGUIListView.new("BedWarLicenseBuy-show-Price-List", self.llShowList, nil, Orientation.Horizontal)
  self.lvShowItemList:setItemSpace(20)
  local itemWight = self.lvShowItemList:getHeight()
  self.showItemAdapt = require("ui..adapter.LicenseRewardShowItemAdapt").new()
  self.showItemAdapt:setItemSize(itemWight, itemWight)
  self.lvShowItemList:setAdapter(self.showItemAdapt)
  self.lvShowItemList.offset = 0
  self.awPet = self:getChildWindow("BedWarLicenseBuy-pet_actor", GUIType.ActorWindow)
  local llSlideBlock = self:getChildWindow("BedWarLicenseBuy-pet_touch")
  llSlideBlock:registerEvent(GUIEvent.TouchDown, function(events)
    self.awPet:TouchDown(events.position)
  end)
  llSlideBlock:registerEvent(GUIEvent.TouchMove, function(events)
    self.awPet:TouchMove(events.position)
  end)
  self.lvShowItemList.root:registerEvent(GUIEvent.ScrollMoveStart, function(events)
    self.isBeScroll = true
  end)
  self.lvShowItemList.root:registerEvent(GUIEvent.ScrollMoveChange, function(events)
    local scroll = events.offset
    local x = self.lvShowItemList:getHeight() + 20
    if 10 < scroll then
      local last = table.remove(self.payPriceConfig, #self.payPriceConfig)
      table.insert(self.payPriceConfig, 1, last)
      self.showItemAdapt:setData(self.payPriceConfig)
      scroll = scroll - x
      self.lvShowItemList.root:SetScrollOffset(scroll)
    end
  end)
  self.lvShowItemList.root:registerEvent(GUIEvent.ScrollMoveEnd, function(events)
    self.isBeScroll = false
  end)
  self.lvShowItemList.root:registerEvent(GUIEvent.ScrollCardClick, function(events)
    self.isBeScroll = false
  end)
  self.needShowRewardDisplay = false
  self.needShowDescribe = false
end

function UILicenseRewardBuy:onStart()
  self:initLanguage()
end

function UILicenseRewardBuy:initLanguage()
  self:getChildWindow("BedWarLicenseBuy-tip1", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_license_buy_tip_title"))
  self:getChildWindow("BedWarLicenseBuy-tip2", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_license_buy_tip_title"))
  self:getChildWindow("BedWarLicenseBuy-introduce1", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_license_buy_tip_introduce"))
  self:getChildWindow("BedWarLicenseBuy-introduce2", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_license_buy_tip_introduce"))
  self:getChildWindow("BedWarLicenseBuy-mark_text", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_license_buy_tip_recommend"))
end

function UILicenseRewardBuy:isShowAnim()
  return false
end

function UILicenseRewardBuy:onShow(source)
  if GUILicense.siRewardDisplayImage:IsVisible() == true then
    GUILicense.siRewardDisplayActor:SetActor1("", "")
    GUILicense.siRewardDisplayImage:SetVisible(false)
    LuaTimer:cancel(GUILicense.rewardDisplaySkillKey)
    GUILicense.awRewardActor:SetVisible(false)
    self.needShowRewardDisplay = true
  elseif GUILicense.awRewardActor:IsVisible() == true then
    GUILicense.awRewardActor:SetVisible(false)
    self.needShowDescribe = true
  end
  local Interval = GUILicense:calculateLevelInterval(GUILicense.playerLevel)
  local playerInterval = ReportUtil.getPlayerLevelInterval()
  if source then
    if BaseMain:getGameType() == "g1046" then
      GameAnalytics:design(1, {
        "H_License_ClickGuide",
        source,
        playerInterval,
        Interval
      })
    else
      GameAnalytics:design(1, {
        "G_License_ClickGuide",
        source,
        playerInterval,
        Interval
      })
    end
  end
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(GUILicense.seasonDate)
  self.stBuy:SetText(Lang:getString(seasonConfig.LicensePrice))
  self.stBuyLuxury:SetText(Lang:getString(seasonConfig.LuxuryPrice))
  self.stName1:SetText(Lang:getString(seasonConfig.License_Name))
  self.stInfo1:SetText(Lang:getString(seasonConfig.License_Info))
  self.stName2:SetText(Lang:getString(seasonConfig.Luxury_Name))
  self.stInfo2:SetText(Lang:getString(seasonConfig.Luxury_Info))
  self.awPet:SetArea({
    0,
    seasonConfig.PetOffsetX1
  }, {
    0,
    seasonConfig.PetOffsetY1
  }, {
    0,
    seasonConfig.PetSize1
  }, {0, 1})
  LuaTimer:cancel(self.actorSkillKey)
  self.awPet:SetActor1(seasonConfig.PetActorName, seasonConfig.PetSkillName)
  local skillTime = self.awPet:GetActor():GetSkillTimeLength(seasonConfig.PetSkillName)
  self.actorSkillKey = LuaTimer:scheduleTimer(function()
    local curRotate = self.awPet:GetRotateY()
    self.awPet:SetActor1(seasonConfig.PetActorName, "idle", curRotate)
    self.awPet:SetActor1(seasonConfig.PetActorName, seasonConfig.PetSkillName, curRotate)
  end, skillTime)
  self:getChildWindow("BedWarLicenseBuy-pet_price_num", GUIType.StaticText):SetText(seasonConfig.PetValue)
  self:getChildWindow("BedWarLicenseBuy-pet_text", GUIType.StaticText):SetText(Lang:getString(seasonConfig.PetName))
  self.payPriceConfig = LicenseConfig:getGrandPriceConfigBySeason(GUILicense.seasonDate, 2)
  self.listScroll = (self.lvShowItemList:getHeight() + 20) * #self.payPriceConfig - self.lvShowItemList:getWidth()
  self.showItemAdapt:setData(self.payPriceConfig)
  self.isRight = true
  self.lvShowItemList.root:GetChildByIndex(0):removeAllEvents()
  self.lvShowItemList.root:GetChildByIndex(0):registerEvent(GUIEvent.TouchUp, function(events)
    self.isBeScroll = false
  end)
end

function UILicenseRewardBuy:onHide()
  LuaTimer:cancel(self.actorSkillKey)
  self.awPet:SetActor1("", "")
  if self.needShowRewardDisplay == true then
    GUILicense:onShow(1)
    GUILicense.siRewardDisplayImage:SetVisible(true)
    self.needShowRewardDisplay = false
  elseif self.needShowDescribe == true then
    GUILicense.awRewardActor:SetVisible(true)
    self.needShowDescribe = false
  end
end

function UILicenseRewardBuy:onTick()
  local scroll = self.lvShowItemList.root:GetScrollOffset()
  local x = self.lvShowItemList:getHeight() + 20
  while x < -scroll do
    local first = table.remove(self.payPriceConfig, 1)
    table.insert(self.payPriceConfig, first)
    self.showItemAdapt:setData(self.payPriceConfig)
    scroll = scroll + x
    self.lvShowItemList.root:SetScrollOffset(scroll)
  end
  if not self.isBeScroll then
    self.lvShowItemList.root:SetScrollOffset(scroll - 2)
  end
end

return UILicenseRewardBuy

local UIInput = class("UIInput", IGUILayout)

function UIInput:onLoad()
  self.stTitle = self:getChildWindow("BedWarInputView-Title", GUIType.StaticText)
  self.btnClose = self:getChildWindow("BedWarInputView-Close", GUIType.Button)
  self.btnConfirm = self:getChildWindow("BedWarInputView-Confirm", GUIType.Button)
  self.etInput = self:getChildWindow("BedWarInputView-Input", GUIType.Edit)
  self:initRegister()
end

function UIInput:initRegister()
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.clickUI()
    GUIInput:hide()
    if self.cancelFun then
      self.cancelFun()
    end
  end)
  self.btnConfirm:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.clickUI()
    GUIInput:hide()
    if self.confirmFun then
      self.confirmFun(self.etInput:GetText())
    end
  end)
end

function UIInput:onShow(data)
  self.stTitle:SetText(Lang:getString(data.title or "gui_input_title"))
  self.btnConfirm:SetText(Lang:getString(data.btnText or "gui_input_confirm"))
  self.etInput:SetText(data.defaultText or "")
  self.confirmFun = false
  self.cancelFun = false
  if data.confirmFun and type(data.confirmFun) == "function" then
    self.confirmFun = data.confirmFun
  end
  if data.cancelFun and type(data.cancelFun) == "function" then
    self.cancelFun = data.cancelFun
  end
end

return UIInput

local ActivityTab = class("ActivityTab")

function ActivityTab:ctor(tab, tab_nor, tab_pre, red_point)
  self.tab = tab
  self.tab_nor = tab_nor
  self.tab_pre = tab_pre
  self.red_point = red_point
  self.tab_nor:SetVisible(false)
  self.tab_pre:SetVisible(false)
  self.red_point:SetVisible(false)
end

function ActivityTab:setTabText(text)
  self.tab_nor:GetChildByIndex(1):SetText(text)
  self.tab_pre:GetChildByIndex(0):SetText(text)
end

function ActivityTab:check(checked)
  self.tab_nor:SetVisible(not checked)
  self.tab_pre:SetVisible(checked)
end

function ActivityTab:redHint(show)
  self.red_point:SetVisible(show)
end

ActivityType = {
  FirstRecharge = 1,
  TiroSignIn = 2,
  SuperPlayer = 3,
  FreeGift = 4
}
local UIActivity = class("UIActivity", IGUILayout)

function UIActivity:onLoad()
  self.tabs = {}
  self.panels = {}
  self.curType = ActivityType.FreeGift
  self:getChildWindow("BedWarActivity-Title"):SetText(Lang:getString("bed.war.activity.title"))
  self:getChildWindow("BedWarActivity-Continue"):registerEvent(GUIEvent.Click, function()
    SoundUtil.clickUI()
    self:hide()
  end)
  local texts = {
    "activity.tab.txt.1",
    "activity.tab.txt.2",
    "activity.tab.txt.3",
    "activity.tab.txt.4"
  }
  for type = 1, 4 do
    local tab = self:getChildWindow(string.format("BedWarActivity-Tab-%d", type))
    local tab_nor = self:getChildWindow(string.format("BedWarActivity-Tab-Nor-%d", type))
    local tab_pre = self:getChildWindow(string.format("BedWarActivity-Tab-Pre-%d", type))
    local red_point = self:getChildWindow(string.format("BedWarActivity-Tab-Red-Point-%d", type))
    self.tabs[type] = ActivityTab.new(tab, tab_nor, tab_pre, red_point)
    self.tabs[type]:setTabText(Lang:getString(texts[type]))
    tab_nor:registerEvent(GUIEvent.TouchUp, function()
      SoundUtil.clickUI()
      self:onTabChange(type)
    end)
  end
  local panels = self:getChildWindow("BedWarActivity-Panels")
  GUIFirstRecharge = UIHelper.newGameGUILayout("GUIFirstRecharge", "BedWarFirstRecharge.json", panels)
  GUITiroSignIn = UIHelper.newGameGUILayout("GUITiroSignIn", "BedWarTiroSignIn.json", panels)
  GUISuperPlayer = UIHelper.newGameGUILayout("GUISuperPlayer", "BedWarSuperPlayer.json", panels)
  GUIFreeGift = UIHelper.newGameGUILayout("GUIFreeGift", "BedWarFreeGift.json", panels)
  self.panels[ActivityType.FirstRecharge] = GUIFirstRecharge
  self.panels[ActivityType.TiroSignIn] = GUITiroSignIn
  self.panels[ActivityType.SuperPlayer] = GUISuperPlayer
  self.panels[ActivityType.FreeGift] = GUIFreeGift
  for _, panel in pairs(self.panels) do
    panel:hide()
  end
  self.tabs[ActivityType.FirstRecharge].tab:SetVisible(false)
  self:onTabChange(ActivityType.TiroSignIn)
  self:initEvent()
end

function UIActivity:initEvent()
  local btnClose = self:getChildWindow("BedWarActivity-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.clickUI()
    self:hide()
  end)
  self:registerDataCallBack("FirstRecharge", function(data)
    self:onUpdateFirstRechargeData(data)
  end, DataBuilderProcessor)
  self:registerEvent(Events.UpdateActivityRedPointEvent, function(type, visible)
    for tab_type, tab in pairs(self.tabs) do
      if tab_type == type then
        tab:redHint(visible)
        break
      end
    end
  end)
end

function UIActivity:onShow(params)
  if type(params) == "string" and 0 < #params then
    local type = tonumber(params)
    self:onTabChange(type)
  else
    self:selectCurPanel()
  end
end

function UIActivity:onTabChange(type)
  if self.curType == type then
    return
  end
  self.curType = type
  for type, tab in pairs(self.tabs) do
    tab:check(type == self.curType)
  end
  self:selectCurPanel()
end

function UIActivity:selectCurPanel()
  for type, panel in pairs(self.panels) do
    if type == self.curType then
      panel:show()
    else
      panel:hide()
    end
  end
end

function UIActivity:onUpdateFirstRechargeData(data)
  local showUI = data:getBoolParam("showUI")
  local canReceive = data:getBoolParam("canReceive")
  local i = 0
  if showUI and canReceive then
    self.tabs[ActivityType.FirstRecharge].tab:SetVisible(true)
  else
    self.tabs[ActivityType.FirstRecharge].tab:SetVisible(false)
  end
  self:updateTabYPos()
  if self.curType == ActivityType.FirstRecharge then
    self:onTabChange(ActivityType.TiroSignIn)
  end
  GUIFirstRecharge:setCanReceive(canReceive)
end

function UIActivity:hideSuperPlayer()
  self.tabs[ActivityType.SuperPlayer].tab:SetVisible(false)
  self:updateTabYPos()
  if self.curType == ActivityType.SuperPlayer then
    self:onTabChange(ActivityType.TiroSignIn)
  end
end

function UIActivity:updateTabYPos()
  local visibleCount = 0
  for _, tab in pairs(self.tabs) do
    if tab.tab:IsVisible() then
      tab.tab:SetYPosition({
        0.151079 * visibleCount,
        0
      })
      visibleCount = visibleCount + 1
    end
  end
end

return UIActivity

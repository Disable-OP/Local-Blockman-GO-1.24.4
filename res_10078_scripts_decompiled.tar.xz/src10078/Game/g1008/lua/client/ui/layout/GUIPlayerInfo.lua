local effectUIs = {}
local potionIdMap = {
  1,
  8,
  14
}
local effectIcons = {
  ["1"] = "set:bed_war_player_info.json image:effect_move_speed",
  ["8"] = "set:bed_war_player_info.json image:effect_jump",
  ["14"] = "set:bed_war_player_info.json image:effect-invisibility"
}
local SingingIcon = {
  "set:bed_war_player_info.json image:img_0_icon_camouflage_double",
  "set:bed_war_player_info.json image:img_0_icon_wither",
  "set:bed_war_player_info.json image:img_0_icon_ender_dragon",
  "set:bed_war_player_info.json image:img_0_icon_paragliders"
}

local function hideEngineWindow(name)
  local window = GUIManager:getWindowByName(name)
  if not window then
    return
  end
  window:SetXPosition({0, 6000})
  window:SetVisible(false)
end

local function setTouchable(window, touchable)
  window:SetTouchable(touchable)
  local count = window:GetChildCount()
  if count == 0 then
    return
  end
  for index = 1, count do
    setTouchable(window:GetChildByIndex(index - 1), touchable)
  end
end

local function getActivePotionEffects()
  local potionMap = {}
  for _, potionId in pairs(potionIdMap) do
    local potionEffect = PlayerManager:getClientPlayer().Player:getActivePotionEffectById(potionId)
    if potionEffect then
      table.insert(potionMap, potionEffect)
    end
  end
  return potionMap
end

local UIPlayerInfo = class("GUIPlayerInfo", IGUILayout)

function UIPlayerInfo:onLoad()
  setTouchable(GUIManager:getPlayerInfo(), false)
  self:setEngineUI()
  self.llSinging = self:getChildWindow("BedWarPlayerInfo-Singing", GUIType.Layout)
  self.siSingingIcon = self:getChildWindow("BedWarPlayerInfo-Singing-Icon", GUIType.StaticImage)
  self.pbSingingValue = self:getChildWindow("BedWarPlayerInfo-Singing-Value", GUIType.ProgressBar)
  self.siArmorBg = self:getChildWindow("BedWarPlayerInfo-Armor-Bg", GUIType.StaticImage)
  self.stArmorText = self:getChildWindow("BedWarPlayerInfo-Armor-Text", GUIType.StaticText)
  self.siAppleBg = self:getChildWindow("BedWarPlayerInfo-Apple-Bg", GUIType.StaticImage)
  self.stAppleText = self:getChildWindow("BedWarPlayerInfo-Apple-Text", GUIType.StaticText)
  self.llBuff = self:getChildWindow("BedWarPlayerInfo-Buff", GUIType.Layout)
  self.llMain = self:getChildWindow("BedWarPlayerInfo-Main-Layout", GUIType.Layout)
  self.oldPositionX = self.siArmorBg:GetXPosition()
end

function UIPlayerInfo:setEngineUI()
  hideEngineWindow("PlayerInfo-Armor")
  hideEngineWindow("PlayerInfo-FoodSaturation")
  hideEngineWindow("PlayerInfo-Effect-Layout")
  local llHealth = GUIManager:getWindowByName("PlayerInfo-Health", GUIType.Layout)
  llHealth:SetArea({0, -135}, {0, -164}, {0, 240}, {0, 26})
  local ivHealthIcon = GUIManager:getWindowByName("PlayerInfo-Health-Icon", GUIType.StaticImage)
  ivHealthIcon:SetVerticalAlignment(VerticalAlignment.Center)
  ivHealthIcon:SetArea({0, 0}, {0, 0}, {0, 32}, {0, 32})
  ivHealthIcon:SetImage("set:bed_war_player_info.json image:ic_health")
  self.pbHealthValue = GUIManager:getWindowByName("PlayerInfo-Health-Value", GUIType.ProgressBar)
  self.pbHealthValue:SetArea({0, 35}, {0, 0}, {1, -35}, {0, 22})
  self.pbHealthValue:SetBackImage("set:bed_war_player_info.json image:info_bg")
  self.pbHealthValue:SetProgressImage("set:bed_war_player_info.json image:health_value")
  self.pbHealthValue:SetProperty("StretchOffset", "15 15 0 0")
  self.tvHealthText = GUIManager:getWindowByName("PlayerInfo-Health-Number", GUIType.StaticText)
  self.tvHealthText:SetArea({0, 25}, {0, 0.5}, {1, -25}, {0, 12})
  self.tvHealthText:SetFont(GUIFontManager:Instance():GetFont("YSB16"))
  self.llApple = GUIManager:getWindowByName("PlayerInfo-Apple", GUIType.Layout)
  self.llApple:SetArea({0, -135}, {1, -130}, {0, 240}, {0, 22})
  local ivAppleIcon = GUIManager:getWindowByName("PlayerInfo-Apple-Icon", GUIType.StaticImage)
  ivAppleIcon:SetVerticalAlignment(VerticalAlignment.Bottom)
  ivAppleIcon:SetArea({0, 2}, {0, 0}, {0, 28}, {0, 32})
  ivAppleIcon:SetImage("set:bed_war_player_info.json image:ic_apple")
  local pbAppleValue = GUIManager:getWindowByName("PlayerInfo-Apple-Value", GUIType.ProgressBar)
  pbAppleValue:SetArea({0, 35}, {0, 0}, {1, -35}, {0, 22})
  pbAppleValue:SetBackImage("set:bed_war_player_info.json image:value_bg")
  pbAppleValue:SetProgressImage("set:bed_war_player_info.json image:apple_value")
  pbAppleValue:SetProperty("StretchOffset", "15 15 0 0")
  self.tvAppleText = GUIManager:getWindowByName("PlayerInfo-Apple-Number", GUIType.StaticText)
  self.tvAppleText:SetArea({0, 25}, {0, 0.5}, {1, -25}, {0, 12})
  self.tvAppleText:SetFont(GUIFontManager:Instance():GetFont("YSB16"))
end

local fullSingingTime = 1
local singingTime = 0

function UIPlayerInfo:breakSinging()
  singingTime = 0
end

function UIPlayerInfo:startSinging(time)
  fullSingingTime = time
  singingTime = time
  self:onTick(0)
end

function UIPlayerInfo:setSingingIcon(index)
  self.siSingingIcon:SetImage(SingingIcon[index])
end

function UIPlayerInfo:onTick(frameTime)
  local armor = Game:getPlayer():getTotalArmorValue()
  self.siArmorBg:SetVisible(0 < armor)
  self.stArmorText:SetText(math.floor(armor))
  if self.llApple:IsVisible() then
    self.siAppleBg:SetVisible(true)
    self.siArmorBg:SetXPosition(self.oldPositionX)
  else
    self.siAppleBg:SetVisible(false)
    self.siArmorBg:SetXPosition(self.siAppleBg:GetXPosition())
  end
  self.stAppleText:SetText(self.tvAppleText:GetText())
  self:updateEffectsUI()
  singingTime = singingTime - frameTime
  if 0 < fullSingingTime and 0 < singingTime then
    self.llSinging:SetVisible(true)
    self.pbSingingValue:SetProgress(singingTime / fullSingingTime)
  else
    self.llSinging:SetVisible(false)
  end
end

function UIPlayerInfo:updateEffectsUI()
  local potionMap = getActivePotionEffects()
  local buffMap = BuffInfo.Buffs
  for _, window in pairs(effectUIs) do
    window:SetVisible(false)
  end
  for index, potionEffect in pairs(potionMap) do
    self:updateEffectUI(index, effectIcons[tostring(potionEffect:getPotionID())], potionEffect:getDuration() / 20)
  end
  local potionMapIndex = #potionMap
  for index, buff in pairs(buffMap) do
    local buffDuration = buff.endTime - os.time()
    if buffDuration < 0 then
      buffDuration = 0
    end
    self:updateEffectUI(index + potionMapIndex, buff.image, buffDuration)
  end
  return potionMap
end

function UIPlayerInfo:updateEffectUI(index, image, duration)
  local iconWidth = 39
  
  local function newWindow(xPosition, yPosition)
    local effectIcon = GUIManager:createGUIWindow(GUIType.StaticImage, "BedWarPlayerInfo-Effect-" .. GUIManager:applyWindowId())
    effectIcon:SetArea({0, xPosition}, {0, yPosition}, {0, iconWidth}, {0, iconWidth})
    effectIcon:SetVerticalAlignment(VerticalAlignment.Bottom)
    self.llBuff:AddChildWindow(effectIcon)
    local effectTime = GUIManager:createGUIWindow(GUIType.StaticText, "BedWarPlayerInfo-Effect-Time-" .. GUIManager:applyWindowId())
    effectTime:SetArea({0, -2}, {0, -2}, {0, 0}, {0, 0})
    effectTime:SetFont(GUIFontManager:Instance():GetFont("HT12"))
    effectTime:SetTextHorzAlign(HorizontalAlignment.Right)
    effectTime:SetTextVertAlign(VerticalAlignment.Bottom)
    effectTime:SetHorizontalAlignment(HorizontalAlignment.Right)
    effectTime:SetVerticalAlignment(VerticalAlignment.Bottom)
    effectTime:SetTextBoader(Color.BLACK)
    effectIcon:AddChildWindow(effectTime)
    table.insert(effectUIs, effectIcon)
    return effectIcon
  end
  
  local window = effectUIs[index]
  local rowCount = 2
  if not window then
    local xPosition = (iconWidth + 1) * math.floor((index - 1) % rowCount)
    local yPosition = (iconWidth + 1) * math.floor((index - 1) / rowCount) * -1
    window = newWindow(xPosition, yPosition)
  end
  window:SetImage(image)
  window:GetChildByIndex(0):SetText(math.floor(duration))
  window:SetVisible(true)
end

function UIPlayerInfo:setPropPacketVisible(visible)
  local stShowName = GUIManager:getWindowByName("RootGuiLayout-Item-Name")
  local llHealth = GUIManager:getWindowByName("PlayerInfo-Health", GUIType.Layout)
  if visible then
    self.llMain:SetYPosition({0, -164})
    llHealth:SetYPosition({0, -164})
    stShowName:SetYPosition({1, -225})
  else
    self.llMain:SetYPosition({0, -95})
    llHealth:SetYPosition({0, -95})
    stShowName:SetYPosition({1, -160})
  end
end

return UIPlayerInfo

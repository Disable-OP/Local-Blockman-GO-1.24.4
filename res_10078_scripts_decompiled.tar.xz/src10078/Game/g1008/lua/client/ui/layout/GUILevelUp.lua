local function getLevelUpReward(level)
  local rewards = {}
  
  local yaoshi, dress_id_list, dress_num_list, rune_id_list, rune_num_list, box_id, box_num = ExpConfig:getLevelReward(level)
  if dress_id_list and dress_num_list and #dress_id_list == #dress_num_list then
    for i = 1, #dress_id_list do
      local item = {}
      item.img = ExpConfig:getLevelDressImg(i, level) or ""
      item.num = dress_num_list[i]
      table.insert(rewards, item)
    end
  end
  if 0 < yaoshi then
    local yaoshi_item = {}
    yaoshi_item.img = "set:bedwar_settlement_single.json image:key_icon"
    yaoshi_item.num = yaoshi
    table.insert(rewards, yaoshi_item)
  end
  if rune_id_list and rune_num_list and #rune_id_list == #rune_num_list then
    for i = 1, #rune_id_list do
      local item = {}
      item.img = ExpConfig:getLevelRuneImg(i, level) or ""
      item.num = rune_num_list[i]
      table.insert(rewards, item)
    end
  end
  if 0 < box_id and 0 < box_num then
    local box_item = {}
    box_item.img = ExpConfig:getLevelBoxImg(level)
    box_item.num = box_num
    table.insert(rewards, box_item)
  end
  return rewards
end

local UILevelUp = class("UILevelUp", IGUILayout)

function UILevelUp:onLoad()
  local btnClose = self:getChildWindow("BedWarLevelUp-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local btnConfirm = self:getChildWindow("BedWarLevelUp-Confirm", GUIType.Button)
  btnConfirm:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  self.llRewards = self:getChildWindow("BedWarLevelUp-Rewards")
  self.llRewards:CleanupChildren()
  self.lvRewards = IGUIListView.new("BedWarLevelUp-Rewards-List", self.llRewards, nil, Orientation.Horizontal)
  self.lvRewards:setItemSpace(20)
  self:registerDataCallBack("LevelUpData", function(data)
    self:showLevelUpReward(data)
  end, DataBuilderProcessor)
end

function UILevelUp:onStart()
  self:initLanguage()
end

function UILevelUp:initLanguage()
  local btnConfirm = self:getChildWindow("BedWarLevelUp-Confirm", GUIType.Button)
  btnConfirm:SetText(Lang:getString("gui_dialog_tip_btn_sure"))
  local tvTitle1 = self:getChildWindow("BedWarLevelUp-Title-Text1", GUIType.StaticText)
  local tvTitle2 = self:getChildWindow("BedWarLevelUp-Title-Text2", GUIType.StaticText)
  local tvTitle3 = self:getChildWindow("BedWarLevelUp-Title-Text3", GUIType.StaticText)
  tvTitle1:SetText(Lang:getString("gui_bed_war_lvup_theme"))
  tvTitle2:SetText(Lang:getString("gui_bed_war_lvup_theme"))
  tvTitle3:SetText(Lang:getString("gui_bed_war_lvup_theme"))
  self.isSetLang = true
end

function UILevelUp:showLevelUpReward(data)
  if GUIGMControlPanel then
    GUIGMControlPanel:hide()
  end
  local oldLv = data:getNumberParam("oldLv")
  local newLv = data:getNumberParam("newLv")
  local tvOldLv = self:getChildWindow("BedWarLevelUp-Old-Lv", GUIType.StaticText)
  local tvNewLv = self:getChildWindow("BedWarLevelUp-New-Lv", GUIType.StaticText)
  tvOldLv:SetText(string.format("Lv.%d", oldLv))
  tvNewLv:SetText(string.format("Lv.%d", newLv))
  self.lvRewards:clearItems()
  local rewards = getLevelUpReward(newLv)
  local width = math.min(110 * #rewards - 20, self.llRewards:GetPixelSize().x)
  self.lvRewards:setItemSpace(20)
  self.lvRewards:setArea({
    0,
    (self.llRewards:GetPixelSize().x - width) / 2
  }, {0, 0}, {0, width}, {1, 0})
  for _, reward in pairs(rewards) do
    local item = UIHelper.newGameGUIWindow("GUILevelUpReward", "BedWarLevelUpReward.json")
    item:onDataChanged(reward)
    self.lvRewards:addItem(item)
  end
  LuaTimer:schedule(function()
    self:show()
  end, 300)
end

return UILevelUp

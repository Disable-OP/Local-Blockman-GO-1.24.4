require("ui..window.GUILicenseGrandPriceItem")
require("ui..window.GUILicenseDescribe")
local UILicenseGrandPriceDisplay = class("UILicenseGrandPriceDisplay", IGUILayout)

function UILicenseGrandPriceDisplay:onLoad()
  local stTitle = self:getChildWindow("LicenseGrandPrise-Title", GUIType.StaticText)
  stTitle:SetText(Lang:getString("gui_bed_war_license_grand_price_title"))
  local llContent = self:getChildWindow("LicenseGrandPrise-Content", GUIType.Layout)
  self.gvDescribe = UIHelper.newGameGUIWindow("GUILicenseDescribe", "BedWarLicenseGrandDescribe.json")
  self.gvDescribe:setVisible(false)
  llContent:AddChildWindow(self.gvDescribe.root)
  local close = self:getChildWindow("LicenseGrandPrise-Close", GUIType.Button)
  close:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local closeMask = self:getChildWindow("LicenseGrandPrise-Close-Mask", GUIType.Button)
  closeMask:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  self.llFreeList = self:getChildWindow("LicenseGrandPrise-Free-Price-List", GUIType.Layout)
  self.lvFreeList = IGUIListView.new("LicenseGrandPrise-Free-Price-List-list", self.llFreeList, nil, Orientation.Horizontal)
  self.lvFreeList:setItemSpace(28)
  local freeWight = self.lvFreeList:getHeight()
  self.freePriceAdapt = require("ui..adapter.LicenseDisplayAdapt").new()
  self.freePriceAdapt:setItemSize(freeWight, freeWight)
  self.lvFreeList:setAdapter(self.freePriceAdapt)
  self.lvFreeList.offset = 0
  self.lvFreeList.root:registerEvent(GUIEvent.ScrollMoveChange, function(event)
    if self.lvFreeList.offset == event.offset then
      return
    end
    self.lvFreeList.offset = event.offset
    self:onLongClickEnd()
  end)
  self.llPayList = self:getChildWindow("LicenseGrandPrise-Pay-Price-List", GUIType.Layout)
  self.lvPayList = IGUIListView.new("LicenseGrandPrise-Pay-Price-List-list", self.llPayList, nil, Orientation.Horizontal)
  self.lvPayList:setItemSpace(28)
  local payWight = self.lvPayList:getHeight()
  self.payPriceAdapt = require("ui..adapter.LicenseDisplayAdapt").new()
  self.payPriceAdapt:setItemSize(payWight, payWight)
  self.lvPayList:setAdapter(self.payPriceAdapt)
  self.lvPayList.offset = 0
  self.lvPayList.root:registerEvent(GUIEvent.ScrollMoveChange, function(event)
    if self.lvPayList.offset == event.offset then
      return
    end
    self.lvPayList.offset = event.offset
    self:onLongClickEnd()
  end)
  self.btnBuy = self:getChildWindow("LicenseGrandPrise-Buy", GUIType.Button)
  self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
    GUILicenseRewardBuy:show("PreviewPage")
  end)
  self.btnBuy:SetText(Lang:getString("gui_bed_war_license_display_btn"))
  local stFreeTitle = self:getChildWindow("LicenseGrandPrise-Free-Price-text", GUIType.StaticText)
  stFreeTitle:SetText(Lang:getString("gui_bed_war_license_display_free_title"))
  local stPayTitle = self:getChildWindow("LicenseGrandPrise-Pay-Price-Text", GUIType.StaticText)
  stPayTitle:SetText(Lang:getString("gui_bed_war_license_display_pay_title"))
  local btnDescribeHide = self:getChildWindow("LicenseGrandPrise-Describe-hide", GUIType.Button)
  btnDescribeHide:registerEvent(GUIEvent.ButtonClick, function()
    self:onLongClickEnd()
  end)
end

function UILicenseGrandPriceDisplay:onShow()
  if GUILicense.hadBuy > 0 then
    self.btnBuy:SetVisible(false)
  end
end

function UILicenseGrandPriceDisplay:setItemData(season)
  local freePriceConfigs = LicenseConfig:getGrandPriceConfigBySeason(season, 1)
  local payPriceConfig = LicenseConfig:getGrandPriceConfigBySeason(season, 2)
  self.freePriceAdapt:setData(freePriceConfigs)
  self.payPriceAdapt:setData(payPriceConfig)
end

function UILicenseGrandPriceDisplay:onLongClick(index, rewardType, describe)
  self.gvDescribe:setVisible(true)
  local curFreeOffset = self.lvFreeList.root:GetScrollOffset()
  local curPayOffset = self.lvPayList.root:GetScrollOffset()
  local height = self.lvFreeList:getHeight()
  if rewardType == 2 then
    self.gvDescribe:onDataChange(describe)
    local area = self.llPayList:GetArea()
    local describeX = index * height + 94 - height + (index - 1) * 28 + curPayOffset
    self.gvDescribe.root:SetXPosition({0, describeX})
    self.gvDescribe.root:SetYPosition({
      area.min.y[1],
      -self.gvDescribe.root:GetPixelSize().y
    })
  else
    self.gvDescribe:onDataChange(describe)
    local area = self.llFreeList:GetArea()
    local describeX = index * height + 94 - height + (index - 1) * 28 + curFreeOffset
    self.gvDescribe.root:SetXPosition({0, describeX})
    self.gvDescribe.root:SetYPosition({
      area.min.y[1],
      -self.gvDescribe.root:GetPixelSize().y
    })
  end
end

function UILicenseGrandPriceDisplay:onLongClickEnd()
  self.gvDescribe:setVisible(false)
end

return UILicenseGrandPriceDisplay

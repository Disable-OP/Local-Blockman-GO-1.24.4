local UIBoxLottery = class("UIBoxLottery", IGUILayout)

function UIBoxLottery:onLoad()
  self.hasCheckNum = {
    ["1"] = 0,
    ["2"] = 0,
    ["3"] = 0
  }
  self.HasNum = 0
  self.curIntegral = 0
  self.Lv1Num = 0
  self.IntegralNum = 0
  self.needIntegral = 230
  self.isHaveAd = false
  self.btnClose = self:getChildWindow("BoxLottery-Close", GUIType.Button)
  self.btnIntegralBox = self:getChildWindow("BoxLottery-Integral-Open", GUIType.Button)
  self.btnOpenBox = self:getChildWindow("BoxLottery-Box-Lv1-BoxLotteryItem-Open", GUIType.Button)
  self.btnOpenBoxTen = self:getChildWindow("BoxLottery-Box-Lv1-BoxLotteryItem-Open-Ten", GUIType.Button)
  self.btnLV1Question = self:getChildWindow("BoxLottery-Box-Lv1-BoxLotteryItem-Question", GUIType.Button)
  self.btnIntegralBoxQuestion = self:getChildWindow("BoxLottery-Integral-Box-Question", GUIType.Button)
  self.btnWatchAd = self:getChildWindow("BoxLottery-Box-Lv1-BoxLotteryItem-Video-Ad", GUIType.Button)
  self.btnWatchAd:SetText(Lang:getString("bed.war.free.box.lottery"))
  self.btnWatchAd:SetVisible(false)
  self.layIntegral = self:getChildWindow("BoxLottery-Integral", GUIType.Layout)
  self.pgIntegralProgress = self:getChildWindow("BoxLottery-Integral-Progress", GUIType.ProgressBar)
  self.stProgressText = self:getChildWindow("BoxLottery-Integral-Progress-Text", GUIType.StaticText)
  self.stLv1Text = self:getChildWindow("BoxLottery-Box-Lv1-BoxLotteryItem-Integral-Text", GUIType.StaticText)
  self.stOneOpenText = self:getChildWindow("BoxLottery-One-Open-Text", GUIType.StaticText)
  self.stTenOpenText = self:getChildWindow("BoxLottery-Ten-Open-Text", GUIType.StaticText)
  self.siKeyIcon = self:getChildWindow("BoxLottery-Box-Lv1-BoxLotteryItem-Key-Icon", GUIType.StaticImage)
  self.siKeyIconTen = self:getChildWindow("BoxLottery-Box-Lv1-BoxLotteryItem-Key-Icon-Ten", GUIType.StaticImage)
  self.btnOpenBox:SetText(Lang:getString("gui_bed_war_license_exchange_btn_one"))
  self.btnOpenBoxTen:SetText(Lang:getString("gui_bed_war_license_exchange_btn_ten"))
  self.IntegralBox = GUIBoxLotteryConfig:findLotteryBoxById(Define.BoxType.ULTIMATE_BOX)
  self.actIntegralActor = self:getChildWindow("BoxLottery-Integral-Actor", GUIType.ActorWindow)
  self.actIntegralActor:SetActor1(self.IntegralBox.Actor, "idle", 0)
  self.actIntegralActor:UseBodyPart(self.IntegralBox.ActorBody, self.IntegralBox.ActorBodyId)
  self.actIntegralActor:PlaySkill("idle")
  self.actIntegralActor:SetVisible(true)
  self.Lv1Box = GUIBoxLotteryConfig:findLotteryBoxById(Define.BoxType.BRONZE_BOX)
  self.stLv1Text:SetText(self.Lv1Box.AddIntegral)
  self.actLv1Box = self:getChildWindow("BoxLottery-Box-Lv1-BoxLotteryItem-Actor", GUIType.ActorWindow)
  self.actLv1Box:SetActor1(self.Lv1Box.Actor, "idle", 0)
  self.actLv1Box:SetVisible(true)
  self.btnProbability = self:getChildWindow("BoxLottery-Probability", GUIType.Button)
  if Game:isChina() then
    self.btnProbability:SetVisible(true)
    self.btnProbability:registerEvent(GUIEvent.ButtonClick, function()
      ProbabilityDialog.show("g1008_1")
    end)
  else
    self.btnProbability:SetVisible(false)
  end
  self:updateLanguage()
  self:register()
end

function UIBoxLottery:register()
  self:registerDataCallBack("BoxLotteryData", function(data)
    for _, v in pairs(data) do
      self.hasCheckNum[tostring(v.Id)] = v.HasNum
      if tonumber(v.Id) == 1 then
        self.Lv1Num = v.HasNum
      elseif tonumber(v.Id) == 2 then
        self.IntegralNum = v.HasNum
      elseif tonumber(v.Id) > 2 then
        Events.OpenLotteryBoxEvent:invoke(v.Id, v.HasNum)
      end
      self:setLotteryConfig()
    end
  end, JsonBuilderProcessor)
  self:registerDataCallBack("ShowBoxLottery", function(data)
    local isOpen = data:getBoolParam("isOpen")
    self.curIntegral = data:getNumberParam("curIntegral")
    self.needIntegral = data:getNumberParam("needIntegral")
    self:setLotteryConfig()
    if isOpen then
      GUIBoxLottery:show()
    end
  end, DataBuilderProcessor)
  self:registerDataCallBack("BoxLotteryAd", function(data)
    local isShowAd = data:getBoolParam("isShowAd")
    local isOpenBox = data:getBoolParam("isOpenBox")
    self.isHaveAd = isShowAd
    if isOpenBox then
      Events.OpenLotteryBoxEvent:invoke(Define.BoxType.BRONZE_BOX)
    end
    self:checkAdUI()
  end, DataBuilderProcessor)
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundType.ClosePanel)
    RootGuiLayout.Instance():showMainControl()
  end)
  self.btnIntegralBox:registerEvent(GUIEvent.ButtonClick, function()
    if self.IntegralBox ~= nil then
      if self.IntegralNum == 0 and self.pgIntegralProgress:GetProgress() < 1 then
        return false
      end
      SoundUtil.playSound(SoundType.Click)
      Events.OpenLotteryBoxEvent:invoke(Define.BoxType.ULTIMATE_BOX)
    end
  end)
  self.btnIntegralBoxQuestion:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundType.Click)
    GUIBoxDetail:showDetail(Define.BoxType.ULTIMATE_BOX)
  end)
  self.btnLV1Question:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundType.Click)
    GUIBoxDetail:showDetail(Define.BoxType.BRONZE_BOX)
  end)
  self.btnOpenBox:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundType.Click)
    Events.OpenLotteryBoxEvent:invoke(Define.BoxType.BRONZE_BOX)
  end)
  self.btnOpenBoxTen:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundType.Click)
    Events.OpenLotteryBoxEvent:invoke(Define.BoxType.BRONZE_BOX, 10)
  end)
  self.btnWatchAd:registerEvent(GUIEvent.ButtonClick, function()
    ClientHelper.onWatchAd(104601)
  end)
end

function UIBoxLottery:onShow()
  self:checkAdUI()
end

function UIBoxLottery:checkAdUI()
  local showAd = ClientHelper.getBoolPrefs("ShowVideoAd") and not isBeta
  self.btnWatchAd:SetVisible(showAd and self.isHaveAd)
  if self.btnWatchAd:IsVisible() then
    ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ADS_PLACEMENT, "104601")
  end
end

function UIBoxLottery:setOpenNum(key)
end

function UIBoxLottery:updateLanguage()
  self:getChildWindow("BoxLottery-Title-Text", GUIType.StaticText):SetText(Lang:getString("gui.chest.lottery.title"))
  self:getChildWindow("BoxLottery-Open-Hint-Text", GUIType.StaticText):SetText(Lang:getString("gui.chest.lottery.hint"))
end

function UIBoxLottery:setLotteryConfig()
  if self.needIntegral == 0 then
    self.layIntegral:SetVisible(false)
    return
  end
  if 0 < self.Lv1Num then
    self.actLv1Box:PlaySkill("active")
  else
    self.actLv1Box:PlaySkill("idle")
  end
  if 0 >= self.Lv1Num then
    self.btnOpenBox:SetNormalImage("set:dress.json image:btn_orange")
    self.btnOpenBox:SetPushedImage("set:dress.json image:btn_orange")
    self.siKeyIcon:SetVisible(true)
    self.stOneOpenText:SetText(self.Lv1Box.NeedKey)
    self.stOneOpenText:SetXPosition({0.5, 0})
  else
    self.btnOpenBox:SetNormalImage("set:dress.json image:btn_green")
    self.btnOpenBox:SetPushedImage("set:dress.json image:btn_green")
    self.siKeyIcon:SetVisible(false)
    self.stOneOpenText:SetText(string.format("%s(%d)", Lang:getString("bed.war.free.box.lottery"), self.Lv1Num))
    self.stOneOpenText:SetXPosition({0, 0})
  end
  if self.Lv1Num <= 10 then
    self.btnOpenBoxTen:SetNormalImage("set:dress.json image:btn_orange")
    self.btnOpenBoxTen:SetPushedImage("set:dress.json image:btn_orange")
    self.siKeyIconTen:SetVisible(true)
    self.stTenOpenText:SetText(self.Lv1Box.NeedKey * 10)
    self.stTenOpenText:SetXPosition({0.5, 0})
  else
    self.btnOpenBoxTen:SetNormalImage("set:dress.json image:btn_green")
    self.btnOpenBoxTen:SetPushedImage("set:dress.json image:btn_green")
    self.siKeyIconTen:SetVisible(false)
    self.stTenOpenText:SetText(string.format("%s(%d)", Lang:getString("bed.war.free.box.lottery"), math.floor(self.Lv1Num / 10)))
    self.stTenOpenText:SetXPosition({0, 0})
  end
  self.layIntegral:SetVisible(true)
  self.pgIntegralProgress:SetProgress(self.curIntegral / self.needIntegral)
  if self.IntegralBox ~= nil then
    if 0 < self.IntegralNum then
      self.stProgressText:SetText(string.format("%d/%d(%d)", self.curIntegral, self.needIntegral, self.IntegralNum))
      self.actIntegralActor:PlaySkill("active")
    else
      self.stProgressText:SetText(string.format("%d/%d", self.curIntegral, self.needIntegral))
      if self.curIntegral / self.needIntegral >= 1 then
        self.actIntegralActor:PlaySkill("active")
      else
        self.actIntegralActor:PlaySkill("idle")
      end
    end
  else
    self.stProgressText:SetText(string.format("%d/%d", self.curIntegral, self.needIntegral))
    self.actIntegralActor:PlaySkill("idle")
  end
end

return UIBoxLottery

require("common.config.TaskConfig")
local UIChallengeTask = class("GUIChallengeTask", IGUILayout)

function UIChallengeTask:onLoad()
  local llRoot = self:getChildWindow("ChallengeTask", GUIType.Layout)
  local size = llRoot:GetPixelSize()
  local llWindow = self:getChildWindow("ChallengeTask-window", GUIType.Layout)
  local width = math.min(1060, size.x)
  llWindow:SetWidth({0, width})
  self.stRewardName = self:getChildWindow("ChallengeTask-reward_name", GUIType.StaticText)
  self.stProgressCount1 = self:getChildWindow("ChallengeTask-progress_count", GUIType.StaticText)
  self.stProgressCount2 = self:getChildWindow("ChallengeTask-progress_count_accept", GUIType.StaticText)
  self.stEndTip = self:getChildWindow("ChallengeTask-tip_end", GUIType.StaticText)
  self.stEndTipAccept = self:getChildWindow("ChallengeTask-tip_end_accept", GUIType.StaticText)
  self.siProgressBg = self:getChildWindow("ChallengeTask-progress_bg", GUIType.StaticImage)
  self.siProgressAcceptBg = self:getChildWindow("ChallengeTask-progress_bg_accept", GUIType.StaticImage)
  self.siGift = self:getChildWindow("ChallengeTask-gift", GUIType.StaticImage)
  self.siGiftEffect = self:getChildWindow("ChallengeTask-gift_effect", GUIType.StaticImage)
  local btnClose = self:getChildWindow("ChallengeTask-close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local siMask = self:getChildWindow("ChallengeTask-mask", GUIType.StaticImage)
  siMask:registerEvent(GUIEvent.Click, function()
    self:hide()
  end)
  local btnBack = self:getChildWindow("ChallengeTask-back", GUIType.Button)
  btnBack:SetText(Lang:getString("gui_bed_war_hall_all_challenge"))
  btnBack:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
    GUITreasureChallenge:show(false)
  end)
  local btnGiveUp = self:getChildWindow("ChallengeTask-bt_giveup", GUIType.Button)
  btnGiveUp:SetText(Lang:getString("gui_bed_war_hall_give_up"))
  btnGiveUp:registerEvent(GUIEvent.ButtonClick, function()
    self:onGiveUp()
  end)
  self.btnStartChallenge = self:getChildWindow("ChallengeTask-start_challenge_accept", GUIType.Button)
  self.btnStartChallenge:SetText(Lang:getString("gui_bed_war_hall_start_challenge"))
  self.btnStartChallenge:registerEvent(GUIEvent.ButtonClick, function()
    self:onStartChallenge()
  end)
  self.btnAdButton = self:getChildWindow("ChallengeTask-ad_button", GUIType.Button)
  self.btnAdButton:registerEvent(GUIEvent.ButtonClick, function()
    self:onClickAdButton()
  end)
  self.pbProgress = self:getChildWindow("ChallengeTask-progress", GUIType.ProgressBar)
  self.siRewardIcon = self:getChildWindow("ChallengeTask-reward_icon", GUIType.StaticImage)
  self.siRewardSmallIconBg = self:getChildWindow("ChallengeTask-reward_icon_bg", GUIType.StaticImage)
  self.siRewardSmallIcon = self:getChildWindow("ChallengeTask-reward_small_icon", GUIType.StaticImage)
  self.amwRewardModel = self:getChildWindow("ChallengeTask-reward_model", GUIType.ActorWindow)
  local taskList = self:getChildWindow("ChallengeTask-task_list", GUIType.Layout)
  self.gvTaskList = IGUIGridView.new("ChallengeTask-List", taskList)
  self.gvTaskList:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvTaskList:setConfig(0, 14, 1)
  self.taskAdapter = UIHelper.newGameAdapter("ChallengeTaskAdapter")
  local itemWidth = self.gvTaskList:getWidth() - 32
  local itemHeight = (self.gvTaskList:getHeight() - 70) / 4
  self.taskAdapter:setItemSize(itemWidth, itemHeight)
  self.gvTaskList:setAdapter(self.taskAdapter)
  self:getChildWindow("ChallengeTask-title", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_ChallengeTask_title"))
  self:getChildWindow("ChallengeTask-reward_title", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_reward_title"))
  self:getChildWindow("ChallengeTask-task_title", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_task_title"))
  self:getChildWindow("ChallengeTask-progress_title", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_progress_title"))
  self:getChildWindow("ChallengeTask-progress_title_accept", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_progress_title"))
  self:getChildWindow("ChallengeTask-tip_task", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_progress_tip"))
  self:registerDataCallBack("AlreadyOwnedReward", function()
    self:onAlreadyOwnedItem()
  end)
  self:registerDataCallBack("CanNotGiveUpChallenge", function(data)
    self:canNotGiveUpChallenge(data)
  end, DataBuilderProcessor)
  self:registerDataCallBack("ShowTreasureAd", function(data)
    self:initAdButton(data)
  end, DataBuilderProcessor)
  local llSlideBlock = self:getChildWindow("ChallengeTask-reward_slide_block")
  llSlideBlock:registerEvent(GUIEvent.TouchDown, function(events)
    self.amwRewardModel:TouchDown(events.position)
  end)
  llSlideBlock:registerEvent(GUIEvent.TouchMove, function(events)
    self.amwRewardModel:TouchMove(events.position)
  end)
end

function UIChallengeTask:isShowAnim()
  return false
end

function UIChallengeTask:refreshUI(rewardId)
  self.rewardId = rewardId
  local reward = TreasureChallenge:getRewardData(rewardId)
  if not reward then
    return
  end
  self.amwRewardModel:SetWidth({
    reward.scale2,
    0
  })
  self.amwRewardModel:SetYPosition({
    0,
    reward.offset2
  })
  self.siRewardIcon:SetArea({0, 0}, {
    0,
    reward.offset2
  }, {
    0,
    reward.scale2 * 120
  }, {
    0,
    reward.scale2 * 120
  })
  self.stEndTip:SetText(Lang:getTipString(1046004, "\226\150\162FF00FA9A" .. (tostring(math.floor((TreasureChallenge.challengeConfig.endDate - os.time()) / 86400)) .. "\226\150\162FFFFD68E" .. "\t" .. "\226\150\162FF00FA9A" .. reward.minDays) .. "\226\150\162FFFFD68E"))
  self.stEndTipAccept:SetText(Lang:getTipString(1046004, "\226\150\162FF00FA9A" .. (tostring(math.floor((TreasureChallenge.challengeConfig.endDate - os.time()) / 86400)) .. "\226\150\162FFFFD68E" .. "\t" .. "\226\150\162FF00FA9A" .. reward.minDays) .. "\226\150\162FFFFD68E"))
  self.stRewardName:SetText(Lang:getString(reward.name))
  if reward.type == 1 then
    self.amwRewardModel:SetActor1("", "", 0)
    self.siRewardIcon:SetVisible(true)
    self.siRewardSmallIconBg:SetVisible(false)
    self.siRewardIcon:SetImage(reward.image)
  elseif reward.type == 2 then
    self.siRewardIcon:SetVisible(false)
    self.siRewardSmallIconBg:SetVisible(false)
    self.amwRewardModel:SetActor1(reward.actorName, reward.uiSkillName, 0)
  elseif reward.type == 3 then
    self.amwRewardModel:SetActor1("", "", 0)
    self.siRewardIcon:SetVisible(false)
    self.siRewardSmallIconBg:SetVisible(true)
    self.siRewardSmallIcon:SetImage(reward.image)
  end
  if reward.status == Define.ChallengeStatus.Experiencing then
    self.siProgressBg:SetVisible(true)
    self.siProgressAcceptBg:SetVisible(false)
  else
    self.siProgressBg:SetVisible(false)
    self.siProgressAcceptBg:SetVisible(true)
    self.btnStartChallenge:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_green")
    self.btnStartChallenge:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_green")
    self.btnStartChallenge:SetTouchable(true)
    for _, iReward in pairs(TreasureChallenge.rewardData) do
      if iReward.status == Define.ChallengeStatus.Experiencing then
        self.btnStartChallenge:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_gray")
        self.btnStartChallenge:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_gray")
        self.btnStartChallenge:SetTouchable(false)
      end
    end
  end
  self.pbProgress:SetProgress(reward.havePoints / reward.needPoints)
  self.stProgressCount1:SetText(string.format("\226\150\162FFFFD700%s\226\150\162FFFFFFFF/%s", tostring(reward.havePoints), tostring(reward.needPoints)))
  self.stProgressCount2:SetText(string.format("\226\150\162FFFFD700%s\226\150\162FFFFFFFF/%s", tostring(reward.havePoints), tostring(reward.needPoints)))
  self.taskAdapter:setData(reward.taskGroup)
end

function UIChallengeTask:onGiveUp()
  CustomDialog.builder().setTitleText("gui_bed_war_hall_give_up_challenge").setRightText(Lang:getString("gui_dialog_tip_btn_sure")).setContentText(Lang:getString("gui_bed_war_hall_give_up_tip")).setRightClickListener(function()
    CommonPacketSender:sendGiveUpChallengeTask(self.rewardId)
  end).setLeftText(Lang:getString("gui_dialog_tip_btn_cancel")).show()
end

function UIChallengeTask:onStartChallenge()
  CommonPacketSender:sendStartChallengeTask(self.rewardId)
end

function UIChallengeTask:onAlreadyOwnedItem()
  CustomDialog.builder().setTitleText("gui_bed_war_hall_already_owned_challenge").setRightText(Lang:getString("gui_dialog_tip_btn_sure")).setContentText(Lang:getString("gui_bed_war_hall_already_owned_tip")).setHideLeftButton().show()
end

function UIChallengeTask:canUndergoReward()
  local reward = TreasureChallenge:getRewardData(self.rewardId)
  GUIChallengeRewardReceive:init(reward, true)
  self:hide()
  LuaTimer:schedule(function()
    self:show()
  end, 1700)
  CustomDialog.hide()
end

function UIChallengeTask:canNotGiveUpChallenge(data)
  local hour = data:getNumberParam("hour")
  local sec = data:getNumberParam("sec")
  CustomDialog.builder().setTitleText("gui_bed_war_hall_not_give_up").setRightText(Lang:getString("gui_dialog_tip_btn_sure")).setContentText(Lang:getTipString(1046051, hour .. "\t" .. sec)).setHideLeftButton().show()
end

function UIChallengeTask:showGiftAnim()
  LuaTimer:cancel(self.key1)
  local rotate = 0
  self.siGiftEffect:SetEffectName("g1008_treasure_04.effect")
  self.key1 = LuaTimer:scheduleTimer(function()
    rotate = rotate + 0.314159
    self.siGift:SetRotate(-math.sin(rotate) * 13)
  end, 15, 30)
end

function UIChallengeTask:initAdButton(data)
  self.btnAdButton:SetVisible(data:getBoolParam("isShow") and WatchADSwitch:getSwitchBoolByType(2))
  self.adProgress = data:getNumberParam("progress")
end

function UIChallengeTask:onClickAdButton()
  local tip = "gui_bed_war_challenge_ad_hall_tip"
  local canShowAd = true
  if BaseMain:getGameType() ~= "g1046" then
    tip = "gui_bed_war_challenge_ad_game_tip"
    canShowAd = false
  end
  FreeGiftWatchADTipContent:setInfo("set:advertisement_system.json image:challenge_exp", "X" .. self.adProgress, "gui_bed_war_challenge_ad_tip")
  FreeGiftWatchADTipContent:setFont("HT64")
  FreeGiftWatchADTipContent:setTextColor("0.913726 0.305882 0.117647 1")
  FreeGiftWatchADTipContent:setBorderColor("0.988235 0.905882 0.105882 1")
  WatchAdTip.init().setContentView(FreeGiftWatchADTipContent).setTitle(Lang:getString("gui_bed_war_challenge_ad_title")).setTipText(Lang:getString(tip)).show(Define.AdType.Challenge, "").setLeftBtnEnabled(canShowAd)
  SoundUtil.playSound(SoundType.Click)
end

return UIChallengeTask

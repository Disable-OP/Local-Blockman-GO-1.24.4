local UIDailySignIn = class("UIDailySignIn", IGUILayout)

function UIDailySignIn:onLoad()
  self:getChildWindow("BedWarDailySignIn-Title"):SetText(Lang:getString("bed.war.daily.sign.in.title"))
  local btnClose = self:getChildWindow("BedWarDailySignIn-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.clickUI()
    self:hide()
  end)
  local llContent = self:getChildWindow("BedWarDailySignIn-Content")
  self.gvItems = IGUIGridView.new("BedWarDailySignIn-Items", llContent)
  self.gvItems:setArea({0, 0}, {0, 0}, {1, -40}, {1, -40})
  self.gvItems:setConfig(20, 20, 4)
  self.gvItems.root:SetHorizontalAlignment(HorizontalAlignment.Center)
  self.gvItems.root:SetVerticalAlignment(VerticalAlignment.Center)
  self:registerDataCallBack("DailySignIn", function(data)
    self:onUpdateDailySignInData(data)
  end, JsonBuilderProcessor)
  self:registerDataCallBack("ReissueDailySignIn", function(data)
    self:onNeedReissueDailySignIn(data)
  end, DataBuilderProcessor)
end

function UIDailySignIn:onShow()
  if self.gvItems:getItemCount() ~= 0 then
    return
  end
  local items = DailySignInConfig.getItems()
  local contentWidth = self.gvItems:getWidth()
  local contentHeight = self.gvItems:getHeight()
  local itemWidth = (contentWidth - 60) / 4
  local itemHeight = (contentHeight - 20) / 2
  local size = 0
  local i = 0
  for _, item in pairs(items) do
    local Item = UIHelper.newGameGUIWindow("GUIDailySignInItem", "BedWarDailySignInItem.json")
    Item:setWidth({
      0,
      itemWidth * item.Size + (item.Size - 1) * 10
    })
    Item:setHeight({0, itemHeight})
    Item:setSignInItem(item)
    size = size + item.Size
    if 4 < size then
      i = i + 1
      local SpaceItem = GUIManager:createGUIWindow(GUIType.Layout, string.format("BedWarDailySignIn-Space-%d", i))
      local Size = 4 - (size - item.Size)
      SpaceItem:SetWidth({
        0,
        itemWidth * Size + (Size - 1) * 10
      })
      SpaceItem:SetHeight({0, itemHeight})
      self.gvItems.root:AddItem(SpaceItem)
      size = item.Size
    end
    if size == 4 then
      size = 0
    end
    self.gvItems:addItem(Item)
  end
end

function UIDailySignIn:onUpdateDailySignInData(items)
  for _, item in pairs(items) do
    local Item = self.gvItems:getItem("id", item.Id)
    if Item ~= nil then
      Item:setStatus(item.Status)
    else
      DailySignInConfig.updateStatus(item.Id, item.Status)
    end
    if item.Status == DailySignInStatus.SIGN_IN then
      Events.UpdateDailySignInRedPointEvent:invoke(true)
    end
  end
end

function UIDailySignIn:onNeedReissueDailySignIn(data)
  local id = data:getNumberParam("id")
  local price = data:getNumberParam("price")
  local rightIcon
  if WatchADSwitch:getSwitchBoolByType(6) then
    rightIcon = "set:free_gift.json image:movie_ticket_icon"
    price = 1
  else
    rightIcon = "set:app_shop.json image:bedwar_key"
  end
  ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ADS_PLACEMENT, tostring(Define.AdType.FreeSignInAgain))
  CustomDialog.builder().setTitleText("gui_dialog_tip_title_tip").setContentText(Lang:getString("sign_in_again")).setLeftIcon("set:bed_war_cube_vedio_ad.json image:ad").setLeftText("bedWar.signInAgain.tip.ad.btn").setRightIcon(rightIcon).setRightText(tostring(price)).setLeftClickListener(function()
    ClientHelper.onWatchAd(Define.AdType.FreeSignInAgain, id)
  end).setRightClickListener(function()
    if WatchADSwitch:getSwitchBoolByType(6) then
      if PlayerWallet.getMoneyByCoinId(Define.Money.TICKET) > 1 then
        GamePacketSender:sendConfirmSignInAgainByTicket(id, true)
      else
        GUIStore:show(StoreId.CubeStore, 11)
      end
    else
      PayHelper.checkMoney(Define.Money.KEY, price, function(canBuy)
        if canBuy then
          GamePacketSender:sendConfirmSignInAgainByTicket(id, false)
        else
          GUIStore:show(StoreId.CubeStore, 8)
        end
      end)
    end
  end).show()
end

return UIDailySignIn

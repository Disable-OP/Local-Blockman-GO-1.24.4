local UIBedWarLottery = class("GUIBedWarLottery2", IGUILayout)

function UIBedWarLottery:onLoad()
  self.refreshPrice = 0
  self.llBackGround = self:getChildWindow("BedWarLottery2-bg", GUIType.Layout)
  self.llDetailsBackGround = self:getChildWindow("BedWarLottery2-details-bg", GUIType.Layout)
  self.btnOutSide = self:getChildWindow("BedWarLottery2-outside_bt", GUIType.Button)
  self.btnClose = self:getChildWindow("BedWarLottery2-close", GUIType.Button)
  self.btnRefresh = self:getChildWindow("BedWarLottery2-refresh", GUIType.Button)
  self.btnDetailsClose = self:getChildWindow("BedWarLottery2-detail_close", GUIType.Layout)
  self.btnDetails = self:getChildWindow("BedWarLottery2-detail_bt", GUIType.Button)
  self.btnRefresh = self:getChildWindow("BedWarLottery2-refresh", GUIType.Button)
  self.llItemBackGround = self:getChildWindow("BedWarLottery2-itemGridViewLayout", GUIType.Layout)
  self.llRightCardBackGround = self:getChildWindow("BedWarLottery2-CardGridViewLayout", GUIType.Layout)
  self.llDetailsGridView = self:getChildWindow("BedWarLottery2-DetailsGridViewLayout", GUIType.Layout)
  self.tvRefresh = self:getChildWindow("BedWarLottery2-refresh-text", GUIType.StaticText)
  self.tvKeyNumber = self:getChildWindow("BedWarLottery2-key-number", GUIType.StaticText)
  self.awRefreshKey = self:getChildWindow("BedWarLottery2-key", GUIType.StaticImage)
  self.btnOutSide:registerEvent(GUIEvent.ButtonClick, function()
    self:close()
  end)
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:close()
  end)
  self.btnRefresh:registerEvent(GUIEvent.ButtonClick, function()
    PayHelper.checkMoney(Define.Money.KEY, self.refreshPrice, function(canBuy)
      if canBuy then
        GamePacketSender:sendBedWarLotteryRefresh()
      else
        CustomDialog.hide()
        GUIStore:show(StoreId.CubeStore, 8)
      end
    end)
  end)
  self.btnDetails:registerEvent(GUIEvent.ButtonClick, function()
    self.llDetailsBackGround:SetVisible(true)
    self.btnDetailsClose:SetVisible(true)
  end)
  self.btnDetailsClose:registerEvent(GUIEvent.TouchDown, function()
    self.llDetailsBackGround:SetVisible(false)
    self.btnDetailsClose:SetVisible(false)
  end)
  self:registerDataCallBack("ReplaceTip", function(data)
    self:onShowLotteryReplace(data)
  end, DataBuilderProcessor)
  self:registerDataCallBack("FreeRefresh", function()
    self:onCanFreeRefresh()
  end)
  self:getChildWindow("BedWarLottery2-title-text", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_lottery_title"))
  self:getChildWindow("BedWarLottery2-right-title-text", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_lottery_right_title"))
  self:getChildWindow("BedWarLottery2-rules", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_lottery_rule"))
  self.tvRefresh:SetText(Lang:getString("gui_bed_war_lottery_refresh"))
  self.gvItem = IGUIGridView.new("item_grid_view", self.llItemBackGround)
  self.gvItem:setArea({0, 10}, {0, 0}, {1, 0}, {1, 0})
  self.gvItem:setConfig(0, 5, 1)
  self.gvCard = IGUIGridView.new("card_grid_view", self.llRightCardBackGround)
  self.gvCard:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvCard:setConfig(30, 15, 3)
  self.gvDetails = IGUIGridView.new("details-grid-view", self.llDetailsGridView)
  self.gvDetails:setArea({0, 5}, {0, 0}, {1, 0}, {1, 0})
  self.gvDetails:setConfig(10, 10, 6)
  self:initItemLayout()
  self:initCardLayout()
  self:initDetailsLayout()
end

function UIBedWarLottery:close()
  self:hide()
end

function UIBedWarLottery:onTick()
  self.tvKeyNumber:SetText(PlayerWallet.getMoneyByCoinId(Define.Money.KEY))
end

function UIBedWarLottery:onCanFreeRefresh()
  self.awRefreshKey:SetVisible(false)
  self.tvRefresh:SetText(Lang:getString("gui_bed_war_refresh_free"))
end

function UIBedWarLottery:onGetReward(rewardId, price, seq)
  local itemNum = self.gvItem:getItemCount()
  local cardNum = self.gvCard:getItemCount()
  for i = 1, itemNum do
    local Item = self.gvItem:getItem("index", i)
    Item:setGet(tonumber(rewardId))
  end
  for i = 1, cardNum do
    local Card = self.gvCard:getItem("index", i)
    if i == tonumber(seq) then
      Card:onOpenCard(rewardId)
    end
    Card:updatePrice(price)
  end
  GamePacketSender:sendLotteryEffectEnd()
end

function UIBedWarLottery:onGetRefreshResult(result, refreshPrice, lotteryPrice)
  if not result then
    return
  end
  local rewardIds = StringUtil.split(tostring(result), "#")
  local itemNum = self.gvItem:getItemCount()
  local cardNum = self.gvCard:getItemCount()
  local detailsNum = self.gvDetails:getItemCount()
  for i = 1, itemNum do
    local Item = self.gvItem:getItem("index", i)
    local reward = tonumber(rewardIds[i])
    Item:updateItem(tonumber(reward))
  end
  for i = 1, cardNum do
    local Card = self.gvCard:getItem("index", i)
    Card:updatePrice(lotteryPrice)
    Card:showCard()
  end
  for i = 1, detailsNum do
    local Detail = self.gvDetails:getItem("index", i)
    Detail:onNotSelected()
  end
  for _, reward in pairs(rewardIds) do
    for i = 1, detailsNum do
      local Detail = self.gvDetails:getItem("index", i)
      Detail:SelectReward(tonumber(reward))
    end
  end
  if tonumber(refreshPrice) > 0 then
    self.awRefreshKey:SetVisible(true)
    self.tvRefresh:SetText(tostring(refreshPrice))
  end
  self.refreshPrice = tonumber(refreshPrice)
end

function UIBedWarLottery:initItemLayout()
  local hight = (self.gvItem:getHeight() - 25) / 6
  for i = 1, 6 do
    local Item = UIHelper.newGameGUIWindow("GUILotteryItem", "BedWarLotteryItem.json")
    Item:setArea({0, 0}, {0, 0}, {0.95, 0}, {0, hight})
    Item:init(i)
    Item.root:SetTouchable(false)
    self.gvItem:addItem(Item)
  end
end

function UIBedWarLottery:initCardLayout()
  local width = (self.gvCard:getWidth() - 60) / 3
  width = width < 151 and width or 151
  local hight = (self.gvCard:getHeight() - 15) / 2
  hight = hight < 180 and hight or 180
  for i = 1, 6 do
    local Card = UIHelper.newGameGUIWindow("GUILotteryCardItem2", "BedWarLotteryCard2.json")
    Card:setArea({0, 0}, {0, 0}, {0, width}, {0, hight})
    Card:init(i)
    Card.root:SetTouchable(true)
    self.gvCard:addItem(Card)
  end
end

function UIBedWarLottery:initDetailsLayout()
  local width = (self.gvDetails:getWidth() - 50) / 6
  width = width < 80 and width or 80
  local rewards = LotteryConfig.rewards()
  local sort = {}
  for _, reward in pairs(rewards) do
    table.insert(sort, reward)
  end
  table.sort(sort, function(a1, a2)
    return a1.SortWeight < a2.SortWeight
  end)
  local count = 0
  for i, value in pairs(sort) do
    count = count + 1
    local DetailItem = UIHelper.newGameGUIWindow("GUILotteryDetailItem2", "BedWarLotteryDetailItem2.json")
    DetailItem:setArea({0, 0}, {0, 0}, {0, width}, {0, width})
    DetailItem:init(count)
    DetailItem.root:SetTouchable(false)
    DetailItem:setRewardImage(value.Id)
    DetailItem.root:SetVerticalAlignment(VerticalAlignment.Top)
    DetailItem.root:SetHorizontalAlignment(HorizontalAlignment.Left)
    self.gvDetails:addItem(DetailItem)
  end
end

function UIBedWarLottery:onShowLotteryReplace(data)
  local oldId = data:getNumberParam("oldId")
  local newId = data:getNumberParam("newId")
  LotteryReplaceContent:setGoodsInfo(oldId, newId)
  CustomDialog.builder().setContentView(LotteryReplaceContent).setTitleText("gui_dialog_tip_title_tip").setRightText("gui_dialog_tip_btn_sure").setRightClickListener(function()
    GamePacketSender:sendLotteryReplace(true)
  end).setLeftText("gui_dialog_tip_btn_cancel").setLeftClickListener(function()
    GamePacketSender:sendLotteryReplace(false)
  end).show()
end

return UIBedWarLottery

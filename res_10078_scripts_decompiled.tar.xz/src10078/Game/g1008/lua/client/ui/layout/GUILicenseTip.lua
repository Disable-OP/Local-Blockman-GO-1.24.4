local UILicenseTip = class("UILicenseTip", IGUILayout)

function UILicenseTip:onLoad()
  local stTitle = self:getChildWindow("BedWarLicenseTip-Title", GUIType.StaticText)
  stTitle:SetText(Lang:getString("gui_bed_war_license_buy_level_title"))
  self.stContent = self:getChildWindow("BedWarLicenseTip-Content", GUIType.StaticText)
  self.llBtnContentOne = self:getChildWindow("BedWarLicenseTip-Btn-Content-One", GUIType.Layout)
  self.llBtnContentTwo = self:getChildWindow("BedWarLicenseTip-Btn-Content-Two", GUIType.Layout)
  self.stBtnContentTwoText = self:getChildWindow("BedWarLicenseTip-Btn-Content-Two-Text", GUIType.StaticText)
  self.stBtnContentOneText = self:getChildWindow("BedWarLicenseTip-Btn-Content-One-Text", GUIType.StaticText)
  self.stBtnContentOneText:SetText(Lang:getString("gui_dialog_tip_btn_sure"))
  local btnMaskClose = self:getChildWindow("BedWarLicenseTip-Mask-Close", GUIType.Button)
  btnMaskClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local btnClose = self:getChildWindow("BedWarLicenseTip-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  self.btnSure = self:getChildWindow("BedWarLicenseTip-Btn", GUIType.Button)
  self.btnSure:registerEvent(GUIEvent.ButtonClick, function()
    if self.type == "buyLevel" then
      GamePacketSender:sendBedWarLicenseBuyLevel(GUILicense.seasonDate, GUILicense.playerLevel, GUILicense.freeUpgradeTime ~= DateUtil.getYearDay())
      self:hide()
    elseif self.type == "refreshTaskLackYaoshi" then
      RootGuiLayout.Instance():showMainControl()
      RootGuiLayout.Instance():showAppShop(1)
    else
      self:hide()
    end
  end)
end

function UILicenseTip:onShow(type, data)
  self.type = type
  if type == "buyLevel" then
    self.stContent:SetText(Lang:getString("gui_bed_war_license_buy_level_content"))
    self.stBtnContentTwoText:SetText(data)
    self.llBtnContentOne:SetVisible(false)
    self.llBtnContentTwo:SetVisible(true)
  end
  if type == "exchangeSuccess" then
    self.stContent:SetText(Lang:getString("gui_bed_war_license_exchange_success"))
    self.llBtnContentOne:SetVisible(true)
    self.llBtnContentTwo:SetVisible(false)
  end
  if type == "lackOfHorn" then
    self.stContent:SetText(Lang:getString("gui_bed_war_license_lackOfHorn"))
    self.llBtnContentOne:SetVisible(true)
    self.llBtnContentTwo:SetVisible(false)
  end
  if type == "refreshTaskLackYaoshi" then
    self.stContent:SetText(Lang:getString("gui_bed_war_license_lack_yaoshi"))
    self.llBtnContentOne:SetVisible(true)
    self.llBtnContentTwo:SetVisible(false)
  end
  if type == "cannot_exchange" then
    self.stContent:SetText(Lang:getString("gui_bed_war_exchange_btn_cannot_exchange"))
    self.llBtnContentOne:SetVisible(true)
    self.llBtnContentTwo:SetVisible(false)
  end
end

return UILicenseTip

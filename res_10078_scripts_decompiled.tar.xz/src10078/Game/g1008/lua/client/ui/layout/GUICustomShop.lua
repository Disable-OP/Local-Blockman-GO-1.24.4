local UICustomShop = class("GUICustomShop", IGUILayout)

function UICustomShop:onLoad()
  self.curSelectTab = nil
  self.curSelectGoods = nil
  self.btnClose = self:getChildWindow("BedWarCustomShop-Close", GUIType.Button)
  local llMoney = self:getChildWindow("BedWarCustomShop-Money", GUIType.Layout)
  self.lvMoney = IGUIListView.new("BedWarCustomShop-Money-List", llMoney, nil, Orientation.Horizontal)
  self.lvMoney:setItemSpace(30)
  self.llChip = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
  self.llChip:onDataChanged({
    ItemId = 0,
    RealId = Define.Money.COMMON_CHIP
  })
  self.lvMoney:addItem(self.llChip)
  self.llKey = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
  self.llKey:onDataChanged({
    ItemId = 0,
    RealId = Define.Money.KEY
  })
  self.lvMoney:addItem(self.llKey)
  self.llDiamond = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
  self.llDiamond:onDataChanged({
    ItemId = 0,
    RealId = Define.Money.DIAMOND
  })
  self.lvMoney:addItem(self.llDiamond)
  local llLeft = self:getChildWindow("BedWarCustomShop-Left", GUIType.Layout)
  local llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "bed.war.custom.shop", function()
    self:hide(true)
  end)
  llLeft:AddChildWindow(llReturn.root)
  self.btnBuy = self:getChildWindow("BedWarCustomShop-Buy", GUIType.Button)
  self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
    self:onBuyClick()
  end)
  self.tvNoBuyText = self:getChildWindow("BedWarCustomShop-No-Buy-Text", GUIType.StaticText)
  self.siNoBuy = self:getChildWindow("BedWarCustomShop-No-Buy-Bg", GUIType.StaticImage)
  self.siContentBg = self:getChildWindow("BedWarCustomShop-Content-Bg", GUIType.StaticImage)
  self.awPlayer1 = self:getChildWindow("BedWarCustomShop-Player1", GUIType.ActorWindow)
  self.awPlayer2 = self:getChildWindow("BedWarCustomShop-Player2", GUIType.ActorWindow)
  self.awPet1 = self:getChildWindow("BedWarCustomShop-Pet1", GUIType.ActorWindow)
  self.awPet2 = self:getChildWindow("BedWarCustomShop-Pet2", GUIType.ActorWindow)
  self.awActor = self:getChildWindow("BedWarCustomShop-Actor", GUIType.ActorWindow)
  self.siActorEffect = self:getChildWindow("BedWarCustomShop-Actor-Effect", GUIType.StaticImage)
  local llSlideBlock = self:getChildWindow("BedWarCustomShop-Slide-Block")
  llSlideBlock:registerEvent(GUIEvent.TouchDown, function(events)
    self.awPlayer1:TouchDown(events.position)
    self.awPlayer2:TouchDown(events.position)
    self.awPet1:TouchDown(events.position)
    self.awPet2:TouchDown(events.position)
    self.awActor:TouchDown(events.position)
  end)
  llSlideBlock:registerEvent(GUIEvent.TouchMove, function(events)
    self.awPlayer1:TouchMove(events.position)
    self.awPlayer2:TouchMove(events.position)
    self.awPet1:TouchMove(events.position)
    self.awPet2:TouchMove(events.position)
    self.awActor:TouchDown(events.position)
  end)
  self.llGoodsList = self:getChildWindow("BedWarCustomShop-GoodsList")
  self.llItemList = self:getChildWindow("BedWarCustomShop-ItemList")
  self:initGoodsListUI()
  self:initItemList()
  self:initTabs()
  self:showModelType(CustomShopModelType.Small)
end

function UICustomShop:initItemList()
  self.tagGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
  self.cbWoodTag = self:getChildWindow("BedWarCustomShop-Wood", GUIType.CheckBox)
  self.cbIronTag = self:getChildWindow("BedWarCustomShop-Iron", GUIType.CheckBox)
  self.cbGoldTag = self:getChildWindow("BedWarCustomShop-Gold", GUIType.CheckBox)
  self.cbDiamondTag = self:getChildWindow("BedWarCustomShop-Diamond", GUIType.CheckBox)
  self.tvWoodTag = self:getChildWindow("BedWarCustomShop-Wood-Text", GUIType.StaticText)
  self.tvIronTag = self:getChildWindow("BedWarCustomShop-Iron-Text", GUIType.StaticText)
  self.tvGoldTag = self:getChildWindow("BedWarCustomShop-Gold-Text", GUIType.StaticText)
  self.tvDiamondTag = self:getChildWindow("BedWarCustomShop-Diamond-Text", GUIType.StaticText)
  self.tagGroup:addCheckBox(self:getChildWindow("BedWarCustomShop-Wood", GUIType.CheckBox), function(checked)
    if checked then
      self:showModelType(CustomShopConfig:getTabModelType(self.curSelectTab.tabId[1]))
      local goodsList = CustomShopConfig:getGoodsList(self.curSelectTab.tabId[1])
      self.goodsAdapter:setData(goodsList)
      if 0 < #goodsList then
        GUICustomShop:onSelectGoods(goodsList[1])
      end
      self.goodsAdapter:setScrollOffset(0)
    end
  end)
  self.tagGroup:addCheckBox(self:getChildWindow("BedWarCustomShop-Iron", GUIType.CheckBox), function(checked)
    if checked then
      self:showModelType(CustomShopConfig:getTabModelType(self.curSelectTab.tabId[2]))
      local goodsList = CustomShopConfig:getGoodsList(self.curSelectTab.tabId[2])
      self.goodsAdapter:setData(goodsList)
      if 0 < #goodsList then
        GUICustomShop:onSelectGoods(goodsList[1])
      end
      self.goodsAdapter:setScrollOffset(0)
    end
  end)
  self.tagGroup:addCheckBox(self:getChildWindow("BedWarCustomShop-Gold", GUIType.CheckBox), function(checked)
    if checked then
      self:showModelType(CustomShopConfig:getTabModelType(self.curSelectTab.tabId[3]))
      local goodsList = CustomShopConfig:getGoodsList(self.curSelectTab.tabId[3])
      self.goodsAdapter:setData(goodsList)
      if 0 < #goodsList then
        GUICustomShop:onSelectGoods(goodsList[1])
      end
      self.goodsAdapter:setScrollOffset(0)
    end
  end)
  self.tagGroup:addCheckBox(self:getChildWindow("BedWarCustomShop-Diamond", GUIType.CheckBox), function(checked)
    if checked then
      self:showModelType(CustomShopConfig:getTabModelType(self.curSelectTab.tabId[4]))
      local goodsList = CustomShopConfig:getGoodsList(self.curSelectTab.tabId[4])
      self.goodsAdapter:setData(goodsList)
      if 0 < #goodsList then
        GUICustomShop:onSelectGoods(goodsList[1])
      end
      self.goodsAdapter:setScrollOffset(0)
    end
  end)
end

function UICustomShop:initGoodsListUI()
  self.llGoodsList:SetArea({0, 0}, {0.05, 0}, {0.93, 0}, {0.95, 0})
  self.gvGoodsList = IGUIGridView.new("BedWarCustomShop-Goods-List", self.llGoodsList)
  self.gvGoodsList.root:SetArea({0, 15}, {0, 5}, {1, -10}, {0.95, -5})
  self.gvGoodsList.root:SetClipChild(false)
  self.gvGoodsList:setConfig(8, 8, 3)
  self.goodsAdapter = UIHelper.newGameAdapter("CustomShopGoodsAdapter")
  local contentWidth = self.gvGoodsList:getWidth() - 18
  local itemWidth = contentWidth / 3
  local itemHeight = itemWidth / 142 * 220
  self.goodsAdapter:setItemSize(itemWidth, itemHeight)
  self.gvGoodsList:setAdapter(self.goodsAdapter)
end

function UICustomShop:isShowAnim()
  return false
end

function UICustomShop:show(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.openStore)
  end
  self.super.show(self)
end

function UICustomShop:hide(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.closeStore)
  end
  self.super.hide(self)
end

function UICustomShop:onTick()
  self.llDiamond:onTick()
  self.llKey:onTick()
  self.llChip:onTick()
end

local function setDefaultCloth()
  local map = {
    "custom_hair",
    "clothes_tops",
    "clothes_pants",
    "custom_shoes"
  }
  local inv = Game:getPlayer():getInventory()
  for index = 101, 104 do
    local info = inv:getItemStackInfo(index - 1)
    if info.id == 0 then
      GUICustomShop:useBodyPart(map[index - 100], "1")
    end
  end
end

function UICustomShop:onShow()
  if self.curSelectGoods ~= nil then
    if isGameStart then
      self:initPlayerActor()
    end
    return
  end
  for pos, item in pairs(self.lvTabs.items) do
    if pos == 1 then
      item:setChecked(true)
      break
    end
  end
  self:initPlayerActor()
end

function UICustomShop:initTabs()
  local llTabs = self:getChildWindow("BedWarCustomShop-Tabs")
  self.lvTabs = IGUIListView.new("BedWarCustomShop-Tabs-List", llTabs)
  self.lvTabs:setItemSpace(0)
  local customShop = CustomShopConfig:getCustomShop()
  for _, pages in pairs(customShop) do
    local tab = UIHelper.newGameGUIWindow("GUICustomShopTab", "BedWarCustomShopTab.json")
    tab:setArea({0, 0}, {0, 0}, {1, 0}, {0, 55})
    tab:onDataChanged(pages)
    self.lvTabs:addItem(tab)
  end
  customShop = {}
end

local function updateTabsLayout(tabs, tab)
  local itemHeight = tab.root:GetPixelSize().y
  local listHeight = tabs.root:GetPixelSize().y
  tabs.root:SetItemHeight(itemHeight + listHeight + math.random(1, 100))
  local items = tabs.items
  local _tab
  for _, item in pairs(items) do
    if item == tab then
      _tab = tab
    end
  end
  if not _tab then
    return
  end
  itemHeight = _tab.root:GetPixelSize().y
  local itemPosY = _tab.root:GetYPosition()[2]
  listHeight = tabs:getHeight()
  local currentOffset = tabs.root:GetScrollOffset()
  if listHeight > itemPosY + itemHeight + currentOffset and itemPosY >= -currentOffset then
    return
  end
  local container = tabs.root:GetChildByIndex(0)
  local containerHeight = container:GetPixelSize().y
  local maxOffset = listHeight - containerHeight
  local needOffset = itemPosY + currentOffset
  local offset = currentOffset - needOffset
  tabs.root:SetScrollOffset(math.min(math.max(offset, maxOffset), 0))
end

function UICustomShop:onSelectTab(tab)
  self:onSelectSubTab(tab)
  for _, item in pairs(self.lvTabs.items) do
    item:setChecked(item.pageId == tab.pageId)
  end
end

function UICustomShop:setSelectTab(tabId)
  for _, page in pairs(self.lvTabs.items) do
    for _, tab in pairs(page.tabs) do
      if type(tab.tabId) == "number" then
        if tab.tabId == tabId then
          tab:setChecked(true)
          self:onSelectTab(tab)
          return
        end
      elseif type(tab.tabId) == "table" then
        for _, _tabId in pairs(tab.tabId) do
          if _tabId == tabId then
            tab:setChecked(true)
            self:onSelectTab(tab)
            return
          end
        end
      end
    end
  end
end

function UICustomShop:updateTabsLayout(tab)
  updateTabsLayout(self.lvTabs, tab)
end

function UICustomShop:showModelType(type)
  self.siActorEffect:SetVisible(false)
  if type == CustomShopModelType.Small then
    self.awPlayer1:SetVisible(true)
    self.awPlayer2:SetVisible(false)
    self.awActor:SetVisible(false)
    self.siContentBg:SetImage("set:bed_war_3_dress_store_bg.json image:img_0_shop09")
  elseif type == CustomShopModelType.SingleActor then
    self.awPlayer1:SetVisible(false)
    self.awPlayer2:SetVisible(false)
    self.awActor:SetVisible(true)
    self.siContentBg:SetImage("set:bed_war_3_dress_store_bg.json image:img_0_shop03")
  else
    self.awPlayer1:SetVisible(false)
    self.awPlayer2:SetVisible(true)
    self.awActor:SetVisible(false)
    self.siContentBg:SetImage("set:bed_war_3_dress_store_bg.json image:img_0_shop03")
  end
end

function UICustomShop:useBodyPart(part, mesh, notInit)
  notInit = notInit or false
  if self.awPlayer1:IsVisible() then
    if not notInit then
      self:initPlayerActor()
    end
    self.awPlayer1:UseBodyPart(part, mesh)
  end
  if self.awPlayer2:IsVisible() then
    if not notInit then
      self:initPlayerActor()
    end
    self.awPlayer2:UseBodyPart(part, mesh)
  end
end

function UICustomShop:initPlayerActor()
  if not self.awPlayer1:GetActor() then
    self.awPlayer1:SetActorInfo("boy.actor", {}, 0)
  end
  self.awPlayer2:SetActorByUserId(Game:getPlatformUserId(), 0, false, function()
    self.awPlayer1:SetActorByUserId(Game:getPlatformUserId())
  end)
end

function UICustomShop:playSkill(skill)
  self.awPlayer1:PlaySkill(skill)
  self.awPlayer2:PlaySkill(skill)
end

function UICustomShop:unloadBodyPart(part)
  self.awPlayer1:UnloadBodyPart(part)
  self.awPlayer2:UnloadBodyPart(part)
end

function UICustomShop:onSelectGoods(goods)
  local oldGoods = self.curSelectGoods
  self.curSelectGoods = nil
  self.goodsAdapter:notifyItemDataChange(oldGoods)
  self.curSelectGoods = goods
  self.goodsAdapter:notifyItemDataChange(goods)
  self:updateBuyButtonUI()
  CustomShop:onSelectGoods(self.curSelectGoods)
end

function UICustomShop:updateGoodsLayout(goods)
  for index, _goods in pairs(CustomShopConfig:getGoodsList(goods.TabId)) do
    if _goods.Id == goods.Id then
      self.gvGoodsList:getWidth()
      local height = self.goodsAdapter:getItemHeight()[2]
      local upperHeight = (math.ceil(index / 3) - 1) * (height + 8)
      self.goodsAdapter:setScrollOffset(-upperHeight)
    end
  end
end

function UICustomShop:updateBuyButtonUI()
  if not self.curSelectGoods then
    return
  end
  self.btnBuy:SetVisible(true)
  self.btnBuy:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy01")
  self.btnBuy:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy01")
  self.btnBuy:SetProperty("TextBorderColor", "0.639216 0.278431 0.0627451 1")
  self.siNoBuy:SetVisible(false)
  if self.curSelectGoods.Time == -1 or self.curSelectGoods.Time > 0 then
    self.btnBuy:SetProperty("TextBorderColor", "0.0235294 0.52549 0.556863 1")
    self.btnBuy:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy02")
    self.btnBuy:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy02")
    if self.curSelectGoods.Status == CustomShopGoodsStatus.Equiped then
      self.btnBuy:SetText(Lang:getString("bed.war.custom.shop.unload"))
      local type = CustomShopConfig:getTabType(tonumber(self.curSelectTab.tabId))
      if type == CustomGoodsType.Action then
        self.btnBuy:SetVisible(false)
        self.tvNoBuyText:SetText(Lang:getString("good.equipped"))
        self.siNoBuy:SetVisible(true)
      end
    else
      self.btnBuy:SetText(Lang:getString("bed.war.custom.shop.equip"))
    end
  else
    if self.curSelectGoods.GetWay == 2 then
      self.btnBuy:SetVisible(false)
      self.siNoBuy:SetVisible(true)
      self.tvNoBuyText:SetText(Lang:getString("get.by.sum.recharge"))
      return
    elseif self.curSelectGoods.GetWay == 3 then
      self.btnBuy:SetVisible(false)
      self.siNoBuy:SetVisible(true)
      self.tvNoBuyText:SetText(Lang:getString("get.by.treasure.challenge"))
      return
    elseif self.curSelectGoods.GetWay == 4 then
      self.btnBuy:SetVisible(false)
      self.siNoBuy:SetVisible(true)
      self.tvNoBuyText:SetText(Lang:getString("get.by.license"))
    end
    self.btnBuy:SetText(Lang:getString("shop_btn_buy"))
  end
end

function UICustomShop:onSelectSubTab(tab)
  if self.curSelectTab then
    CustomShop:onTabChange(self.curSelectTab, false)
  end
  self.curSelectTab = tab
  CustomShop:onTabChange(self.curSelectTab, true)
  local goodsList
  if type(tab.tabId) == "table" then
    self.llItemList:SetVisible(true)
    self.llGoodsList:SetArea({0, 0}, {0.14, 0}, {0.93, 0}, {0.86, 0})
    if tab.tagLang[1] then
      self.tvWoodTag:SetText(Lang:getString(tab.tagLang[1]))
      self.cbWoodTag:SetVisible(true)
    else
      self.cbWoodTag:SetVisible(false)
    end
    if tab.tagLang[2] then
      self.tvIronTag:SetText(Lang:getString(tab.tagLang[2]))
      self.cbIronTag:SetVisible(true)
    else
      self.cbIronTag:SetVisible(false)
    end
    if tab.tagLang[3] then
      self.tvGoldTag:SetText(Lang:getString(tab.tagLang[3]))
      self.cbGoldTag:SetVisible(true)
    else
      self.cbGoldTag:SetVisible(false)
    end
    if tab.tagLang[4] then
      self.tvDiamondTag:SetText(Lang:getString(tab.tagLang[4]))
      self.cbDiamondTag:SetVisible(true)
    else
      self.cbDiamondTag:SetVisible(false)
    end
    local curIndex = self.tagGroup:getCurIndex()
    if 0 < curIndex and curIndex <= #tab.tabId then
      self:showModelType(CustomShopConfig:getTabModelType(tab.tabId[curIndex]))
      goodsList = CustomShopConfig:getGoodsList(tab.tabId[curIndex])
    else
      self:showModelType(CustomShopConfig:getTabModelType(tab.tabId[1]))
      goodsList = CustomShopConfig:getGoodsList(tab.tabId[1])
      self.tagGroup:selectIndex(1)
    end
  else
    self.llItemList:SetVisible(false)
    self.llGoodsList:SetArea({0, 0}, {0.05, 0}, {0.93, 0}, {0.95, 0})
    self:showModelType(CustomShopConfig:getTabModelType(tab.tabId))
    goodsList = CustomShopConfig:getGoodsList(tab.tabId)
  end
  self.goodsAdapter:setData(goodsList)
  if 0 < #goodsList then
    GUICustomShop:onSelectGoods(goodsList[1])
  end
  self.goodsAdapter:setScrollOffset(0)
end

function UICustomShop:updateListUI()
  self.goodsAdapter:notifyDataChange()
  self:updateBuyButtonUI()
end

function UICustomShop:updateGoodsUI(goods)
  self.goodsAdapter:notifyItemDataChange(goods)
end

function UICustomShop:onBuyClick()
  if not self.curSelectGoods then
    return
  end
  if self.curSelectGoods.Time == -1 or self.curSelectGoods.Time > 0 then
    if self.curSelectGoods.Status == CustomShopGoodsStatus.Equiped then
      CustomShop:onUnloadGoods(self.curSelectGoods)
    else
      SoundUtil.playSound(SoundConfig.useGoodsStore)
      CustomShop:onEquipGoods(self.curSelectGoods)
    end
  else
    ReportUtil.reportCustomShopBuy("button1", self.curSelectGoods.Id)
    SoundUtil.playSound(SoundConfig.buyGoodsStore)
    if 0 > self.curSelectGoods.DiscountPrices1 then
      return
    end
    GoodsDetailContent:setGoodsBuyInfo(self.curSelectGoods, self.curSelectGoods.Image, self.curSelectGoods.Name, self.curSelectGoods.CoinId1, self.curSelectGoods.DiscountPrices1, self.curSelectGoods.CoinId2, self.curSelectGoods.DiscountPrices2)
    PopUpWindows.builder().setContentView(GoodsDetailContent).setTitleText("gui_bird_store_desc").show()
  end
end

function UICustomShop:showBuyGoodsSuccess(goodsId)
  local goods = CustomShopConfig:getGoodsConfig(goodsId)
  if not goods then
    return
  end
  if CustomShopConfig:getGoodsType(goods) == CustomGoodsType.Action and not GUICustomShop:isShow() then
    CustomShop:onEquipGoods(goods)
    return
  end
  if not GUICustomShop:isShow() then
    return
  end
  GoodsDetailContent:setGoodsShowInfo(goods)
  PopUpWindows.builder().setTitleText("gui_bed_war_buy_success").setContentView(GoodsDetailContent).setCloseVisible(false).setClickBgClose(false).show()
end

function UICustomShop:setSingleActor(config)
  self.awActor:SetActorInfo(config.ActorName, {}, 20)
  if config.EffectName and string.len(config.EffectName) > 0 then
    self.siActorEffect:SetVisible(true)
    self.siActorEffect:SetEffectName(config.EffectName)
  else
    self.siActorEffect:SetVisible(false)
  end
end

function UICustomShop:openCustomShopByGoodsId(goodsId)
  local goodConfig = CustomShopConfig:getGoodsConfig(goodsId)
  if goodConfig then
    self:show(true)
    self:setSelectTab(goodConfig.TabId)
    if type(self.curSelectTab.tabId) == "table" then
      for index, value in pairs(self.curSelectTab.tabId) do
        if value == goodConfig.TabId then
          self.tagGroup:selectIndex(index)
          break
        end
      end
    end
    self:onSelectGoods(goodConfig)
    self:updateGoodsLayout(goodConfig)
  end
end

return UICustomShop

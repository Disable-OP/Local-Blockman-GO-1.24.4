local UITiroSignIn = class("UITiroSignIn", IGUILayout)

function UITiroSignIn:onLoad()
  local llItems = self:getChildWindow("BedWarTiroSignIn-Items")
  self.gvItems = IGUIGridView.new("BedWarTiroSignIn-Items-Container", llItems)
  self.gvItems:setConfig(10, 10, 4)
  self:registerDataCallBack("TiroSignIn", function(data)
    self:onUpdateTrioSignInData(data)
  end, JsonBuilderProcessor)
end

function UITiroSignIn:isShowAnim()
  return false
end

function UITiroSignIn:onShow()
  if self.gvItems:getItemCount() ~= 0 then
    return
  end
  local items = TiroSignInConfig.getItems()
  local contentWidth = self.gvItems:getWidth()
  local contentHeight = self.gvItems:getHeight()
  local itemWidth = (contentWidth - 30) / 4
  local itemHeight = (contentHeight - 10) / 2
  local size = 0
  local i = 0
  for _, item in pairs(items) do
    local Item = UIHelper.newGameGUIWindow("GUITiroSignInItem", "BedWarTiroSignInItem.json")
    Item:setWidth({
      0,
      itemWidth * item.Size + (item.Size - 1) * 10
    })
    Item:setHeight({0, itemHeight})
    Item:setSignInItem(item)
    size = size + item.Size
    if 4 < size then
      i = i + 1
      local SpaceItem = GUIManager:createGUIWindow(GUIType.Layout, string.format("GUIBedWarTiroSignIn-Space-%d", i))
      local Size = 4 - (size - item.Size)
      SpaceItem:SetWidth({
        0,
        itemWidth * Size + (Size - 1) * 10
      })
      SpaceItem:SetHeight({0, itemHeight})
      self.gvItems.root:AddItem(SpaceItem)
      size = item.Size
    end
    if size == 4 then
      size = 0
    end
    self.gvItems:addItem(Item)
  end
end

function UITiroSignIn:onUpdateTrioSignInData(items)
  for _, item in pairs(items) do
    local Item = self.gvItems:getItem("id", item.Id)
    if Item ~= nil then
      Item:setStatus(item.Status)
    else
      TiroSignInConfig.updateStatus(item.Id, item.Status)
    end
    if item.Status == TiroSignInStatus.WAIT_RECEIVE then
      Events.UpdateActivityRedPointEvent:invoke(2, true)
    end
  end
end

return UITiroSignIn

local UIBoxRewardResult = class("UIBoxRewardResult", IGUILayout)
local WaitList = {}
local itemList = {}
local iconList = {}
local textList = {}

local function hideAllChild(window)
  local count = window:GetChildCount()
  for i = 1, count do
    window:GetChildByIndex(i - 1):SetVisible(false)
  end
end

local function CreateRewardItem(index, parent)
  if itemList[index] then
    return itemList[index]
  end
  local Width = 110
  local ivBackground = GUIManager:createGUIWindow(GUIType.StaticImage, string.format("BoxRewardResult-Rewards-Background-%d", index))
  ivBackground:SetArea({0, 0}, {0, 25}, {0, Width}, {0, Width})
  ivBackground:SetHorizontalAlignment(HorizontalAlignment.Center)
  ivBackground:SetVerticalAlignment(VerticalAlignment.Center)
  ivBackground:SetImage("set:box.json image:reward_bg2")
  local eivIcon = GUIManager:createGUIWindow(GUIType.EffectViewOfObtainment, string.format("BoxRewardResult-Rewards-Icon-%d", index))
  eivIcon:SetWidth({
    0,
    Width * 0.85
  })
  eivIcon:SetHeight({
    0,
    Width * 0.85
  })
  eivIcon:SetHorizontalAlignment(HorizontalAlignment.Center)
  eivIcon:SetVerticalAlignment(VerticalAlignment.Center)
  local tvName = GUIManager:createGUIWindow(GUIType.StaticText, string.format("BoxRewardResult-Rewards-Text-%d", index))
  tvName:SetWidth({1.5, 0})
  tvName:SetHeight({0, 40})
  tvName:SetYPosition({1, 8})
  tvName:SetTextHorzAlign(HorizontalAlignment.Center)
  tvName:SetTextVertAlign(VerticalAlignment.Center)
  tvName:SetHorizontalAlignment(HorizontalAlignment.Center)
  tvName:SetTextBoader(Color.BLACK)
  tvName:SetProperty("Font", "HT14")
  tvName:SetProperty("TextWordWrap", "true")
  eivIcon:AddChildWindow(tvName)
  ivBackground:AddChildWindow(eivIcon)
  iconList[index] = eivIcon
  textList[index] = tvName
  itemList[index] = ivBackground
  parent:AddChildWindow(ivBackground)
  return ivBackground
end

function UIBoxRewardResult:onLoad()
  self.rewardIdsQueue = {}
  self.layContent = self:getChildWindow("BoxRewardResult-Content", GUIType.Layout)
  self.awResultBox = self:getChildWindow("BoxRewardResult-Box", GUIType.ActorWindow)
  self.llContinue = self:getChildWindow("BoxRewardResult-BoxOpen-Continue", GUIType.Layout)
  self.evoImage = self:getChildWindow("BoxRewardResult-Image", GUIType.EffectViewOfObtainment)
  self.stName = self:getChildWindow("BoxRewardResult-Name", GUIType.StaticText)
  self.stDes = self:getChildWindow("BoxRewardResult-Des", GUIType.StaticText)
  self.btnContinue = self:getChildWindow("BoxRewardResult-Continue", GUIType.Button)
  self.llMoreReward = self:getChildWindow("BoxRewardResult-MoreReward", GUIType.Layout)
  self.siOneReward = self:getChildWindow("BoxRewardResult-Reward-Bg", GUIType.StaticImage)
  self:updateLanguage()
  self:register()
end

function UIBoxRewardResult:updateLanguage()
  self:getChildWindow("BoxRewardResult-Continue", GUIType.Button):SetText(Lang:getString("box_lottetry_continue"))
  self:getChildWindow("BoxRewardResult-Title", GUIType.StaticText):SetText(Lang:getString("gui.chest.reward.result.title"))
end

function UIBoxRewardResult:register()
  Listener.registerCallBack(Events.OpenLotteryBoxEvent, function(id, num)
    self:onOpenLotteryBox(id, num or 1)
  end)
  self:registerDataCallBack("BoxRewardResult", function(data)
    local rewardId = data:getNumberParam("rewardId")
    if self:isShow() then
      table.insert(WaitList, rewardId)
    else
      self:onShowBoxRewardResult(rewardId)
    end
  end, DataBuilderProcessor)
  self:registerDataCallBack("BoxRewardResults", function(rewardIds)
    local rewards = StringUtil.split(rewardIds, "#")
    if self:isShow() then
      if 10 < #rewards then
        for i = 1, #rewards / 10 do
          local data = {}
          for i = 1, 10 do
            table.insert(data, rewards[1])
            table.remove(rewards, 1)
          end
          table.insert(WaitList, data)
        end
        if 0 < #rewards then
          table.insert(WaitList, rewards)
        end
      else
        table.insert(WaitList, rewards)
      end
    else
      self:onShowBoxRewardResults(rewards)
    end
  end)
  self.btnContinue:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundType.Click)
    if 0 < #WaitList then
      local rewardId = table.remove(WaitList, 1)
      LuaTimer:schedule(function()
        if type(rewardId) ~= "number" and 1 < #rewardId then
          self:onShowBoxRewardResults(rewardId)
        else
          self:onShowBoxRewardResult(rewardId)
        end
      end, 0)
      return
    end
    self:hide()
  end)
  self.llContinue:registerEvent(GUIEvent.TouchUp, function()
    SoundUtil.playSound(SoundType.Click)
    self:openDelayEnd()
  end)
end

function UIBoxRewardResult:onShowBoxRewardResult(rewardId)
  local reward = RewardConfig.findRewardById(rewardId)
  if reward == nil then
    WaitList = {}
    self:hide()
    return false
  end
  self.layContent:SetVisible(false)
  self.awResultBox:SetVisible(true)
  if self.awResultBox:IsVisible() then
    SoundUtil.playSound(SoundType.Click)
    self.awResultBox:PlaySkill("open")
    self.llContinue:SetVisible(true)
    self.openDelayKey = LuaTimer:schedule(function()
      self:openDelayEnd()
    end, 0)
  end
  self.siOneReward:SetVisible(true)
  self.llMoreReward:SetVisible(false)
  self.evoImage:SetImage(reward.Image)
  self.stName:SetText(Lang:getString(reward.Name))
  self.stDes:SetText(Lang:getString(reward.Desc))
  self:show()
end

function UIBoxRewardResult:onShowBoxRewardResults(rewardIds)
  self.layContent:SetVisible(false)
  self.awResultBox:SetVisible(true)
  if self.awResultBox:IsVisible() then
    SoundUtil.playSound(SoundType.Click)
    self.awResultBox:PlaySkill("open")
    self.llContinue:SetVisible(true)
    self.openDelayKey = LuaTimer:schedule(function()
      self:openDelayEnd()
    end, 0)
  else
    self.layContent:SetVisible(true)
  end
  self.siOneReward:SetVisible(false)
  self.llMoreReward:SetVisible(true)
  hideAllChild(self.llMoreReward)
  local Width = 110
  local Height = 110
  local SpaceX = 50
  local SpaceY = 50
  local PosX = (Width + SpaceX) * (math.min(#rewardIds, 5) - 1) / -2
  local PosY = (Height + SpaceY) * math.floor((#rewardIds - 1) / 5) / -2
  for index, rewardId in pairs(rewardIds) do
    local reward = RewardConfig.findRewardById(rewardId)
    if reward then
      local item = CreateRewardItem(index, self.llMoreReward)
      iconList[index]:SetImage(reward.Image)
      textList[index]:SetText(Lang:getString(reward.Name))
      item:SetXPosition({0, PosX})
      item:SetYPosition({0, PosY})
      item:SetVisible(true)
      PosX = PosX + Width + SpaceX
      if index % 5 == 0 then
        PosX = (Width + SpaceX) * (math.min(#rewardIds, 5) - 1) / -2
        PosY = PosY + Height + SpaceY
      end
    end
  end
  self:show()
end

function UIBoxRewardResult:openDelayEnd()
  LuaTimer:cancel(self.openDelayKey or 0)
  self.awResultBox:SetVisible(false)
  self.layContent:SetVisible(true)
  self.llContinue:SetVisible(false)
end

function UIBoxRewardResult:onOpenLotteryBox(id, num)
  local config = GUIBoxLotteryConfig:findLotteryBoxById(id)
  if config == nil or num <= 0 then
    return
  end
  local money = PlayerWallet.getMoneyByCoinId(5)
  if money < config.NeedKey * num and num > GUIBoxLottery.hasCheckNum[tostring(id)] then
    RootGuiLayout.Instance():showMainControl()
    GUIStore:show(StoreId.CubeStore, 8)
    return
  end
  CommonPacketSender:sendBedWarOpenLotteryBox(id, num)
  if string.len(config.Actor) <= 7 then
    return false
  end
  self.awResultBox:SetActor1(config.Actor, "idle", 0)
  self.awResultBox:UseBodyPart(config.ActorBody, config.ActorBodyId)
end

return UIBoxRewardResult

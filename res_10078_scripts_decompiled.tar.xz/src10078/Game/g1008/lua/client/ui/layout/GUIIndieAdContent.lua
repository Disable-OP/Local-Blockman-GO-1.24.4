local GUIIndieAdContent = class("GUIIndieAdContent", IGUILayout)

function GUIIndieAdContent:onLoad()
  self:getChildWindow("BedWarIndieAdContent-tip1", GUIType.StaticText):SetText(Lang:getString("bed.war.cube.vedio.ad.content"))
  self:getChildWindow("BedWarIndieAdContent-tip2", GUIType.StaticText):SetText(Lang:getString("bed.war.cube.vedio.ad.count"))
end

IndieAdContent = buildCustomDialogContent(GUIIndieAdContent, "BedWarIndieAdContent.json")

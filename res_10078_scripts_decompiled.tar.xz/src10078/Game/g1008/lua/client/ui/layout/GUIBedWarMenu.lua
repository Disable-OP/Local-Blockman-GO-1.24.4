local UIBedWarMenu = class("UIBedWarMenu", IGUILayout)

function UIBedWarMenu:onLoad()
  self.rbPlayerList = self:getChildWindow("Menu-Radio-Player", GUIType.RadioButton)
  self.btnResumeGame = self:getChildWindow("Menu-Radio-Resume-Game", GUIType.RadioButton)
  local menuList = GUIManager:getWindowByName("Menu-Radio-List", GUIType.Layout)
  local rbBackHall = GUIManager:getWindowByName("Menu-Radio-Back-Hall", GUIType.RadioButton)
  rbBackHall = rbBackHall or GUIManager:createGUIWindow(GUIType.RadioButton, "Menu-Radio-Back-Hall")
  rbBackHall:SetVisible(true)
  rbBackHall:SetVerticalAlignment(VerticalAlignment.Bottom)
  rbBackHall:SetArea({0, 6}, {0, -92}, {1, -12}, {0, 86})
  rbBackHall:SetNormalImage("set:new_gui_material.json image:menu_radio_nor")
  rbBackHall:SetPushedImage("set:new_gui_material.json image:menu_radio_pre")
  rbBackHall:SetProperty("StretchType", "NineGrid")
  rbBackHall:SetProperty("StretchOffset", "16 16 16 20")
  local siArrow = GUIManager:getWindowByName("Menu-Radio-Back-Hall-Arrow", GUIType.StaticImage)
  siArrow = siArrow or GUIManager:createGUIWindow(GUIType.StaticImage, "Menu-Radio-Back-Hall-Arrow")
  siArrow:SetImage("set:new_gui_material.json image:menu_radio_arrow")
  siArrow:SetVerticalAlignment(VerticalAlignment.Center)
  siArrow:SetHorizontalAlignment(HorizontalAlignment.Left)
  siArrow:SetArea({1, 0}, {0, 0}, {0, 20}, {0, 37})
  siArrow:SetVisible(false)
  local rbBackHallText = GUIManager:getWindowByName("Menu-Radio-Back-Hall-Text", GUIType.RadioButton)
  if not rbBackHallText then
    rbBackHallText = GUIManager:createGUIWindow(GUIType.RadioButton, "Menu-Radio-Back-Hall-Text")
    rbBackHall:AddChildWindow(rbBackHallText)
    rbBackHall:AddChildWindow(siArrow)
    menuList:AddChildWindow(rbBackHall)
  end
  rbBackHallText:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  rbBackHallText:SetText(Lang:getString("gui.backHall"))
  rbBackHallText:SetFont(GUIFontManager:Instance():GetFont("HT20"))
  rbBackHallText:SetProperty("TextShadow", "true")
  rbBackHallText:SetTouchable(false)
  local area = self.btnResumeGame:GetArea()
  self.btnResumeGame:SetArea({
    area.min.x[1],
    area.min.x[2]
  }, {
    area.min.y[1],
    area.min.y[2] - 86
  }, {1, -12}, {0, 86})
  rbBackHall:registerEvent(GUIEvent.RadioStateChanged, function()
    if rbBackHall:IsSelected() then
      self.rbPlayerList:SetSelected(true)
      GUIManager:hideWindowByName("Menu.json")
      CustomDialog.builder().setTitleText("gui_dialog_tip_title_tip").setRightText(Lang:getString("gui_dialog_tip_btn_sure")).setContentText(Lang:getString("gui_bed_war_mane_back_hall_tip")).setRightClickListener(function()
        GamePacketSender:sendBackHall()
      end).setLeftText(Lang:getString("gui_dialog_tip_btn_cancel")).show()
    end
  end)
end

return UIBedWarMenu

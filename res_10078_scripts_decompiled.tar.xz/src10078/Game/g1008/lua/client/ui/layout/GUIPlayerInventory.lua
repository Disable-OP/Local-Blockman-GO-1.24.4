local function hideEngineWindow(name)
  local window = GUIManager:getWindowByName(name)
  
  if not window then
    return
  end
  window:SetXPosition({0, 6000})
  window:SetVisible(false)
end

local UIPlayerInventory = class("GUIPlayerInventory", IGUILayout)

function UIPlayerInventory:onLoad()
  local screenWidth = self:getChildWindow("PlayerInventory"):GetPixelSize().x
  screenWidth = math.min(math.max(screenWidth - 352, 900), screenWidth)
  local llInventory = self:getChildWindow("PlayerInventory-Inventory")
  llInventory:SetArea({0, 0}, {0, 53}, {0, screenWidth}, {1, -167})
  local ivTitle = self:getChildWindow("PlayerInventory-Page-Title-Bg", GUIType.StaticImage)
  ivTitle:SetArea({0, 0}, {0, 0}, {1, 0}, {0, 57})
  ivTitle:SetProperty("StretchOffset", "20 20 20 20")
  ivTitle:SetImage("set:bed_war_player_inventory.json image:title")
  local ivClose = self:getChildWindow("PlayerInventory-CloseButton", GUIType.StaticImage)
  ivClose:SetArea({1, -57}, {0, 0}, {0, 40}, {0, 40})
  ivClose:SetImage("set:bed_war_block_shop.json image:close")
  local tvTitle = self:getChildWindow("PlayerInventory-Title", GUIType.StaticText)
  tvTitle:SetArea({0, 0}, {0, 0}, {0, 400}, {0, 57})
  local llPanel = self:getChildWindow("PlayerInventory-InventoryPanel", GUIType.Layout)
  llPanel:SetProperty("StretchOffset", "15 15 1 20")
  llPanel:SetBackImage("set:bed_war_player_inventory.json image:bg_base")
  hideEngineWindow("PlayerInventory-ArmorTab")
end

local cd_itemId = 0
local cd_totalTime = 0
local cd_curTime = 0

function UIPlayerInventory:UpdateItemCd(itemId, totalTime, curTime)
  cd_itemId = itemId
  cd_totalTime = totalTime * 1000
  cd_curTime = curTime * 1000
end

function UIPlayerInventory:onTick(frameTime)
  if cd_curTime <= 0 then
    return
  end
  cd_curTime = cd_curTime - frameTime
  if cd_curTime < 0 then
    cd_curTime = 0
  end
  local slotTable = self:getChildWindow("Main-VisibleBar-SlotTable", GUIType.SlotTable)
  local inv = Game:getPlayer():getInventory()
  for i = 0, 8 do
    local info = inv:getHotBarInventory(i)
    if info and info.id == tonumber(cd_itemId) then
      local itemSlot = slotTable:GetItemSlot(0, i)
      if GuiItemSlot.setItemSkillCdProgress ~= nil then
        itemSlot:setItemSkillCdProgress(cd_curTime, cd_totalTime)
      end
    end
  end
end

return UIPlayerInventory

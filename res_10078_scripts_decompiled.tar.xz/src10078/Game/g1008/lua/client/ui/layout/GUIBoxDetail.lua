require("ui..window.GUILotteryBoxItem")
local UIBoxDetail = class("UILotteryBoxDetail", IGUILayout)

function UIBoxDetail:onLoad()
  self.btnClose = self:getChildWindow("LotteryBoxDetail-Close", GUIType.Button)
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundType.Click)
    self:hide()
  end)
end

function UIBoxDetail:updateUIByType(Type)
  local data = GUIBoxLotteryConfig:findLotteryBoxByType(Type)
  self:getChildWindow("LotteryBoxDetail-Title", GUIType.StaticText):SetText(Lang:getString(data.Name))
end

function UIBoxDetail:showDetail(type)
  self:updateUIByType(type)
  local LotteryBoxDetail = self:getChildWindow("LotteryBoxDetail-Reward-Items", GUIType.Layout)
  LotteryBoxDetail:CleanupChildren()
  local gvItems = IGUIGridView.new("LotteryBoxDetail-Item", LotteryBoxDetail)
  gvItems:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  gvItems:setConfig(6, 6, 7)
  gvItems.root:SetHorizontalAlignment(HorizontalAlignment.Center)
  gvItems.root:SetVerticalAlignment(VerticalAlignment.Center)
  local ContentSize = LotteryBoxDetail:GetPixelSize().x
  local itemHeightandHeight = (ContentSize - 36) / 7
  local Boxs = GUIBoxLotteryConfig:findLotteryBoxRewardByType(type)
  table.sort(Boxs, function(a, b)
    if a.Id < b.Id then
      return true
    end
    return false
  end)
  for _, box in pairs(Boxs) do
    local LotteryBox = RewardConfig.findRewardById(box.RewardId)
    local Item = UIHelper.newGameGUIWindow("GUILotteryBoxItem", "LotteryBoxItem.json")
    Item:setWidth({0, itemHeightandHeight})
    Item:setHeight({0, itemHeightandHeight})
    Item:onSetImage(LotteryBox.Image)
    Item:registerClick(box.RewardId)
    if box.IsCore == 1 then
      Item.bg:SetImage("set:box.json image:reward_bg1_big")
    else
      Item.bg:SetImage("set:box.json image:reward_bg1")
    end
    gvItems:addItem(Item)
  end
  self:show()
end

return UIBoxDetail

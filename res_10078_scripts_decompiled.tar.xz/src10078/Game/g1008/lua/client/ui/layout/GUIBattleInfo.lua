local TabColor = {
  Normal = {
    0.486275,
    0.537255,
    0.603922,
    1
  },
  Select = {
    0.866667,
    0.992157,
    1,
    1
  }
}
local UIBattleInfo = class("GUIBattleInfo", IGUILayout)

function UIBattleInfo:onLoad()
  self.llOutSize = self:getChildWindow("BedWarBattleInfo-OutSize", GUIType.Layout)
  self.llOutSize:registerEvent(GUIEvent.TouchUp, function()
    self:hide(true)
  end)
  self.btnClose = self:getChildWindow("BedWarBattleInfo-Close", GUIType.Button)
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide(true)
  end)
  self.battleInfo = {}
  self.tabs = {}
  self.tabTimerKey1 = nil
  self.tabTimerKey2 = nil
end

function UIBattleInfo:isShowAnim()
  return false
end

function UIBattleInfo:show(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.openBattle)
  end
  self.super.show(self)
end

function UIBattleInfo:hide(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.closeBattle)
  end
  self.super.hide(self)
end

function UIBattleInfo:onGameStart()
  local llTeamInfo = self:getChildWindow("BedWarBattleInfo-Team-Info")
  llTeamInfo:CleanupChildren()
  self.battleInfo = {}
  self.tabs = {}
  self.leftTeamInfo = UIHelper.newGameGUIWindow("GUIBattleTeamInfo", "BedWarBattleTeamInfo.json")
  local contentWidth = llTeamInfo:GetPixelSize().x
  local contentHeight = llTeamInfo:GetPixelSize().y
  local teamInfoWidth = (contentWidth - 20) / 2
  self.leftTeamInfo.root:SetWidth({0, teamInfoWidth})
  self.leftTeamInfo.root:SetHeight({0, contentHeight})
  self.leftTeamInfo.root:SetXPosition({0, 10})
  self.leftTeamInfo:initPlayers()
  llTeamInfo:AddChildWindow(self.leftTeamInfo.root)
  self.rightTeamInfo = UIHelper.newGameGUIWindow("GUIBattleTeamInfo", "BedWarBattleTeamInfo.json")
  self.rightTeamInfo.root:SetWidth({0, teamInfoWidth})
  self.rightTeamInfo.root:SetHeight({0, contentHeight})
  self.rightTeamInfo.root:SetXPosition({0, -10})
  self.rightTeamInfo.root:SetHorizontalAlignment(HorizontalAlignment.Right)
  self.rightTeamInfo:initPlayers()
  self.rightTeamInfo:setRightLayout()
  llTeamInfo:AddChildWindow(self.rightTeamInfo.root)
  local teamIds = {}
  local userIds = UserManager.Instance():getAllUser()
  local selfTeamId = "0"
  for _, userId in pairs(userIds) do
    local info = GameInfoManager:getPlayerInfo(userId)
    if not info then
      GameInfoManager:newPlayerInfo(userId)
      info = GameInfoManager:getPlayerInfo(userId)
    end
    local teamId = info:getValue("teamId")
    if tonumber(teamId) >= 1 and tonumber(teamId) <= 4 then
      if teamIds[teamId] == nil then
        teamIds[teamId] = tonumber(teamId)
      end
      local battleInfo = self.battleInfo[teamId]
      if not battleInfo then
        battleInfo = {
          teamId = tonumber(teamId),
          players = {}
        }
        self.battleInfo[teamId] = battleInfo
      end
      local data = {userId = userId, info = info}
      if tostring(userId) == tostring(Game:getPlatformUserId()) then
        selfTeamId = teamId
      end
      table.insert(battleInfo.players, data)
      GameInfoManager:registerObserver(tostring(userId), function(_)
        self.leftTeamInfo:updateTeamInfo()
        self.leftTeamInfo.adapter:notifyItemDataChange(data)
        self.rightTeamInfo:updateTeamInfo()
        self.rightTeamInfo.adapter:notifyItemDataChange(data)
      end)
    end
  end
  local battleInfo = self.battleInfo[selfTeamId]
  if battleInfo then
    local me
    for pos, player in pairs(battleInfo.players) do
      if tostring(player.userId) == tostring(Game:getPlatformUserId()) then
        me = player
        table.remove(battleInfo.players, pos)
        break
      end
    end
    table.insert(battleInfo.players, 1, me)
    self.leftTeamInfo:setTeamInfo(battleInfo)
    local ivMyTeamIcon = self:getChildWindow("BedWarBattleInfo-My-Team-Icon", GUIType.StaticImage)
    ivMyTeamIcon:SetImage(TeamGUIInfo[selfTeamId].tab_icon)
  end
  teamIds[selfTeamId] = nil
  local ids = {}
  for _, teamId in pairs(teamIds) do
    table.insert(ids, teamId)
  end
  if #ids ~= 0 then
    self.rightTeamInfo:setTeamInfo(self.battleInfo[ids[1]])
  end
  for i = 1, 3 do
    local teamId = ids[i]
    local cbTab = self:getChildWindow("BedWarBattleInfo-Team-Tab" .. tostring(i), GUIType.CheckBox)
    if teamId ~= nil then
      cbTab:registerEvent(GUIEvent.CheckStateChanged, function()
        local checked = cbTab:GetChecked()
        if checked then
          cbTab:SetTextColor(TabColor.Select)
          for _, tab in pairs(self.tabs) do
            if tab.teamId == teamId then
              tab.icon:SetImage(TeamGUIInfo[tostring(tab.teamId)].tab_icon)
            else
              tab.icon:SetImage(TeamGUIInfo[tostring(tab.teamId)].tab_icon_normal)
            end
            tab.checkbox:SetChecked(tab.teamId == teamId)
          end
          LuaTimer:cancel(self.tabTimerKey1)
          LuaTimer:cancel(self.tabTimerKey2)
          self.rightTeamInfo.root:SetAlpha(1)
          self.tabTimerKey1 = LuaTimer:scheduleTimerWithEnd(function()
            self.rightTeamInfo.root:SetAlpha(self.rightTeamInfo.root:GetAlpha() - 0.08)
          end, function()
            self.rightTeamInfo:setTeamInfo(self.battleInfo[tostring(teamId)])
            self.tabTimerKey2 = LuaTimer:scheduleTimer(function()
              self.rightTeamInfo.root:SetAlpha(self.rightTeamInfo.root:GetAlpha() + 0.08)
            end, 20, 12)
          end, 20, 12)
          SoundUtil.playSound(self.selectTabSound)
        else
          local needCheck = true
          for _, tab in pairs(self.tabs) do
            if tab.checkbox:GetChecked() then
              needCheck = false
            end
          end
          if needCheck then
            cbTab:SetChecked(true)
            return
          end
          cbTab:SetTextColor(TabColor.Normal)
        end
      end)
      if i == 1 then
        LuaTimer:schedule(function()
          cbTab:SetChecked(true)
          self.selectTabSound = SoundConfig.selectTabBattle
        end, 0)
      end
      local ivTabIcon = self:getChildWindow("BedWarBattleInfo-Tab-Icon" .. tostring(i), GUIType.StaticImage)
      ivTabIcon:SetImage(TeamGUIInfo[tostring(teamId)].tab_icon)
      self.tabs[tostring(teamId)] = {
        checkbox = cbTab,
        icon = ivTabIcon,
        teamId = teamId
      }
    else
      cbTab:SetVisible(false)
    end
  end
end

function UIBattleInfo:updatePlayerListUI()
  if self.leftTeamInfo then
    self.leftTeamInfo.adapter:notifyDataChange()
  end
  if self.rightTeamInfo then
    self.rightTeamInfo.adapter:notifyDataChange()
  end
end

return UIBattleInfo

local UIUtils = T(Global, "UIUtils")
local UISettlementSingle = class("UISettlementSingle", IGUILayout)

function UISettlementSingle:onLoad()
  self.btBack = self:getChildWindow("SettlementSingle-Back", GUIType.Button)
  self.btWatch = self:getChildWindow("SettlementSingle-Watch", GUIType.Button)
  self.btAgain = self:getChildWindow("SettlementSingle-PlayAgain", GUIType.Button)
  self.btExit = self:getChildWindow("SettlementSingle-Exit", GUIType.Button)
  self.btNext = self:getChildWindow("SettlementSingle-Next", GUIType.Button)
  self.btShare = self:getChildWindow("SettlementSingle-Share", GUIType.Button)
  self.btShare:SetVisible(not Game:isChina() and not Game:isEnableIndie())
  self.llShare = self:getChildWindow("SettlementSingle-Share-Hide", GUIType.Layout)
  self.uivHeadIcon = self:getChildWindow("SettlementSingle-HeadIcon", GUIType.UrlImage)
  self.uivHeadIcon:setChildMaterial(0)
  self.btDoubleAd = self:getChildWindow("SettlementSingle-Key-Double-Ad", GUIType.Button)
  self.btRankProtect = self:getChildWindow("SettlementSingle-Rank-Protect-Ad", GUIType.Button)
  self.siBackTip = self:getChildWindow("SettlementSingle-Back-Tip", GUIType.StaticImage)
  self:getChildWindow("SettlementSingle-Back-Text", GUIType.StaticText):SetText(Lang:getString("gui.backHall"))
  self:getChildWindow("SettlementSingle-Watch-Text", GUIType.StaticText):SetText(Lang:getString("gui.watch"))
  self:getChildWindow("SettlementSingle-PlayAgain-Text", GUIType.StaticText):SetText(Lang:getString("gui.playAgain"))
  self:getChildWindow("SettlementSingle-Exit-Text", GUIType.StaticText):SetText(Lang:getString("wordart_exit_game"))
  self:getChildWindow("SettlementSingle-Next-Text", GUIType.StaticText):SetText(Lang:getString("gui.next"))
  self.stBackTip = self:getChildWindow("SettlementSingle-Back-Tip-Text", GUIType.StaticText)
  self.isDoubleKey = false
  self:initRegister()
end

function UISettlementSingle:initRegister()
  self:registerDataCallBack("SingleSettlement", function(data)
    isGameEnd = true
    RootGuiLayout.Instance():showMainControl()
    self:updateInfo(data)
    SoundUtil.playSound(SoundConfig.nextSettlement)
    GUISettlementSingle:show()
  end, DataBuilderProcessor)
  self.btBack:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.backHallSettlement)
    GamePacketSender:sendBackHall()
  end)
  self.btAgain:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.againSettlement)
    GamePacketSender:sendPlayAgain(Game:getPlatformUserId())
  end)
  self.btNext:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.nextSettlement)
    if TeamConfig:getTeamCount() > 4 then
      GUIResult8P:show()
    else
      GUIResult:show()
    end
  end)
  self.btWatch:registerEvent(GUIEvent.ButtonClick, function()
    GUIManager:getWindowByName("BedWarGameMain-MenuList-ShortMessage"):SetVisible(false)
    GUIBedWarToolBar.btnBackHall:SetVisible(true)
    GUIBedWarToolBar.btnPlayerAgain:SetVisible(true)
    RootGuiLayout.Instance():showMainControl()
  end)
  self.btExit:registerEvent(GUIEvent.ButtonClick, function()
    GUIBedWarSetting:onClickExit()
  end)
  self.btDoubleAd:registerEvent(GUIEvent.ButtonClick, function()
    if WatchADSwitch:getSwitchBoolByType(5) then
      WatchAdTip.init().setContentVisible(false).SetYPosition({0, -20}).setTitle("gui_bed_war_free_gift_tip_title").setTipText("gui_bed_war_settlement_single_double_key").banJumpToShop().show(Define.AdType.DoubleKey)
    else
      ClientHelper.onWatchAd(Define.AdType.DoubleKey)
    end
    SoundUtil.playSound(SoundType.Click)
  end)
  self.btRankProtect:registerEvent(GUIEvent.ButtonClick, function()
    if WatchADSwitch:getSwitchBoolByType(4) then
      WatchAdTip.init().setContentVisible(false).SetYPosition({0, -20}).setTipText("gui_bed_war_settlement_single_rank_protect").setTitle("gui_bed_war_free_gift_tip_title").banJumpToShop().show(Define.AdType.RankHonourProtect)
    end
  end)
  self:registerDataCallBack("KeyAdSettlementSingle", function(data)
    self:onWatchAd(data)
  end)
  self.btShare:registerEvent(GUIEvent.ButtonClick, function()
    if isTest then
      self:hide()
    else
      self:onShare(true)
    end
  end)
end

function UISettlementSingle:onShare(open)
  if open then
    self.isShare = true
    self.llShare:SetVisible(false)
    self.btDoubleAd:SetVisible(false)
    self.btRankProtect:SetVisible(false)
    ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_SCREEN_CAPTURE)
  else
    self.isShare = false
    self.llShare:SetVisible(true)
    self.btDoubleAd:SetVisible(true)
    self.btRankProtect:SetVisible(true)
  end
end

function UISettlementSingle:show(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.openSettlement)
  end
  self.super.show(self)
end

function UISettlementSingle:onShow()
  if GUICommunitySharing and not ClientHelper.getBoolForKey("g1008_CommunitySharing") then
    ClientHelper.putBoolForKey("g1008_CommunitySharing", true)
    GUICommunitySharing:show()
  end
end

function UISettlementSingle:updateInfo(data)
  local info = GameInfoManager:getPlayerInfo(Game:getPlatformUserId())
  if not info then
    return
  end
  local bg = self:getChildWindow("SettlementSingle-Bg")
  local totalWidth = math.min(bg:GetPixelSize().x)
  local totalHeight = math.min(bg:GetPixelSize().y)
  if 3.1683168316831685 < totalWidth / totalHeight then
    totalWidth = totalHeight / 404 * 1280
  else
    totalHeight = totalWidth / 1280 * 404
  end
  self:getChildWindow("SettlementSingle-Content"):SetArea({0, 0}, {0, 0}, {0, totalWidth}, {0, totalHeight})
  local rank = tonumber(info:getValue("rank"))
  local honorId = data:getNumberParam("honorId") or 0
  honorId = honorId + 1
  local rewardExp = data:getNumberParam("rewardExp") or 0
  local cupExp = data:getNumberParam("cupExp") or 0
  local maxExp = data:getNumberParam("maxExp") or 0
  local level = data:getNumberParam("level") or 1
  local key = data:getNumberParam("key") or 0
  local honour = data:getNumberParam("honour") or 1
  local isEnd = data:getBoolParam("isEnd") or false
  local watchAd = data:getBoolParam("watchAd") or false
  local iconConfig = TeamGUIInfo[info:getValue("teamId")]
  self.uivHeadIcon:setDefaultImage(iconConfig.header)
  self.uivHeadIcon:setUrl(info:getValue("picUrl"))
  self:getChildWindow("SettlementSingle-Name", GUIType.StaticText):SetText(info:getValue("userName"))
  self:getChildWindow("SettlementSingle-Border", GUIType.StaticImage):SetImage(iconConfig.header_border2)
  self:getChildWindow("SettlementSingle-Kill-Text", GUIType.StaticText):SetText(info:getValue("kill"))
  self:getChildWindow("SettlementSingle-Die-Text", GUIType.StaticText):SetText(info:getValue("die"))
  self:getChildWindow("SettlementSingle-Assist-Text", GUIType.StaticText):SetText(info:getValue("assist"))
  self:getChildWindow("SettlementSingle-KDA-Text", GUIType.StaticText):SetText(info:getKDA())
  self:getChildWindow("SettlementSingle-RewardExp", GUIType.StaticText):SetText(string.format("+%d", rewardExp))
  self:getChildWindow("SettlementSingle-Key-Text", GUIType.StaticText):SetText(string.format("+%d", key))
  self:getChildWindow("SettlementSingle-Honor-Text", GUIType.StaticText):SetText(string.format("+%d", honour))
  self:getChildWindow("SettlementSingle-Key-Text", GUIType.StaticText):SetTextColor({
    0.7803921568627451,
    0.8352941176470589,
    0.8862745098039215,
    1
  })
  if honour < 0 then
    self:getChildWindow("SettlementSingle-Honor-Text", GUIType.StaticText):SetText(honour)
    self:getChildWindow("SettlementSingle-Rank-Protect-Ad-Text", GUIType.StaticText):SetText("+ " .. -honour)
    self.btRankProtect:SetVisible(true)
  else
    self.btRankProtect:SetVisible(false)
  end
  if watchAd then
    self:getChildWindow("SettlementSingle-Honor-Text", GUIType.StaticText):SetTextColor(Color.GREEN)
  end
  self:getChildWindow("SettlementSingle-Honor-Icon", GUIType.StaticImage):SetImage(string.format("set:bedwar_season_rule.json image:ic_honor_lv%d", honorId))
  self:getChildWindow("SettlementSingle-Level", GUIType.StaticText):SetText("Lv" .. level)
  if cupExp < maxExp then
    self:getChildWindow("SettlementSingle-ExpBar", GUIType.ProgressBar):SetProgress(cupExp / maxExp)
  else
    self:getChildWindow("SettlementSingle-ExpBar", GUIType.ProgressBar):SetProgress("Max")
  end
  self:getChildWindow("SettlementSingle-Exp-Text", GUIType.StaticText):SetText(tostring(cupExp) .. "/" .. maxExp)
  local rewardKey = "g1008DailyReward" .. tostring(PlayerManager:getClientPlayer().userId)
  local showBackTip = ClientHelper.getStringForKey(rewardKey, "")
  challenge = TreasureChallenge:updateRedPoint()
  if showBackTip ~= DateUtil.getYearDay() or GUILicense:showRedPoint() or challenge then
    self.siBackTip:SetVisible(true)
    self.stBackTip:SetText(Lang:getString("gui_to_get_reward"), true)
    local line = math.floor(self.stBackTip:GetTextWidth() / 300) + 1
    self.siBackTip:SetHeight({
      0,
      math.max(self.stBackTip:GetFont():GetFontHeight() * line + 20, 60)
    })
    GUIResult.siBackTip:SetVisible(true)
    GUIResult8P.siBackTip:SetVisible(true)
  else
    self.siBackTip:SetVisible(false)
  end
  if isEnd then
    self:getChildWindow("SettlementSingle-Buttons"):SetVisible(false)
    self:getChildWindow("SettlementSingle-Buttons-End"):SetVisible(true)
    if TeamConfig:getTeamCount() > 4 then
      GUIResult8P:onUpdateUI()
    else
      GUIResult:onUpdateUI()
    end
  else
    local teamId = info:getValue("teamId")
    local teamInfo = GameInfoManager:getTeamInfo(teamId)
    if not teamInfo or 0 < tonumber(teamInfo:getValue("liveCount")) then
    else
    end
  end
  self:setRankNum(rank)
end

function UISettlementSingle:onTick()
  if not self.isShare then
    self.btDoubleAd:SetVisible(not self.isDoubleKey)
  end
end

function UISettlementSingle:onShow()
  self:onTick()
  if self.btDoubleAd:IsVisible() then
    ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ADS_PLACEMENT, Define.AdType.DoubleKey)
  end
end

function UISettlementSingle:onWatchAd(data)
  local builder = DataBuilder.new():fromData(data)
  local key = builder:getNumberParam("key")
  local stKey = self:getChildWindow("SettlementSingle-Key-Text", GUIType.StaticText)
  stKey:SetText(string.format("+%d", key))
  stKey:SetTextColor(Color.GREEN)
  self.isDoubleKey = true
  self.btDoubleAd:SetVisible(false)
end

function UISettlementSingle:onRankProtect(data)
end

function UISettlementSingle:setRankNum(rank)
  local numberLayout = self:getChildWindow("SettlementSingle-RankNum-Layout", GUIType.Layout)
  if 10 <= rank then
    numberLayout:SetHeight({0.45, 0})
  else
    numberLayout:SetHeight({0.5, 0})
  end
  UIUtils.setNumberToLayout(rank, numberLayout)
end

return UISettlementSingle

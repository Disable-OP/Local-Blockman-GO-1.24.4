local UIUpgradeStore = class("UIUpgradeStore", IGUILayout)

function UIUpgradeStore:onLoad()
  self.curShowType = 0
  self.curSelectGoods = nil
  self.curTipKey = nil
  local llMain = self:getChildWindow("BedWarUpgradeStore-Main", GUIType.Layout)
  local size = llMain:GetPixelSize()
  local width = math.min(size.y / 574 * 1138, size.x)
  llMain:SetWidth({0, width})
  local llMoney = self:getChildWindow("BedWarUpgradeStore-Money", GUIType.Layout)
  self.lvMoney = IGUIListView.new("BedWarUpgradeStore-Money-List", llMoney, nil, Orientation.Horizontal)
  self.lvMoney:setItemSpace(15)
  local llGoodsList = self:getChildWindow("BedWarUpgradeStore-GoodsList", GUIType.Layout)
  self.lvGoodsList = IGUIListView.new("BedWarUpgradeStore-Goods-List", llGoodsList, nil, Orientation.Horizontal)
  self.lvGoodsList:setItemSpace(10)
  self.goodsAdapter = UIHelper.newGameAdapter("UpgradeGoodsAdapter")
  local height = self.lvGoodsList:getHeight()
  local width = height / 117 * 136
  self.goodsAdapter:setItemSize(width, height)
  self.lvGoodsList:setAdapter(self.goodsAdapter)
  local llGoodsGroup = self:getChildWindow("BedWarUpgradeStore-Group-BG")
  local lvGoodsGroup = IGUIListView.new("BedWarUpgradeStore-Group-List", llGoodsGroup)
  lvGoodsGroup:setArea({0, 12}, {0, 12}, {1, -24}, {1, -24})
  lvGoodsGroup:setItemSpace(10)
  local contentWidth = lvGoodsGroup:getWidth()
  self.goodsGroupAdapter = UIHelper.newGameAdapter("UpgradeGoodsDescAdapter")
  self.goodsGroupAdapter:setItemSize(contentWidth, 57)
  lvGoodsGroup:setAdapter(self.goodsGroupAdapter)
  local tvTitleText = self:getChildWindow("BedWarUpgradeStore-Title-Text", GUIType.StaticText)
  tvTitleText:SetText(Lang:getString("gui_bed_war_lvshop_title"))
  self.tvGoodsName = self:getChildWindow("BedWarUpgradeStore-Goods-Name", GUIType.StaticText)
  self.ivGoodsImage = self:getChildWindow("BedWarUpgradeStore-Goods-Image", GUIType.StaticImage)
  self.btnGoodsBuy = self:getChildWindow("BedWarUpgradeStore-Goods-Buy", GUIType.Button)
  self.ivGoodsMoneyIcon = self:getChildWindow("BedWarUpgradeStore-Goods-Price-Icon", GUIType.StaticImage)
  self.tvGoodsMoneyText = self:getChildWindow("BedWarUpgradeStore-Goods-Price-Text", GUIType.StaticText)
  self.tvTips = self:getChildWindow("BedWarUpgradeStore-Tips", GUIType.StaticText)
  self.tvTips:SetVisible(false)
  local btnClose = self:getChildWindow("BedWarUpgradeStore-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide(true)
  end)
  local btnCloseMask = self:getChildWindow("BedWarUpgradeStore-Close-Mask", GUIType.Button)
  btnCloseMask:registerEvent(GUIEvent.ButtonClick, function()
    self:hide(true)
  end)
  self.btnGoodsBuy:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.buyGoodsStore)
    self:onBuyGoods(self.curSelectGoods)
  end)
end

function UIUpgradeStore:isShowAnim()
  return false
end

function UIUpgradeStore:show(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.openStore)
  end
  self.super.show(self, playSound)
end

function UIUpgradeStore:hide(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.closeStore)
  end
  self.super.hide(self)
end

function UIUpgradeStore:onBuyGoodsSuccess(goods)
  local count = GoodsStorePrivilege:onBuyGoods(goods)
  if #goods.Image > 10 then
    HostApi.notifyGetGoods(goods.Image, count)
  else
    HostApi.notifyGetItem(goods.ItemId, 0, count)
  end
end

function UIUpgradeStore:updateListUI()
  if not self:isShow() then
    return
  end
  if not self.curSelectGoods then
    return
  end
  local info = GameInfoManager:getTeamInfo(Game:getPlayer():getTeamId())
  if not info then
    return
  end
  local level = tonumber(info:getValue(self.curSelectGoods.ItemId))
  if level ~= self.curSelectGoods.Level - 1 then
    local _goods = StoreConfig:getUpgradeGoods(self.curSelectGoods.ItemId, self.curSelectGoods.Level + 1)
    if _goods then
      self:showGoodsDetail(_goods)
    end
  end
  self.goodsAdapter:notifyDataChange()
  self.goodsGroupAdapter:notifyDataChange()
end

function UIUpgradeStore:onTick()
  for _, item in pairs(self.lvMoney.items) do
    item:onTick()
  end
end

function UIUpgradeStore:onShow()
  self:updateListUI()
  if self.curSelectGoods then
    return
  end
  local config = StoreConfig:getStoreConfig(StoreId.UpgradeStore)
  if not config then
    return
  end
  self.lvMoney:clearItems()
  for _, data in pairs(config.CurrencyList) do
    local money = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
    money:onDataChanged(data)
    self.lvMoney:addItem(money)
  end
  if #config.Tabs > 0 then
    if 1 < #config.Tabs[1].GoodsList then
      self:showGoodsDetail(config.Tabs[1].GoodsList[1])
    end
    self.goodsAdapter:setData(config.Tabs[1].GoodsList)
  end
end

function UIUpgradeStore:onTick()
  for _, item in pairs(self.lvMoney.items) do
    item:onTick()
  end
end

function UIUpgradeStore:showGoodsDetail(goods)
  if self.curSelectGoods == goods then
    return
  end
  local oldGoods = self.curSelectGoods
  self.curSelectGoods = nil
  self.goodsAdapter:notifyItemDataChange(oldGoods)
  self.curSelectGoods = goods
  ClientStore:setGoodsUI(self.tvGoodsName, self.ivGoodsImage, self.ivGoodsMoneyIcon, self.tvGoodsMoneyText, self.btnGoodsBuy, goods)
  self.goodsAdapter:notifyItemDataChange(goods)
  local group = StoreConfig:getGoodsGroup(self.curSelectGoods.LevelGroup)
  self.goodsGroupAdapter:setData(group)
  GameAnalytics:design(1, {
    "select_upgradeshop",
    tostring(goods.Id)
  })
end

function UIUpgradeStore:getCurrentGoodsId()
  if self.curSelectGoods then
    return self.curSelectGoods.Id
  end
  return 0
end

function UIUpgradeStore:showTips(tips)
  self.tvTips:SetText(tips)
  self.tvTips:SetVisible(true)
  LuaTimer:cancel(self.curTipKey)
  self.curTipKey = LuaTimer:schedule(function()
    self.tvTips:SetVisible(false)
  end, 1000)
end

function UIUpgradeStore:onBuyGoods(goods)
  ClientStore:onBuyGoods(goods, function(success, tips)
    if tips and 0 < #tips then
      self:showTips(tips)
    end
  end)
end

return UIUpgradeStore

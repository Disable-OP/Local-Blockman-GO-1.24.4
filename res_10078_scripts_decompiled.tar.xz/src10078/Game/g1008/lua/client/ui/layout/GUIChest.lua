local UIChest = class("GUIChest", IGUILayout)

function UIChest:onLoad()
  local screenWidth = self:getChildWindow("Chest"):GetPixelSize().x
  screenWidth = math.min(math.max(screenWidth - 352, 900), screenWidth)
  local llContent = self:getChildWindow("Chest-Content")
  llContent:SetArea({0, 0}, {0.105556, 0}, {0, screenWidth}, {0.788889, 0})
  llContent:SetHorizontalAlignment(HorizontalAlignment.Center)
  local ivTitle = self:getChildWindow("Chest-Content-Title", GUIType.Layout)
  ivTitle:SetArea({0, 0}, {0, 0}, {1, 0}, {0, 57})
  ivTitle:SetProperty("StretchOffset", "20 20 20 20")
  ivTitle:SetBackImage("set:bed_war_player_inventory.json image:title")
  local ivClose = self:getChildWindow("Chest-Btn-Quit", GUIType.Button)
  ivClose:SetArea({1, -57}, {0, 0}, {0, 40}, {0, 40})
  ivClose:SetNormalImage("set:bed_war_block_shop.json image:close")
  ivClose:SetPushedImage("set:bed_war_block_shop.json image:close")
  local tvInventoryTitle = self:getChildWindow("Chest-Content-Inventory-Title", GUIType.StaticText)
  tvInventoryTitle:SetArea({0, 0}, {0, 0}, {0.5, 0}, {0, 57})
  local tvChestTitle = self:getChildWindow("Chest-Content-Chest-Title", GUIType.StaticText)
  tvChestTitle:SetArea({0, 0}, {0, 0}, {0.5, 0}, {0, 57})
  local llPanel = self:getChildWindow("Chest-Content-Panel", GUIType.Layout)
  llPanel:SetArea({0, 0}, {0, 57}, {1, 0}, {1, -57})
  llPanel:SetProperty("StretchOffset", "15 15 1 20")
  llPanel:SetBackImage("set:bed_war_player_inventory.json image:bg_base")
  local ivCenterIcon = self:getChildWindow("Chest-Content-Title-Centre-Icon", GUIType.StaticImage)
  ivCenterIcon:SetVisible(false)
  local llInventoryBg = self:getChildWindow("Chest-Content-Inventory-bg", GUIType.StaticImage)
  llInventoryBg:SetArea({0, 15}, {0, 15}, {0.5, -22}, {1, -30})
  llInventoryBg:SetImage("set:bed_war_player_inventory.json image:inventory_bg")
  local llChestBg = self:getChildWindow("Chest-Content-Chest-bg", GUIType.StaticImage)
  llChestBg:SetArea({0, -15}, {0, 15}, {0.5, -22}, {1, -30})
  llChestBg:SetImage("set:bed_war_player_inventory.json image:inventory_bg")
  local siInventory = self:getChildWindow("Chest-Content-Inventory", GUIType.ScrollableInventory)
  local siChest = self:getChildWindow("Chest-Content-Chest", GUIType.ScrollableInventory)
  local contentWidth = siInventory:GetPixelSize().x
  local columnCount = 12
  local itemWidth = 60
  while contentWidth < (itemWidth + 5) * columnCount - 5 do
    columnCount = columnCount - 1
  end
  local interval = (contentWidth - itemWidth * columnCount) / (columnCount - 1)
  siInventory:SetProperty("SlotWidth", itemWidth)
  siInventory:SetProperty("SlotHeight", itemWidth)
  siInventory:SetProperty("HorizontalInterval", interval)
  siInventory:SetProperty("VerticalInterval", interval)
  siInventory:SetProperty("ColumnCount", columnCount)
  siInventory:SetProperty("SlotStyle", "10002")
  siChest:SetProperty("SlotWidth", itemWidth)
  siChest:SetProperty("SlotHeight", itemWidth)
  siChest:SetProperty("HorizontalInterval", interval)
  siChest:SetProperty("VerticalInterval", interval)
  siChest:SetProperty("ColumnCount", columnCount)
  siChest:SetProperty("SlotStyle", "10002")
end

return UIChest

local UIBoxRewardDetail = class("UIBoxRewardDetail", IGUILayout)

function UIBoxRewardDetail:onLoad()
  self.stTitle = self:getChildWindow("BoxRewardDetail-Title", GUIType.StaticText)
  self.siImage = self:getChildWindow("BoxRewardDetail-Image", GUIType.StaticImage)
  self.stName = self:getChildWindow("BoxRewardDetail-Name", GUIType.StaticText)
  self.stDesc = self:getChildWindow("BoxRewardDetail-Desc", GUIType.StaticText)
  self.btnBack = self:getChildWindow("BoxRewardDetail-Back", GUIType.Button)
  self.btnBack:registerEvent(GUIEvent.ButtonClick, function()
    GUIBoxRewardDetail:hide()
  end)
end

function UIBoxRewardDetail:onShow(config)
  self:setConfig(config)
end

function UIBoxRewardDetail:setConfig(config)
  self.stTitle:SetText(Lang:getString(config.Title))
  self.siImage:SetImage(config.Image)
  self.stName:SetText(Lang:getString(config.Name))
  self.stDesc:SetText(Lang:getString(config.Desc))
end

return UIBoxRewardDetail

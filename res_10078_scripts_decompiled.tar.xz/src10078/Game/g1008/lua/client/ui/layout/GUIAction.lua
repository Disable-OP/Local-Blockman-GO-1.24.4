local UIActionLayout = class("UIAction", IGUILayout)

function UIActionLayout:onLoad()
  self.llGameList = self:getChildWindow("BedWarActionList-game_list", GUIType.Layout)
  self.llPlatformList = self:getChildWindow("BedWarActionList-platform_list", GUIType.Layout)
  self:initRegister()
  self:initGameActionList()
  self:initPlatformActionList()
  self:initTab()
end

function UIActionLayout:addActionToList(c_action)
  local goodsConfig = CustomShopConfig:getGoodsConfig(c_action.Id)
  local setting = CustomShopAction.Settings[tostring(c_action.Id)]
  for index, action in pairs(self.actionList) do
    if action.actionId == c_action.ActionId then
      action.isLock = false
      table.remove(self.actionList, index)
      break
    end
  end
  local action = {
    actionId = setting.ActionId,
    Action = setting.Action,
    image = goodsConfig.Image,
    goodsId = setting.Id,
    price = goodsConfig.Price1,
    isLock = false
  }
  table.insert(self.actionList, 1, action)
  self.actionAdapter:setData(self.actionList)
end

function UIActionLayout:removeActionFromList(ActionId)
  for index, action in pairs(self.actionList) do
    if action.actionId == ActionId then
      action.isLock = true
      table.remove(self.actionList, index)
      break
    end
  end
  self.actionAdapter:setData(self.actionList)
end

function UIActionLayout:initGameActionList()
  self.llGameList:CleanupChildren()
  if self.gvActionItems ~= nil then
    self.gvActionItems:destroy()
  end
  self.actionList = {}
  for _, setting in pairs(CustomShopAction.Settings) do
    local goodsConfig = CustomShopConfig:getGoodsConfig(setting.Id)
    if goodsConfig and goodsConfig.GetWay == 1 then
      local action = {
        actionId = setting.ActionId,
        Action = setting.Action,
        image = goodsConfig.Image,
        goodsId = setting.Id,
        price = goodsConfig.Price1,
        isLock = true
      }
      table.insert(self.actionList, action)
    end
  end
  self.gvActionItems = IGUIGridView.new("GameActionList", self.llGameList)
  self.gvActionItems:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvActionItems:setConfig(10, 10, 4)
  local ContentSize = (self.llGameList:GetPixelSize().x - 30) / 4
  self.actionAdapter = UIHelper.newGameAdapter("ActionAdapter")
  self.actionAdapter:setItemSize(ContentSize, ContentSize)
  self.gvActionItems:setAdapter(self.actionAdapter)
  self.actionAdapter:setData(self.actionList)
end

function UIActionLayout:initPlatformActionList()
  local PlatformActionList = GUIManager:getWindowByName("ToolBar-Action-ItemList-GridView", GUIType.GridView)
  self.llPlatformList:AddChildWindow(PlatformActionList)
  PlatformActionList:registerEvent(GUIEvent.Click, function()
    GUIBedWarToolBar.cbAction:SetChecked(false)
  end)
end

function UIActionLayout:initRegister()
  self:getChildWindow("BedWarActionList-bt_close", GUIType.Button):registerEvent(GUIEvent.ButtonClick, function()
    GUIBedWarToolBar.cbAction:SetChecked(false)
  end)
  self:registerEvent(CEvents.ClickSelectableActionItemEvent, function()
    GUIBedWarToolBar.cbAction:SetChecked(false)
  end)
end

function UIActionLayout:initTab()
  self.tabGroup = RadioBoxGroup.new(SoundConfig.switchTab)
  local gameTab = self:getChildWindow("BedWarActionList-game", GUIType.CheckBox)
  local platformTab = self:getChildWindow("BedWarActionList-platform", GUIType.CheckBox)
  self.tabGroup:addCheckBox(gameTab, function(checked)
    if checked then
      gameTab:SetChecked(true)
      platformTab:SetChecked(false)
      self.llGameList:SetVisible(true)
      self.llPlatformList:SetVisible(false)
    end
  end)
  self.tabGroup:addCheckBox(platformTab, function(checked)
    if checked then
      gameTab:SetChecked(false)
      platformTab:SetChecked(true)
      self.llGameList:SetVisible(false)
      self.llPlatformList:SetVisible(true)
    end
  end)
  self.tabGroup:selectIndex(1)
end

return UIActionLayout

local GUILotteryDetailWindowLayout = class("GUILotteryDetailWindowLayout", IGUILayout)

function GUILotteryDetailWindowLayout:onLoad()
  self.ltList = self:getChildWindow("LotteryDetailWindow-list", GUIType.List)
  self.stTile = self:getChildWindow("LotteryDetailWindow-title", GUIType.StaticText)
  self.stTile:SetText(Lang:getString("bed_war_lottery_reward_window"))
  local btnClose = self:getChildWindow("LotteryDetailWindow-close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local btnCloseMask = self:getChildWindow("LotteryDetailWindow-mask", GUIType.Layout)
  btnCloseMask:registerEvent(GUIEvent.Click, function()
    self:hide()
  end)
end

function GUILotteryDetailWindowLayout:setLotteryInfo(data)
  local coreItem = {}
  local commonItem = {}
  for _, config in pairs(data) do
    if config.IsCore == "1" then
      table.insert(commonItem, config)
    else
      table.insert(coreItem, config)
    end
  end
  if self.DetailContent == nil then
    self.DetailContent = UIHelper.newGameGUIWindow("GUILotteryDetailContent", "LotteryDetailContent.json")
    self.DetailContent:setLotteryDetailInfo(coreItem, commonItem)
    self.ltList:AddItem(self.DetailContent.root)
  end
end

return GUILotteryDetailWindowLayout

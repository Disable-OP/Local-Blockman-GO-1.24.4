GUICustomDialog = {}

function GUICustomDialog:showStartGame(hint, gameType)
  if gameType == "g1008" or gameType == "g1062" then
    local TeamService = T(Global, "TeamService")
    TeamService:sendCreateTeam(gameType)
    return
  end
  CustomDialog.builder().setContentText(Lang:getString(hint)).setCloseVisible(false).setRightClickListener(function()
    CustomDialog.builder().setContentText(Lang:getString("gui_bed_war_game_start_time_tip")).setCloseVisible(false).setHideLeftButton().setHideRightButton().show()
    LuaTimer:schedule(function()
      RootGuiLayout.Instance():showMainControl()
      CustomDialog.builder().setContentText(Lang:getString("gui_bed_war_game_start_error_time_tip")).setCloseVisible(false).show()
    end, 7000)
    GamePacketSender:sendBedWarStartGame(gameType)
    Game:resetGame(gameType)
    return true
  end).show()
end

function GUICustomDialog:showLevelLimit(level)
  local content = string.format(Lang:getString("start.game.level.limit"), level)
  CustomDialog.builder().setContentText(content).setHideLeftButton().show()
end

local TabColor = {
  Normal = {
    0.486275,
    0.537255,
    0.603922,
    1
  },
  Select = {
    0.866667,
    0.992157,
    1,
    1
  }
}
local UIResult = class("GUIResult", IGUILayout)

function UIResult:onLoad()
  self:getChildWindow("Result-Back-Text", GUIType.StaticText):SetText(Lang:getString("gui.backHall"))
  self:getChildWindow("Result-PlayAgain-Text", GUIType.StaticText):SetText(Lang:getString("gui.playAgain"))
  self:getChildWindow("Result-Previous-Text", GUIType.StaticText):SetText(Lang:getString("gui.previous"))
  self:getChildWindow("Result-Exit-Text", GUIType.StaticText):SetText(Lang:getString("wordart_exit_game"))
  self.stBackTip = self:getChildWindow("Result-Back-Tip-Text", GUIType.StaticText)
  self.siBackTip = self:getChildWindow("Result-Back-Tip", GUIType.StaticImage)
  self.btnBackTip = self:getChildWindow("Result-Back-Tip-Btn", GUIType.Button)
  self.stBackTip:SetText(Lang:getString("gui_to_get_reward"), true)
  local line = math.floor(self.stBackTip:GetTextWidth() / 300) + 1
  self.siBackTip:SetHeight({
    0,
    math.max(self.stBackTip:GetFont():GetFontHeight() * line + 20, 60)
  })
  self.btnBackTip:registerEvent(GUIEvent.ButtonClick, function()
    self.siBackTip:SetVisible(false)
    LuaTimer:schedule(function()
      self.siBackTip:SetVisible(true)
    end, 5000)
  end)
  self.llShare = self:getChildWindow("Result-Share-Hide", GUIType.Layout)
  self.btnPlayAgain = self:getChildWindow("Result-PlayAgain", GUIType.Button)
  self.btnPlayAgain:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.againSettlement)
    GamePacketSender:sendPlayAgain(Game:getPlatformUserId())
  end)
  self.btnBackHall = self:getChildWindow("Result-Back", GUIType.Button)
  self.btnBackHall:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.backHallSettlement)
    GamePacketSender:sendBackHall()
  end)
  self.btnPrevious = self:getChildWindow("Result-Previous", GUIType.Button)
  self.btnPrevious:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.previousSettlement)
    self:hide()
  end)
  self.btExit = self:getChildWindow("Result-Exit", GUIType.Button)
  self.btExit:registerEvent(GUIEvent.ButtonClick, function()
    GUIBedWarSetting:onClickExit()
  end)
  self.btShare = self:getChildWindow("Result-Share", GUIType.Button)
  self.btShare:SetVisible(not Game:isChina() and not Game:isEnableIndie())
  self.btShare:registerEvent(GUIEvent.ButtonClick, function()
    LuaTimer:schedule(function()
      self:onShare(true)
    end, 0)
  end)
  self.battleInfo = {}
  self.tabs = {}
end

function UIResult:isShowAnim()
  return false
end

function UIResult:onShare(open)
  if open then
    self.llShare:SetVisible(false)
    ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_SCREEN_CAPTURE)
  else
    self.llShare:SetVisible(true)
  end
end

function UIResult:onUpdateUI()
  local llTeamInfo = self:getChildWindow("Result-Team-Info")
  llTeamInfo:CleanupChildren()
  self.battleInfo = {}
  self.tabs = {}
  self.leftTeamInfo = UIHelper.newGameGUIWindow("GUIResultTeamItem", "ResultTeamItem.json")
  local contentWidth = llTeamInfo:GetPixelSize().x
  local contentHeight = llTeamInfo:GetPixelSize().y
  local teamInfoWidth = (contentWidth - 20) / 2
  self.leftTeamInfo.root:SetWidth({0, teamInfoWidth})
  self.leftTeamInfo.root:SetHeight({0, contentHeight})
  self.leftTeamInfo.root:SetXPosition({0, 10})
  self.leftTeamInfo:initItemPlayers()
  llTeamInfo:AddChildWindow(self.leftTeamInfo.root)
  self.rightTeamInfo = UIHelper.newGameGUIWindow("GUIResultTeamItem", "ResultTeamItem.json")
  self.rightTeamInfo.root:SetWidth({0, teamInfoWidth})
  self.rightTeamInfo.root:SetHeight({0, contentHeight})
  self.rightTeamInfo.root:SetXPosition({0, -10})
  self.rightTeamInfo.root:SetHorizontalAlignment(HorizontalAlignment.Right)
  self.rightTeamInfo:initItemPlayers()
  self.rightTeamInfo:setRightLayout()
  llTeamInfo:AddChildWindow(self.rightTeamInfo.root)
  local teamIds = {}
  local infoList = GameInfoManager:getAllPlayerInfo()
  local selfTeamId = "0"
  for userId, info in pairs(infoList) do
    local teamId = info:getValue("teamId")
    local inGame = tonumber(info:getValue("rank")) ~= 0
    if inGame and tonumber(teamId) >= 1 and tonumber(teamId) <= 4 then
      if teamIds[teamId] == nil then
        teamIds[teamId] = tonumber(teamId)
      end
      local battleInfo = self.battleInfo[teamId]
      if not battleInfo then
        battleInfo = {
          teamId = tonumber(teamId),
          players = {}
        }
        self.battleInfo[teamId] = battleInfo
      end
      local data = {
        userId = tonumber(userId),
        info = info
      }
      if tostring(userId) == tostring(Game:getPlatformUserId()) then
        selfTeamId = teamId
      end
      table.insert(battleInfo.players, data)
      GameInfoManager:registerObserver(tostring(userId), function(_)
        self.leftTeamInfo.adapter:notifyItemDataChange(data)
        self.rightTeamInfo.adapter:notifyItemDataChange(data)
      end)
    end
  end
  local battleInfo = self.battleInfo[selfTeamId]
  if battleInfo then
    local me
    for pos, player in pairs(battleInfo.players) do
      if tostring(player.userId) == tostring(Game:getPlatformUserId()) then
        me = player
        table.remove(battleInfo.players, pos)
        break
      end
    end
    table.insert(battleInfo.players, 1, me)
    self.leftTeamInfo:setTeamInfo(battleInfo)
    local ivMyTeamIcon = self:getChildWindow("Result-My-Team-Icon", GUIType.StaticImage)
    ivMyTeamIcon:SetImage(TeamGUIInfo[selfTeamId].tab_icon)
  end
  teamIds[selfTeamId] = nil
  local ids = {}
  for _, teamId in pairs(teamIds) do
    table.insert(ids, teamId)
  end
  if #ids ~= 0 and not self.rightTeamInfo:setTeamInfo(self.battleInfo[tostring(ids[1])]) then
    for teamId, _battleInfo in pairs(self.battleInfo) do
      for _, player in pairs(_battleInfo.players) do
        player.info:print()
      end
    end
  end
  for i = 1, 3 do
    local teamId = ids[i]
    local cbTab = self:getChildWindow("Result-Team-Tab" .. tostring(i), GUIType.CheckBox)
    if teamId ~= nil then
      cbTab:registerEvent(GUIEvent.CheckStateChanged, function()
        local checked = cbTab:GetChecked()
        if checked then
          cbTab:SetTextColor(TabColor.Select)
          for _, tab in pairs(self.tabs) do
            if tab.teamId == teamId then
              tab.icon:SetImage(TeamGUIInfo[tostring(tab.teamId)].tab_icon)
            else
              tab.icon:SetImage(TeamGUIInfo[tostring(tab.teamId)].tab_icon_normal)
            end
            tab.checkbox:SetChecked(tab.teamId == teamId)
          end
          self.rightTeamInfo:setTeamInfo(self.battleInfo[tostring(teamId)])
        else
          local needCheck = true
          for _, tab in pairs(self.tabs) do
            if tab.checkbox:GetChecked() then
              needCheck = false
            end
          end
          if needCheck then
            cbTab:SetChecked(true)
            return
          end
          cbTab:SetTextColor(TabColor.Normal)
        end
      end)
      if i == 1 then
        LuaTimer:schedule(function()
          cbTab:SetChecked(true)
        end, 0)
      end
      local ivTabIcon = self:getChildWindow("Result-Tab-Icon" .. tostring(i), GUIType.StaticImage)
      ivTabIcon:SetImage(TeamGUIInfo[tostring(teamId)].tab_icon)
      self.tabs[tostring(teamId)] = {
        checkbox = cbTab,
        icon = ivTabIcon,
        teamId = teamId
      }
    else
      cbTab:SetVisible(false)
    end
  end
  self:setWin(selfTeamId)
end

function UIResult:setWin(selfTeamId)
  local selfTeamInfo = GameInfoManager:getTeamInfo(selfTeamId)
  local isWin = "1"
  if selfTeamInfo then
    isWin = selfTeamInfo:getValue("isWin")
  end
  local bg = self:getChildWindow("Result-Title-Bg", GUIType.StaticImage)
  local text = self:getChildWindow("Result-Title-Text", GUIType.StaticText)
  if isWin == "2" then
    bg:SetImage("set:result.json image:title_victory")
    text:SetText(Lang:getString("gui.victory"))
  elseif isWin == "1" then
    bg:SetImage("set:result.json image:title_flatten")
    text:SetText(Lang:getString("gui.flatten"))
  else
    bg:SetImage("set:result.json image:title_failed")
    text:SetText(Lang:getString("gui.failed"))
  end
end

return UIResult

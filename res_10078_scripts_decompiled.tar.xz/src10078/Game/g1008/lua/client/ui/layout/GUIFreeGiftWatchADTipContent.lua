local GUIFreeGiftWatchADTipContent = class("GUIFreeGiftWatchADTipContent", IGUILayout)

function GUIFreeGiftWatchADTipContent:onLoad()
  self.siImage = self:getChildWindow("FreeGiftWatchADTipContent-Image", GUIType.StaticImage)
  self.stNum = self:getChildWindow("FreeGiftWatchADTipContent-Num", GUIType.StaticText)
  self.stTip = self:getChildWindow("FreeGiftWatchADTipContent-Tip", GUIType.StaticText)
end

FreeGiftWatchADTipContent = buildWatchAdTipContent(GUIFreeGiftWatchADTipContent, "FreeGiftWatchADTipContent.json")

function FreeGiftWatchADTipContent:setInfo(image, text, tip)
  self.siImage:SetImage(image)
  self.stNum:SetText(text)
  self.stTip:SetText(Lang:getString(tip))
end

function FreeGiftWatchADTipContent:setTextColor(color)
  self.stNum:SetProperty("TextColor", color)
end

function FreeGiftWatchADTipContent:setBorderColor(color)
  self.stNum:SetProperty("TextBorderColor", color)
end

function FreeGiftWatchADTipContent:setFont(font)
  self.stNum:SetFont(GUIFontManager:Instance():GetFont(font))
end

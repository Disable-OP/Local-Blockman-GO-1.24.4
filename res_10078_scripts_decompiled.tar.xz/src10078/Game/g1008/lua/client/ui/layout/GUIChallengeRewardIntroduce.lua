local GUIChallengeRewardIntroduce = class("GUIChallengeRewardIntroduce", IGUILayout)

function GUIChallengeRewardIntroduce:onLoad()
  self.ivIcon = self:getChildWindow("ChallengeRewardIntroduce-icon", GUIType.StaticImage)
  self.tvName = self:getChildWindow("ChallengeRewardIntroduce-icon_name", GUIType.StaticText)
  self.tvIntroduce = self:getChildWindow("ChallengeRewardIntroduce-text", GUIType.StaticText)
end

ChallengeRewardIntroduce = buildCustomDialogContent(GUIChallengeRewardIntroduce, "ChallengeRewardIntroduce.json")

function ChallengeRewardIntroduce:setRewardIntroduce(image, name, introduce)
  self.ivIcon:SetImage(image)
  self.tvName:SetText(Lang:getString(name))
  self.tvIntroduce:SetText(Lang:getString(introduce))
end

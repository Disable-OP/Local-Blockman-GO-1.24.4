local function setVisible(window, visible)
  window:SetVisible(visible)
  
  local count = window:GetChildCount()
  if count == 0 then
    return
  end
  for index = 1, count do
    setVisible(window:GetChildByIndex(index - 1), visible)
  end
end

SystemSettingRecord = {}

function onSaveSetting()
  if GUIBedWarSetting then
    ClientHelper.putStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_SystemSettings", json.encode(GUIBedWarSetting:getSystemSettingRecord()))
  end
end

local UIBedWarSetting = class("UIBedWarSetting", IGUILayout)

function UIBedWarSetting:onLoad()
  GUIManager:getWindowByName("Menu-Content", GUIType.Layout):SetBackImage("")
  local Menu = GUIManager:getWindowByName("Menu", GUIType.Layout)
  Menu:SetArea({0, 0}, {0, 0}, {1, 0}, {1, -58})
  Menu:SetBackgroundColor({
    0,
    0,
    0,
    0.9
  })
  local MenuBg = GUIManager:getWindowByName("Menu-Radio-Panel", GUIType.Layout)
  MenuBg:SetBackImage("set:bedwar_setting.json image:menu_bg")
  MenuBg:SetProperty("StretchType", "NineGrid")
  MenuBg:SetProperty("StretchOffset", "25 25 25 25")
  local root = GUIManager:getWindowByName("GameSetting", GUIType.Layout)
  local Width = root:GetPixelSize().x
  setVisible(root, false)
  self.llPanel = IGUIListView.new("GameSetting-BedWarPanel", root, nil, Orientation.Vertical)
  self.llPanel:setItemSpace(10)
  self.llBack = self:getChildWindow("BedWarSetting-Back", GUIType.Layout)
  self.boxBasic = self:getChildWindow("BedWarSetting-Basic-Tab", GUIType.CheckBox)
  self.boxOperation = self:getChildWindow("BedWarSetting-Operation-Tab", GUIType.CheckBox)
  self.boxSound = self:getChildWindow("BedWarSetting-Sound-Tab", GUIType.CheckBox)
  self.llBasic = UIHelper.newGameGUIWindow("GUISettingBasic")
  self.llBasic.root:SetArea({0, 0}, {0, 0}, {0, Width}, {0, 322})
  self.llPanel:addItem(self.llBasic)
  self.llOperation = UIHelper.newGameGUIWindow("GUISettingOperation")
  self.llOperation.root:SetArea({0, 0}, {0, 0}, {0, Width}, {0, 550})
  self.llPanel:addItem(self.llOperation)
  self.llSound = UIHelper.newGameGUIWindow("GUISettingSound")
  self.llSound.root:SetArea({0, 0}, {0, 0}, {0, Width}, {0, 322})
  self.llPanel:addItem(self.llSound)
  self.tabGroup = RadioBoxGroup.new()
  self:register()
  self.tabGroup:selectIndex(1)
end

function UIBedWarSetting:onStart()
  self:getChildWindow("BedWarSetting-Title-Shadow", GUIType.StaticText):SetText(Lang:getString("gui.game.setting"))
  self:getChildWindow("BedWarSetting-Title-Shadow1", GUIType.StaticText):SetText(Lang:getString("gui.game.setting"))
  self:getChildWindow("BedWarSetting-Title", GUIType.StaticText):SetText(Lang:getString("gui.game.setting"))
  self:getChildWindow("BedWarSetting-Basic-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.tab.basic"))
  self:getChildWindow("BedWarSetting-Operation-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.tab.operation"))
  self:getChildWindow("BedWarSetting-Sound-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.tab.sound"))
end

function UIBedWarSetting:register()
  self.tabGroup:addCheckBox(self.boxBasic, function(checked)
    self.llBasic:setVisible(checked)
  end)
  self.tabGroup:addCheckBox(self.boxOperation, function(checked)
    self.llOperation:setVisible(checked)
  end)
  self.tabGroup:addCheckBox(self.boxSound, function(checked)
    self.llSound:setVisible(checked)
  end)
  self:getChildWindow("BedWarSetting-Close", GUIType.Button):registerEvent(GUIEvent.ButtonClick, function()
    self:close()
  end)
  self.llBack:registerEvent(GUIEvent.TouchUp, function()
    self:close()
  end)
  self:getChildWindow("BedWarSetting-ExitGame", GUIType.Button):registerEvent(GUIEvent.ButtonClick, function()
    self:onClickExit()
  end)
  self:registerDataCallBack("PlayerReady", function()
    self:initCacheSetting()
  end)
end

function UIBedWarSetting:show(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.openSetting)
  end
  self.super.show(self)
end

function UIBedWarSetting:hide(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.closeSetting)
  end
  self.super.hide(self)
end

function UIBedWarSetting:changeTabStatus(changeIndex)
  local curTab = self.Tabs[changeIndex]
  local checked = curTab:GetChecked()
  if checked then
    for index, tabCheckBox in pairs(self.Tabs) do
      tabCheckBox:SetChecked(index == changeIndex)
      self.Panel[index]:setVisible(index == changeIndex)
    end
  else
    local needCheck = true
    for _, tabCheckBox in pairs(self.Tabs) do
      if tabCheckBox:GetChecked() then
        needCheck = false
      end
    end
    if needCheck then
      curTab:SetChecked(true)
      return
    end
  end
end

function UIBedWarSetting:onClickExit()
  CustomDialog.builder().setContentText(Lang:getString("gui.message.exit.game")).setLeftText("gui.cancel").setRightText("gui.sure").setLeftClickListener(function()
  end).setRightClickListener(function()
    Game:exitGame()
  end).show()
end

function UIBedWarSetting:initCacheSetting()
  self.defaultSetting = FileUtil.getConfigFromYml("setting/DefaultSettings")
  SystemSettingRecord = {}
  local SettingJson = ClientHelper.getStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_SystemSettings", "")
  if string.sub(SettingJson, 1, 1) == "{" then
    SystemSettingRecord = json.decode(SettingJson)
  end
  self:initSystemSetting(SystemSettingRecord)
  if ClientNewReportUtil then
    ClientNewReportUtil:onReportCurrentControlModel(SystemSettingRecord.defaultOperation)
  end
end

function UIBedWarSetting:initSystemSetting(setting)
  local oldSetting = TableUtil.copyTable(setting)
  local defaultFPS = setting.defaultFPS or self.defaultSetting.defaultFPS
  self.llBasic.fpsGroup:selectIndex(defaultFPS)
  if GameType == "g1046" then
    self.llBasic.cameraGroup:selectIndex(2)
  else
    self.llBasic.cameraGroup:selectIndex(1)
  end
  local defaultLuminance = setting.defaultLuminance or self.defaultSetting.defaultLuminance
  self.llBasic:refreshLuminance(defaultLuminance)
  local defaultButtonSize = setting.defaultButtonSize or self.defaultSetting.defaultButtonSize
  self.llBasic:refreshSize(defaultButtonSize)
  local defaultSensitivity = setting.defaultSensitivity or self.defaultSetting.defaultSensitivity
  self.llBasic:refreshSensitive(defaultSensitivity)
  local defaultHorizon = setting.defaultHorizon or self.defaultSetting.defaultHorizon
  self.llBasic:refreshHorizon(defaultHorizon)
  local defaultOperation = setting.defaultOperation or self.defaultSetting.defaultOperation
  self.llOperation.opGroup:selectIndex(defaultOperation)
  local defaultBackGroundSwitch = setting.defaultBackGroundSwitch or self.defaultSetting.defaultBackGroundSwitch
  self.llSound.bgGroup:selectIndex(defaultBackGroundSwitch)
  local defaultBackGroundVolume = setting.defaultBackGroundVolume or self.defaultSetting.defaultBackGroundVolume
  self.llSound:refreshBackGround(defaultBackGroundVolume)
  local defaultEffectSwitch = setting.defaultEffectSwitch or self.defaultSetting.defaultEffectSwitch
  self.llSound.soundGroup:selectIndex(defaultEffectSwitch)
  local defaultEffectVolume = setting.defaultEffectVolume or self.defaultSetting.defaultEffectVolume
  self.llSound:refreshEffect(defaultEffectVolume)
  SystemSettingRecord = oldSetting
end

function UIBedWarSetting:getSystemSettingRecord()
  local setting = {}
  for key, value in pairs(SystemSettingRecord) do
    setting[key] = math.floor(value * 10) / 10
  end
  return setting
end

function UIBedWarSetting:close()
  self:hide(true)
end

function UIBedWarSetting:isFirstPerspective()
  return self.llBasic.cameraGroup:getCurIndex() == 1
end

function UIBedWarSetting:changeCamera(index)
  self.llBasic.cameraGroup:selectIndex(index)
end

return UIBedWarSetting

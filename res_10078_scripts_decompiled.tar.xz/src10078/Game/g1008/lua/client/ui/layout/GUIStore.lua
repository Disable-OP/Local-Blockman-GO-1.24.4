local StoreUIConfig = {
  [StoreId.GoodsStore] = {
    title_name = "gui_bed_war_shop_title"
  },
  [StoreId.UpgradeStore] = {
    title_name = "gui_bed_war_lvshop_title"
  },
  [StoreId.CubeStore] = {
    title_name = "gui_str_app_shop_shop"
  }
}
local UIStore = class("GUIStore", IGUILayout)

function UIStore:onLoad()
  self.curShowType = 0
  self.curSelectGoods = nil
  self.curTipKey = nil
  local llMain = self:getChildWindow("BedWarStore-Main", GUIType.Layout)
  local size = llMain:GetPixelSize()
  local width = math.min(size.y / 574 * 1138, size.x)
  llMain:SetWidth({0, width})
  local llTabs = self:getChildWindow("BedWarStore-Tabs", GUIType.Layout)
  self.lvTabs = IGUIListView.new("BedWarStore-Tabs-List", llTabs)
  self.lvTabs:setArea({0, 8}, {0, 8}, {1, -16}, {1, -16})
  self.lvTabs:setItemSpace(8)
  self.llMoney = self:getChildWindow("BedWarStore-Money", GUIType.Layout)
  self.lvMoney = IGUIListView.new("BedWarStore-Money-List", self.llMoney, nil, Orientation.Horizontal)
  self.lvMoney:setItemSpace(30)
  self.maxMoneyWidth = self.llMoney:GetPixelSize().x
  local llGoodsList = self:getChildWindow("BedWarStore-GoodsList", GUIType.Layout)
  self.gvGoodsList = IGUIGridView.new("BedWarStore-Goods-List-Gird", llGoodsList)
  self.gvGoodsList:setConfig(12, 8, 4)
  self.goodsAdapter = UIHelper.newGameAdapter("StoreGoodsAdapter")
  local contentWidth = self.gvGoodsList:getWidth()
  local itemWidth = (contentWidth - 39) / 4
  local itemHeight = itemWidth / 142 * 190
  self.goodsAdapter:setItemSize(itemWidth, itemHeight)
  self.gvGoodsList:setAdapter(self.goodsAdapter)
  self.tvTitleText = self:getChildWindow("BedWarStore-Title-Text", GUIType.StaticText)
  self.tvGoodsName = self:getChildWindow("BedWarStore-Goods-Name", GUIType.StaticText)
  self.ivGoodsImage = self:getChildWindow("BedWarStore-Goods-Image", GUIType.StaticImage)
  self.tvGoodsDesc = self:getChildWindow("BedWarStore-Goods-Desc", GUIType.StaticText)
  self.btnGoodsBuy = self:getChildWindow("BedWarStore-Goods-Buy", GUIType.Button)
  self.ivGoodsMoneyIcon = self:getChildWindow("BedWarStore-Goods-Money-Icon", GUIType.StaticImage)
  self.tvGoodsMoneyText = self:getChildWindow("BedWarStore-Goods-Money-Text", GUIType.StaticText)
  self.btnSkin = self:getChildWindow("BedWarStore-Skin", GUIType.Button)
  self.btnSkin:SetVisible(false)
  self.tvTips = self:getChildWindow("BedWarStore-Tips", GUIType.StaticText)
  self.tvTips:SetVisible(false)
  local btnClose = self:getChildWindow("BedWarStore-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide(true)
  end)
  local btnCloseMask = self:getChildWindow("BedWarStore-Close-Mask", GUIType.Button)
  repeat
    btnCloseMask:registerEvent(GUIEvent.ButtonClick, function()
      self:hide(true)
    end)
    self.btnGoodsBuy:registerEvent(GUIEvent.ButtonClick, function()
      self:onBuyGoods(self.curSelectGoods)
      SoundUtil.playSound(SoundConfig.buyGoodsStore)
    end)
    do break end -- pseudo-goto
    if GameType == "g1008" then
      self.btnSurveyEntrance = self:getChildWindow("BedWarStore-Survey-Entrance", GUIType.Button)
      self:getChildWindow("BedWarStore-Survey-Entrance-Text", GUIType.StaticText):SetText(Lang:getString("Survey_Entrance"))
      self.btnSurveyEntrance:registerEvent(GUIEvent.ButtonClick, function()
        if GUIBedWarSurveyDesc then
          GUIBedWarSurveyDesc:onShowSurvey()
        end
      end)
      self:registerDataCallBack("ShowSurveyEntrance", function()
        self.btnSurveyEntrance:SetVisible(true)
      end)
    end
  until true
  local llBuyGoods = GUIManager:getWindowByName("BuyGoodsTip-Bg", GUIType.StaticImage)
  llBuyGoods:SetImage("set:bed_war_store.json image:bg_get_goods")
  llBuyGoods:SetArea({0, 0}, {0, 0}, {0, 384}, {0, 96})
  local ivBuyGoodsIcon = GUIManager:getWindowByName("BuyGoodsTip-Icon", GUIType.StaticImage)
  ivBuyGoodsIcon:SetArea({0, -40}, {0, -5}, {0, 53.3}, {0, 53.3})
  self:registerDataCallBack("CubeStoreGetTicketTimes", function(data)
    self.getFreeTicketTimes = data:getNumberParam("times")
    self:updateListUI()
  end, DataBuilderProcessor)
end

function UIStore:isShowAnim()
  return false
end

function UIStore:show(playSound, ...)
  if playSound then
    SoundUtil.playSound(SoundConfig.openStore)
  end
  self.super.show(self, playSound, ...)
end

function UIStore:hide(playSound)
  if playSound then
    SoundUtil.playSound(SoundConfig.closeStore)
  end
  self.super.hide(self)
end

function UIStore:onBuyGoodsSuccess(goods)
  local count = GoodsStorePrivilege:onBuyGoods(goods)
  if goods.TabId < 1000 or GameConfig.useNewLottery ~= 1 then
    if #goods.Image > 10 then
      HostApi.notifyGetGoods(goods.Image, count)
    else
      HostApi.notifyGetItem(goods.ItemId, 0, count)
    end
  end
  self:updateListUI()
  if goods.LevelGroup ~= "#" and not goods.SkipLevel then
    local _goods = StoreConfig:getNextUpgradeGoods(goods.ItemId)
    if _goods then
      self:showGoodsDetail(_goods)
    end
  else
    self.curSelectGoods = nil
    self:showGoodsDetail(goods)
  end
end

function UIStore:updateListUI()
  if not self:isShow() then
    return
  end
  ClientStore:checkAllUpgradeGoods()
  self.goodsAdapter:notifyDataChange()
end

function UIStore:trySelectTab(tabId)
  if not tabId then
    return
  end
  local items = self.lvTabs.items
  for _, item in pairs(items) do
    if item.tabId == tabId then
      item:setChecked(true)
    end
  end
end

function UIStore:onShow(type, tabId, fromMain)
  if type == "" then
    type = StoreId.CubeStore
  end
  if StoreId.GoodsStore == type then
    GameAnalytics:design(0, {
      "VersionForNewItem",
      "OpenGoodsStore",
      fromMain and "2" or "1"
    })
  end
  self:updateListUI()
  local oldGoods = self.curSelectGoods
  self.curSelectGoods = nil
  self:showGoodsDetail(oldGoods)
  if self.curShowType == type then
    self:trySelectTab(tabId)
    self:checkAdReport()
    return
  end
  self.curShowType = type
  local ui_config = StoreUIConfig[type]
  if ui_config then
    self.tvTitleText:SetText(Lang:getString(ui_config.title_name))
  end
  local config = StoreConfig:getStoreConfig(self.curShowType)
  self.lvTabs:clearItems()
  for index, data in pairs(config.Tabs) do
    local tab = UIHelper.newGameGUIWindow("GUIStoreTab", "BedWarStoreTab.json")
    tab:onDataChanged(data)
    tab:setWidth({1, 0})
    self.lvTabs:addItem(tab)
    if index == 1 then
      tab:setChecked(true)
    end
  end
  self.lvMoney:clearItems()
  local width = math.min(#config.CurrencyList * 200, self.maxMoneyWidth)
  self.llMoney:SetWidth({0, width})
  for _, data in pairs(config.CurrencyList) do
    local money = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
    money:onDataChanged(data)
    self.lvMoney:addItem(money)
  end
  self:trySelectTab(tabId)
  self:checkAdReport()
end

function UIStore:checkAdReport()
  if not self.getFreeTicketTimes or self.getFreeTicketTimes <= 0 then
    return
  end
  local hasAdShow = false
  local items = self.gvGoodsList.items
  for _, item in pairs(items) do
    if item.data.GetWay == 2 then
      hasAdShow = true
      break
    end
  end
  if hasAdShow then
    ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ADS_PLACEMENT, Define.AdType.CubeStoreFreeTicket)
  end
end

function UIStore:onTick()
  for _, item in pairs(self.lvMoney.items) do
    item:onTick()
  end
end

function UIStore:onSelectTab(tab)
  local items = self.lvTabs.items
  for _, item in pairs(items) do
    if item ~= tab then
      item:setChecked(false)
    end
  end
  self:showGoodsList(tab.tabId)
  if self.curShowType == StoreId.GoodsStore then
    GameAnalytics:design(1, {
      "page_goodsshop",
      tostring(tab.tabId)
    })
  elseif self.curShowType == StoreId.CubeStore then
    if GameType == "g1046" then
      GameAnalytics:design(1, {
        "H_cube_shop_page",
        tostring(tab.tabId)
      })
    else
      GameAnalytics:design(1, {
        "G_cube_shop_page",
        tostring(tab.tabId)
      })
    end
  end
end

function UIStore:showGoodsList(tabId)
  local config = StoreConfig:getStoreConfig(self.curShowType)
  local goods = {}
  for _, tab in pairs(config.Tabs) do
    if tab.Id == tabId then
      goods = tab.GoodsList
    end
  end
  if 0 < #goods then
    self:showGoodsDetail(goods[1])
  end
  self.goodsAdapter:setData(goods)
end

function UIStore:showGoodsDetail(goods)
  if self.curSelectGoods == goods then
    return
  end
  local oldGoods = self.curSelectGoods
  self.curSelectGoods = nil
  self.goodsAdapter:notifyItemDataChange(oldGoods)
  self.curSelectGoods = goods
  ClientStore:setGoodsUI(self.tvGoodsName, self.ivGoodsImage, self.ivGoodsMoneyIcon, self.tvGoodsMoneyText, self.btnGoodsBuy, goods)
  self.btnSkin:SetVisible(goods.BlockShopTabId ~= nil)
  self.tvGoodsDesc:SetText(Lang:getString(goods.Desc))
  self.goodsAdapter:notifyItemDataChange(goods)
  local storeId = StoreConfig:getGoodsStoreId(self.curSelectGoods)
  if storeId == StoreId.GoodsStore then
    GameAnalytics:design(1, {
      "select_goodsshop",
      tostring(goods.Id)
    })
  elseif storeId == StoreId.CubeStore then
    GameAnalytics:design(1, {
      "select_culbshop",
      tostring(goods.Id)
    })
  end
end

function UIStore:getCurrentGoodsId()
  if self.curSelectGoods then
    return self.curSelectGoods.Id
  end
  return 0
end

function UIStore:showTips(tips)
  self.tvTips:SetText(tips)
  self.tvTips:SetVisible(true)
  LuaTimer:cancel(self.curTipKey)
  self.curTipKey = LuaTimer:schedule(function()
    self.tvTips:SetVisible(false)
  end, 1000)
end

function UIStore:onBuyGoods(goods)
  ClientStore:onBuyGoods(goods, function(success, tips)
    if tips and 0 < #tips then
      self:showTips(tips)
    end
    if success then
      self:showGoodsDetail(goods)
    end
  end)
end

function UIStore:hideSurveyEntrance()
  self.btnSurveyEntrance:SetVisible(false)
end

return UIStore

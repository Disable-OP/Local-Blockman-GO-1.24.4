require("hall.config.FriendScreenConfig")
local FriendManager = T(Global, "FriendManager")
local UIFriends = class("UIFriends", IGUILayout)
local UIUtils = T(Global, "UIUtils")
local WebPageUtil = T(Global, "WebPageUtil")
local TabType = {
  Friend = 1,
  Recommend = 2,
  Request = 3,
  Subscribe = 4
}
local ScreenType = {
  Segment = 1,
  Lang = 2,
  Sex = 3
}
local TabText = {
  [TabType.Friend] = "gui_friend_friend_tab",
  [TabType.Recommend] = "gui_friend_recommend_tab",
  [TabType.Request] = "gui_friend_request_tab",
  [TabType.Subscribe] = "gui_friend_subscribe_tab"
}
local SubscribeTabType = {Focus = 1, Fans = 2}
local SubscribeTabText = {
  [SubscribeTabType.Focus] = "gui_friend_focus_tab",
  [SubscribeTabType.Fans] = "gui_friend_fans_tab"
}
local RecommendType = {WithSearchText = 0, WithScreen = 1}
local NoneTipText = {
  NoFriend = "gui.no.friend.tip",
  NoFans = "gui.no.fans.tip",
  NoFollow = "gui.no.follow.tip"
}

function UIFriends:onLoad()
  self.selectTab = 0
  self.dataList = {}
  self.stTitle = self:getChildWindow("BedWarFriends-Title-Text", GUIType.StaticText)
  local llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui_friend_title", function()
    SoundUtil.clickUI()
    GUIFriends:hide()
  end)
  self.root:AddChildWindow(llReturn.root)
  self.tabs = {
    [TabType.Friend] = {
      btn = self:getChildWindow("BedWarFriends-Friend-Tab", GUIType.Button),
      line = self:getChildWindow("BedWarFriends-Friend-Line", GUIType.StaticImage)
    },
    [TabType.Recommend] = {
      btn = self:getChildWindow("BedWarFriends-Recommend-Tab", GUIType.Button),
      line = self:getChildWindow("BedWarFriends-Recommend-Line", GUIType.StaticImage)
    },
    [TabType.Request] = {
      btn = self:getChildWindow("BedWarFriends-Request-Tab", GUIType.Button),
      line = self:getChildWindow("BedWarFriends-Request-Line", GUIType.StaticImage)
    },
    [TabType.Subscribe] = {
      btn = self:getChildWindow("BedWarFriends-Subscribe-Tab", GUIType.Button),
      line = self:getChildWindow("BedWarFriends-Subscribe-Line", GUIType.StaticImage)
    }
  }
  self.layouts = {
    [TabType.Friend] = self:getChildWindow("BedWarFriends-Content-Friend", GUIType.Layout),
    [TabType.Recommend] = self:getChildWindow("BedWarFriends-Content-Recommend", GUIType.Layout),
    [TabType.Request] = self:getChildWindow("BedWarFriends-Content-Request", GUIType.Layout),
    [TabType.Subscribe] = self:getChildWindow("BedWarFriends-Content-Subscribe", GUIType.Layout)
  }
  self.layRecommendContent = self:getChildWindow("BedWarFriends-Recommend-List", GUIType.Layout)
  self.screenItem = {
    [ScreenType.Segment] = {
      win = self:getChildWindow("BedWarFriends-Segment", GUIType.Layout)
    },
    [ScreenType.Lang] = {
      win = self:getChildWindow("BedWarFriends-Lang", GUIType.Layout)
    },
    [ScreenType.Sex] = {
      win = self:getChildWindow("BedWarFriends-Sex", GUIType.Layout)
    }
  }
  self.screenData = {}
  self.laySubscribeContent = self:getChildWindow("BedWarFriends-Subscribe-List", GUIType.Layout)
  self.subscribeTabs = {
    [SubscribeTabType.Focus] = self:getChildWindow("BedWarFriends-Subscribe-Focus", GUIType.Button),
    [SubscribeTabType.Fans] = self:getChildWindow("BedWarFriends-Subscribe-Fans", GUIType.Button)
  }
  self:initSubscribeTabs()
  self.btnScreen = self:getChildWindow("BedWarFriends-Screen-Btn", GUIType.Button)
  self.btnChange = self:getChildWindow("BedWarFriends-Change-Btn", GUIType.Button)
  self.btnSearch = self:getChildWindow("BedWarFriends-Search-Btn", GUIType.Button)
  self.etSearch = self:getChildWindow("BedWarFriends-Search-Input", GUIType.Edit)
  self.stSearch = self:getChildWindow("BedWarFriends-Search-Text", GUIType.StaticText)
  self.llNoFriendTip = self:getChildWindow("BedWarFriends-No-Friend-Tip", GUIType.Layout)
  self.stNoFriendTipText = self:getChildWindow("BedWarFriends-No-Friend-Tip-Text", GUIType.StaticText)
  self.stSearch:SetText(Lang:getString("gui_friend_search_text"))
  self.btnChange:SetText(Lang:getString("gui_friend_change_btn_text"))
  self.btnScreen:SetText(Lang:getString("gui_friend_screen_btn_text"))
  self.stNoFriendTipText:SetText(Lang:getString("gui.no.friend.tip"))
  self.llNoFriendTip:SetVisible(false)
  self.etSearch:SetMaxLength(30)
  self:initRegister()
  self:initTabs()
  self:initContents()
  self:initSelectList()
  self:initSubscribeTabs()
  self:setTabSelect(TabType.Friend)
  self:setSubscribeTabSelect(SubscribeTabType.Focus)
end

function UIFriends:initRegister()
  for type, v in pairs(self.tabs) do
    v.btn:registerEvent(GUIEvent.ButtonClick, function()
      SoundUtil.clickUI()
      self:setTabSelect(type)
    end)
  end
  for type, v in pairs(self.subscribeTabs) do
    v:registerEvent(GUIEvent.ButtonClick, function()
      SoundUtil.clickUI()
      self:setSubscribeTabSelect(type)
    end)
  end
  self.btnChange:registerEvent(GUIEvent.ButtonClick, function()
    self:screenRecommend(true)
  end)
  self.btnScreen:registerEvent(GUIEvent.ButtonClick, function()
    self:screenRecommend()
  end)
  self.btnSearch:registerEvent(GUIEvent.ButtonClick, function()
    self:searchFriend()
  end)
  self.root:registerEvent(GUIEvent.Click, function()
    self:hideScreenList()
  end)
  self:registerEvent(Events.FinishLoadFriendDataEvent, function()
    self:refreshData(TabType.Friend)
  end)
  self:registerEvent(Events.FinishParseRequestsDataEvent, function()
    self:refreshData(TabType.Request)
  end)
  self:registerEvent(Events.FinishParseRecommendDataEvent, function()
    self:refreshData(TabType.Recommend)
  end)
  self:registerEvent(Events.ScreenBeSelectedEvent, function(data)
    self.screenDataChange = true
    if data.subType == 0 then
      self.screenData[data.mainType] = nil
      return
    end
    self.screenData[data.mainType] = data.key
  end)
  self:registerEvent(Events.PlayerFollowEvent, function(userId, followOperationType)
    if not GUIFriends:isShow() then
      return
    end
    self:onPlayerFollowStatusChange(userId, followOperationType)
  end)
  local xOffset = self.tabs[TabType.Request].btn:GetPixelSize().x / 4
  UIUtils.addRedDot(self.tabs[TabType.Request].btn, Define.RedDotKey.FriendApply, nil, {
    offset = VectorUtil.newVector2(-xOffset, -3)
  })
end

function UIFriends:initTabs()
  for type, v in pairs(self.tabs) do
    v.btn:SetText(Lang:getString(TabText[type]))
    v.btn:SetNormalImage("")
    v.btn:SetPushedImage("")
    v.btn:SetTextColor(Define.TabTextColor.Normal)
    v.line:SetVisible(true)
  end
end

function UIFriends:initContents()
  self.contentAdapter = {}
  for type, v in pairs(self.layouts) do
    v:SetVisible(false)
    local config, itemHeight, itemWidth
    if type == TabType.Friend then
      self.contentAdapter[type] = {
        list = IGUIGridView.new("BedWarFriends-Friend-List-Gird", v),
        adapter = UIHelper.newGameAdapter("FriendItemAdapter")
      }
      config = {
        0,
        19,
        1
      }
      itemWidth = self.contentAdapter[type].list:getWidth()
      itemHeight = itemWidth / 902 * 150
      self.contentAdapter[type].adapter:setBottomCall(function()
        FriendManager.LoadMoreFriend()
      end)
    elseif type == TabType.Recommend then
      self.contentAdapter[type] = {
        list = IGUIGridView.new("BedWarFriends-Recommend-List-Gird", self.layRecommendContent),
        adapter = UIHelper.newGameAdapter("RecommendItemAdapter")
      }
      config = {
        50,
        31,
        2
      }
      itemWidth = (self.contentAdapter[type].list:getWidth() - 50) / 2
      itemHeight = itemWidth / 429.5 * 153
    elseif type == TabType.Request then
      self.contentAdapter[type] = {
        list = IGUIGridView.new("BedWarFriends-Request-List-Gird", v),
        adapter = UIHelper.newGameAdapter("RequestItemAdapter")
      }
      config = {
        0,
        32,
        1
      }
      itemWidth = self.contentAdapter[type].list:getWidth()
      itemHeight = itemWidth / 931 * 185
      self.contentAdapter[type].adapter:setBottomCall(function()
        FriendManager.LoadMoreFriendRequest()
      end)
    elseif type == TabType.Subscribe then
      self.contentAdapter[type] = {
        list = IGUIGridView.new("BedWarFriends-Subscribe-List-Gird", self.laySubscribeContent),
        adapter = UIHelper.newGameAdapter("SubscribeItemAdapter")
      }
      config = {
        0,
        15,
        1
      }
      itemWidth = self.contentAdapter[type].list:getWidth()
      itemHeight = itemWidth / 902 * 124
      self.contentAdapter[type].adapter:setBottomCall(function()
        self:loadSubscribeData(self.curSubscribeTabType)
      end)
    end
    if self.contentAdapter[type] then
      self.contentAdapter[type].list:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
      self.contentAdapter[type].list:setConfig(config[1], config[2], config[3])
      self.contentAdapter[type].adapter:setItemSize(itemWidth, itemHeight)
      self.contentAdapter[type].list:setAdapter(self.contentAdapter[type].adapter)
    end
  end
end

function UIFriends:initSubscribeTabs()
  for type, v in pairs(self.subscribeTabs) do
    v:SetText(Lang:getString(SubscribeTabText[type]))
    v:SetNormalImage("set:bed_war_3_button.json image:btn_0_non_current04")
    v:SetPushedImage("set:bed_war_3_button.json image:btn_0_non_current04")
    v:SetTextColor(Define.TabTextColor.Normal)
  end
end

function UIFriends:initSelectList()
  for type, v in pairs(self.screenItem) do
    local list = UIHelper.newGameGUIWindow("GUISelectList", "BedWarSelectList.json")
    v.win:AddChildWindow(list.root)
    list:initList(type)
    v.list = list
  end
end

function UIFriends:setTabSelect(type)
  if type == TabType.Request then
    UIUtils.updateRedDotCount(Define.RedDotKey.FriendApply, 0)
  end
  if not self.firstInitRecommend and type == TabType.Recommend then
    self.firstInitRecommend = true
    FriendManager.LoadFriendRecommend()
  end
  if type == TabType.Subscribe then
    for _, subscribeTabType in pairs(SubscribeTabType) do
      self:loadSubscribeData(subscribeTabType)
    end
    self.contentAdapter[type].adapter:setScrollOffset(0)
  end
  if self.selectTab and self.selectTab ~= 0 then
    local oldTab = self.tabs[self.selectTab]
    self.layouts[self.selectTab]:SetVisible(false)
    oldTab.btn:SetNormalImage("")
    oldTab.btn:SetPushedImage("")
    oldTab.btn:SetTextColor(Define.TabTextColor.Normal)
    oldTab.line:SetVisible(true)
  end
  local newTab = self.tabs[type]
  self.layouts[type]:SetVisible(true)
  newTab.btn:SetNormalImage("set:bed_war_3_button.json image:btn_0_current01")
  newTab.btn:SetPushedImage("set:bed_war_3_button.json image:btn_0_current01")
  newTab.btn:SetTextColor(Define.TabTextColor.Select)
  newTab.line:SetVisible(false)
  self.selectTab = type
  self.llNoFriendTip:SetVisible(type == TabType.Friend and self.dataList[type] and 0 >= #self.dataList[type])
  self.stNoFriendTipText:SetText(Lang:getString(NoneTipText.NoFriend))
  if type == TabType.Recommend then
    self:hideScreenList()
  end
  if type == TabType.Subscribe then
    local text = Lang:getString(self.curSubscribeTabType == SubscribeTabType.Focus and NoneTipText.NoFollow or NoneTipText.NoFans)
    local key = self.curSubscribeTabType == SubscribeTabType.Focus and "Focus" or "Fans"
    local items = WebPageUtil:getWebPageItems(key)
    self.llNoFriendTip:SetVisible(#items == 0)
    self.stNoFriendTipText:SetText(Lang:getString(text))
  end
end

function UIFriends:setSubscribeTabSelect(type)
  if self.curSubscribeTabType and self.curSubscribeTabType ~= 0 then
    local oldTab = self.subscribeTabs[self.curSubscribeTabType]
    oldTab:SetNormalImage("set:bed_war_3_button.json image:btn_0_non_current04")
    oldTab:SetPushedImage("set:bed_war_3_button.json image:btn_0_non_current04")
    oldTab:SetTextColor(Define.TabTextColor.Normal)
  end
  local newTab = self.subscribeTabs[type]
  newTab:SetNormalImage("set:bed_war_3_button.json image:btn_0_current04")
  newTab:SetPushedImage("set:bed_war_3_button.json image:btn_0_current04")
  newTab:SetTextColor(Define.TabTextColor.Select)
  self.curSubscribeTabType = type
  self:updateSubscribeList()
end

function UIFriends:updateSubscribeList()
  local data = {}
  if self.curSubscribeTabType == SubscribeTabType.Fans then
    data = WebPageUtil:getWebPageItems("Fans")
  else
    data = WebPageUtil:getWebPageItems("Focus")
  end
  self.contentAdapter[TabType.Subscribe].adapter:setData(data, true)
  if self.selectTab == TabType.Subscribe then
    local text = Lang:getString(self.curSubscribeTabType == SubscribeTabType.Focus and NoneTipText.NoFollow or NoneTipText.NoFans)
    self.llNoFriendTip:SetVisible(#data <= 0)
    self.stNoFriendTipText:SetText(Lang:getString(text))
  end
end

function UIFriends:loadSubscribeData(type)
  if type == SubscribeTabType.Fans then
    if not WebPageUtil:createWebPage("Fans", function(pageNo, _, callback)
      WebService:GetPlayerFansList(Game:getPlatformUserId(), pageNo, function(code, data)
        if code ~= 1 or not data then
          return
        end
        callback(data.data)
      end)
    end, 10, function()
      if self.curSubscribeTabType == type then
        self:updateSubscribeList()
      end
    end) then
      WebPageUtil:loadMorePageItem("Fans")
    end
  elseif type == SubscribeTabType.Focus and not WebPageUtil:createWebPage("Focus", function(pageNo, _, callback)
    WebService:GetPlayerFollowList(Game:getPlatformUserId(), pageNo, function(code, data)
      if code ~= 1 or not data then
        return
      end
      callback(data.data)
    end)
  end, 10, function()
    if self.curSubscribeTabType == type then
      self:updateSubscribeList()
    end
  end) then
    WebPageUtil:loadMorePageItem("Focus")
  end
end

function UIFriends:refreshData(type)
  if type == TabType.Friend then
    self:updateFriend()
  elseif type == TabType.Request then
    self:updateRequest()
  elseif type == TabType.Recommend then
    self:updateRecommend()
  end
end

function UIFriends:updateFriend()
  local friends = FriendManager.GetFriends()
  local friendList = {}
  for _, userId in pairs(friends) do
    table.insert(friendList, UserInfoCache:GetCache(userId))
  end
  self.dataList[TabType.Friend] = friendList
  self.contentAdapter[TabType.Friend].adapter:setData(friendList, true)
  self.llNoFriendTip:SetVisible(self.selectTab == TabType.Friend and #friendList <= 0)
end

function UIFriends:updateRecommend()
  local recommend = FriendManager.recommend or {}
  self.dataList[TabType.Recommend] = recommend
  self.contentAdapter[TabType.Recommend].adapter:setData(recommend)
end

function UIFriends:updateRequest()
  local requests = FriendManager.GetAllFriendRequest()
  self.dataList[TabType.Request] = requests
  self.contentAdapter[TabType.Request].adapter:setData(requests, true)
end

function UIFriends:searchFriend()
  local condition = self.etSearch:GetText()
  local data = {}
  if condition and string.len(condition) > 0 then
    data.searchText = condition
    data.type = RecommendType.WithSearchText
    FriendManager.LoadFriendRecommendWithScreen(data)
  end
end

function UIFriends:screenRecommend(needReload)
  if not FriendManager.CanScreen(Game:getPlatformUserId()) then
    return
  end
  local data = {}
  if not needReload and next(self.screenData) then
    if self.screenDataChange then
      for i, v in pairs(self.screenData) do
        if i == ScreenType.Lang and v then
          data.language = v
        elseif i == ScreenType.Sex and v then
          data.sex = v
        end
      end
      self.screenDataChange = false
    else
      return
    end
  end
  if next(data) then
    data.type = RecommendType.WithScreen
    FriendManager.LoadFriendRecommendWithScreen(data)
  else
    self.screenDataChange = true
    FriendManager.LoadFriendRecommend()
  end
end

function UIFriends:onShow()
  if not self.first then
    self:setTabSelect(TabType.Friend)
    self.first = true
  end
  if self.selectTab == TabType.Friend and self.contentAdapter[TabType.Friend].adapter:getItemCount() < 1 then
    self:setTabSelect(TabType.Recommend)
  end
  self:hideScreenList()
end

function UIFriends:hideScreenList()
  for type, v in pairs(self.screenItem) do
    v.list:hideList()
  end
end

function UIFriends:onPlayerFollowStatusChange(userId, operationType)
  local fanList = WebPageUtil:getWebPageItems("Fans")
  local focusList = WebPageUtil:getWebPageItems("Focus")
  
  local function findFunc(item)
    return item.userId == userId
  end
  
  if operationType == Define.FollowOperationType.CancelFollow then
    local fan = TableUtil.findElementByFun(fanList, findFunc)
    if fan then
      fan.followStatus = Define.FollowStatus.Fan
    end
    local focus = TableUtil.findElementByFun(focusList, findFunc)
    if focus then
      TableUtil.tableRemove(focusList, focus)
    end
    self:updateSubscribeList()
  elseif operationType == Define.FollowOperationType.Follow then
    local followStatus = Define.FollowStatus.Follow
    local fan = TableUtil.findElementByFun(fanList, findFunc)
    if fan then
      fan.followStatus = Define.FollowStatus.EachFollow
      followStatus = Define.FollowStatus.EachFollow
    end
    UserInfoCache:GetCacheByUserIds({userId}, function()
      local info = UserInfoCache:GetCache(userId)
      info.followStatus = followStatus
      table.insert(focusList, 1, info)
      self:updateSubscribeList()
    end)
  end
end

return UIFriends

local UIVisitorsListContentLayout = class("UIVisitorsListContentLayout", IGUILayout)

function UIVisitorsListContentLayout:ctor(name, parent)
  self.super.ctor(self, name, parent)
end

function UIVisitorsListContentLayout:onLoad()
  self.llInfo = self:getChildWindow("VisitorsListContent-Info", GUIType.Layout)
  self.stToday = self:getChildWindow("VisitorsListContent-Today", GUIType.StaticText)
  self.stHistory = self:getChildWindow("VisitorsListContent-History", GUIType.StaticText)
  self.llList = self:getChildWindow("VisitorsListContent-List", GUIType.Layout)
  self:initView()
  self.gvVisitorsList = IGUIGridView.new("VisitorsListContent-Visitors-List", self.llList)
  self.gvVisitorsList.root:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvVisitorsList:setConfig(14, 10, 1)
  self.visitorsAdapter = UIHelper.newGameAdapter("VisitorsAdapter")
  self.visitorsAdapter:setItemSize(686, 101)
  self.gvVisitorsList:setAdapter(self.visitorsAdapter)
end

function UIVisitorsListContentLayout:initView()
  self.stToday:SetText(Lang:getString("gui.personal.visitors.today") .. ":\226\150\162FF81F3EA 0")
  self.stHistory:SetText(Lang:getString("gui.personal.visitors.history") .. ":\226\150\162FF81F3EA 0")
end

function UIVisitorsListContentLayout:setData(data)
  if not data then
    return
  end
  self.stToday:SetText(Lang:getString("gui.personal.visitors.today") .. ":\226\150\162FF81F3EA  " .. data.dailyVisitorCount)
  self.stHistory:SetText(Lang:getString("gui.personal.visitors.history") .. ":\226\150\162FF81F3EA  " .. data.historyVisitorCount)
  local effectiveVisitors = {}
  for _, visitorInfo in pairs(data.visitorInfos) do
    if UserInfoCache:GetCache(visitorInfo.visitorId) then
      table.insert(effectiveVisitors, visitorInfo)
    end
  end
  self.visitorsAdapter:setData(effectiveVisitors)
end

VisitorsListContentLayout = buildPopUpWindowsContent(UIVisitorsListContentLayout, "VisitorsListContent.json")
return UIVisitorsListContentLayout

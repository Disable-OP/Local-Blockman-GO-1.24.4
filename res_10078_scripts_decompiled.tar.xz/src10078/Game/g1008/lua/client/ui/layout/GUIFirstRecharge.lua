local UIFirstRecharge = class("UIFirstRecharge", IGUILayout)

function UIFirstRecharge:onLoad()
  self.canReceive = false
  self.btnRecharge = self:getChildWindow("BedWarFirstRecharge-Recharge", GUIType.Button)
  self.btnRecharge:SetText(Lang:getString("bed.war.activity.recharge"))
  self.btnRecharge:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.clickUI()
    if self.canReceive then
      Events.UpdateActivityRedPointEvent:invoke(1, false)
      GamePacketSender:sendReceiveFirstRecharge()
    else
      ClientHelper.onRecharge(1)
    end
  end)
  local tvDescText = self:getChildWindow("BedWarFirstRecharge-Desc-Text")
  tvDescText:SetText(Lang:getString("bed.war.first.recharge.desc"))
  local llReward = self:getChildWindow("BedWarFirstRecharge-Rewards")
  self.gvRewards = IGUIGridView.new("BedWarFirstRecharge-Rewards-Childs", llReward)
  self.gvRewards:setConfig(10, 10, 3)
end

function UIFirstRecharge:onShow()
  if self.gvRewards:getItemCount() ~= 0 then
    return
  end
  local rewards = FirstRechargeConfig.getRewards()
  local contentWidth = self.gvRewards:getWidth()
  local contentHeight = self.gvRewards:getHeight()
  local itemWidth = (contentWidth - 20) / 3
  local itemHeight = (contentHeight - 10) / 2
  for _, reward in pairs(rewards) do
    local item = UIHelper.newGameGUIWindow("GUIFirstRechargeReward", "BedWarFirstRechargeReward.json")
    item:setWidth({0, itemWidth})
    item:setHeight({0, itemHeight})
    item:setReward(reward.RewardId)
    self.gvRewards:addItem(item)
  end
end

function UIFirstRecharge:setCanReceive(canReceive)
  self.canReceive = canReceive
  if self.canReceive then
    Events.UpdateActivityRedPointEvent:invoke(1, true)
    self.btnRecharge:SetText(Lang:getString("bed.war.activity.receive"))
  else
    Events.UpdateActivityRedPointEvent:invoke(1, false)
    self.btnRecharge:SetText(Lang:getString("bed.war.activity.recharge"))
  end
end

return UIFirstRecharge

local UIBedWarSurvey = class("UIBedWarSurvey", IGUILayout)

function UIBedWarSurvey:onLoad()
  self.tvTitle = self:getChildWindow("BedWarSurvey-Title", GUIType.StaticText)
  self.tvTip = self:getChildWindow("BedWarSurvey-Tip", GUIType.StaticText)
  self.tvPush = self:getChildWindow("BedWarSurvey-Push-Text", GUIType.StaticText)
  self.tvProgress = self:getChildWindow("BedWarSurvey-Progress-Text", GUIType.StaticText)
  self.tvTitle:SetText(Lang:getString("Survey_Title"))
  self.tvTip:SetText(Lang:getString("Survey_Tip"))
  self.tvPush:SetText(Lang:getString("Survey_Push"))
  self.pbProgress = self:getChildWindow("BedWarSurvey-Progress", GUIType.ProgressBar)
  local llItems = self:getChildWindow("BedWarSurvey-Items", GUIType.Layout)
  self.lvItems = IGUIListView.new("BedWarSurvey-Items-List", llItems)
  self.lvItems:setArea({0, 8}, {0, 8}, {1, -16}, {1, -16})
  self.lvItems:setItemSpace(8)
  local allTask = SurveyConfig:getAllTask()
  for index, task in pairs(allTask) do
    local item = UIHelper.newGameGUIWindow("GUIBedWarSurveyItem", "BedWarSurveyItem.json")
    item:init(index, task)
    item:setWidth({1, 0})
    self.lvItems:addItem(item)
  end
  self.tvProgress:SetText("0/" .. tostring(#allTask))
  local btnClose = self:getChildWindow("BedWarSurvey-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide(true)
  end)
  local btnPush = self:getChildWindow("BedWarSurvey-Push", GUIType.Button)
  btnPush:registerEvent(GUIEvent.ButtonClick, function()
    self:onClickPush()
  end)
end

function UIBedWarSurvey:onClickPush()
  local allTask = SurveyConfig:getAllTask()
  local totalNum = #allTask
  local curSelectNum = 0
  local pushData = {}
  local itemsCount = self.lvItems:getItemCount()
  for index = 1, itemsCount do
    local item = self.lvItems:getItem("index", index)
    local questionId, select = item:onDoReport()
    if questionId and select then
      pushData[questionId] = select
    end
    if item:checkIsSelect() then
      curSelectNum = curSelectNum + 1
    else
      item:showFlash()
      if index <= 2 then
        index = 0
      else
        index = index - 2
      end
      local offset = 154 * index
      self.lvItems.root:SetScrollOffset(-offset)
      break
    end
  end
  if totalNum == curSelectNum then
    PlayerManager:getClientPlayer():sendPacket({
      pid = "GameAnalytics",
      event = "BedWar_Survey",
      pushData = json.encode(pushData)
    })
    GamePacketSender:sendPushSurveySuccess()
    self:hide(true)
    GUIStore:hideSurveyEntrance()
  end
end

function UIBedWarSurvey:onSelectNewItem()
  local allTask = SurveyConfig:getAllTask()
  local totalNum = #allTask
  local curSelectNum = 0
  local itemsCount = self.lvItems:getItemCount()
  for index = 1, itemsCount do
    local item = self.lvItems:getItem("index", index)
    if item:checkIsSelect() then
      curSelectNum = curSelectNum + 1
    end
  end
  self.pbProgress:SetProgress(curSelectNum / totalNum)
  self.tvProgress:SetText(tostring(curSelectNum) .. "/" .. tostring(totalNum))
end

return UIBedWarSurvey

local UIPropPacketLayout = class("UIPropPacketLayout", IGUILayout)
local gui_mainControl = DynamicCastHelper.dynamicCastGuiMainControl(RootGuiLayout.Instance():getLayout(0))
local PropPacketData = {}

function UIPropPacketLayout:ctor(parent)
  self.super.ctor(self, "PropPacket.json", parent)
end

function UIPropPacketLayout:onLoad()
  self.llHotBarBg = self:getChildWindow("PropPacket-HotBar-Bg", GUIType.Layout)
  self.stHotBar = self:getChildWindow("PropPacket-HotBar", GUIType.SlotTable)
  self.btnOpen = self:getChildWindow("PropPacket-Open", GUIType.Button)
  self.llPacket = self:getChildWindow("PropPacket-Packet", GUIType.Layout)
  self.llPackBg = self:getChildWindow("PropPacket-Pack-Bg", GUIType.Layout)
  self.llPacketContent = self:getChildWindow("PropPacket-Packet-Content", GUIType.Layout)
  self.llPacketTitle = self:getChildWindow("PropPacket-Packet-Title", GUIType.Layout)
  self.stPacketTitleText = self:getChildWindow("PropPacket-Packet-Title-Text", GUIType.StaticText)
  self.btnPacketClose = self:getChildWindow("PropPacket-Packet-Close", GUIType.Button)
  self.llPacketHotBarBg = self:getChildWindow("PropPacket-Packet-HotBar-Bg", GUIType.Layout)
  self.stPacketHotBarText = self:getChildWindow("PropPacket-Packet-HotBar-Text", GUIType.StaticText)
  self.llPacketMainBg = self:getChildWindow("PropPacket-Packet-Main-Bg", GUIType.Layout)
  self.stPacketMainText = self:getChildWindow("PropPacket-Packet-Main-Text", GUIType.StaticText)
  self.btnTipBtn = self:getChildWindow("PropPacket-Tip-Btn", GUIType.Button)
  self.btnMoreBtn = self:getChildWindow("PropPacket-More-Btn", GUIType.Button)
  self:openPacket(false)
  self.gvPacketHotBar = GUIManager:createGUIWindow(GUIType.GridView, "PropPacket-Packet-HotBar-GridView")
  self.gvPacketHotBar:SetArea({0, 0}, {0, 0}, {1, 0}, {1, -20})
  self.gvPacketHotBar:InitConfig(10, 10, 7)
  self.gvPacketHotBar:SetItemAlignment(HorizontalAlignment.Center)
  self.gvPacketHotBar:SetVerticalAlignment(VerticalAlignment.Center)
  self.llPacketHotBarBg:AddChildWindow(self.gvPacketHotBar)
  self.gvPacketMain = GUIManager:createGUIWindow(GUIType.GridView, "PropPacket-Packet-Main-GridView")
  self.gvPacketMain:SetArea({0, 0}, {0, 0}, {1, 0}, {1, -20})
  self.gvPacketMain:InitConfig(10, 10, 7)
  self.gvPacketMain:SetItemAlignment(HorizontalAlignment.Center)
  self.gvPacketMain:SetVerticalAlignment(VerticalAlignment.Center)
  self.llPacketMainBg:AddChildWindow(self.gvPacketMain)
  self.HotBarList = {}
  self.MainList = {}
  for index = Define.PROP_INDEX_START, Define.PROP_INDEX_END do
    local GUIItemSlot = self.stHotBar:GetItemSlot(0, index - Define.PROP_INDEX_START)
    GUIItemSlot:registerEvent(GUIEvent.Click, function()
      self:clickHotBar(index - Define.PROP_INDEX_START)
    end)
    local item = UIHelper.newGameGUIWindow("GUIPropPacketItem")
    item.root:registerEvent(GUIEvent.Click, function()
      self:clickPacketHotBar(item)
    end)
    self.gvPacketHotBar:AddItem(item.root)
    table.insert(self.HotBarList, item)
  end
  for i = 1, 28 do
    local item = UIHelper.newGameGUIWindow("GUIPropPacketItem")
    item.root:registerEvent(GUIEvent.Click, function()
      self:clickPacketMain(item)
    end)
    self.gvPacketMain:AddItem(item.root)
    table.insert(self.MainList, item)
  end
  self:initEvent()
end

function UIPropPacketLayout:initView()
  self.stPacketTitleText:SetText(Lang:getString("gui.prop.packet.title"))
  local textWith = self.stPacketTitleText:GetTextWidth()
  self.btnTipBtn:SetXPosition({
    0,
    self.stPacketTitleText:GetXPosition()[2] + 20 + textWith
  })
  self.stPacketHotBarText:SetText(Lang:getString("gui.prop.packet.bar"))
  self.stPacketMainText:SetText(Lang:getString("gui.prop.packet.main"))
  self.btnMoreBtn:SetText(Lang:getString("gui.prop.packet.more"))
end

function UIPropPacketLayout:onStart()
  self:initView()
end

function UIPropPacketLayout:initEvent()
  self.llPackBg:registerEvent(GUIEvent.Click, function()
    self:openPacket(false)
  end)
  self.btnOpen:registerEvent(GUIEvent.ButtonClick, function()
    self:openPacket(true)
  end)
  self.btnPacketClose:registerEvent(GUIEvent.ButtonClick, function()
    self:openPacket(false)
  end)
  self.btnTipBtn:registerEvent(GUIEvent.ButtonClick, function()
    if not GUICommonActivityTextDialog then
      local UICommonActivityTextDialog = require("client.activity.layout.GUICommonActivityTextDialog")
      GUICommonActivityTextDialog = UICommonActivityTextDialog.new("GameActivityTextDialog.json")
      GUICommonActivityTextDialog:setAlwaysOnTop(true)
      GUICommonActivityTextDialog:hide()
    end
    GUICommonActivityTextDialog:showText("gui.prop.packet.tip.title", "gui.prop.packet.tip.text")
  end)
  self.btnMoreBtn:registerEvent(GUIEvent.ButtonClick, function()
    GUIStore:show(StoreId.CubeStore, 7)
  end)
end

function UIPropPacketLayout:onTick()
  local player = Game:getPlayer()
  if player then
    local inv = player:getInventory()
    if inv then
      for index = Define.PROP_INDEX_START, Define.PROP_INDEX_END do
        self.stHotBar:setItemStack(0, index - Define.PROP_INDEX_START, inv:getStackInSlot(index))
      end
      local index = inv:getCurrentItemIndexInMain()
      if index <= Define.PROP_INDEX_END then
        self.stHotBar:selectItemSlot(index - Define.PROP_INDEX_START)
      end
    end
  end
  gui_mainControl:updateGuiSlotTableSkillCd(self.stHotBar)
end

function UIPropPacketLayout:clickHotBar(index)
  local player = Game:getPlayer()
  if player then
    local inv = player:getInventory()
    if inv then
      inv:setCurrentItemIndexInMain(index + Define.PROP_INDEX_START)
      PlayerManager:getClientPlayer():sendPacket({
        pid = "ClickHotBar",
        index = index
      })
    end
  end
end

function UIPropPacketLayout:clickPacketHotBar(item)
  if not item.propData then
    return
  end
  local packet = {
    pid = "UnloadPropItem",
    itemId = item.propData.itemId
  }
  PlayerManager:getClientPlayer():sendPacket(packet)
end

function UIPropPacketLayout:clickPacketMain(item)
  if not item.propData then
    return
  end
  local packet = {
    pid = "EquipPropItem",
    itemId = item.propData.itemId
  }
  PlayerManager:getClientPlayer():sendPacket(packet)
end

function UIPropPacketLayout:refreshUI(data)
  for key, propData in pairs(data) do
    PropPacketData[key] = propData
    if propData.count == 0 then
      PropPacketData[key] = nil
    end
  end
  if not GuiItemStack.getRenderItems() then
    LuaTimer:schedule(function()
      self:refreshUI(data)
    end, 100)
    return
  end
  for _, item in pairs(self.MainList) do
    item:onDataChanged()
  end
  for _, item in pairs(self.HotBarList) do
    item:onDataChanged()
  end
  if Game:isEnableIndie() and GameType == "g1046" then
  else
    if TableUtil.isEmpty(PropPacketData) then
      GUIPlayerInfo:setPropPacketVisible(false)
      self:hide()
      return
    end
    GUIPlayerInfo:setPropPacketVisible(true)
    self:show()
  end
  local MainData = {}
  for itemId, propData in pairs(PropPacketData) do
    if propData.equipIndex ~= -1 then
      local item = self.HotBarList[propData.equipIndex + 1]
      if item then
        item:onDataChanged(propData)
      end
    else
      table.insert(MainData, propData)
    end
  end
  table.sort(MainData, function(a, b)
    return a.itemId < b.itemId
  end)
  for index, propData in pairs(MainData) do
    local item = self.MainList[index]
    if item then
      item:onDataChanged(propData)
    end
  end
end

function UIPropPacketLayout:openPacket(open)
  self.llPacket:SetVisible(open)
  if Game:isEnableIndie() and GameType == "g1046" then
    if open then
      self:show()
    else
      self:hide()
    end
  end
end

return UIPropPacketLayout

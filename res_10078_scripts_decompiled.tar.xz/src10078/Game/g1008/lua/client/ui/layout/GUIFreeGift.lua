local UIFreeGift = class("UIFreeGift", IGUILayout)

function UIFreeGift:onLoad()
  self.lastTime = 0
  self:getChildWindow("BedWarFreeGift-Title", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_free_gift_title"))
  self:getChildWindow("BedWarFreeGift-Refresh-Text", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_free_gift_refresh_time_tip"))
  self.stRefreshTime = self:getChildWindow("BedWarFreeGift-Refresh-Time", GUIType.StaticText)
  self.stTicketNum = self:getChildWindow("BedWarFreeGift-Movie-Ticket-Num", GUIType.StaticText)
  self.btnAddTicket = self:getChildWindow("BedWarFreeGift-Movie-Ticket-Add", GUIType.Button)
  local llGiftList = self:getChildWindow("BedWarFreeGift-Gift-List", GUIType.Layout)
  self.gvGiftList = IGUIListView.new("BedWarFreeGift-Gift-List-Gv", llGiftList, nil, Orientation.Horizontal)
  self.gvGiftList:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvGiftList:setItemSpace(20)
  self.giftListAdapt = UIHelper.newGameAdapter("FreeGiftAdapt")
  local parentHigh = self.gvGiftList:getHeight()
  self.giftListAdapt:setItemSize(parentHigh * 215 / 362, parentHigh)
  self.gvGiftList:setAdapter(self.giftListAdapt)
  self:register()
end

function UIFreeGift:register()
  self:registerDataCallBack("InitFreeGiftData", function(data)
    self:calculateItemStatus(data)
    self:checkRedPoint()
  end, JsonBuilderProcessor)
  self:registerDataCallBack("GetFreeGiftReward", function(data)
    self:onGetReward(data)
  end, DataBuilderProcessor)
  self.btnAddTicket:registerEvent(GUIEvent.ButtonClick, function()
    GUIStore:show(StoreId.CubeStore, 11)
  end)
end

function UIFreeGift:checkRedPoint()
  for _, gift in pairs(self.gifts) do
    if gift.Times > 0 then
      Events.UpdateActivityRedPointEvent:invoke(ActivityType.FreeGift, true)
      return
    end
  end
end

function UIFreeGift:onShow()
  Events.UpdateActivityRedPointEvent:invoke(ActivityType.FreeGift, false)
end

function UIFreeGift:calculateItemStatus(data)
  self.gifts = TableUtil.copyTable(FreeGiftConfig:getGifts())
  for _, gift in pairs(self.gifts) do
    local findGift = false
    for _, d in pairs(data) do
      if gift.Id == d.Id then
        if d.CDEndTime <= os.time() then
          gift.CDEndTime = -1
        else
          gift.CDEndTime = d.CDEndTime
        end
        gift.Times = d.Times
        findGift = true
      end
    end
    if not findGift then
      gift.CDEndTime = -1
    end
  end
  self.giftListAdapt:setData(self.gifts)
end

function UIFreeGift:onTick()
  local time = os.time()
  if self.lastTime ~= time then
    for _, gift in pairs(self.gifts) do
      if time <= gift.CDEndTime then
        gift.CD = gift.CDEndTime - time
      else
        gift.CD = 0
      end
      if gift.CDEndTime == -1 then
        gift.CD = 0
      end
    end
    self.giftListAdapt:notifyDataChange()
    self.lastTime = time
    local refreshTime = DateUtil.getDayLastTime(os.time(), true) - os.time()
    local h = math.floor(refreshTime / 3600)
    local m = math.floor(refreshTime / 60 - h * 60)
    local refreshString = h .. "h" .. m .. "min"
    self.stRefreshTime:SetText(refreshString)
  end
  self.ticketNum = PlayerWallet.getMoneyByCoinId(Define.Money.TICKET)
  self.stTicketNum:SetText(self.ticketNum)
end

function UIFreeGift:onGetReward(data)
  local Id = data:getNumberParam("id")
  local giftConfig = FreeGiftConfig:getGiftById(Id)
  WatchAdTip.hide()
  local rewardConfig = RewardConfig.findRewardById(giftConfig.RewardId)
  if rewardConfig and tonumber(rewardConfig.RewardType) == Define.RewardType.CHEST then
    Events.OpenLotteryBoxEvent:invoke(tonumber(rewardConfig.RewardId))
  else
    GUIRewardResult:onShowRewards(giftConfig.RewardId)
  end
  for _, gift in pairs(self.gifts) do
    if gift.Id == Id then
      gift.CDEndTime = os.time() + giftConfig.CD
      gift.Times = gift.Times - 1
    end
  end
  self:onTick()
end

return UIFreeGift

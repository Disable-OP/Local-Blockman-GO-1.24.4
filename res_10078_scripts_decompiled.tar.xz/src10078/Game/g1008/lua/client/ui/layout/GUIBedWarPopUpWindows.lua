local dialog

local function getChildWindow(window, name, type)
  local child = window:getChildWindow(name, type)
  if not child then
    error("PopUpWindows must have" .. name .. " child window.")
  end
  return child
end

local GUIBedWarPopUpWindows = class("GUIBedWarPopUpWindows", IGUILayout)

function GUIBedWarPopUpWindows:onLoad()
  self.contents = {}
  self.contentView = nil
  self.closeClickListener = nil
  self.clickBgClose = true
  local name = string.gsub(self.__name, ".json", "-")
  self.llBg = getChildWindow(self, name .. "Bg", GUIType.Layout)
  self.llContent = getChildWindow(self, name .. "Content", GUIType.Layout)
  self.llPanel = getChildWindow(self, name .. "Panel", GUIType.Layout)
  self.tvTitleText = getChildWindow(self, name .. "Title-Text", GUIType.StaticText)
  self.btnClose = getChildWindow(self, name .. "Close", GUIType.Button)
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    if self.closeClickListener then
      self.closeClickListener()
    end
    self:hide()
    SoundUtil.playSound(SoundType.ClosePanel)
  end)
  self.llBg:registerEvent(GUIEvent.Click, function()
    if self.clickBgClose then
      self:hide()
      SoundUtil.playSound(SoundType.ClosePanel)
    end
  end)
end

function GUIBedWarPopUpWindows:setDefault()
  self.closeClickListener = nil
  self.clickBgClose = true
  self.tvTitleText:SetText(Lang:getString("gui_dialog_tip_title_tip"))
  self.btnClose:SetVisible(true)
  self.llPanel:SetArea({0, 0}, {0, 0}, {0, 640}, {0, 390})
  self.llContent:SetArea({0, 0}, {0, 70}, {1, -20}, {0, 215})
  if self.contentView ~= nil then
    self.contentView:hide()
    self.contentView = nil
  end
end

function GUIBedWarPopUpWindows:hide()
  self.disableTime = self.disableTime or 0
  if self.disableTime > 0 then
    print("GUIBedWarPopUpWindows:hide " .. self.disableTime)
    return
  end
  if self:isAlwaysShow() then
    return
  end
  if self:isShow() then
    self.root:SetVisible(false)
    self:onHide()
  end
end

function GUIBedWarPopUpWindows:onHide()
  self:setDefault()
end

function GUIBedWarPopUpWindows:builder()
  self:setDefault()
end

function GUIBedWarPopUpWindows:setContentView(view)
  self.contentView = self.contents[view.__name]
  if self.contentView ~= nil then
    self.contentView:show()
    local width = self.contentView.root:GetWidth()
    local height = self.contentView.root:GetHeight()
    self.llPanel:SetWidth({
      0,
      width[2] + 45
    })
    self.llPanel:SetHeight({
      0,
      height[2] + 90
    })
  else
    HostApi.log("GUIBedWarPopUpWindows [can't find content view --- name:" .. view.__name .. "]", 1)
  end
end

PopUpWindows = {}

function PopUpWindows.builder()
  dialog:builder()
  return PopUpWindows
end

function PopUpWindows.setTitleText(title)
  dialog.tvTitleText:SetText(Lang:getString(title))
  return PopUpWindows
end

function PopUpWindows.setContentView(view)
  dialog:setContentView(view)
  return PopUpWindows
end

function PopUpWindows.setCloseVisible(visible)
  dialog.btnClose:SetVisible(visible)
  return PopUpWindows
end

function PopUpWindows.setClickBgClose(isClose)
  dialog.clickBgClose = isClose
  return PopUpWindows
end

function PopUpWindows.setCloseClickListener(listener)
  dialog.closeClickListener = listener
  return PopUpWindows
end

function PopUpWindows.show()
  PopUpWindows.setAlwaysOnTop()
  dialog:show()
  SoundUtil.playSound(SoundType.OpenPanel)
end

function PopUpWindows.hide()
  dialog:hide()
end

function PopUpWindows.isShow()
  if not dialog then
    return false
  end
  return dialog:isShow()
end

function PopUpWindows.setAlwaysOnTop()
  dialog:setAlwaysOnTop(false)
  dialog:setAlwaysOnTop(true)
  return PopUpWindows
end

function initPopUpWindows(name)
  if dialog ~= nil then
    return
  end
  dialog = GUIBedWarPopUpWindows.new(name)
end

function buildPopUpWindowsContent(class, name)
  local content = class.new(name, dialog.llContent)
  content:hide()
  dialog.contents[name] = content
  return content
end

local function hideEngineWindow(name)
  local window = GUIManager:getWindowByName(name)
  
  if not window then
    return
  end
  window:SetXPosition({0, 6000})
  window:SetVisible(false)
end

local UIArmorPanel = class("GUIArmorPanel", IGUILayout)

function UIArmorPanel:onLoad()
  hideEngineWindow("ArmorPanel-Inventory-Radio")
  hideEngineWindow("ArmorPanel-Foot-Icon")
  hideEngineWindow("ArmorPanel-Inventory-Title-Name")
  hideEngineWindow("ArmorPanel-Inventory-Detail")
  hideEngineWindow("ArmorPanel-Dress-Layout")
  hideEngineWindow("ArmorPanel-Inventory-Btn-Neaten")
  hideEngineWindow("ArmorPanel-SellLayout")
  local tvName = self:getChildWindow("ArmorPanel-Player-Model-Title-Name", GUIType.StaticText)
  tvName:SetProperty("TextBorderColor", "0 0 0 1")
  tvName:SetFont(GUIFontManager:Instance():GetFont("HT16"))
  local ivTitleBG = self:getChildWindow("ArmorPanel-Player-Model-Title-BG", GUIType.StaticImage)
  ivTitleBG:SetYPosition({0, 5})
  local llPlayerModel = self:getChildWindow("ArmorPanel-Player-Model", GUIType.Layout)
  llPlayerModel:SetBackImage("set:bed_war_player_inventory.json image:player_bg")
  llPlayerModel:SetArea({0, 6}, {0, 6}, {0.375, -6}, {1, -24})
  llPlayerModel:SetProperty("StretchOffset", "0 0 0 0")
  local size = llPlayerModel:GetPixelSize().y
  local awvPlayerModel = self:getChildWindow("ArmorPanel-Actor", GUIType.ActorWindow)
  awvPlayerModel:SetArea({0, 5}, {0.03, 0}, {0, size}, {0.7, 0})
  local slArmors = self:getChildWindow("ArmorPanel-EquipedArmors", GUIType.SlotTable)
  slArmors:SetVerticalAlignment(VerticalAlignment.Bottom)
  slArmors:SetArea({0, 0}, {0, -15}, {0.662447, 0}, {0, 70})
  slArmors:SetProperty("RowCount", "1")
  slArmors:SetProperty("ColumnCount", "4")
  slArmors:SetProperty("HorizontalInterval", 0.07)
  slArmors:SetProperty("SlotWidth", 57)
  slArmors:SetProperty("SlotHeight", 57)
  local llInventoryLayout = self:getChildWindow("ArmorPanel-Inventory-Layout", GUIType.Layout)
  llInventoryLayout:SetArea({0, -6}, {0, 6}, {0.605603, 6}, {1, -24})
  llInventoryLayout:SetBackImage("set:bed_war_player_inventory.json image:inventory_bg")
  local siInventory = self:getChildWindow("ArmorPanel-Inventory", GUIType.ScrollableInventory)
  siInventory:SetArea({0, 10}, {0, 10}, {1, -20}, {1, -20})
  local contentWidth = siInventory:GetPixelSize().x
  local columnCount = 12
  local itemWidth = 68
  while contentWidth < (itemWidth + 10) * columnCount - 10 do
    columnCount = columnCount - 1
  end
  local interval = (contentWidth - itemWidth * columnCount) / (columnCount - 1)
  siInventory:SetProperty("SlotWidth", itemWidth)
  siInventory:SetProperty("SlotHeight", itemWidth)
  siInventory:SetProperty("HorizontalInterval", interval)
  siInventory:SetProperty("VerticalInterval", interval)
  siInventory:SetProperty("ColumnCount", columnCount)
  local mask = GUIManager:createGUIWindow(GUIType.Layout, "ArmorPanel-Player-Model-Mask")
  mask:SetArea({0, 0}, {0.8, 0}, {1, 0}, {0.2, 0})
  llPlayerModel:AddChildWindow(mask)
end

return UIArmorPanel

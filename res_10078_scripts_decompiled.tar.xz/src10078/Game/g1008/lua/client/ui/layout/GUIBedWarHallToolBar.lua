local UIBedWarHallToolBarLayout = class("UIBedWarHallToolBarLayout", IGUILayout)

function UIBedWarHallToolBarLayout:onLoad()
  self.tvLevelText = self:getChildWindow("BedWarHallToolBar-LvTxt")
  self.tvLevelExp = self:getChildWindow("BedWarHallToolBar-LvExp")
  self.pbLevelProgress = self:getChildWindow("BedWarHallToolBar-LVProgressBar", GUIType.ProgressBar)
  self.tvKeyText = self:getChildWindow("BedWarHallToolBar-KeyTxt")
  self.tvRankText = self:getChildWindow("BedWarHallToolBar-RankTxt")
  self.ivRankIcon = self:getChildWindow("BedWarHallToolBar-RankImg", GUIType.StaticImage)
  self.tvHonorText = self:getChildWindow("BedWarHallToolBar-HonorTxt")
  self:registerDataCallBack("HallInfo", function(data)
    self:onHallInfoUpdate(data)
  end, DataBuilderProcessor)
  self:registerDataCallBack("CurrentSeasonInfo", function(data)
    self:onCurrentSeasonInfoUpdate(data)
  end, DataBuilderProcessor)
end

function UIBedWarHallToolBarLayout:onHallInfoUpdate(data)
  local width = self.root:GetPixelSize().x
  width = 685 < width and 685 or width
  self.root:SetWidth({0, width})
  local level = data:getNumberParam("level")
  self.level = level
  local curExp = data:getNumberParam("curExp")
  local maxExp = data:getNumberParam("maxExp")
  local key = data:getNumberParam("key")
  local isMax = data:getBoolParam("isMax")
  self.tvLevelText:SetText(tostring(level))
  if not isMax then
    if 0 < maxExp then
      local expTxt = string.format("%d/%d", curExp, maxExp)
      self.tvLevelExp:SetVisible(true)
      self.tvLevelExp:SetText(expTxt)
      self.pbLevelProgress:SetProgress(curExp / maxExp)
    else
      self.tvLevelExp:SetVisible(false)
      self.pbLevelProgress:SetProgress(0)
    end
  else
    self.tvLevelExp:SetVisible(true)
    self.tvLevelExp:SetText("MAX")
    self.pbLevelProgress:SetProgress(0)
  end
  self.tvKeyText:SetText(tostring(key))
  PlayerWallet:setMoneyCount(5, key)
  GUIBoxLottery:setOpenNum(key)
end

function UIBedWarHallToolBarLayout:onCurrentSeasonInfoUpdate(data)
  local honorId = data:getNumberParam("honorId")
  local rank = data:getNumberParam("rank")
  local honor = data:getNumberParam("honor")
  self.tvRankText:SetText(string.format("NO:%d", rank))
  self.tvHonorText:SetText(tostring(honor))
  self.ivRankIcon:SetImage(string.format("set:bedwar_season_rule.json image:ic_honor_lv%d", honorId + 1))
end

function UIBedWarHallToolBarLayout:getPlayerLevel()
  return self.level or 0
end

return UIBedWarHallToolBarLayout

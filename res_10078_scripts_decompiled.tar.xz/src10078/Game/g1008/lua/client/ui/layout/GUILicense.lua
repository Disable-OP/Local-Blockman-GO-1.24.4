require("common.config.TaskConfig")
local UILicense = class("UILicense", IGUILayout)
local UIUtils = T(Global, "UIUtils")

function UILicense:calculateLevelInterval(level)
  local Interval = 0
  if level == 1 then
    Interval = "1"
  elseif 2 <= level and level <= 5 then
    Interval = "2_5"
  elseif 6 <= level and level <= 10 then
    Interval = "6_10"
  elseif 11 <= level and level <= 20 then
    Interval = "11_20"
  elseif 21 <= level and level <= 25 then
    Interval = "21_25"
  elseif 26 <= level and level <= 30 then
    Interval = "26_30"
  elseif 31 <= level and level <= 45 then
    Interval = "31_45"
  elseif 46 <= level and level <= 60 then
    Interval = "46_60"
  elseif 61 <= level and level <= 70 then
    Interval = "61_70"
  elseif 71 <= level and level <= 80 then
    Interval = "71_80"
  elseif 81 <= level then
    Interval = "80_120"
  end
  return Interval
end

function UILicense:checkHasLicense()
  if self.seasonDate > 0 then
    return true
  end
  CustomDialog.builder().setTitleText(Lang:getString("gui_bed_war_season_tip_title")).setHideLeftButton().setContentText(Lang:getString("gui_bed_war_season_tip_content")).setRightText(Lang:getString("gui_dialog_tip_btn_sure")).show()
  return false
end

function UILicense:onLoad()
  self.pages = {}
  self.taskList = {}
  self.seasonTaskList = {}
  self.refreshId = 0
  self.refreshTimes = 1
  self.rewardSelect = {Index = -1, position = nil}
  self.refreshTask = false
  self.offset = 0
  self.playerLevel = 0
  self.reFreshTime = DateUtil.getWeekLastTime(os.time(), true) + 79200
  local btnClose = self:getChildWindow("BedWarLicense-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide(true)
  end)
  self.btnExchangeDetail = self:getChildWindow("BedWarLicense-Detail", GUIType.Button)
  self.btnExchangeDetail:SetVisible(false)
  self.btnExchangeDetail:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundType.Click)
    GUIBoxDetail:showDetail(self.ExchangeDetail)
  end)
  self.btnGrandPrice = self:getChildWindow("BedWarLicense-Reward-List-left-down-Icon", GUIType.Button)
  self.btnGrandPrice:registerEvent(GUIEvent.ButtonClick, function()
    if self:checkHasLicense() then
      if BaseMain:getGameType() == "g1046" then
        GameAnalytics:design(1, {
          "H_License_bigprize",
          "BigPrize"
        })
      else
        GameAnalytics:design(1, {
          "G_License_bigprize",
          "BigPrize"
        })
      end
      GUILicenseGrandPriceDisplay:show()
    end
  end)
  self.btnBuy = self:getChildWindow("BedWarLicense-Reward-License-Buy", GUIType.Button)
  self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
    if self:checkHasLicense() then
      if self.hadBuy > 0 then
        if BaseMain:getGameType() == "g1046" then
          GameAnalytics:design(1, {
            "H_License_bigprize",
            "LicenseBuy"
          })
        else
          GameAnalytics:design(1, {
            "G_License_bigprize",
            "LicenseBuy"
          })
        end
        GUILicenseGrandPriceDisplay:show()
      else
        GUILicenseRewardBuy:show("YellowButton")
      end
    end
  end)
  local btnGeyAll = self:getChildWindow("BedWarLicense-Reward-Get-All", GUIType.Button)
  btnGeyAll:registerEvent(GUIEvent.ButtonClick, function()
    if self:checkHasLicense() then
      if BaseMain:getGameType() == "g1046" then
        GameAnalytics:design(1, {
          "H_License_receive"
        })
      else
        GameAnalytics:design(1, {
          "G_License_receive"
        })
      end
      GamePacketSender:sendBedWarLicenseGetReward(nil, nil, nil, self.seasonDate, true)
    end
  end)
  self.tvRightRewardUp = self:getChildWindow("BedWarLicense-Reward-List-right-up", GUIType.StaticImage)
  self.tvRightRewardDown = self:getChildWindow("BedWarLicense-Reward-List-right-down", GUIType.StaticImage)
  local btnFreeStageReward = self:getChildWindow("BedWarLicense-Reward-List-right-up-Btn", GUIType.Button)
  btnFreeStageReward:registerEvent(GUIEvent.ButtonClick, function()
    local rewardConfig = self.Rewards[self.cueStageLevel]
    if rewardConfig then
      self:showDescribe(rewardConfig.FreeRewardImage, rewardConfig.FreeDesc, rewardConfig.FreeShowType, rewardConfig.FreeActor, rewardConfig.FreeActorSkillName)
    end
  end)
  local btnPayStageReward = self:getChildWindow("BedWarLicense-Reward-List-right-down-Btn", GUIType.Button)
  btnPayStageReward:registerEvent(GUIEvent.ButtonClick, function()
    local rewardConfig = self.Rewards[self.cueStageLevel]
    if rewardConfig then
      self:showDescribe(rewardConfig.PayRewardImage, rewardConfig.PayDesc, rewardConfig.PayShowType, rewardConfig.PayActor, rewardConfig.PayActorSkillName)
    end
  end)
  self.btnBack = self:getChildWindow("BedWarLicense-Reward-List-Back", GUIType.Button)
  self.btnBack:SetVisible(false)
  self.btnBack:registerEvent(GUIEvent.ButtonClick, function()
    self.rewardListAdapt:setScrollOffset(self.offset)
  end)
  self.llMoney = self:getChildWindow("BedWarLicense-Money", GUIType.Layout)
  self.lvMoney = IGUIListView.new("BedWarLicense-Money-List", self.llMoney, nil, Orientation.Horizontal)
  self.lvMoney:setItemSpace(30)
  self.llHorn = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
  self.llHorn:onDataChanged({
    ItemId = 0,
    RealId = Define.Money.HORN
  })
  self.lvMoney:addItem(self.llHorn)
  self.llDiamond = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
  self.llDiamond:onDataChanged({
    ItemId = 0,
    RealId = Define.Money.DIAMOND
  })
  self.lvMoney:addItem(self.llDiamond)
  local llTabs = self:getChildWindow("BedWarLicense-Tab", GUIType.Layout)
  self.lvTabs = IGUIListView.new("BedWarLicense-Tab-List", llTabs, nil, Orientation.Horizontal)
  self.lvTabs:setItemSpace(4)
  local llRewardsList = self:getChildWindow("BedWarLicense-Reward-List-Items", GUIType.Layout)
  self.gvRewardList = IGUIListView.new("BedWarLicense-Reward-List-Items-Grid", llRewardsList, nil, Orientation.Horizontal)
  self.gvRewardList:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvRewardList:setItemSpace(0)
  self.rewardListAdapt = UIHelper.newGameAdapter("LicenseRewardListAdapt")
  local parentHigh = self.gvRewardList:getHeight()
  self.rewardListAdapt:setItemSize(130, parentHigh)
  self.gvRewardList:setAdapter(self.rewardListAdapt)
  local llTaskList = self:getChildWindow("BedWarLicense-Task-List", GUIType.Layout)
  self.lvTaskList = IGUIListView.new("BedWarLicense-Task-List-Grid", llTaskList, nil, Orientation.Vertical)
  self.lvTaskList:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.lvTaskList:setItemSpace(20)
  local llExchangeList = self:getChildWindow("BedWarLicense-Exchange-Layout", GUIType.Layout)
  self.gvExchangeList = IGUIGridView.new("BedWarLicense-Exchange-Layout-Items", llExchangeList)
  self.gvExchangeList:setArea({0, 5}, {0, 5}, {1, 0}, {1, 0})
  self.gvExchangeList:setConfig(13, 12, 4)
  self.exchangeListAdapt = UIHelper.newGameAdapter("LicenseExchangeAdapt")
  local exchangeParentWith = self.gvExchangeList:getWidth()
  local exchangeParentHigh = self.gvExchangeList:getHeight()
  local exchangeItemWith = (exchangeParentWith - 44) / 4
  local exchangeItemHigh = exchangeParentHigh / 2.5
  self.exchangeListAdapt:setItemSize(exchangeItemWith, exchangeItemHigh)
  self.gvExchangeList:setAdapter(self.exchangeListAdapt)
  self.llExchangeOne = self:getChildWindow("BedWarLicense-Describe-One", GUIType.Layout)
  self.llExchangeTen = self:getChildWindow("BedWarLicense-Describe-Ten", GUIType.Layout)
  self.siRewardDescribe = self:getChildWindow("BedWarLicense-Reward-Describe-Image", GUIType.StaticImage)
  self.stRewardDescribe = self:getChildWindow("BedWarLicense-Reward-Describe-Text", GUIType.StaticText)
  self.siRewardDescribeEffect = self:getChildWindow("BedWarLicense-Reward-Describe-Effect", GUIType.StaticImage)
  self.stExchangeTime = self:getChildWindow("BedWarLicense-Exchange-Time-Text", GUIType.StaticText)
  self.siExchangeDescribe = self:getChildWindow("BedWarLicense-Describe-Item", GUIType.StaticImage)
  self.stExchangeDescribe = self:getChildWindow("BedWarLicense-Describe-Text", GUIType.StaticText)
  self.stExchangePrice = self:getChildWindow("BedWarLicense-Describe-Exchange-Num", GUIType.StaticText)
  self.stExchangeOnePrice = self:getChildWindow("BedWarLicense-Describe-Exchange-Num-One", GUIType.StaticText)
  self.stExchangeTenPrice = self:getChildWindow("BedWarLicense-Describe-Exchange-Num-Ten", GUIType.StaticText)
  self.btnExchange = self:getChildWindow("BedWarLicense-Describe-Exchange", GUIType.Button)
  self.btnExchange:registerEvent(GUIEvent.ButtonClick, function()
    self:onExchange(1)
  end)
  self.btnExchangeOne = self:getChildWindow("BedWarLicense-Describe-Exchange-One", GUIType.Button)
  self.btnExchangeOne:registerEvent(GUIEvent.ButtonClick, function()
    self:onExchange(1)
  end)
  self.btnExchangeTen = self:getChildWindow("BedWarLicense-Describe-Exchange-Ten", GUIType.Button)
  self.btnExchangeTen:registerEvent(GUIEvent.ButtonClick, function()
    self:onExchange(10)
  end)
  self.btnCannotExchange = self:getChildWindow("BedWarLicense-Describe-Cannot-Exchange", GUIType.Button)
  self.btnCannotExchange:registerEvent(GUIEvent.ButtonClick, function()
    CustomDialog.builder().setTitleText(Lang:getString("gui_bed_war_season_tip_title")).setHideLeftButton().setContentText(Lang:getString("gui_bed_war_exchange_btn_had_get")).setRightText(Lang:getString("gui_dialog_tip_btn_sure")).show()
  end)
  self.siFreeStageReward = self:getChildWindow("BedWarLicense-Reward-List-right-up-Item", GUIType.StaticImage)
  self.siPayStageReward = self:getChildWindow("BedWarLicense-Reward-List-right-down-Item", GUIType.StaticImage)
  self.siFreeStageRewardHadGet = self:getChildWindow("BedWarLicense-Reward-List-right-up-HadGet", GUIType.StaticImage)
  self.siPayStageRewardHadGet = self:getChildWindow("BedWarLicense-Reward-List-right-down-HadGet", GUIType.StaticImage)
  self.siRewardStageEffect = self:getChildWindow("BedWarLicense-Reward-List-right-down-Effect", GUIType.StaticImage)
  self.siFreeRewardEffect = self:getChildWindow("BedWarLicense-Reward-List-right-up-Effect2", GUIType.StaticImage)
  self.siPayRewardEffect = self:getChildWindow("BedWarLicense-Reward-List-right-down-Effect2", GUIType.StaticImage)
  self.stRewardRightUpNum = self:getChildWindow("BedWarLicense-Reward-List-right-up-Num", GUIType.StaticText)
  self.stRewardRightDownNum = self:getChildWindow("BedWarLicense-Reward-List-right-down-Num", GUIType.StaticText)
  self.stRewardLineLevel = self:getChildWindow("BedWarLicense-Reward-List-right-Line-Level-Text", GUIType.StaticText)
  self.stRewardLevel = self:getChildWindow("BedWarLicense-Reward-Up-Level", GUIType.StaticText)
  self.pbRewardLevel = self:getChildWindow("BedWarLicense-Reward-Up-Progress-bar", GUIType.ProgressBar)
  self.stRewardEXP = self:getChildWindow("BedWarLicense-Reward-Up-Progress-Text", GUIType.StaticText)
  self.stRewardTime = self:getChildWindow("BedWarLicense-Reward-Up-Time-Text", GUIType.StaticText)
  self.awRewardActor = self:getChildWindow("BedWarLicense-Reward-Describe-Actor", GUIType.ActorWindow)
  self.stTaskChallengeNum = self:getChildWindow("BedWarLicense-Task-Season-Chellenge-Num", GUIType.StaticText)
  self.siRedPoint = self:getChildWindow("BedWarLicense-Task-Season-Chellenge-Red-Point", GUIType.StaticImage)
  self.stNextRewardLevel = self:getChildWindow("BedWarLicense-Task-Describe-Next-Reward-Level", GUIType.StaticText)
  self.stNextRewardName = self:getChildWindow("BedWarLicense-Task-Describe-Reward-Name", GUIType.StaticText)
  self.siTaskDescribe = self:getChildWindow("BedWarLicense-Task-Describe-image", GUIType.StaticImage)
  self.stTaskRefreshTime = self:getChildWindow("BedWarLicense-Task-Free-Refresh-Text", GUIType.StaticText)
  self.stTaskLevel = self:getChildWindow("BedWarLicense-Task-Level", GUIType.StaticText)
  self.pbTaskLevel = self:getChildWindow("BedWarLicense-Task-Progress-bar", GUIType.ProgressBar)
  self.stTaskEXP = self:getChildWindow("BedWarLicense-Task-Progress-Text", GUIType.StaticText)
  self.stTaskEXPLimit = self:getChildWindow("BedWarLicense-Task-Limit-EXP-Num", GUIType.StaticText)
  local btnSeasonTask = self:getChildWindow("BedWarLicense-Task-Season-Chellenge", GUIType.Button)
  btnSeasonTask:registerEvent(GUIEvent.ButtonClick, function()
    if self:checkHasLicense() then
      self:hide()
      GUILicenseSeasonTask:show()
    end
  end)
  self.siLock = self:getChildWindow("BedWarLicense-Reward-List-left-down-Lock", GUIType.StaticImage)
  self.stExchangeLevel = self:getChildWindow("BedWarLicense-Exchange-Progress-Level", GUIType.StaticText)
  self.pbExchangeLevel = self:getChildWindow("BedWarLicense-Exchange-Progress-bar", GUIType.ProgressBar)
  self.stExchangeEXP = self:getChildWindow("BedWarLicense-Exchange-Progress-Text", GUIType.StaticText)
  self.siGetAllRedPoint = self:getChildWindow("BedWarLicense-Reward-Get-All-Red-Point", GUIType.StaticImage)
  local llReward = self:getChildWindow("BedWarLicense-Reward", GUIType.Layout)
  table.insert(self.pages, llReward)
  local llTask = self:getChildWindow("BedWarLicense-Task", GUIType.Layout)
  table.insert(self.pages, llTask)
  local llExchange = self:getChildWindow("BedWarLicense-Exchange", GUIType.Layout)
  table.insert(self.pages, llExchange)
  self.seasonDate, self.exchangeDate, self.endSeasonDate, self.periodDate = LicenseConfig:calculateSeason()
  if self.seasonDate ~= -1 then
    self.Rewards = TableUtil.copyTable(LicenseConfig:getLevelRewardBySeason(self.seasonDate))
    self.Exchange = TableUtil.copyTable(LicenseConfig:getExchangeConfigBySeason(self.seasonDate))
  else
    self.Rewards = {}
    self.Exchange = {}
  end
  local btnRewardDisplayImageBtn = self:getChildWindow("BedWarLicense-Reward-Describe-Display-Image-Btn", GUIType.Button)
  btnRewardDisplayImageBtn:registerEvent(GUIEvent.ButtonClick, function()
    if self.hadBuy == 0 then
      GUILicenseRewardBuy:show("AdImage")
    end
  end)
  self:register()
  self.siRewardDisplayImage = self:getChildWindow("BedWarLicense-Reward-Describe-Display-Image", GUIType.StaticImage)
  self.siRewardDisplayActor = self:getChildWindow("BedWarLicense-Reward-Describe-Display-Actor", GUIType.ActorWindow)
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
  if not seasonConfig then
    return
  end
  self.siRewardDisplayActor:SetActor1(seasonConfig.PetActorName, seasonConfig.PetSkillName)
  self.siRewardDisplayActor:SetArea({
    0,
    seasonConfig.PetOffsetX2
  }, {
    0,
    seasonConfig.PetOffsetY2
  }, {
    0,
    seasonConfig.PetSize2
  }, {0, 1})
end

function UILicense:onStart()
  self:initLanguage()
end

function UILicense:initLanguage()
  local stFree1 = self:getChildWindow("BedWarLicense-Reward-List-left-up-Text1", GUIType.StaticText)
  local stFree2 = self:getChildWindow("BedWarLicense-Reward-List-left-up-Text2", GUIType.StaticText)
  stFree1:SetText(Lang:getString("gui_bed_war_license_reward_free"))
  stFree2:SetText(Lang:getString("gui_bed_war_license_reward_free"))
  local stPay1 = self:getChildWindow("BedWarLicense-Reward-List-left-down-Text1", GUIType.StaticText)
  local stPay2 = self:getChildWindow("BedWarLicense-Reward-List-left-down-Text2", GUIType.StaticText)
  stPay1:SetText(Lang:getString("gui_bed_war_license_reward_pay"))
  stPay2:SetText(Lang:getString("gui_bed_war_license_reward_pay"))
  local btnRewardGetAll = self:getChildWindow("BedWarLicense-Reward-Get-All", GUIType.Button)
  btnRewardGetAll:SetText(Lang:getString("gui_bed_war_license_get_all"))
  local stTaskEXPLimitText = self:getChildWindow("BedWarLicense-Task-Limit-EXP-Title", GUIType.StaticText)
  stTaskEXPLimitText:SetText(Lang:getString("gui_bed_war_license_task_exp_limit"))
  local stSeasonTaskText = self:getChildWindow("BedWarLicense-Task-Season-Chellenge-Text", GUIType.StaticText)
  stSeasonTaskText:SetText(Lang:getString("gui_bed_war_license_task_chellenge"))
  local stExchangeBtnText = self:getChildWindow("BedWarLicense-Describe-Exchange-Text", GUIType.StaticText)
  stExchangeBtnText:SetText(Lang:getString("gui_bed_war_license_exchange_btn"))
  local stExchangeOneBtnText = self:getChildWindow("BedWarLicense-Describe-Exchange-Text-One", GUIType.StaticText)
  stExchangeOneBtnText:SetText(Lang:getString("gui_bed_war_license_exchange_btn_one"))
  local stExchangeTenBtnText = self:getChildWindow("BedWarLicense-Describe-Exchange-Text-Ten", GUIType.StaticText)
  stExchangeTenBtnText:SetText(Lang:getString("gui_bed_war_license_exchange_btn_ten"))
  local stCannotExchange = self:getChildWindow("BedWarLicense-Cannot-Exchange-Text", GUIType.StaticText)
  stCannotExchange:SetText(Lang:getString("gui_bed_war_license_cannot_exchange"))
  local stTaskDescribeTitle = self:getChildWindow("BedWarLicense-Task-Describe-Title-Text", GUIType.StaticText)
  stTaskDescribeTitle:SetText(Lang:getString("gui_bed_war_license_task_describe_title"))
  local stTaskDescribeTitleShadow = self:getChildWindow("BedWarLicense-Task-Describe-Title-Text-shadow", GUIType.StaticText)
  stTaskDescribeTitleShadow:SetText(Lang:getString("gui_bed_war_license_task_describe_title"))
end

function UILicense:register()
  self:registerDataCallBack("BedWarLicenseData", function(data)
    self:onDataUpdate(data)
  end, JsonBuilderProcessor)
  self:registerDataCallBack("BedWarLicenseGetRewardSuccess", function(data)
    self:onGetRewardSuccess(data)
  end, JsonBuilderProcessor)
  self:registerDataCallBack("BedWarLicensePaySuccess", function(data)
    self:onPaySuccess(data)
  end, JsonBuilderProcessor)
  self:registerDataCallBack("BedWarLicenseExchangeSuccess", function(data)
    self:onExchangeSuccess(data)
  end, JsonBuilderProcessor)
  self:registerDataCallBack("LicenseDailyTask", function(data)
    self:onGetDailyTaskInfo(data)
  end, DataBuilderProcessor)
  self:registerDataCallBack("CleanTasks", function(data)
    self.taskList = {}
  end)
  self:registerDataCallBack("LicenseSeasonTask", function(data)
    self:onGetSeasonTaskInfo(data)
  end, DataBuilderProcessor)
  self:registerDataCallBack("LicenseFinishTask", function(data)
    self:onFinishTask(data)
  end, DataBuilderProcessor)
  self:registerDataCallBack("LicenseCleanTask", function(data)
    local type = data:getParam("Type")
    if type == "week" then
      self.taskList = {}
    elseif type == "season" then
      self.seasonTaskList = {}
    end
  end, DataBuilderProcessor)
  self:registerDataCallBack("LicenseWeekEXP", function(data)
    self.weekEXP = data:getNumberParam("WeekEXP")
    local weekConfig = LicenseConfig:getWeekConfig(self.seasonDate, self.week)
    if weekConfig then
      self.stTaskEXPLimit:SetText(self.weekEXP .. " / " .. weekConfig.EXPLimit)
    end
  end, DataBuilderProcessor)
  self:registerDataCallBack("BuyCustomGoodsSuccess", function(goodsId)
    self:checkExchangeDressStatus(goodsId)
  end)
  self:registerDataCallBack("WatchLicenseADSuccess", function(data)
    self:onWatchLicenseADSuccess(data)
  end, DataBuilderProcessor)
end

function UILicense:onWatchLicenseADSuccess(data)
  self.curEXP = data:getNumberParam("curEXP")
  self.playerLevel = data:getNumberParam("curLV")
  self.freeUpgradeTime = data:getNumberParam("freeTime")
  self:showContent()
end

function UILicense:onFinishTask(data)
  self.curEXP = data:getNumberParam("EXP")
  self.playerLevel = data:getNumberParam("level")
  self.weekEXP = data:getNumberParam("weekLimit")
  local weekConfig = LicenseConfig:getWeekConfig(self.seasonDate, self.week)
  if not weekConfig then
    return
  end
  self.stTaskEXPLimit:SetText(self.weekEXP .. " / " .. weekConfig.EXPLimit)
  if self.playerLevel == #self.Rewards then
    self.curEXP = -1
  end
  if self.seasonDate ~= -1 and self.loadFinish then
    self:showContent()
  end
end

function UILicense:onGetDailyTaskInfo(data)
  local finishNum = data:getNumberParam("finishNum")
  local taskId = data:getNumberParam("taskId")
  local progress = data:getNumberParam("progress")
  local status = data:getNumberParam("status")
  local taskInfo = {
    taskId = taskId,
    progress = progress,
    status = status,
    finishNum = finishNum
  }
  local haveTask = false
  for index, task in pairs(self.taskList) do
    if task.taskId == taskId then
      table.remove(self.taskList, index)
      table.insert(self.taskList, index, taskInfo)
      haveTask = true
    end
  end
  if not haveTask then
    table.insert(self.taskList, taskInfo)
    self:onTaskListUpDate()
  else
    local item = self.lvTaskList:getItem("taskId", taskId)
    if item then
      item:onDataChange(taskInfo)
    end
  end
end

function UILicense:onGetSeasonTaskInfo(data)
  local refreshId = data:getNumberParam("refreshId")
  local taskId = data:getNumberParam("taskId")
  local progress = data:getNumberParam("progress")
  local status = data:getNumberParam("status")
  local taskInfo = {
    taskId = taskId,
    progress = progress,
    status = status
  }
  if not taskId then
    return
  end
  if refreshId == -1 then
    local haveTask = false
    for index, task in pairs(self.seasonTaskList) do
      if task.taskId == taskId then
        table.remove(self.seasonTaskList, index)
        table.insert(self.seasonTaskList, index, taskInfo)
        haveTask = true
      end
    end
    if not haveTask then
      table.insert(self.seasonTaskList, taskInfo)
    end
  else
    for index, task in pairs(self.seasonTaskList) do
      if task.taskId == refreshId then
        table.remove(self.seasonTaskList, index)
        table.insert(self.seasonTaskList, index, taskInfo)
      end
    end
  end
  table.sort(self.seasonTaskList, function(a, b)
    return a.taskId < b.taskId
  end)
  GUILicenseSeasonTask:updateData()
  GUILicenseSeasonTask:showRedPoint()
end

function UILicense:onGetRewardSuccess(data)
  self.bigRewardList = {}
  self.smallRewardList = {}
  self.getFreeReward = self.getFreeReward or {}
  self.getPayReward = self.getPayReward or {}
  for _, reward in pairs(data) do
    local rewardConfig = LicenseConfig:getRewardByLV(GUILicense.seasonDate, reward.Lv)
    if rewardConfig then
      self.smallRewardList[reward.rewardId] = self.smallRewardList[reward.rewardId] or 0
      if reward.rewardType == "free" then
        local rewardData = {
          rewardId = reward.rewardId,
          Lv = reward.Lv
        }
        table.insert(self.getFreeReward, rewardData)
        if rewardConfig.FreeSpecialReward == 1 then
          table.insert(self.bigRewardList, reward.rewardId)
        else
          self.smallRewardList[reward.rewardId] = self.smallRewardList[reward.rewardId] + rewardConfig.FreeNum
        end
      elseif reward.rewardType == "pay" then
        local rewardData = {
          rewardId = reward.rewardId,
          Lv = reward.Lv
        }
        table.insert(self.getPayReward, rewardData)
        if rewardConfig.PaySpecialReward == 1 then
          table.insert(self.bigRewardList, reward.rewardId)
        else
          self.smallRewardList[reward.rewardId] = self.smallRewardList[reward.rewardId] + rewardConfig.PayNum
        end
      end
    end
  end
  self:showRewardTip()
  self:itemStatusChange()
  self.rewardListAdapt:notifyDataChange()
end

function UILicense:showRewardTip()
  self.bigRewardList = self.bigRewardList or {}
  self.smallRewardList = self.smallRewardList or {}
  if #self.bigRewardList > 0 then
    local reward = {name = "", image = ""}
    local rewardId = table.remove(self.bigRewardList, 1)
    local rewardConfig = RewardConfig.findRewardById(rewardId)
    if rewardConfig then
      reward.image = rewardConfig.Image
      reward.name = rewardConfig.Name
    else
      local good = CustomShopConfig:getGoodsConfig(rewardId)
      if good then
        reward.image = good.Image
        reward.name = good.Name
      end
    end
    GUIChallengeRewardReceive:init(reward, false, function()
      LuaTimer:schedule(function()
        self:showRewardTip()
      end, 0)
    end)
    GUIChallengeRewardReceive.stRibbon:SetText(Lang:getString("bed.war.reward.title"))
    return
  end
  local result = {}
  for rewardId, count in pairs(self.smallRewardList) do
    if #result == 5 then
      break
    end
    if count ~= 0 then
      local rewardConfig = RewardConfig.findRewardById(rewardId)
      if rewardConfig then
        table.insert(result, {
          Image = rewardConfig.Image,
          Name = rewardConfig.Name,
          Count = count
        })
        self.smallRewardList[rewardId] = nil
      else
        local good = CustomShopConfig:getGoodsConfig(rewardId)
        if good then
          table.insert(result, {
            Image = good.Image,
            Name = good.Name,
            Count = count
          })
          self.smallRewardList[rewardId] = nil
        end
      end
    end
  end
  if 0 < #result then
    GUIRewardResult:onShowRewardsTip(result, true, function()
      LuaTimer:schedule(function()
        self:showRewardTip()
      end, 0)
    end)
  end
end

function UILicense:updateRewardData(data)
  local rewards = {}
  for _, reward in pairs(data) do
    local rewardConfig = LicenseConfig:getRewardByLV(GUILicense.seasonDate, reward.Lv)
    if rewardConfig then
      local haveReward = false
      for _, rewardsItem in pairs(rewards) do
        if reward.rewardId == rewardsItem.rewardId then
          haveReward = rewardsItem
          break
        end
      end
      if haveReward then
        if reward.rewardType == "pay" then
          haveReward.Num = haveReward.Num + rewardConfig.PayNum
        elseif reward.rewardType == "free" then
          haveReward.Num = haveReward.Num + rewardConfig.FreeNum
        end
      else
        local temp = {}
        if reward.rewardType == "pay" then
          temp = {
            rewardId = reward.rewardId,
            Num = rewardConfig.PayNum
          }
        elseif reward.rewardType == "free" then
          temp = {
            rewardId = reward.rewardId,
            Num = rewardConfig.FreeNum
          }
        end
        table.insert(rewards, temp)
      end
    end
  end
  return rewards
end

function UILicense:onPaySuccess(data)
  GUILicenseBuyLevelTip:hide()
  self.curEXP = data.curEXP
  self.playerLevel = data.curLV
  self.hadBuy = data.hadBuy
  if self.playerLevel == #self.Rewards then
    self.curEXP = -1
  end
  self:checkShowBigPriceByLevel()
  self:showContent()
  if self.hadBuy ~= 0 then
    self.btnBuy:SetText(Lang:getString("gui_bed_war_license_display"))
  else
    self.btnBuy:SetText(Lang:getString("gui_bed_war_license_buy"))
  end
end

function UILicense:onExchangeSuccess(data)
  local exchangeConfig = LicenseConfig:getExchangeConfigByItemId(self.seasonDate, data.itemId)
  if not exchangeConfig then
    return
  end
  local canFind = false
  for _, exchangeData in pairs(self.exchangeReward) do
    if exchangeData.itemId == data.itemId then
      canFind = true
      exchangeData.num = exchangeData.num + data.num
      break
    end
  end
  if not canFind then
    table.insert(self.exchangeReward, data)
  end
  local rewardConfig = RewardConfig.findRewardById(data.itemId)
  if rewardConfig and tonumber(rewardConfig.RewardType) == Define.RewardType.CHEST then
  else
    if rewardConfig and tonumber(rewardConfig.RewardType) == Define.RewardType.CUSTOM_SHOP then
      table.insert(self.dress, data.itemId)
    end
    self.smallRewardList = {}
    self.smallRewardList[data.itemId] = exchangeConfig.Num * data.num
    self:showRewardTip()
  end
  self:ExchangeListUpDate()
end

function UILicense:onDataUpdate(data)
  self.playerLevel = data.license_level or 1
  self.hadBuy = data.license_buy or 0
  self.weekEXP = data.license_week_exp or 0
  self.curEXP = data.license_exp or 0
  self.freeUpgradeTime = data.free_upgrade_time or DateUtil.getYearDay()
  self.getFreeReward = data.get_free_reward or {}
  self.getPayReward = data.get_pay_reward or {}
  self.exchangeReward = data.exchange_reward or {}
  self.dress = data.had_get_dress or {}
  self.week = data.license_week or 1
  self.showEffectTask = data.show_effect_task or {}
  if self.playerLevel == #self.Rewards then
    self.curEXP = -1
  end
  if self.seasonDate ~= data.season_data and self.seasonDate ~= nil then
    self.seasonDate = data.season_data
    if 0 < self.seasonDate then
      self.Rewards = TableUtil.copyTable(LicenseConfig:getLevelRewardBySeason(self.seasonDate))
      self.Exchange = TableUtil.copyTable(LicenseConfig:getExchangeConfigBySeason(self.seasonDate))
      self.endSeasonDate = LicenseConfig:getSeasonEndTime(self.seasonDate)
    else
      self.Rewards = {}
      self.Exchange = {}
      self.endSeasonDate = -1
    end
  end
  local weekConfig = LicenseConfig:getWeekConfig(self.seasonDate, self.week)
  if weekConfig then
    self.stTaskEXPLimit:SetText(self.weekEXP .. " / " .. weekConfig.EXPLimit)
  end
  self.exchangeSelect = -1
  self.loadFinish = true
  self:showContent()
  self:onTaskListUpDate()
  GUILicenseGrandPriceDisplay:setItemData(self.seasonDate)
  if self:isShow() then
    local seasonConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
    if seasonConfig then
      self.siRewardDisplayActor:SetActor1(seasonConfig.PetActorName, seasonConfig.PetSkillName)
      self.siRewardDisplayActor:SetArea({
        0,
        seasonConfig.PetOffsetX2
      }, {
        0,
        seasonConfig.PetOffsetY2
      }, {
        0,
        seasonConfig.PetSize2
      }, {0, 1})
      local skillTime = self.siRewardDisplayActor:GetActor():GetSkillTimeLength(seasonConfig.PetSkillName)
      LuaTimer:cancel(self.rewardDisplaySkillKey)
      self.rewardDisplaySkillKey = LuaTimer:scheduleTimer(function()
        local curRotate = self.siRewardDisplayActor:GetRotateY()
        self.siRewardDisplayActor:SetActor1(seasonConfig.PetActorName, "idle", curRotate)
        self.siRewardDisplayActor:SetActor1(seasonConfig.PetActorName, seasonConfig.PetSkillName, curRotate)
      end, skillTime)
      self.btnBuy:SetText(Lang:getString("gui_bed_war_license_buy"))
      self:showDescribe("", "", 2)
      self.siRewardDisplayImage:SetVisible(true)
    end
  end
  if GUILicenseRewardBuy:isShow() then
    GUILicenseRewardBuy:onShow("seasonChange")
  end
  if GUIIndieMain then
    GUIIndieMain:onSeasonUpdate(self.seasonDate)
  end
end

function UILicense:showContent()
  self:itemStatusChange()
  self:RewardListUpDate()
  self:ExchangeListUpDate()
  self:onPlayerDataUpDate()
end

function UILicense:onPlayerDataUpDate()
  self.stRewardLevel:SetText("LV. " .. self.playerLevel)
  self.stExchangeLevel:SetText("LV. " .. self.playerLevel)
  self.stTaskLevel:SetText("LV. " .. self.playerLevel)
  GUILicenseSeasonTask.stLevel:SetText("LV. " .. self.playerLevel)
  if self.curEXP == -1 then
    self.pbRewardLevel:SetProgress(1)
    self.stRewardEXP:SetText("MAX")
    self.pbExchangeLevel:SetProgress(1)
    self.stExchangeEXP:SetText("MAX")
    self.pbTaskLevel:SetProgress(1)
    self.stTaskEXP:SetText("MAX")
    GUILicenseSeasonTask.pbLevelProgress:SetProgress(1)
    GUILicenseSeasonTask.stLevelProgress:SetText("MAX")
  elseif self.Rewards and self.Rewards[self.playerLevel] ~= nil then
    local expValue = self.curEXP / self.Rewards[self.playerLevel].NeedEXP
    local expText = self.curEXP .. "/" .. self.Rewards[self.playerLevel].NeedEXP
    self.pbRewardLevel:SetProgress(expValue)
    self.stRewardEXP:SetText(expText)
    self.pbExchangeLevel:SetProgress(expValue)
    self.stExchangeEXP:SetText(expText)
    self.pbTaskLevel:SetProgress(expValue)
    self.stTaskEXP:SetText(expText)
    GUILicenseSeasonTask.pbLevelProgress:SetProgress(expValue)
    GUILicenseSeasonTask.stLevelProgress:SetText(expText)
  end
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
  local stTitle = self:getChildWindow("BedWarLicense-Season-Text", GUIType.StaticText)
  local stTitle2 = self:getChildWindow("BedWarLicense-Season-Text2", GUIType.StaticText)
  local stLicenseText1 = self:getChildWindow("BedWarLicense-License_Text1", GUIType.StaticText)
  local stLicenseText2 = self:getChildWindow("BedWarLicense-License_Text2", GUIType.StaticText)
  stTitle:SetText(Lang:getString("gui_bed_war_license_title"))
  stTitle2:SetText(Lang:getString("gui_bed_war_license_title"))
  local weekConfig = LicenseConfig:getWeekConfig(self.seasonDate, self.week)
  if seasonConfig then
    local text = Lang:getString("gui_bed_war_license_title") .. "/"
    stTitle:SetText(text)
    stTitle2:SetText(text)
    local width = stTitle:GetTextWidth()
    stTitle:SetWidth({0, width})
    stTitle2:SetWidth({0, width})
    stLicenseText1:SetText(Lang:getString(seasonConfig.SeasonLang))
    stLicenseText2:SetText(Lang:getString(seasonConfig.SeasonLang))
    GUILicenseSeasonTask.stLicenseText1:SetText(Lang:getString(seasonConfig.SeasonLang))
    GUILicenseSeasonTask.stLicenseText2:SetText(Lang:getString(seasonConfig.SeasonLang))
  end
  if weekConfig then
    self.stTaskEXPLimit:SetText(self.weekEXP .. " / " .. weekConfig.EXPLimit)
  end
  if self.hadBuy ~= nil then
    if 0 < self.hadBuy then
      self.siLock:SetVisible(false)
    else
      self.siLock:SetVisible(true)
    end
  end
end

function UILicense:itemStatusChange()
  for _, reward in pairs(self.Rewards) do
    reward.FreeStatue = 0
    reward.PayStatue = 0
    if reward.Lv <= self.playerLevel then
      if reward.FreeReward ~= "#" then
        reward.FreeStatue = 1
      end
      if self.hadBuy ~= 0 and reward.PayReward ~= "#" then
        reward.PayStatue = 1
      end
      for _, hadGetReward in pairs(self.getFreeReward) do
        if reward.FreeReward == hadGetReward.rewardId and reward.Lv == hadGetReward.Lv then
          reward.FreeStatue = 2
        end
      end
      for _, hadGetReward in pairs(self.getPayReward) do
        if reward.PayReward == hadGetReward.rewardId and reward.Lv == hadGetReward.Lv and self.hadBuy ~= 0 then
          reward.PayStatue = 2
        end
      end
    end
  end
  self:showRedPoint()
end

function UILicense:onShow(tabIndex)
  LuaTimer:cancel(self.rewardDisplaySkillKey)
  if self.seasonDate == -1 then
    self:hide()
    CustomDialog.builder().setHideLeftButton().setTitleText("gui_challenge_not_open_title").setContentText(Lang:getString("gui_challenge_not_open")).setRightText(Lang:getString("gui_dialog_tip_btn_sure")).show()
    return
  end
  tabIndex = tonumber(tabIndex) or 1
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
  if seasonConfig then
    self.siRewardDisplayActor:SetActor1(seasonConfig.PetActorName, seasonConfig.PetSkillName)
    self.siRewardDisplayActor:SetArea({
      0,
      seasonConfig.PetOffsetX2
    }, {
      0,
      seasonConfig.PetOffsetY2
    }, {
      0,
      seasonConfig.PetSize2
    }, {0, 1})
    local skillTime = self.siRewardDisplayActor:GetActor():GetSkillTimeLength(seasonConfig.PetSkillName)
    self.rewardDisplaySkillKey = LuaTimer:scheduleTimer(function()
      local curRotate = self.siRewardDisplayActor:GetRotateY()
      self.siRewardDisplayActor:SetActor1(seasonConfig.PetActorName, "idle", curRotate)
      self.siRewardDisplayActor:SetActor1(seasonConfig.PetActorName, seasonConfig.PetSkillName, curRotate)
    end, skillTime)
    self:showDescribe("", "", 2)
    self.siRewardDisplayImage:SetVisible(true)
  end
  self.reFreshTime = DateUtil.getWeekLastTime(os.time(), true) + 79200
  self.refreshId = 0
  for _, layout in pairs(self.pages) do
    if layout:IsVisible() then
      layout:SetVisible(false)
    end
  end
  local Tabs = LicenseConfig.TabConfig
  if not Tabs then
    return
  end
  self.lvTabs:clearItems()
  local tabsWidth = self.lvTabs:getWidth()
  for index, data in pairs(Tabs) do
    local tab = UIHelper.newGameGUIWindow("GUILicenseTab", "BedWarLicenseTab.json")
    tab:onDataChanged(data)
    tab:setHeight({1, 0})
    tab:setWidth({
      0,
      (tabsWidth - 8) / 3
    })
    self.lvTabs:addItem(tab)
    if index == tabIndex then
      self.curSelectId = 0
      self:onSelectChange(data.Id)
    end
  end
  if self.seasonDate ~= -1 then
    self:showContent()
    for i = self.playerLevel + 1, #self.Rewards do
      if self.Rewards[i].StageReward == 1 then
        if self.hadBuy ~= 0 then
          self.siTaskDescribe:SetImage(self.Rewards[i].PayRewardImage)
          self.stNextRewardName:SetText(Lang:getString(self.Rewards[i].PayDesc))
        else
          self.siTaskDescribe:SetImage(self.Rewards[i].FreeRewardImage)
          self.stNextRewardName:SetText(Lang:getString(self.Rewards[i].FreeDesc))
        end
        self.stNextRewardLevel:SetText(i)
        break
      end
    end
  end
  if self.hadBuy ~= 0 then
    self.btnBuy:SetText(Lang:getString("gui_bed_war_license_display"))
  else
    self:checkShowBigPriceByLevel()
    self.btnBuy:SetText(Lang:getString("gui_bed_war_license_buy"))
  end
  self.llMoney:SetVisible(true)
end

function UILicense:checkShowBigPriceByLevel()
  if self.hadBuy ~= 0 then
    return
  end
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
  if not seasonConfig then
    return
  end
  local llGuide = GUIManager:getWindowByName("GuideSystem")
  for index, showLevel in pairs(seasonConfig.ShowBuyLevel) do
    if self.playerLevel == tonumber(showLevel) and not llGuide:IsVisible() and tonumber(ClientHelper.getStringForKey("showBigPriceLevel", 1)) ~= self.playerLevel then
      ClientHelper.putStringForKey("showBigPriceLevel", tostring(self.playerLevel))
      table.remove(seasonConfig.ShowBuyLevel, index)
      GUILicenseBigPrice:show()
    end
  end
end

function UILicense:onTaskListUpDate()
  self.lvTaskList:clearItems()
  for _, data in pairs(self.taskList) do
    local task = UIHelper.newGameGUIWindow("GUILicenseTaskItem", "BedWarLicenseTaskItem.json")
    task:setWidth({1, 0})
    task:onDataChange(data)
    self.lvTaskList:addItem(task)
  end
end

function UILicense:onTick()
  self.llDiamond:onTick()
  self.llHorn:onTick()
  if self.seasonDate ~= -1 then
    local time = os.time()
    local refreshTime = self.reFreshTime - time
    local RefreshTime = math.floor(refreshTime / 3600)
    local refreshDay = math.floor(RefreshTime / 24)
    local refreshHour = RefreshTime - refreshDay * 24
    if time < self.endSeasonDate and self.endSeasonDate ~= -1 then
      local lastTime = self.endSeasonDate - time
      local day = math.floor(lastTime / 86400)
      local hour = math.floor((lastTime - day * 86400) / 3600)
      local lastString = string.format(Lang:getString("gui_bed_war_license_reward_time"), day, hour)
      self.stRewardTime:SetText(Lang:getString(lastString))
      self.stExchangeTime:SetText(Lang:getString(lastString))
    end
    local refreshText = string.format(Lang:getString("gui_bed_war_license_task_refresh_time"), refreshDay, refreshHour)
    self.stTaskRefreshTime:SetText(refreshText)
    local curOffset = self.gvRewardList.root:GetScrollOffset()
    if 0 < curOffset then
      local item = self.gvRewardList:getItem("Lv", 1)
      if item then
        item.siExtraLine:SetArea({
          0,
          -curOffset
        }, {0.471649, 0}, {0, curOffset}, {0.061856, 0})
      end
      return
    end
    if -(curOffset - self.offset) > 10 * self.rewardItemWidth[2] then
      self.btnBack:SetVisible(true)
    else
      self.btnBack:SetVisible(false)
    end
    local grandPriceLevel = math.floor(-curOffset / self.rewardItemWidth[2] + 5.6)
    for i = grandPriceLevel, #self.Rewards do
      if self.Rewards[i].StageReward == 1 then
        if self.Rewards[i].FreeShowType == 2 then
          self.siFreeRewardEffect:SetVisible(true)
        else
          self.siFreeRewardEffect:SetVisible(false)
        end
        if self.Rewards[i].PayShowType == 2 then
          self.siPayRewardEffect:SetVisible(true)
        else
          self.siPayRewardEffect:SetVisible(false)
        end
        self.tvRightRewardUp:SetVisible(0 < self.Rewards[i].FreeNum)
        self.tvRightRewardDown:SetVisible(0 < self.Rewards[i].PayNum)
        self.siFreeStageReward:SetImage(self.Rewards[i].FreeRewardImage)
        self.siPayStageReward:SetImage(self.Rewards[i].PayRewardImage)
        self.siFreeStageRewardHadGet:SetVisible(self.Rewards[i].FreeStatue == 2)
        self.siPayStageRewardHadGet:SetVisible(self.Rewards[i].PayStatue == 2)
        self.stRewardLineLevel:SetText(i)
        self.stRewardRightUpNum:SetText("\195\151" .. self.Rewards[i].FreeNum)
        self.stRewardRightDownNum:SetText("\195\151" .. self.Rewards[i].PayNum)
        self.cueStageLevel = i
        break
      end
    end
  end
end

function UILicense:RewardListUpDate()
  for index, reward in pairs(self.Rewards) do
    if reward.FreeReward ~= "#" then
      local freeReward = RewardConfig.findRewardById(reward.FreeReward)
      if freeReward then
        reward.FreeType = tonumber(freeReward.RewardType)
        reward.FreeRewardImage = freeReward.Image
        reward.FreeDesc = freeReward.Desc
        reward.freeRewardStatue = 0
      end
    else
      reward.FreeType = 0
      reward.FreeRewardImage = ""
      reward.FreeDesc = ""
      reward.freeRewardStatue = 0
    end
    if reward.PayReward ~= "#" then
      local payReward = RewardConfig.findRewardById(reward.PayReward)
      if payReward then
        reward.PayType = tonumber(payReward.RewardType)
        reward.PayRewardImage = payReward.Image
        reward.PayDesc = payReward.Desc
        reward.payRewardStatue = 0
      end
    else
      reward.PayType = 0
      reward.PayRewardImage = ""
      reward.PayDesc = ""
      reward.payRewardStatue = 0
    end
  end
  self.rewardItemWidth = self.rewardListAdapt:getItemWidth()
  self.rewardListAdapt:setData(self.Rewards)
  if self.playerLevel + 3 < #self.Rewards then
    self.offset = -(self.playerLevel - 2) * self.rewardItemWidth[2]
    self.rewardListAdapt:setScrollOffset(self.offset)
  else
    self.offset = -(#self.Rewards - 6) * self.rewardItemWidth[2]
    self.rewardListAdapt:setScrollOffset(self.offset)
  end
end

function UILicense:showRedPoint()
  for _, reward in pairs(self.Rewards) do
    if reward.FreeStatue == 1 or reward.PayStatue == 1 then
      self.siGetAllRedPoint:SetVisible(true)
      UIUtils.updateRedDotCount(Define.RedDotKey.License, 1)
      return true
    end
  end
  self.siGetAllRedPoint:SetVisible(false)
  UIUtils.updateRedDotCount(Define.RedDotKey.License, 0)
  return false
end

function UILicense:ExchangeListUpDate()
  for _, exchange in pairs(self.Exchange) do
    exchange.Statue = 1
    exchange.hadExchange = 0
    for _, dress in pairs(self.dress or {}) do
      if dress == exchange.ItemId then
        exchange.Statue = 0
      end
    end
    for _, hadExchange in pairs(self.exchangeReward or {}) do
      if hadExchange.itemId == exchange.ItemId then
        exchange.hadExchange = hadExchange.num
      end
    end
  end
  self.exchangeListAdapt:setData(self.Exchange)
  if self.exchangeSelect == -1 and #self.Exchange >= 1 then
    self:onExchangeItemChange(self.Exchange[1])
  end
end

function UILicense:checkExchangeDressStatus(itemId)
  local change = false
  for _, exchange in pairs(self.Exchange) do
    local itemConfig = RewardConfig.findRewardById(exchange.ItemId)
    if itemConfig and itemConfig.RewardId == tonumber(itemId) then
      table.insert(self.dress, exchange.ItemId)
      change = true
    end
  end
  if change then
    self:onExchangeItemChange(self.Exchange[1])
  end
end

function UILicense:onSelectChange(selectId)
  local items = self.lvTabs.items
  for _, item in pairs(items) do
    if item.tabId == self.curSelectId and self.curSelectId ~= 0 then
      item:setChecked(false)
      self.pages[item.tabId]:SetVisible(false)
    end
    if item.tabId == selectId then
      item:setChecked(true)
      self.pages[item.tabId]:SetVisible(true)
    end
  end
  self.curSelectId = selectId
end

function UILicense:onRewardSelectChange(selectId, position)
  self.rewardSelect.Index = selectId
  self.rewardSelect.position = position
  self.rewardListAdapt:notifyDataChange()
end

function UILicense:showDescribe(image, describe, showType, actor, skillName)
  LuaTimer:cancel(self.actorSkillKey or 0)
  self.siRewardDisplayImage:SetVisible(false)
  if showType == 3 then
    local seasonConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
    if seasonConfig then
      self.awRewardActor:SetArea({
        0,
        seasonConfig.PetOffsetX2 * 0.8
      }, {
        0,
        seasonConfig.PetOffsetY2 * 0.8 - 30
      }, {
        0,
        seasonConfig.PetSize2 * 0.8
      }, {0, 1})
    end
    self.awRewardActor:SetActor1(actor, "idle", 0)
    self.awRewardActor:SetActor1(actor, skillName, 0)
    self.siRewardDescribe:SetVisible(false)
    self.awRewardActor:SetVisible(true)
    self.siRewardDescribeEffect:SetVisible(false)
    local skillTime = self.awRewardActor:GetActor():GetSkillTimeLength(skillName)
    self.actorSkillKey = LuaTimer:scheduleTimer(function()
      local curRotate = self.awRewardActor:GetRotateY()
      self.awRewardActor:SetActor1(actor, "idle", curRotate)
      self.awRewardActor:SetActor1(actor, skillName, curRotate)
    end, skillTime)
  else
    if showType == 2 then
      self.siRewardDescribeEffect:SetVisible(true)
    else
      self.siRewardDescribeEffect:SetVisible(false)
    end
    self.siRewardDescribe:SetImage(image)
    self.siRewardDescribe:SetVisible(true)
    self.awRewardActor:SetVisible(false)
  end
  self.stRewardDescribe:SetText(Lang:getString(describe))
end

function UILicense:onExchangeItemChange(exchangeData)
  GUILicenseExchangeNum.price = exchangeData.Price
  self.canExchange = exchangeData.BuyLimit - exchangeData.hadExchange
  self.siExchangeDescribe:SetImage(exchangeData.Image)
  self.stExchangeDescribe:SetText(Lang:getString(exchangeData.Desc))
  if exchangeData.LVLimit > self.playerLevel then
    self.btnCannotExchange:SetVisible(false)
    self.btnExchange:SetVisible(true)
    self.btnExchange:SetNormalImage("set:bedwar_licenseexchange.json image:cannot_exchange")
    self.stExchangePrice:SetText(exchangeData.Price)
    self.btnExchange:SetTouchable(false)
    self.btnExchangeOne:SetVisible(false)
    self.btnExchangeTen:SetVisible(false)
  elseif exchangeData.Statue == 0 then
    self.btnCannotExchange:SetVisible(true)
    self.btnExchange:SetVisible(false)
  else
    self.stExchangePrice:SetText(exchangeData.Price)
    self.btnCannotExchange:SetVisible(false)
    self.btnExchange:SetNormalImage("set:bedwar_license.json image:btn_yello")
    self.btnExchange:SetTouchable(true)
    self.btnExchange:SetVisible(true)
    self.btnExchangeOne:SetVisible(true)
    self.stExchangeOnePrice:SetText(exchangeData.Price)
    self.btnExchangeTen:SetVisible(true)
    self.stExchangeTenPrice:SetText(exchangeData.Price * 10)
  end
  local rewardConfig = RewardConfig.findRewardById(exchangeData.ItemId)
  if rewardConfig and tonumber(rewardConfig.RewardType) == Define.RewardType.CHEST then
    self.btnExchangeDetail:SetVisible(true)
    self.ExchangeDetail = rewardConfig.RewardId
    self.llExchangeOne:SetVisible(false)
    self.llExchangeTen:SetVisible(true)
  else
    self.btnExchangeDetail:SetVisible(false)
    self.llExchangeOne:SetVisible(true)
    self.llExchangeTen:SetVisible(false)
  end
  if exchangeData.ItemId == self.exchangeSelect then
    return
  end
  self.exchangeSelect = exchangeData.ItemId
  self.exchangeListAdapt:notifyDataChange()
end

function UILicense:isSelect(selectId, position)
  if self.rewardSelect.Index == selectId and self.rewardSelect.position == position then
    return true
  end
  return false
end

function UILicense:isShowEXP(Lv)
  if Lv <= self.playerLevel then
    return true
  end
  return false
end

function UILicense:isShowBuyLevel(Lv)
  if Lv == self.playerLevel + 1 then
    return true
  end
  return false
end

function UILicense:isExchangeSelect(selectId)
  if self.exchangeSelect == selectId then
    return true
  end
  return false
end

function UILicense:canExchangeNumByMoney()
  local price
  for _, reward in pairs(self.Exchange) do
    if reward.ItemId == self.exchangeSelect then
      price = reward.Price
    end
  end
  return PlayerWallet.getMoneyByCoinId(Define.Money.HORN) / price
end

function UILicense:onExchange(num)
  if self.seasonDate ~= -1 then
    if num > self.canExchange then
      GUILicenseTip:show("cannot_exchange")
    else
      PayHelper.checkMoney(Define.Money.HORN, tonumber(self.stExchangePrice:GetText()) * num, function(canBuy)
        if canBuy then
          GamePacketSender:sendBedWarLicenseExchange(GUILicense.seasonDate, GUILicense.exchangeSelect, num)
        end
      end)
    end
  end
end

return UILicense

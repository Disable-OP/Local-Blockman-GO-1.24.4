local UILicenseExchangeNum = class("UILicenseExchangeNum", IGUILayout)

function UILicenseExchangeNum:onLoad()
  self.price = 1
  self.etText = self:getChildWindow("BedWarLicenseExchangeNum-EditText", GUIType.Edit)
  local stTitle = self:getChildWindow("BedWarLicenseExchangeNum-Title", GUIType.StaticText)
  stTitle:SetText(Lang:getString("gui_bed_war_license_exchange_num_title"))
  self.stContent = self:getChildWindow("BedWarLicenseExchangeNum-Tips", GUIType.StaticText)
  self.stBtn = self:getChildWindow("BedWarLicenseExchangeNum-Exchange-Text", GUIType.StaticText)
  local btnClose = self:getChildWindow("BedWarLicenseExchangeNum-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local btnDown = self:getChildWindow("BedWarLicenseExchangeNum-Down", GUIType.Button)
  btnDown:registerEvent(GUIEvent.ButtonClick, function()
    local num = self.etText:GetText()
    if tonumber(num) <= 0 then
      return
    end
    num = num - 1
    self.etText:SetText(num)
    self.stBtn:SetText(num * self.price)
  end)
  local btnUp = self:getChildWindow("BedWarLicenseExchangeNum-Up", GUIType.Button)
  btnUp:registerEvent(GUIEvent.ButtonClick, function()
    local num = self.etText:GetText()
    if tonumber(num) >= self.canExchange then
      return
    end
    num = num + 1
    self.etText:SetText(num)
    self.stBtn:SetText(num * self.price)
  end)
  local btnExchange = self:getChildWindow("BedWarLicenseExchangeNum-Exchange", GUIType.Button)
  btnExchange:registerEvent(GUIEvent.ButtonClick, function()
    local num = self.etText:GetText()
    if tonumber(num) > 0 then
      GamePacketSender:sendBedWarLicenseExchange(GUILicense.seasonDate, GUILicense.exchangeSelect, num)
    end
    self:hide()
  end)
end

function UILicenseExchangeNum:onShow(maxNum)
  self.stBtn:SetText(0)
  local text = string.format(Lang:getString("gui_bed_war_license_exchange_num_content"), maxNum)
  self.stContent:SetText(text)
  self.etText:SetText(0)
  self:setAlwaysOnTop(true)
  local limitByMoney = GUILicense:canExchangeNumByMoney()
  if maxNum < limitByMoney then
    self.canExchange = maxNum
  else
    self.canExchange = limitByMoney
  end
end

return UILicenseExchangeNum

local UIBedWarToolBar = class("UIToolBar", IGUILayout)
local UIUtils = T(Global, "UIUtils")

function UIBedWarToolBar:onLoad()
  GUIManager:getToolBar():SetArea({0, 0}, {1, 0}, {1, 0}, {0, 54})
  self.root:SetLevel(49)
  self.btnShop = self:getChildWindow("BedWarToolBar-Menu-Shop", GUIType.Button)
  self.cbSetting = self:getChildWindow("BedWarToolBar-Menu-Setting", GUIType.CheckBox)
  self.cbChat = self:getChildWindow("BedWarToolBar-Chat", GUIType.CheckBox)
  self.cbAction = self:getChildWindow("BedWarToolBar-Action", GUIType.CheckBox)
  self.btnChargeCube = self:getChildWindow("BedWarToolBar-Charge", GUIType.Button)
  self.stCubeNum = self:getChildWindow("BedWarToolBar-cube-Num", GUIType.StaticText)
  self.btnChangeCamera = self:getChildWindow("BedWarToolBar-Camera-Change", GUIType.Button)
  self.btnFriend = self:getChildWindow("BedWarToolBar-Friends", GUIType.Button)
  self.stKill = self:getChildWindow("BedWarToolBar-ScoreBoard-Info-KillNum", GUIType.StaticText)
  self.btnBackHall = self:getChildWindow("BedWarToolBar-Back-Hall", GUIType.Button)
  self.btnBackHall:SetVisible(false)
  self.btnPlayerAgain = self:getChildWindow("BedWarToolBar-Play-Again", GUIType.Button)
  self.btnPlayerAgain:SetVisible(false)
  self.imgCommunity = self:getChildWindow("BedWarToolBar-Community", GUIType.StaticImage)
  self.imgVersionNotice = self:getChildWindow("BedWarToolBar-VersionNotice", GUIType.StaticImage)
  self.btnQuestionnaire = self:getChildWindow("BedWarToolBar-Menu-Questionnaire", GUIType.Button)
  if GameType == "g1046" then
    self.btnFriend:SetVisible(true)
  end
  UIUtils.addRedDot(self.cbChat, Define.RedDotKey.ChatNewMsg, nil, {
    offset = VectorUtil.newVector2(4, -3)
  })
  UIUtils.addRedDot(self.imgVersionNotice, Define.RedDotKey.VersionNotice, nil, {
    offset = VectorUtil.newVector2(4, -3)
  })
  self:initView()
  self:register()
end

function UIBedWarToolBar:onStart()
  self.btnBackHall:SetText(Lang:getString("gui.backHall"))
  self.btnPlayerAgain:SetText(Lang:getString("gui.playAgain"))
end

function UIBedWarToolBar:initView()
  self.menuButtonList = UIHelper.newGameGUIWindow("GUIBedWarUIClickPopUpControl")
  self.root:AddChildWindow(self.menuButtonList.root)
  self.menuButtonList:setArea({0, 10}, {0, 72}, {0, 57}, {0, 55})
  if GameType == "g1046" then
    self.redPointRecord = {}
    self.checkInBtn = self.menuButtonList:addButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-Check-In", "set:bedwar_toolbar.json image:menu_sign", "set:bedwar_toolbar.json image:menu_sign", function()
      SoundUtil.clickUI()
      GUIDailySignIn:show()
    end)
    self.activityBtn = self.menuButtonList:addButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-Activity", "set:bedwar_toolbar.json image:menu_activity", "set:bedwar_toolbar.json image:menu_activity", function()
      SoundUtil.clickUI()
      GUIActivity:show()
    end)
    UIUtils.addRedDot(self.activityBtn, Define.RedDotKey.OldActivity, Define.RedDotKey.MenuButton, {
      customImage = "set:bed_war_block_shop.json image:red_point"
    })
    UIUtils.addRedDot(self.checkInBtn, Define.RedDotKey.CheckIn, Define.RedDotKey.MenuButton, {
      customImage = "set:bed_war_block_shop.json image:red_point"
    })
  end
  if GameType ~= "g1046" then
    self.lotteryBtn = self.menuButtonList:addButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-Lottery", "set:bedwar_toolbar.json image:menu_lottery", "set:bedwar_toolbar.json image:menu_lottery", function()
      self:onLotteryBtn()
      GameAnalytics:design(1, {
        "ui_luckybox"
      })
    end)
  end
  local licenseBtn = self.menuButtonList:addButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-License", "set:bedwar_toolbar.json image:menu_license", "set:bedwar_toolbar.json image:menu_license", function()
    if GameType == "g1046" then
      GameAnalytics:design(1, {"H_License"})
    else
      GameAnalytics:design(1, {"G_License"})
    end
    GUILicense:show()
    CommonPacketSender:sendPlayerOpenLicense()
  end)
  local treasureBtn = self.menuButtonList:addButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-Treasure-Challenge", "set:bedwar_toolbar.json image:menu_challenge", "set:bedwar_toolbar.json image:menu_challenge", function()
    if GameType == "g1046" then
      GameAnalytics:design(1, {"H_Treasure"})
    else
      GameAnalytics:design(1, {"G_Treasure"})
    end
    if GUITreasureChallenge then
      GUITreasureChallenge:onDataChange(TreasureChallenge.rewardData)
      GUITreasureChallenge:show(true)
    end
  end)
  self.menuButtonList:addButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-CustomShop", "set:bedwar_toolbar.json image:menu_custom", "set:bedwar_toolbar.json image:menu_custom", function()
    if GameType == "g1046" then
      GameAnalytics:design(1, {
        "H_customshop"
      })
    else
      GameAnalytics:design(1, {
        "G_customshop"
      })
    end
    GUICustomShop:show(true)
  end)
  self.rechargeBtn = self.menuButtonList:addButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-Recharge", "set:bedwar_toolbar.json image:menu_firstcharge", "set:bedwar_toolbar.json image:menu_firstcharge", function()
    ReportUtil.reportClickFirstRecharge(GUISumRechargeLayout.currentId)
    GUISumRechargeLayout:show()
  end)
  UIUtils.addRedDot(self.menuButtonList.root, Define.RedDotKey.MenuButton, nil, {
    customImage = "set:bed_war_block_shop.json image:red_point"
  })
  UIUtils.addRedDot(licenseBtn, Define.RedDotKey.License, Define.RedDotKey.MenuButton, {
    customImage = "set:bed_war_block_shop.json image:red_point"
  })
  UIUtils.addRedDot(treasureBtn, Define.RedDotKey.Challenge, Define.RedDotKey.MenuButton, {
    customImage = "set:bed_war_block_shop.json image:red_point"
  })
  self.menuButtonList:setChecked(true)
end

function UIBedWarToolBar:register()
  self.imgCommunity:registerEvent(GUIEvent.Click, function()
    if GUICommunitySharing then
      GUICommunitySharing:show()
    end
  end)
  self.btnFriend:registerEvent(GUIEvent.ButtonClick, function()
    GUIFriends:show()
  end)
  self.imgVersionNotice:registerEvent(GUIEvent.Click, function()
    GUIVersionNoticeLayout:show()
  end)
  self.btnQuestionnaire:registerEvent(GUIEvent.ButtonClick, function()
    if GUIQuestionnaire then
      GUIQuestionnaire:show()
    end
  end)
  self.btnChargeCube:registerEvent(GUIEvent.ButtonClick, function()
    ClientHelper.onRecharge(1)
  end)
  self.btnChangeCamera:registerEvent(GUIEvent.ButtonClick, function()
    if ClientNewReportUtil then
      ClientNewReportUtil:onPlayerChangePersonView("oldBtn")
    end
    local cruCamera = SystemSettingRecord.defaultCamera
    if cruCamera == 1 then
      GUIBedWarSetting:changeCamera(2)
      SystemSettingRecord.defaultCamera = 2
    elseif cruCamera == 2 then
      GUIBedWarSetting:changeCamera(3)
      SystemSettingRecord.defaultCamera = 3
    elseif cruCamera == 3 then
      GUIBedWarSetting:changeCamera(1)
      SystemSettingRecord.defaultCamera = 1
    end
  end)
  self.cbSetting:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbSetting:GetChecked() then
      self.cbChat:SetChecked(false)
      self.cbAction:SetChecked(false)
      if Game:isEnableIndie() and GUIBedWarIndieSettingLayout then
        GUIBedWarIndieSettingLayout:show()
      else
        GUIManager:showWindowByName("Menu.json")
      end
    elseif Game:isEnableIndie() and GUIBedWarIndieSettingLayout then
      GUIBedWarIndieSettingLayout:show()
    else
      GUIManager:hideWindowByName("Menu.json")
    end
  end)
  self.btnShop:registerEvent(GUIEvent.ButtonClick, function()
    GUIStore:show(StoreId.CubeStore)
    if BaseMain:getGameType() == "g1046" then
      GameAnalytics:design(1, {"H_clubshop"})
    else
      GameAnalytics:design(1, {
        "ui_culbshop"
      })
    end
  end)
  self.cbAction:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbAction:GetChecked() then
      self.cbSetting:SetChecked(false)
      self.cbChat:SetChecked(false)
      GUIAction:show()
    else
      GUIAction:hide()
    end
  end)
  self.cbChat:registerEvent(GUIEvent.CheckStateChanged, function()
    if self.cbChat:GetChecked() then
      self.cbSetting:SetChecked(false)
      self.cbAction:SetChecked(false)
      if BaseMain:getGameType() == "g1046" then
        GUIBedWarHallChatLayout:show(Define.ChatTabType.Lang)
      else
        GUIChatInput:show()
      end
    elseif BaseMain:getGameType() == "g1046" then
      GUIBedWarHallChatLayout:hide()
    else
      GUIChatInput:hide()
    end
  end)
  self.btnBackHall:registerEvent(GUIEvent.ButtonClick, function()
    GamePacketSender:sendBackHall()
  end)
  self.btnPlayerAgain:registerEvent(GUIEvent.ButtonClick, function()
    GamePacketSender:sendPlayAgain(Game:getPlatformUserId())
  end)
  self:registerDataCallBack("PlayerLevel", function(level)
    self.level = tonumber(level)
  end)
  self:registerDataCallBack("ShowSumRecharge", function(data)
    local id = data:getParam("Id")
    local config = SumRechargeConfig:getSumRecharge(id)
    if config then
      if not self.rechargeBtn then
        self.rechargeBtn = self.menuButtonList:addButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-Recharge", "set:bedwar_toolbar.json image:menu_firstcharge", "set:bedwar_toolbar.json image:menu_firstcharge", function()
          ReportUtil.reportClickFirstRecharge(GUISumRechargeLayout.currentId)
          GUISumRechargeLayout:show()
        end)
      end
    else
      self.menuButtonList:removeButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-Recharge")
      self.rechargeBtn = nil
    end
  end, DataBuilderProcessor)
  if GameType == "g1046" then
    self:registerEvent(Events.UpdateActivityRedPointEvent, function(type, visible)
      self:onActivityRedVisible(type, visible)
    end)
    self:registerEvent(Events.UpdateDailySignInRedPointEvent, function(visible)
      self:onDailySignInRedVisible(visible)
    end)
  end
end

function UIBedWarToolBar:onTick()
  local count = PlayerWallet.getMoneyByCoinId(Define.Money.DIAMOND)
  self.stCubeNum:SetText(tostring(count))
  self.cbSetting:SetChecked(GUIManager:getWindowByName("Menu", GUIType.Layout):IsVisible())
  self.imgCommunity:SetVisible(GUICommunitySharing ~= nil and GameType == "g1046")
  self.btnQuestionnaire:SetVisible(GUIQuestionnaire ~= nil)
end

function UIBedWarToolBar:onGameStart()
  if self.GameStart then
    return
  end
  self.GameStart = true
  self:createTeamInfo()
  self:hideList()
  local selfUserId = PlayerManager:getClientPlayer().userId
  self.stKill:SetVisible(true)
  GameInfoManager:registerObserver(tostring(selfUserId), function(info)
    self:updateScoreboard(info)
  end)
end

function UIBedWarToolBar:createTeamInfo()
  local selfUserId = PlayerManager:getClientPlayer().userId
  local clientPlayerInfo = GameInfoManager:getPlayerInfo(selfUserId)
  local selfTeamId = clientPlayerInfo:getValue("teamId")
  local teamList = {selfTeamId}
  for teamId, _ in pairs(TeamConfig:getTeams()) do
    if tostring(teamId) ~= selfTeamId then
      table.insert(teamList, tostring(teamId))
    end
  end
  local content = self:getChildWindow("BedWarToolBar-TeamInfo-Layout", GUIType.Layout)
  local width = content:GetPixelSize().x
  local scale = width / 443
  scale = 1 < scale and 1 or scale
  content:CleanupChildren()
  local listBox = IGUIListView.new("BedWarToolBar-TeamInfo-List", content, nil, Orientation.Horizontal)
  listBox.root:SetClipChild(false)
  listBox.root:SetHorizontalAlignment(HorizontalAlignment.Center)
  listBox:setItemSpace(5 * scale)
  local teamLayoutWidth = 0
  for index, teamId in pairs(teamList) do
    local teamInfo = GameInfoManager:getTeamInfo(teamId)
    if teamInfo and 0 < tonumber(teamInfo:getValue("totalCount")) then
      local guiTeam = UIHelper.newGameGUIWindow("GUITeamInfo")
      guiTeam:initTeam(teamId, teamId == selfTeamId)
      guiTeam:updateInfo(teamInfo)
      if GameType == "g1008" then
        guiTeam.root:SetWidth({
          0,
          96 * scale
        })
        guiTeam.root:SetHeight({
          0,
          48 * scale
        })
        teamLayoutWidth = teamLayoutWidth + 101 * scale
      else
        guiTeam.root:SetWidth({
          0,
          48 * scale
        })
        guiTeam.root:SetHeight({
          0,
          48 * scale
        })
        guiTeam.siIcon:SetWidth({1, 0})
        teamLayoutWidth = teamLayoutWidth + 53 * scale
      end
      guiTeam.stCount:SetTextScale(scale)
      guiTeam.stNum:SetTextScale(scale)
      guiTeam.stCount:SetVisible(GameType ~= "g1008")
      guiTeam.stNum:SetVisible(GameType == "g1008")
      listBox:addItem(guiTeam)
    end
    if index == 1 then
      local vsLayout = GUIManager:createGUIWindow(GUIType.Layout, "BedWarToolBar-TeamInfo-VS")
      vsLayout:SetWidth({
        0,
        39 * scale
      })
      vsLayout:SetHeight({
        0,
        23 * scale
      })
      vsLayout:SetVerticalAlignment(VerticalAlignment.Center)
      vsLayout:SetBackImage("set:bedwar_toolbar.json image:VS")
      vsLayout:SetProperty("StretchType", "NineGrid")
      vsLayout:setMaterial(20001)
      listBox.root:AddItem(vsLayout)
    end
  end
  teamLayoutWidth = teamLayoutWidth + 39 * scale
  listBox:setArea({0, 0}, {0, 0}, {0, teamLayoutWidth}, {1, 0})
end

function UIBedWarToolBar:updateScoreboard(info)
  self.stKill:SetText(info:getValue("kill"))
end

function UIBedWarToolBar:cameraChange()
  local cruCamera = Blockman.Instance():getCurrPersonView()
  if cruCamera == 1 then
    self.btnChangeCamera:SetPushedImage("set:bedwar_toolbar.json image:change_camera_2")
    self.btnChangeCamera:SetNormalImage("set:bedwar_toolbar.json image:change_camera_2")
  elseif cruCamera == 2 then
    self.btnChangeCamera:SetPushedImage("set:bedwar_toolbar.json image:change_camera_3")
    self.btnChangeCamera:SetNormalImage("set:bedwar_toolbar.json image:change_camera_3")
  elseif cruCamera == 0 then
    self.btnChangeCamera:SetPushedImage("set:bedwar_toolbar.json image:change_camera_1")
    self.btnChangeCamera:SetNormalImage("set:bedwar_toolbar.json image:change_camera_1")
  end
end

function UIBedWarToolBar:getPlayerLevel()
  return self.level or 0
end

function UIBedWarToolBar:hideList()
  if not self.listKey then
    self.listKey = LuaTimer:schedule(function()
      if self.menuButtonList:getChecked() then
        self.menuButtonList:setChecked(false)
      end
    end, GameConfig.mainTabRedPoint * 1000)
  end
end

function UIBedWarToolBar:onLotteryBtn()
  GUILottery:show()
  SoundUtil.playSound(SoundConfig.openLottery)
end

function UIBedWarToolBar:onActivityRedVisible(type, visible)
  if not self:isNeedLoad() then
    return
  end
  self.redPointRecord[type] = visible
  for _, record in pairs(self.redPointRecord) do
    if record then
      UIUtils.updateRedDotCount(Define.RedDotKey.OldActivity, 1)
      return
    end
  end
  UIUtils.updateRedDotCount(Define.RedDotKey.OldActivity, 0)
end

function UIBedWarToolBar:onDailySignInRedVisible(visible)
  if visible then
    UIUtils.updateRedDotCount(Define.RedDotKey.CheckIn, 1)
  else
    UIUtils.updateRedDotCount(Define.RedDotKey.CheckIn, 0)
  end
end

return UIBedWarToolBar

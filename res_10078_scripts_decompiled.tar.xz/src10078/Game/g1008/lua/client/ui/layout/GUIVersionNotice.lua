local UIVersionNoticeLayout = class("UIVersionNoticeLayout", IGUILayout)
local VersionNoticeConfig = require("game.config.VersionNoticeConfig")
local UIUtils = T(Global, "UIUtils")

function UIVersionNoticeLayout:ctor()
  self.super.ctor(self, "VersionNotice.json")
end

function UIVersionNoticeLayout:onLoad()
  self.llMain = self:getChildWindow("VersionNotice-Main", GUIType.Layout)
  self.siTitleLayout = self:getChildWindow("VersionNotice-Title-Layout", GUIType.StaticImage)
  self.stTitleText = self:getChildWindow("VersionNotice-Title-Text", GUIType.StaticText)
  self.btnClose = self:getChildWindow("VersionNotice-Close", GUIType.Button)
  self.llContentLayout = self:getChildWindow("VersionNotice-Content-Layout", GUIType.Layout)
  self.stDetailTitle = self:getChildWindow("VersionNotice-Detail-Title", GUIType.StaticText)
  self.siLine = self:getChildWindow("VersionNotice-Line", GUIType.StaticImage)
  local llDetailView = self:getChildWindow("VersionNotice-Detail-View", GUIType.Layout)
  self.stDetailText = UIHelper.newGameGUIWindow("GUISlideText", llDetailView)
  self.stDetailText:SetProperty("TextWordWrap", "true")
  self.stDetailText:SetFont(GUIFontManager:Instance():GetFont("HT18"))
  self.stDetailText:SetTextLineExtraSpace(5)
  self.stTitleText:SetText(Lang:getString("gui.version.title"))
  self.red_point_record = json.decode(ClientHelper.getStringForKey("g1008_VersionNotice_Red_Point_Record" .. tostring(Game:getPlatformUserId()), "{}"))
  self:initView()
  self:initTab()
  self:initRegister()
end

function UIVersionNoticeLayout:initView()
end

function UIVersionNoticeLayout:initTab()
  local llTabLayout = self:getChildWindow("VersionNotice-Tab-Layout", GUIType.Layout)
  self.gvTab = GUIManager:createGUIWindow(GUIType.GridView, "VersionNotice-Tab-GridView")
  self.gvTab:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvTab:InitConfig(0, 9, 1)
  llTabLayout:AddChildWindow(self.gvTab)
  self.tab_group = RadioBoxGroup.new(SoundConfig.switchTab)
  local all_version = VersionNoticeConfig:getAllConfig()
  for index, data in pairs(all_version) do
    if data.is_show then
      local checkBox = self:newTab(index, data)
      self.gvTab:AddItem(checkBox)
    end
    if data.is_current then
      self.cur_version_index = index
    end
  end
  LuaTimer:schedule(function()
    self:checkRedPoint()
  end, 0)
end

function UIVersionNoticeLayout:newTab(index, data)
  local checkBox = GUIManager:createGUIWindow(GUIType.CheckBox, "VersionNotice-Tab-" .. index)
  local redPoint = GUIManager:createGUIWindow(GUIType.StaticImage, "VersionNotice-Tab-RedPoint-" .. index)
  checkBox:SetNormalImage("set:version_notice.json image:img_9_btn01")
  checkBox:SetPushedImage("set:version_notice.json image:img_9_btn02")
  checkBox:SetText(Lang:getString(data.tab_lang))
  checkBox:SetArea({0, 0}, {0, 0}, {1, 0}, {0, 69})
  checkBox:SetFont(GUIFontManager:Instance():GetFont("HT18"))
  checkBox:SetProperty("TextBorder", "true")
  checkBox:SetProperty("TextRenderOffset", "0 -5")
  checkBox:AddChildWindow(redPoint)
  redPoint:SetArea({1, -14}, {0, 0}, {0, 14}, {0, 15})
  redPoint:SetImage("set:bed_war_block_shop.json image:red_point")
  self.red_point_record[data.version_code] = self.red_point_record[data.version_code] or false
  if self.red_point_record[data.version_code] then
    redPoint:SetVisible(false)
  end
  self.tab_group:addCheckBox(checkBox, function(change_state)
    if change_state then
      self:selectTab(data, checkBox, redPoint)
    end
  end)
  return checkBox
end

function UIVersionNoticeLayout:initRegister()
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  self.root:registerEvent(GUIEvent.Click, function()
    self:hide()
  end)
end

function UIVersionNoticeLayout:selectTab(data, checkBox, redPoint)
  self.stDetailTitle:SetText(Lang:getString(data.title_lang))
  local text = Lang:getString(data.detail_lang)
  self.stDetailText:SetText(text, data.line_count)
  if not self.red_point_record[data.version_code] then
    redPoint:SetVisible(false)
    self.red_point_record[data.version_code] = true
    self:checkRedPoint()
    ClientHelper.putStringForKey("g1008_VersionNotice_Red_Point_Record" .. tostring(Game:getPlatformUserId()), json.encode(self.red_point_record))
  end
end

function UIVersionNoticeLayout:checkRedPoint()
  UIUtils.updateRedDotCount(Define.RedDotKey.VersionNotice, 0)
  for _, record in pairs(self.red_point_record) do
    if not record then
      UIUtils.updateRedDotCount(Define.RedDotKey.VersionNotice, 1)
      return
    end
  end
end

function UIVersionNoticeLayout:onShow()
  if self.tab_group:getCurIndex() == 0 then
    self.tab_group:selectIndex(self.cur_version_index)
  end
end

return UIVersionNoticeLayout

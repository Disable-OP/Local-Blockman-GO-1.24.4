local UIIndieMainV3ClickLayout = class("UIIndieMainV3ClickLayout", IGUILayout)

function UIIndieMainV3ClickLayout:ctor(parent)
  self.super.ctor(self, "IndieMainV3Click.json", parent)
end

function UIIndieMainV3ClickLayout:onLoad()
  self.llClick = self:getChildWindow("IndieMainV3Click-Click", GUIType.Layout)
  self.llEffect = self:getChildWindow("IndieMainV3Click-Effect", GUIType.Layout)
  self:initView()
  self:initEvent()
end

function UIIndieMainV3ClickLayout:initView()
end

function UIIndieMainV3ClickLayout:initEvent()
  self:registerEvent(CEvents.GUISystemTouchDown, function(point)
    self:showEffect(point.x, point.y)
  end)
end

function UIIndieMainV3ClickLayout:showEffect(x, y)
  self.llClick:SetArea({0, x}, {0, y}, {0, 0}, {0, 0})
  self.llEffect:SetEffectName("")
  self.llEffect:SetEffectName("img_0_click.effect")
end

function UIIndieMainV3ClickLayout:isMainControl()
  return true
end

return UIIndieMainV3ClickLayout

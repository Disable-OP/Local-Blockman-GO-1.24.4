local UILicenseBuyLevelTip = class("UILicenseBuyLevelTip", IGUILayout)

function UILicenseBuyLevelTip:onLoad()
  local btnBuyLevel = self:getChildWindow("BedWarLicenseBuyLevelTip-Buy", GUIType.Button)
  btnBuyLevel:registerEvent(GUIEvent.ButtonClick, function()
    GamePacketSender:sendBedWarLicenseBuyLevel(GUILicense.seasonDate)
  end)
  local btnClose = self:getChildWindow("BedWarLicenseBuyLevelTip-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  self.stLevelText = self:getChildWindow("BedWarLicenseBuyLevelTip-Text", GUIType.StaticText)
  local stTitle = self:getChildWindow("BedWarLicenseBuyLevelTip-Title", GUIType.StaticText)
  stTitle:SetText(Lang:getString("gui_bed_war_license_buy_level_title"))
  local stContent = self:getChildWindow("BedWarLicenseBuyLevelTip-Content", GUIType.StaticText)
  stContent:SetText(Lang:getString("gui_bed_war_license_buy_level_content"))
end

function UILicenseBuyLevelTip:onShow()
end

return UILicenseBuyLevelTip

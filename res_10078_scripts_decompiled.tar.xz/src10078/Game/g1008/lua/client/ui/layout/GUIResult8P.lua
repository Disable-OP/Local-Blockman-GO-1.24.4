local UIResult8P = class("GUIResult8P", IGUILayout)

function UIResult8P:onLoad()
  self:getChildWindow("Result8P-Title-Text", GUIType.StaticText):SetText(Lang:getString("final.summary.rank"))
  self.btnQuitGame = self:getChildWindow("Result8P-Quit-Game", GUIType.Button)
  self.btnQuitGame:SetText(Lang:getString("wordart_exit_game"))
  self.btnBackHall = self:getChildWindow("Result8P-Back-Hall", GUIType.Button)
  self.btnBackHall:SetText(Lang:getString("gui.backHall"))
  self.btnPrevious = self:getChildWindow("Result8P-Last-Page", GUIType.Button)
  self.btnPrevious:SetText(Lang:getString("gui.previous"))
  self.btnPlayAgain = self:getChildWindow("Result8P-Next-Game", GUIType.Button)
  self.btnPlayAgain:SetText(Lang:getString("gui.playAgain"))
  self.stBackTip = self:getChildWindow("Result8P-Back-Tip-Text", GUIType.StaticText)
  self.siBackTip = self:getChildWindow("Result8P-Back-Tip", GUIType.StaticImage)
  self.btnBackTip = self:getChildWindow("Result8P-Back-Tip-Btn", GUIType.Button)
  self.stBackTip:SetText(Lang:getString("gui_to_get_reward"), true)
  local line = math.floor(self.stBackTip:GetTextWidth() / 300) + 1
  self.siBackTip:SetHeight({
    0,
    math.max(self.stBackTip:GetFont():GetFontHeight() * line + 20, 60)
  })
  self.btnBackTip:registerEvent(GUIEvent.ButtonClick, function()
    self.siBackTip:SetVisible(false)
    LuaTimer:schedule(function()
      self.siBackTip:SetVisible(true)
    end, 5000)
  end)
  self.llBottom = self:getChildWindow("Result8P-Bottom", GUIType.Layout)
  self.btnQuitGame:registerEvent(GUIEvent.ButtonClick, function()
    Game:exitGame()
  end)
  self.btnPlayAgain:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.againSettlement)
    GamePacketSender:sendPlayAgain(Game:getPlatformUserId())
  end)
  self.btnBackHall:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.backHallSettlement)
    GamePacketSender:sendBackHall()
  end)
  self.btnPrevious:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.playSound(SoundConfig.previousSettlement)
    self:hide()
  end)
  self.btShare = self:getChildWindow("Result8P-Share", GUIType.Button)
  self.btShare:SetVisible(not Game:isChina() and not Game:isEnableIndie())
  self.btShare:registerEvent(GUIEvent.ButtonClick, function()
    LuaTimer:schedule(function()
      self:onShare(true)
    end, 0)
  end)
  local llPlayers = self:getChildWindow("Result8P-Players", GUIType.Layout)
  self.gvPlayers = IGUIGridView.new("Result8P-Players-List", llPlayers)
  self.gvPlayers:setConfig(0, 6, 1)
end

function UIResult8P:isShowAnim()
  return false
end

function UIResult8P:onShare(open)
  if open then
    self.llBottom:SetVisible(false)
    ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_SCREEN_CAPTURE)
  else
    self.llBottom:SetVisible(true)
  end
end

function UIResult8P:onUpdateUI()
  local players = {}
  local infoList = GameInfoManager:getAllPlayerInfo()
  for userId, info in pairs(infoList) do
    local data = {
      info = info,
      rank = tonumber(info:getValue("rank")) or 100,
      userId = tonumber(userId)
    }
    if data.rank > 0 then
      table.insert(players, data)
    end
    GameInfoManager:registerObserver(tostring(userId), function(_)
      local item = self.gvPlayers:getItem("curInfo", info)
      if item then
        item:onDataChanged(data)
      end
    end)
  end
  table.sort(players, function(a, b)
    if a.rank ~= b.rank then
      return a.rank < b.rank
    end
    return a.userId < b.userId
  end)
  for rank, player in pairs(players) do
    player.rank = rank
    local item = UIHelper.newGameGUIWindow("GUIResultPlayerItem8P", "ResultPlayerItem8P.json")
    item:onDataChanged(player)
    item:setArea({0, 0}, {0, 0}, {1, 0}, {0, 56})
    self.gvPlayers:addItem(item)
  end
end

return UIResult8P

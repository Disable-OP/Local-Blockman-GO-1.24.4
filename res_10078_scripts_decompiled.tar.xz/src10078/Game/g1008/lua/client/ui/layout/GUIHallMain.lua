local function hideEngineWindow(name)
  local window = GUIManager:getWindowByName(name)
  
  if not window then
    return
  end
  window:SetXPosition({0, 6000})
  window:SetVisible(false)
end

local function setTouchable(window, touchable)
  window:SetTouchable(touchable)
  local count = window:GetChildCount()
  if count == 0 then
    return
  end
  for index = 1, count do
    setTouchable(window:GetChildByIndex(index - 1), touchable)
  end
end

local UIHallMain = class("UIHallMain", IGUILayout)
local UIUtils = T(Global, "UIUtils")

function UIHallMain:onLoad()
  self.btnTeamInvite = self:getChildWindow("BedWarMain-Team-Invite", GUIType.Button)
  self.btnTriggerGift = self:getChildWindow("BedWarMain-Trigger-Gift", GUIType.Button)
  self.privilegeCards = {}
  self.task = nil
  self:initView()
  self:initEvent()
  self:setEngineUIStyle()
end

function UIHallMain:initView()
  self.btnTriggerGift:SetVisible(false)
  Plugins.CallTargetPluginFunc("trigger_gift", "setOpenButton", self.btnTriggerGift)
  UIUtils.addRedDot(self.btnTriggerGift, Define.RedDotKey.TriggerGift, nil, {
    offset = VectorUtil.newVector2(-6, 14)
  })
  UIUtils.addRedDot(self.btnTeamInvite, Define.RedDotKey.TeamInvite, nil, {
    offset = VectorUtil.newVector2(4, -3),
    isParentBindVisible = true
  })
end

function UIHallMain:initEvent()
  self.btnTeamInvite:registerEvent(GUIEvent.ButtonClick, function()
    GUICreateTeamInviteListLayout:show()
  end)
  self:registerDataCallBack("PrivilegeStatus", function(data)
    self:onUpdatePrivilegeStatus(data)
  end, JsonBuilderProcessor)
end

function UIHallMain:setEngineUIStyle()
  ClientHelper.putFloatPrefs("PoleControlMaxDistance", 65)
  ClientHelper.putFloatPrefs("MainControlKeyAlphaNormal", 1)
  ClientHelper.putFloatPrefs("MainControlKeyAlphaPress", 1)
  local ivPoleArrow = GUIManager:getWindowByName("Main-PoleControl-Arrow", GUIType.StaticImage)
  ivPoleArrow:SetImage("set:pole.json image:pole_arrow")
  local wMoveState = GUIManager:getWindowByName("Main-MoveState")
  wMoveState:SetArea(wMoveState:GetXPosition(), wMoveState:GetYPosition(), {0, 70}, {0, 70})
  local wJumControls = GUIManager:getWindowByName("Main-Jump-Controls")
  wJumControls:SetArea(wJumControls:GetXPosition(), wJumControls:GetYPosition(), {0, 138}, {0, 377})
  local btnSkillRelease = GUIManager:getWindowByName("Main-Skill-Release-btn", GUIType.Button)
  btnSkillRelease:SetNormalImage("set:bedwarsmall.json image:free_skill")
  btnSkillRelease:SetPushedImage("set:bedwarsmall.json image:free_skill")
  btnSkillRelease:SetArea(btnSkillRelease:GetXPosition(), btnSkillRelease:GetYPosition(), {0, 120}, {0, 120})
  local ivSneak = GUIManager:getWindowByName("Main-MoveState-Sneak", GUIType.StaticImage)
  ivSneak:SetImage("set:move_state.json image:sneak_circle")
  local btnFly = GUIManager:getWindowByName("Main-Fly", GUIType.Button)
  btnFly:SetNormalImage("set:bedwarsmall.json image:fly")
  btnFly:SetPushedImage("set:bedwarsmall.json image:fly")
  btnFly:SetArea(btnFly:GetXPosition(), btnFly:GetYPosition(), {0, 70}, {0, 70})
  hideEngineWindow("Main-Player-Exp")
  GUIManager:getWindowByName("Main-Chat-Message"):SetArea({0, 10}, {0, 130}, {0.38, 0}, {0.42, 0})
  local bgWatch = GUIManager:getWindowByName("Main-Watch-Battle-Bg", GUIType.StaticImage)
  bgWatch:SetProperty("StretchOffset", "60 10 0 0")
  bgWatch:SetImage("set:bedwar_toolbar.json image:bg_onWatch")
  GUIManager:getWindowByName("Main-Watch-Battle-Tip"):SetHeight({0, 49})
  GUIManager:getWindowByName("Main-Watch-Battle-Tip"):SetWidth({0, 250})
  GUIManager:getWindowByName("Main-Watch-Battle-Text"):SetArea({0, 50}, {0, 0}, {1, -50}, {1, 0})
  GUIManager:getWindowByName("Main-Watch-Battle-Text"):SetHorizontalAlignment(HorizontalAlignment.Left)
end

function UIHallMain:onUpdatePrivilegeStatus(items)
  for _, item in pairs(items) do
    local privilege = self.privilegeCards[item.Id]
    if privilege == nil then
      local width = 70
      local count = self.llPrivilegeCards:GetChildCount()
      privilege = UIHelper.newGameGUIWindow("GUIPrivilegeStatusItem", "PrivilegeStatusItem.json")
      privilege:setArea({
        1,
        count * (-20 - width) - 25
      }, {0, 0}, {0, width}, {0, width})
      self.llPrivilegeCards:AddChildWindow(privilege.root)
    end
    privilege:initPrivilegeStatus(item.Icon, item.Time, item.Id)
    self.privilegeCards[item.Id] = privilege
  end
  if self.task ~= nil then
    LuaTimer:cancel(self.task)
  end
  self.task = LuaTimer:schedule(function()
    for _, privilege in pairs(self.privilegeCards) do
      privilege.time = privilege.time - 60
      privilege:updateTimeText()
    end
  end, 60000, 60000)
end

function UIHallMain:cameraChange()
end

return UIHallMain

local UIBedWarSurveyDesc = class("UIBedWarSurveyDesc", IGUILayout)

function UIBedWarSurveyDesc:onLoad()
  self.tvTitle = self:getChildWindow("BedWarSurveyDesc-Title", GUIType.StaticText)
  self.tvTip = self:getChildWindow("BedWarSurveyDesc-Tip", GUIType.StaticText)
  self.tvTip:SetText(Lang:getString("Survey_Desc_Reward"))
  local llItems = self:getChildWindow("BedWarSurveyDesc-Items", GUIType.Layout)
  self.gvItems = IGUIGridView.new("UIBedWarSurveyDesc-Items-List", llItems)
  self.gvItems:setArea({0, 8}, {0, 8}, {1, 0}, {1, 0})
  self.gvItems:setConfig(20, 16, 5)
  local allTask = SurveyConfig:getNeedUseItemTask()
  self.itemTotalNum = SurveyConfig:getNeedUseItemTaskNum()
  for index, task in pairs(allTask) do
    local item = UIHelper.newGameGUIWindow("GUIBedWarSurveyDescItem", "BedWarSurveyDescItem.json")
    item:init(index, task)
    item:setWidth({0, 176})
    item:setHeight({0, 206})
    self.gvItems:addItemByIndex(item, index)
  end
  self.tvTitle:SetText(Lang:getTipString(1046054, "(" .. tostring(0) .. "/" .. tostring(self.itemTotalNum) .. ")"))
  local btnClose = self:getChildWindow("BedWarSurveyDesc-Close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide(true)
  end)
  self:registerDataCallBack("SurveyUseItemTimes", function(data)
    self:onUpdateUseItemTimes(data)
  end, DataBuilderProcessor)
  self.curUsedItemNum = 0
end

function UIBedWarSurveyDesc:onUpdateUseItemTimes(data)
  local itemId = data:getNumberParam("itemId")
  local times = data:getNumberParam("times")
  self.curUsedItemNum = 0
  for index = 1, self.itemTotalNum do
    local item = self.gvItems:getItem("index", index)
    if item.itemId == itemId then
      item:onUseTimesChange(times)
    end
    if 0 < item.useTimes then
      self.curUsedItemNum = self.curUsedItemNum + 1
    end
  end
  self.tvTitle:SetText(Lang:getTipString(1046054, "(" .. tostring(self.curUsedItemNum) .. "/" .. tostring(self.itemTotalNum) .. ")"))
end

function UIBedWarSurveyDesc:onShowSurvey()
  if self.curUsedItemNum == self.itemTotalNum then
    GUIBedWarSurvey:show(true)
  else
    GUIBedWarSurveyDesc:show(true)
  end
end

return UIBedWarSurveyDesc

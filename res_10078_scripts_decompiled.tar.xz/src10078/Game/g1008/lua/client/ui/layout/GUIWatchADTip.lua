local UIWatchADTip = class("UIWatchADTip", IGUILayout)
local tip

function UIWatchADTip:onLoad()
  self.contents = {}
  self.contentView = nil
  local name = string.gsub(self.__name, ".json", "-")
  self.llContent = self:getChildWindow(name .. "Content", GUIType.Layout)
  self.stTipText = self:getChildWindow(name .. "Tip-Text", GUIType.StaticText)
  self.stTipTitle = self:getChildWindow(name .. "Tip-Title", GUIType.StaticText)
  self.btnWatchAd = self:getChildWindow(name .. "Tip-Watch-AD", GUIType.Button)
  self.btnUseTicket = self:getChildWindow(name .. "Tip-Use-Ticket", GUIType.Button)
  self.stTicketNum = self:getChildWindow(name .. "Tip-Ticket-Num", GUIType.StaticText)
  self.btnMaskClose = self:getChildWindow(name .. "Mask-Close", GUIType.Button)
  self.btnClose = self:getChildWindow(name .. "Tip-Close", GUIType.Button)
  self:register()
end

function UIWatchADTip:register()
  self.btnMaskClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  self.btnWatchAd:registerEvent(GUIEvent.ButtonClick, function()
    ClientHelper.onWatchAd(self.type, self.params)
    if ClientHelper.getBoolPrefs("ShowVideoAd") and not isBeta then
      self:hide()
    end
  end)
  self.btnUseTicket:registerEvent(GUIEvent.ButtonClick, function()
    self:useMovieTicket()
  end)
end

function UIWatchADTip:useMovieTicket()
  if self.ticketNum >= 1 then
    CommonPacketSender:sendUseMovieTicket(self.type, self.params)
    self:hide()
  elseif self.canJump then
    self:hide()
    GUIStore:show(StoreId.CubeStore, 11)
  end
end

function UIWatchADTip:onTick()
  if self.ticketNum == 0 then
    self.stTicketNum:SetTextColor(Color.RED)
  else
    self.stTicketNum:SetTextColor(Color.WHITE)
  end
  if GameType ~= "g1046" then
    if isGameEnd then
      self.btnWatchAd:SetText(Lang:getString("gui_bed_war_watch_ad_btn_hall"))
      self.btnWatchAd:SetNormalImage("set:advertisement_system.json image:adver_btn")
      if not self.btnWatchAd:IsTouchable() then
        self.btnWatchAd:SetTouchable(true)
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ADS_PLACEMENT, tostring(self.type))
      end
    else
      self.btnWatchAd:SetNormalImage("set:advertisement_system.json image:not_adver_btn")
      self.btnWatchAd:SetTouchable(false)
    end
  end
end

function UIWatchADTip:onShow(type, params)
  self.type = type
  self.params = params or ""
end

function UIWatchADTip:init()
  if self.contentView ~= nil then
    self.contentView:hide()
    self.contentView = nil
  end
  if GameType ~= "g1046" then
    self.btnWatchAd:SetText(Lang:getString("gui_bed_war_watch_ad_btn_game"))
  else
    self.btnWatchAd:SetText(Lang:getString("gui_bed_war_watch_ad_btn_hall"))
  end
  self.stTipText:SetText(Lang:getString("gui_bed_war_watch_ad_tip"))
  self.btnWatchAd:SetNormalImage("set:advertisement_system.json image:adver_btn")
  self.btnWatchAd:SetPushedImage("set:advertisement_system.json image:adver_btn")
  self.btnWatchAd:SetTouchable(true)
  self.stTipText:SetYPosition({0, 80})
  self.llContent:SetVisible(true)
  self.canJump = true
end

function UIWatchADTip:setLeftText(text)
  if not text or #text == 0 then
    self.btnWatchAd:SetText("")
  else
    self.btnWatchAd:SetText(Lang:getString(text))
  end
end

function UIWatchADTip:setRightText(text)
  if not text or #text == 0 then
    self.btnUseTicket:SetText("")
  else
    self.btnUseTicket:SetText(Lang:getString(text))
  end
end

function UIWatchADTip:setContentView(view)
  self.contentView = self.contents[view.__name]
  if self.contentView ~= nil then
    self.contentView:show()
  end
end

function UIWatchADTip:setTipText(text)
  self.stTipText:SetText(Lang:getString(text))
end

function UIWatchADTip:updateTicketNum()
  self.ticketNum = PlayerWallet.getMoneyByCoinId(Define.Money.TICKET)
  local ticketNumText = "1 / " .. self.ticketNum
  self.stTicketNum:SetText(ticketNumText)
end

function UIWatchADTip:setTitle(title)
  self.stTipTitle:SetText(Lang:getString(title))
end

function UIWatchADTip:SetYPosition(YPosition)
  self.stTipText:SetYPosition(YPosition)
end

WatchAdTip = {}

function WatchAdTip.init()
  tip:init()
  return WatchAdTip
end

function WatchAdTip.setContentView(name)
  tip:setContentView(name)
  return WatchAdTip
end

function WatchAdTip.setTipText(text)
  tip:setTipText(text)
  return WatchAdTip
end

function WatchAdTip.show(type, params)
  tip:show(type, params)
  tip:updateTicketNum()
  return WatchAdTip
end

function WatchAdTip.setTitle(title)
  tip:setTitle(title)
  return WatchAdTip
end

function WatchAdTip.isShow()
  return tip:isShow()
end

function WatchAdTip.hide()
  tip:hide()
end

function WatchAdTip.setLeftBtnImage(image)
  tip.btnWatchAd:SetNormalImage(image)
  tip.btnWatchAd:SetPushedImage(image)
end

function WatchAdTip.setLeftBtnTouchable(touchable)
  tip.btnWatchAd:SetTouchable(touchable)
end

function WatchAdTip.setLeftBtnEnabled(enabled)
  tip.btnWatchAd:SetTouchable(enabled)
  if enabled == false then
    tip.btnWatchAd:SetNormalImage("set:advertisement_system.json image:not_adver_btn")
    tip.btnWatchAd:SetPushedImage("set:advertisement_system.json image:not_adver_btn")
  else
    tip.btnWatchAd:SetNormalImage("set:advertisement_system.json image:adver_btn")
    tip.btnWatchAd:SetPushedImage("set:advertisement_system.json image:adver_btn")
  end
end

function WatchAdTip.setContentVisible(visible)
  tip.llContent:SetVisible(visible)
  return WatchAdTip
end

function WatchAdTip.SetYPosition(YPosition)
  tip:SetYPosition(YPosition)
  return WatchAdTip
end

function WatchAdTip.banJumpToShop()
  tip.canJump = false
  return WatchAdTip
end

function initWatchAdTip(name)
  if tip ~= nil then
    return
  end
  tip = UIWatchADTip.new(name)
end

function buildWatchAdTipContent(class, name)
  local content = class.new(name, tip.llContent)
  content:hide()
  tip.contents[name] = content
  return content
end

local UIRewardResult = class("UIRewardResult", IGUILayout)

function UIRewardResult:onLoad()
  self:getChildWindow("BedWarRewardResult-Title-Text"):SetText(Lang:getString("bed.war.reward.title"))
  self.llRewards = self:getChildWindow("BedWarRewardResult-Rewards", GUIType.Layout)
  self.tvHint = self:getChildWindow("BedWarRewardResult-Hint", GUIType.StaticText)
  self.tvHint:SetText(Lang:getString("bed.war.reward.close.hint"))
  self:getChildWindow("BedWarRewardResult-Watch-Ad", GUIType.Button):SetVisible(false)
  self.root:registerEvent(GUIEvent.TouchUp, function()
    self:close()
  end)
  self:registerDataCallBack("RewardResult", function(data)
    self:onGetRewardResult(data)
  end, DataBuilderProcessor)
end

function UIRewardResult:onGetRewardResult(data)
  local rewardIds = data:getParam("rewardIds")
  self:onShowRewards(rewardIds)
end

function UIRewardResult:onShowRewards(rewardIds)
  local rewards = RewardConfig.findRewardByIds(rewardIds)
  self:onShowRewardsTip(rewards)
end

function UIRewardResult:onShowRewardsTip(rewards, isShowCount, closeCallBack)
  self.closeCallBack = closeCallBack
  if #rewards == 0 then
    return
  end
  SoundUtil.playSound(SoundType.GetCoin)
  self.llRewards:CleanupChildren()
  local Width = 110
  local Space = 25
  local PosX = (Width + Space) * (#rewards - 1) / -2
  for index, reward in pairs(rewards) do
    local ivBackground = GUIManager:createGUIWindow(GUIType.StaticImage, string.format("BedWarRewardResult-Rewards-Background-%d", index))
    ivBackground:SetArea({0, PosX}, {0, 25}, {0, Width}, {0, Width})
    ivBackground:SetHorizontalAlignment(HorizontalAlignment.Center)
    ivBackground:SetImage("set:bed_war_reward_result.json image:goods")
    local eivIcon = GUIManager:createGUIWindow(GUIType.EffectViewOfObtainment, string.format("BedWarRewardResult-Rewards-Icon-%d", index))
    eivIcon:SetWidth({
      0,
      Width * 0.9
    })
    eivIcon:SetHeight({
      0,
      Width * 0.9
    })
    eivIcon:SetHorizontalAlignment(HorizontalAlignment.Center)
    eivIcon:SetVerticalAlignment(VerticalAlignment.Center)
    eivIcon:SetImage(reward.Image)
    local tvName = GUIManager:createGUIWindow(GUIType.StaticText, string.format("BedWarRewardResult-Rewards-Text-%d", index))
    tvName:SetWidth({1.2, 0})
    tvName:SetHeight({0, 40})
    tvName:SetYPosition({1, 8})
    tvName:SetTextHorzAlign(HorizontalAlignment.Center)
    tvName:SetTextVertAlign(VerticalAlignment.Center)
    tvName:SetHorizontalAlignment(HorizontalAlignment.Center)
    tvName:SetTextBoader(Color.BLACK)
    tvName:SetProperty("Font", "HT14")
    tvName:SetProperty("TextWordWrap", "true")
    if isShowCount then
      tvName:SetText(Lang:getString(reward.Name))
      if tonumber(reward.Count) ~= 1 then
        local tvCount = GUIManager:createGUIWindow(GUIType.StaticText, string.format("BedWarRewardResult-Rewards-Count-%d", index))
        tvCount:SetWidth({0.2, 0})
        tvCount:SetHeight({0, 25})
        tvCount:SetYPosition({1, -25})
        tvCount:SetXPosition({0, -4})
        tvCount:SetTextHorzAlign(HorizontalAlignment.Right)
        tvCount:SetTextVertAlign(VerticalAlignment.Center)
        tvCount:SetHorizontalAlignment(HorizontalAlignment.Right)
        tvCount:SetTextBoader(Color.BLACK)
        tvCount:SetProperty("Font", "HT14")
        tvCount:SetText(tostring(reward.Count))
        eivIcon:AddChildWindow(tvCount)
      end
    else
      tvName:SetText(Lang:getString(reward.Name))
    end
    eivIcon:AddChildWindow(tvName)
    ivBackground:AddChildWindow(eivIcon)
    self.llRewards:AddChildWindow(ivBackground)
    PosX = PosX + Width + Space
  end
  self:show()
end

function UIRewardResult:close()
  self:hide()
  if self.closeCallBack then
    self.closeCallBack()
    self.closeCallBack = nil
  end
end

return UIRewardResult

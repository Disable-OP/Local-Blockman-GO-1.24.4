local UITreasureChallenge = class("GUITreasureChallenge", IGUILayout)

function UITreasureChallenge:onLoad()
  local llRoot = self:getChildWindow("TreasureChallenge", GUIType.Layout)
  local size = llRoot:GetPixelSize()
  local llWindow = self:getChildWindow("TreasureChallenge-window", GUIType.Layout)
  local width = math.min(1060, size.x)
  llWindow:SetWidth({0, width})
  self.stCompletedNum = self:getChildWindow("TreasureChallenge-numTip", GUIType.StaticText)
  self.stTimeNum = self:getChildWindow("TreasureChallenge-tip_text", GUIType.StaticText)
  local btnClose = self:getChildWindow("TreasureChallenge-close", GUIType.Button)
  btnClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local siMask = self:getChildWindow("TreasureChallenge-mask", GUIType.StaticImage)
  siMask:registerEvent(GUIEvent.Click, function()
    self:hide()
  end)
  local content = self:getChildWindow("TreasureChallenge-content", GUIType.Layout)
  self.gvChallengeList = IGUIListView.new("TreasureChallenge-ChallengeList", content, nil, Orientation.Horizontal)
  self.gvChallengeList:setArea({0, 20}, {0, 10}, {1, -20}, {1, 0})
  self.gvChallengeList:setItemSpace(20)
  self.gvChallengeList.root:SetClipChild(false)
  self.challengeAdapter = require("ui..adapter.ChallengeRewardAdapter").new()
  local itemWidth = 188
  local itemHeight = 364
  self.challengeAdapter:setItemSize(itemWidth, itemHeight)
  self.gvChallengeList:setAdapter(self.challengeAdapter)
  self:getChildWindow("TreasureChallenge-title", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_challenge_title"))
  self:getChildWindow("TreasureChallenge-timeTip", GUIType.StaticText):SetText(Lang:getString("gui_bed_war_hall_challenge_tip"))
  self.rewardData = {}
end

function UITreasureChallenge:isShowAnim()
  return false
end

function UITreasureChallenge:onDataChange(rewardData)
  self.rewardNum = #rewardData
  self.challengeAdapter:setData(rewardData)
  local completedNum = 0
  for _, reward in pairs(rewardData) do
    if reward.status == Define.ChallengeStatus.Completed then
      completedNum = completedNum + 1
    end
  end
  if TreasureChallenge.challengeConfig.endDate ~= nil then
    self.stTimeNum:SetText(Lang:getTipString(1046003, "\226\150\162FF00FA9A" .. tostring(math.floor((TreasureChallenge.challengeConfig.endDate - os.time()) / 86400)) .. "\226\150\162FFFFFFFF"))
    self.stCompletedNum:SetText(string.format("%s : \226\150\162FFFFD700%d\226\150\162FFFFFFFF/%d", Lang:getString("gui_bed_war_hall_completed_challenge"), completedNum, self.rewardNum))
  end
end

function UITreasureChallenge:onShow(needHide)
  if TreasureChallengeConfig.times == "0" then
    self:hide()
    CustomDialog.builder().setHideLeftButton().setTitleText("gui_challenge_not_open_title").setContentText(Lang:getString("gui_challenge_not_open")).setRightText(Lang:getString("gui_dialog_tip_btn_sure")).show()
    return
  end
  TreasureChallenge:showNewChallengeTip()
  if needHide == true or needHide == nil then
    for _, iReward in pairs(TreasureChallenge.rewardData) do
      if iReward.status == Define.ChallengeStatus.Experiencing then
        self:hide()
        GUIChallengeTask:refreshUI(iReward.rewardId)
        GUIChallengeTask:show()
        break
      end
    end
  end
end

return UITreasureChallenge

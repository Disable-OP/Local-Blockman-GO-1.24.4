local UIChallengeRewardReceive = class("GUIChallengeRewardReceive", IGUILayout)

function UIChallengeRewardReceive:onLoad()
  self.stName = self:getChildWindow("ChallengeRewardReceive-item_name", GUIType.StaticText)
  self.stTip = self:getChildWindow("ChallengeRewardReceive-tip", GUIType.StaticText)
  self.siIcon = self:getChildWindow("ChallengeRewardReceive-item", GUIType.StaticImage)
  self.siEffect2 = self:getChildWindow("ChallengeRewardReceive-effect2", GUIType.StaticImage)
  self.siEffect3 = self:getChildWindow("ChallengeRewardReceive-effect3", GUIType.StaticImage)
  self.btnSure = self:getChildWindow("ChallengeRewardReceive-sure", GUIType.Button)
  self.btnSure:SetText(Lang:getString("gui_bed_war_hall_sure"))
  self.btnSure:registerEvent(GUIEvent.ButtonClick, function()
    self:onClick()
  end)
  self.root:registerEvent(GUIEvent.Click, function()
    self:onClick()
  end)
  self.stRibbon = self:getChildWindow("ChallengeRewardReceive-ribbon_text", GUIType.StaticText)
end

function UIChallengeRewardReceive:init(reward, isUndergo, closeCallBack)
  self.stName:SetText(Lang:getString(reward.name))
  self.siIcon:SetImage(reward.image)
  if isUndergo then
    self.stRibbon:SetText(Lang:getString("gui_bed_war_hall_Undergo_title"))
    self.stTip:SetText(Lang:getString("gui_bed_war_Undergo_Tip"))
    self.btnSure:SetYPosition({0, 520})
  else
    self.btnSure:SetYPosition({0, 460})
    self.stTip:SetText("")
    self.stRibbon:SetText(Lang:getString("gui_bed_war_hall_completed"))
  end
  self.isUndergo = isUndergo
  self.reward = reward
  self.closeCallBack = closeCallBack
  GUIManager:addShowQueue(GUIChallengeRewardReceive, 1)
  self:show()
end

function UIChallengeRewardReceive:onClick()
  if self.closeCallBack then
    self:hide()
    self.closeCallBack()
    self.closeCallBack = nil
    return
  end
  if self.canClose then
    if self.isUndergo then
      self:hide()
      if self.reward.itemType == 1 or self.reward.itemType == 3 then
        local goodConfig = CustomShopConfig:getGoodsConfig(self.reward.itemId)
        if goodConfig then
          GUICustomShop:openCustomShopByGoodsId(self.reward.itemId)
          CustomShop:onEquipGoods(goodConfig)
        end
      elseif self.reward.itemType == 2 and BaseMain:getGameType() == "g1046" then
        GUIManager:showWindowByName("BedWarRune.json")
      end
    else
      self:hide()
      GUIChallengeTask:hide()
      GUITreasureChallenge:show(false)
    end
  end
end

function UIChallengeRewardReceive:onShow()
  self.siEffect2:SetEffectName("g1008_treasure_02.effect")
  self.siEffect3:SetEffectName("g1008_treasure_03.effect")
  self.btnSure:SetTouchable(false)
  self.canClose = false
  LuaTimer:schedule(function()
    self.btnSure:SetTouchable(true)
    self.canClose = true
  end, 1700)
end

return UIChallengeRewardReceive

local UISuperPlayer = class("UISuperPlayer", IGUILayout)

function UISuperPlayer:onLoad()
  self.days = 0
  self.canGetAway = false
  self.canGetDaily = false
  self.tvTitle = self:getChildWindow("BedWarSuperPlayer-Title-Text", GUIType.StaticText)
  self.tvTitle:SetText(Lang:getString("bed.war.super.player.title"))
  self:getChildWindow("BedWarSuperPlayer-Hint-Text-1"):SetText(Lang:getString("bed.war.super.player.hint.1"))
  self:getChildWindow("BedWarSuperPlayer-Hint-Text-2"):SetText(Lang:getString("bed.war.super.player.hint.2"))
  local btnBuy = self:getChildWindow("BedWarSuperPlayer-Buy")
  btnBuy:SetText(Lang:getString("bed.war.super.player.buy"))
  btnBuy:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.clickUI()
    if self:checkEnableRecharge() then
      ClientHelper.onRecharge(3)
    end
  end)
  local btnReceive = self:getChildWindow("BedWarSuperPlayer-Receive")
  btnReceive:SetText(Lang:getString("bed.war.super.player.receive"))
  btnReceive:registerEvent(GUIEvent.ButtonClick, function()
    SoundUtil.clickUI()
    self:onReceiveClick()
  end)
  local llBorder1 = self:getChildWindow("BedWarSuperPlayer-Border-1")
  self.gvGetAwayRewards = IGUIGridView.new("BedWarSuperPlayer-Get-Away-Rewards", llBorder1)
  self.gvGetAwayRewards:setConfig(0, 0, 3)
  self.gvGetAwayRewards.root:SetHorizontalAlignment(HorizontalAlignment.Center)
  local llBorder2 = self:getChildWindow("BedWarSuperPlayer-Border-2")
  self.gvGetDailyRewards = IGUIGridView.new("BedWarSuperPlayer-Get-Daily-Rewards", llBorder2)
  self.gvGetDailyRewards:setConfig(0, 0, 3)
  self.gvGetDailyRewards.root:SetHorizontalAlignment(HorizontalAlignment.Center)
  local tvOriginalPrice = self:getChildWindow("BedWarSuperPlayer-Original-Price")
  local text = Lang:getString("bed.war.super.player.original.price")
  if text ~= "bed.war.super.player.original.price" then
    tvOriginalPrice:SetText(text)
  end
  local tvCurrentPrice = self:getChildWindow("BedWarSuperPlayer-Current-Price")
  text = Lang:getString("bed.war.super.player.current.price")
  if text ~= "bed.war.super.player.current.price" then
    tvCurrentPrice:SetText(text)
  end
  self:registerDataCallBack("SuperPlayer", function(data)
    self:onUpdateSuperPlayerData(data)
  end, DataBuilderProcessor)
end

function UISuperPlayer:onShow()
  self:initRewards(self.gvGetAwayRewards, SuperPlayerConfig.getRewardsByType(1))
  self:initRewards(self.gvGetDailyRewards, SuperPlayerConfig.getRewardsByType(2))
  self:setData(self.days, self.canGetAway, self.canGetDaily)
end

function UISuperPlayer:initRewards(container, rewards)
  if container:getItemCount() ~= 0 then
    return
  end
  local count = #rewards
  local contentWidth = container:getWidth()
  local contentHeight = container:getHeight()
  local itemWidth = 0
  local itemSpace = 0
  local rowSize = 3
  if count <= 3 or contentWidth <= 500 then
    if contentWidth <= 300 then
      itemWidth = contentWidth / 3
    else
      itemSpace = (contentWidth - 300) / 4
      itemWidth = 100
    end
    rowSize = 3
  else
    itemSpace = (contentWidth - 400) / 5
    itemWidth = 100
    rowSize = 4
  end
  container:setConfig(itemSpace, 0, rowSize)
  container.root:SetXPosition({0, itemSpace})
  for _, reward in pairs(rewards) do
    local Item = UIHelper.newGameGUIWindow("GUISuperPlayerReward", "BedWarSuperPlayerReward.json")
    Item:setWidth({0, itemWidth})
    Item:setHeight({0, contentHeight})
    Item:setReward(reward.RewardId)
    container:addItem(Item)
  end
end

function UISuperPlayer:onUpdateSuperPlayerData(data)
  local days = data:getNumberParam("days")
  local canGetAway = data:getBoolParam("canGetAway")
  local canGetDaily = data:getBoolParam("canGetDaily")
  self:setData(days, canGetAway, canGetDaily)
end

function UISuperPlayer:setData(days, canGetAway, canGetDaily)
  self.days = days
  self.canGetAway = canGetAway
  self.canGetDaily = canGetDaily
  if 0 < days then
    self.tvTitle:SetText(string.format(Lang:getString("bed.war.super.player.days"), days))
  else
    self.tvTitle:SetText(Lang:getString("bed.war.super.player.title"))
  end
  local btnReceive = self:getChildWindow("BedWarSuperPlayer-Receive", GUIType.Button)
  local canReceive = canGetAway or canGetDaily or days <= 0
  btnReceive:SetEnabled(canReceive)
  if canReceive then
    btnReceive:SetText(Lang:getString("bed.war.super.player.receive"))
  else
    btnReceive:SetText(Lang:getString("bed.war.super.player.received"))
  end
  self:resetRewardStatus(self.gvGetAwayRewards, not canGetAway and 0 < days)
  self:resetRewardStatus(self.gvGetDailyRewards, not canGetDaily and 0 < days)
  Events.UpdateActivityRedPointEvent:invoke(3, 0 < days and (canGetAway or canGetDaily))
  if not self.isFirst and days <= 0 and not canGetDaily and not canGetAway then
    GUIActivity:hideSuperPlayer()
    self.isFirst = true
  end
end

function UISuperPlayer:resetRewardStatus(container, received)
  for _, item in pairs(container.items) do
    item:setReceived(received)
  end
end

function UISuperPlayer:onReceiveClick()
  if self:checkEnableRecharge() then
    if self.days <= 0 then
      ClientHelper.onRecharge(3)
    elseif self.canGetAway or self.canGetDaily then
      GamePacketSender:sendReceiveSuperPlayer()
    end
  end
end

function UISuperPlayer:checkEnableRecharge()
  if not PayHelper.isEnableRecharge() then
    CustomDialog.builder().setContentText(Lang:getString("gui_blockcity_not_open_fun")).setLeftText(nil).show()
    return false
  end
  return true
end

return UISuperPlayer

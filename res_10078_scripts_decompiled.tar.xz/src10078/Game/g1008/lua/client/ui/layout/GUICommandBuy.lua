local UICommandBuy = class("GUICommandBuy", IGUILayout)

function UICommandBuy:onLoad()
  self.llCommandMask = self:getChildWindow("BedWarCommandBuy-mask", GUIType.Layout)
  self.llMoneyBg = self:getChildWindow("BedWarCommandBuy-price_bg", GUIType.Layout)
  self.btBuy = self:getChildWindow("BedWarCommandBuy-buy", GUIType.Button)
  self.btClose = self:getChildWindow("BedWarCommandBuy-close_bt", GUIType.Button)
  self.siEffect = self:getChildWindow("BedWarCommandBuy-effect", GUIType.StaticImage)
  self.siBulletEffect = self:getChildWindow("BedWarCommandBuy-effect_bullet", GUIType.StaticImage)
  self.siMoneyIcon = self:getChildWindow("BedWarCommandBuy-money_icon", GUIType.StaticImage)
  self.stTitle = self:getChildWindow("BedWarCommandBuy-title_text", GUIType.StaticText)
  self.stPrice = self:getChildWindow("BedWarCommandBuy-price_text", GUIType.StaticText)
  self:initRegister()
  self.hadBuy = false
end

function UICommandBuy:onStart()
  self:initLanguage()
end

function UICommandBuy:initLanguage()
  self.stTitle:SetText(Lang:getString("gui_bed_war_detail"))
  self.btBuy:SetText(Lang:getString("shop_btn_buy"))
end

function UICommandBuy:initRegister()
  self.llCommandMask:registerEvent(GUIEvent.Click, function()
    self:onClose()
  end)
  self.btClose:registerEvent(GUIEvent.ButtonClick, function()
    self:onClose()
  end)
  self.btBuy:registerEvent(GUIEvent.ButtonClick, function()
    self:onClickBuy()
  end)
  self:registerDataCallBack("BuyCommandSuccess", function(messageId)
    self:onBuySuccess(messageId)
  end)
end

function UICommandBuy:onOpen(messageId)
  LuaTimer:cancel(self.showEffectKey)
  LuaTimer:cancel(self.showBulletEffectKey1)
  LuaTimer:cancel(self.showBulletEffectKey2)
  self.messageId = messageId
  self.goodsConfig = CommandSettingConfig:getConfigById(messageId)
  local effectConfig = MessageEffectConfig:getConfigById(self.goodsConfig.effectId)
  self:showEffect(effectConfig.flaresEffect, effectConfig.boomEffect)
  if self.goodsConfig.price < 0 then
    self.stPrice:SetText("")
    self.llMoneyBg:SetVisible(false)
  else
    if self.goodsConfig.currencyId == Define.Money.DIAMOND then
      self.siMoneyIcon:SetImage("set:bed_war_store.json image:cube")
    elseif self.goodsConfig.currencyId == Define.Money.KEY then
      self.siMoneyIcon:SetImage("set:bed_war_lottery.json image:key")
    end
    self.stPrice:SetText(self.goodsConfig.price)
    self.llMoneyBg:SetVisible(true)
  end
  self:initLanguage()
  self:show()
end

function UICommandBuy:onClickBuy()
  SoundUtil.playSound(SoundConfig.buyCommand)
  if self.hadBuy == false then
    GameAnalytics:design(1, {
      "buy_command ",
      tostring(self.messageId)
    })
  end
  if self.hadBuy == false and self.goodsConfig.price > 0 then
    if self.goodsConfig.currencyId == Define.Money.DIAMOND then
      PayHelper.checkMoney(Define.Money.DIAMOND, self.goodsConfig.price, function(canBuy)
        if canBuy then
          GamePacketSender:sendBuyCommandGoods(self.messageId)
        end
      end)
    elseif self.goodsConfig.currencyId == Define.Money.KEY then
      PayHelper.checkMoney(Define.Money.KEY, self.goodsConfig.price, function(canBuy)
        if canBuy then
          GamePacketSender:sendBuyCommandGoods(self.messageId)
        else
          CustomDialog.hide()
          GUIStore:show(StoreId.CubeStore, 8)
        end
      end)
    end
  end
  if self.hadBuy == true then
    self:onClose()
  end
end

function UICommandBuy:onClose()
  LuaTimer:cancel(self.showEffectKey)
  LuaTimer:cancel(self.showBulletEffectKey1)
  LuaTimer:cancel(self.showBulletEffectKey2)
  self.siBulletEffect:SetEffectName("DefaultEffect.effect")
  self.siEffect:SetEffectName("DefaultEffect.effect")
  self.hadBuy = false
  SoundUtil.playSound(SoundConfig.closeBuyCommand)
  self:hide()
end

function UICommandBuy:showEffect(flaresEffect, boomEffect)
  local function animation()
    local hPos = 0
    
    LuaTimer:cancel(self.showBulletEffectKey or 0)
    LuaTimer:cancel(self.showEffectKey or 0)
    self.siBulletEffect:SetVisible(true)
    self.siBulletEffect:SetEffectName(flaresEffect)
    self.showBulletEffectKey = LuaTimer:scheduleTimer(function()
      hPos = hPos + 3
      self.siBulletEffect:SetArea({0, 0}, {
        0.5,
        -hPos
      }, {0, 30}, {0, 30})
    end, 10, 45)
    self.showEffectKey = LuaTimer:schedule(function()
      self.siBulletEffect:SetEffectName("DefaultEffect.effect")
      self.siBulletEffect:SetVisible(false)
      self.siEffect:SetEffectName(boomEffect)
      self.siBulletEffect:SetArea({0, 0}, {0.5, 0}, {0, 30}, {0, 30})
    end, 500)
  end
  
  animation()
  self.showBulletEffectKey2 = LuaTimer:scheduleTimer(function()
    animation()
  end, 2500)
end

function UICommandBuy:onBuySuccess(messageId)
  self.root:SetVisible(false)
  LuaTimer:schedule(function()
    self.stTitle:SetText(Lang:getString("gui_bed_war_buy_success"))
    self.llMoneyBg:SetVisible(false)
    self.root:SetVisible(true)
    self.btBuy:SetText(Lang:getString("gui_bed_war_sure"))
    self.hadBuy = true
  end, 200)
end

return UICommandBuy

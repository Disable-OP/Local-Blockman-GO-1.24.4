local CreateTeamInviteAdapter = class("CreateTeamInviteAdapter", IDataAdapter)

function CreateTeamInviteAdapter:getJsonName()
  return ""
end

function CreateTeamInviteAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUICreateTeamInviteItem")
end

function CreateTeamInviteAdapter:getItemWidth()
  return {1, 0}
end

function CreateTeamInviteAdapter:getItemHeight()
  return {0, 106}
end

return CreateTeamInviteAdapter

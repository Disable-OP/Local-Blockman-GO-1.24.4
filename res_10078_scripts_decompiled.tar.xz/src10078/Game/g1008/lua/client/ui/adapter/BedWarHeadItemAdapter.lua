local BedWarHeadItemAdapter = class("BedWarHeadItemAdapter", IDataAdapter)

function BedWarHeadItemAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function BedWarHeadItemAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIBedWarHeadFrameItem")
end

function BedWarHeadItemAdapter:getJsonName()
  return "BedWarHeadFrameShopItem.json"
end

function BedWarHeadItemAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function BedWarHeadItemAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return BedWarHeadItemAdapter

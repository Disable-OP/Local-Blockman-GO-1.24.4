local StoreGoodsAdapter = class("StoreGoodsAdapter", IDataAdapter)

function StoreGoodsAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function StoreGoodsAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIStoreGoods")
end

function StoreGoodsAdapter:getJsonName()
  return "BedWarStoreGoods.json"
end

function StoreGoodsAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function StoreGoodsAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return StoreGoodsAdapter

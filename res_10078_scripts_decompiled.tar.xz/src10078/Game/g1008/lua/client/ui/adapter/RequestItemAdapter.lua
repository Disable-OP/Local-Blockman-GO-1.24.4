local RequestItemAdapter = class("RequestItemAdapter", IDataAdapter)

function RequestItemAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function RequestItemAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIFriendRequestItem")
end

function RequestItemAdapter:getJsonName()
  return "BedWarFriendRequest.json"
end

function RequestItemAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function RequestItemAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return RequestItemAdapter

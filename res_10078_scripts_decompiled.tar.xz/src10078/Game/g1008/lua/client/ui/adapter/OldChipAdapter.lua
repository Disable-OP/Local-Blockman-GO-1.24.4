local OldChipAdapter = class("OldChipAdapter", IDataAdapter)

function OldChipAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function OldChipAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIOldChipItem")
end

function OldChipAdapter:getJsonName()
  return "OldChipItem.json"
end

function OldChipAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function OldChipAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return OldChipAdapter

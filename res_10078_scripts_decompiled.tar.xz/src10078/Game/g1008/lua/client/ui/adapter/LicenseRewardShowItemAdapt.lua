local LicenseRewardShowItemAdapt = class("LicenseRewardShowItemAdapt", IDataAdapter)

function LicenseRewardShowItemAdapt:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LicenseRewardShowItemAdapt:getWindowClass()
  return UIHelper.requireGUIWindow("GUILicenseShowItem")
end

function LicenseRewardShowItemAdapt:getJsonName()
  return "BedWarLicenseShowItem.json"
end

function LicenseRewardShowItemAdapt:getItemWidth()
  return {
    0,
    self.width
  }
end

function LicenseRewardShowItemAdapt:getItemHeight()
  return {
    0,
    self.height
  }
end

return LicenseRewardShowItemAdapt

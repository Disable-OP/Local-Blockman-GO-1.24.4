local LicenseRewardListAdapt = class("LicenseRewardListAdapt", IDataAdapter)

function LicenseRewardListAdapt:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LicenseRewardListAdapt:getWindowClass()
  return UIHelper.requireGUIWindow("GUILicenseRewardListItem")
end

function LicenseRewardListAdapt:getJsonName()
  return "BedWarLicenseRewardListItem.json"
end

function LicenseRewardListAdapt:getItemWidth()
  return {
    0,
    self.width
  }
end

function LicenseRewardListAdapt:getItemHeight()
  return {
    0,
    self.height
  }
end

return LicenseRewardListAdapt

local TeamInvitePlayerAdapter = class("TeamInvitePlayerAdapter", IDataAdapter)

function TeamInvitePlayerAdapter:getJsonName()
  return ""
end

function TeamInvitePlayerAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUITeamInvitePlayerItem")
end

function TeamInvitePlayerAdapter:getItemWidth()
  return {1, 0}
end

function TeamInvitePlayerAdapter:getItemHeight()
  return {0, 78}
end

return TeamInvitePlayerAdapter

local DressShowAdapter = class("DressShowAdapter", IDataAdapter)

function DressShowAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function DressShowAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIDressShowItem")
end

function DressShowAdapter:getJsonName()
  return "DressShowItem.json"
end

function DressShowAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function DressShowAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return DressShowAdapter

local UpgradeGoodsDescAdapter = class("UpgradeGoodsDescAdapter", IDataAdapter)

function UpgradeGoodsDescAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function UpgradeGoodsDescAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIUpgradeGoodsDesc")
end

function UpgradeGoodsDescAdapter:getJsonName()
  return "BedWarUpgradeGoodsDesc.json"
end

function UpgradeGoodsDescAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function UpgradeGoodsDescAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return UpgradeGoodsDescAdapter

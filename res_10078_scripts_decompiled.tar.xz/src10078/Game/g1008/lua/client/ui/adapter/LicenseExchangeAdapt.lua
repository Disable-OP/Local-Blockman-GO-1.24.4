local LicenseExchangeAdapt = class("LicenseExchangeAdapt", IDataAdapter)

function LicenseExchangeAdapt:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LicenseExchangeAdapt:getWindowClass()
  return UIHelper.requireGUIWindow("GUILicenseExchangeItem")
end

function LicenseExchangeAdapt:getJsonName()
  return "BedWarLicenseExchangeItem.json"
end

function LicenseExchangeAdapt:getItemWidth()
  return {
    0,
    self.width
  }
end

function LicenseExchangeAdapt:getItemHeight()
  return {
    0,
    self.height
  }
end

return LicenseExchangeAdapt

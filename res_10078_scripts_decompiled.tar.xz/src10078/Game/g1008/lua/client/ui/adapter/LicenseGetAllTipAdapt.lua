local LicenseGetAllTipAdapt = class("LicenseGetAllTipAdapt", IDataAdapter)

function LicenseGetAllTipAdapt:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LicenseGetAllTipAdapt:getWindowClass()
  return UIHelper.requireGUIWindow("GUILicenseGetAllTipItem")
end

function LicenseGetAllTipAdapt:getJsonName()
  return "BedWarLicenseGetAllItem.json"
end

function LicenseGetAllTipAdapt:getItemWidth()
  return {
    0,
    self.width
  }
end

function LicenseGetAllTipAdapt:getItemHeight()
  return {
    0,
    self.height
  }
end

return LicenseGetAllTipAdapt

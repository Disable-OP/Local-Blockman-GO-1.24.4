local LicenseDisplayAdapt = class("LicenseDisplayAdapt", IDataAdapter)

function LicenseDisplayAdapt:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LicenseDisplayAdapt:getWindowClass()
  return UIHelper.requireGUIWindow("GUILicenseGrandPriceItem")
end

function LicenseDisplayAdapt:getJsonName()
  return "BedWarLicenseGrandItem.json"
end

function LicenseDisplayAdapt:getItemWidth()
  return {
    0,
    self.width
  }
end

function LicenseDisplayAdapt:getItemHeight()
  return {
    0,
    self.height
  }
end

return LicenseDisplayAdapt

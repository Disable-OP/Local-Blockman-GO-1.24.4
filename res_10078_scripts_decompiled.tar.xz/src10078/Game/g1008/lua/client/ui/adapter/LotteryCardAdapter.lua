local LotteryCardAdapter = class("LotteryCardAdapter", IDataAdapter)

function LotteryCardAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LotteryCardAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUILotteryCardItem")
end

function LotteryCardAdapter:getJsonName()
  return "BedWarLotteryCard.json"
end

function LotteryCardAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function LotteryCardAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return LotteryCardAdapter

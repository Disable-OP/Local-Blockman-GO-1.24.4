local VisitorsAdapter = class("VisitorsAdapter", IDataAdapter)

function VisitorsAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function VisitorsAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIVisitorsInfoItem")
end

function VisitorsAdapter:getJsonName()
  return "VisitorsInfoItem.json"
end

function VisitorsAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function VisitorsAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return VisitorsAdapter

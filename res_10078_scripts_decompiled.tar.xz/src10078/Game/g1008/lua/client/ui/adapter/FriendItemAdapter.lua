local FriendItemAdapter = class("FriendItemAdapter", IDataAdapter)

function FriendItemAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function FriendItemAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIFriendItem")
end

function FriendItemAdapter:getJsonName()
  return "BedWarFriendItem.json"
end

function FriendItemAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function FriendItemAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return FriendItemAdapter

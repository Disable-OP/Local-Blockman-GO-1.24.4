local LicenseSeasonTaskAdapt = class("LicenseSeasonTaskAdapt", IDataAdapter)

function LicenseSeasonTaskAdapt:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LicenseSeasonTaskAdapt:getWindowClass()
  return UIHelper.requireGUIWindow("GUILicenseSeasonTaskItem")
end

function LicenseSeasonTaskAdapt:getJsonName()
  return "BedWarLicenseSeasonTaskItem.json"
end

function LicenseSeasonTaskAdapt:getItemWidth()
  return {
    0,
    self.width
  }
end

function LicenseSeasonTaskAdapt:getItemHeight()
  return {
    0,
    self.height
  }
end

return LicenseSeasonTaskAdapt

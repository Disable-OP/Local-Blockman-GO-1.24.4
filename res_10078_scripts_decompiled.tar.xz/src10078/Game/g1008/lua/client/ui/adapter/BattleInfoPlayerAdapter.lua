local BattleInfoPlayerAdapter = class("BattleInfoPlayerAdapter", IDataAdapter)

function BattleInfoPlayerAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function BattleInfoPlayerAdapter:getJsonName()
  return "BedWarBattlePlayerInfo.json"
end

function BattleInfoPlayerAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIBattlePlayerInfo")
end

function BattleInfoPlayerAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function BattleInfoPlayerAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return BattleInfoPlayerAdapter

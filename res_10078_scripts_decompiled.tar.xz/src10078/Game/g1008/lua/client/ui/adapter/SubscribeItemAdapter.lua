local SubscribeItemAdapter = class("SubscribeItemAdapter", IDataAdapter)

function SubscribeItemAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function SubscribeItemAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIFriendSubscribeItem")
end

function SubscribeItemAdapter:getJsonName()
  return "BedWarSubscribeItem.json"
end

function SubscribeItemAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function SubscribeItemAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return SubscribeItemAdapter

local LotteryDetailAdapter = class("LotteryDetailAdapter", IDataAdapter)

function LotteryDetailAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LotteryDetailAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUILotteryDetailItem")
end

function LotteryDetailAdapter:getJsonName()
  return "BedWarLotteryDetailItem.json"
end

function LotteryDetailAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function LotteryDetailAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return LotteryDetailAdapter

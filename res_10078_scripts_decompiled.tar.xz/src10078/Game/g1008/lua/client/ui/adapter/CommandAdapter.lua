local CommandAdapter = class("CommandAdapter", IDataAdapter)

function CommandAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function CommandAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUICommandItem")
end

function CommandAdapter:getJsonName()
  return "BedWarCommandItem.json"
end

function CommandAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function CommandAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return CommandAdapter

local ChallengeRewardAdapter = class("ChallengeRewardAdapter", IDataAdapter)

function ChallengeRewardAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function ChallengeRewardAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIChallengeRewardItem")
end

function ChallengeRewardAdapter:getJsonName()
  return "ChallengeRewardItem.json"
end

function ChallengeRewardAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function ChallengeRewardAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return ChallengeRewardAdapter

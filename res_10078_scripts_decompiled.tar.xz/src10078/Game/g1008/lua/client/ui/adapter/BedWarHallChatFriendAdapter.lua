local BedWarHallChatFriendAdapter = class("BedWarHallChatFriendAdapter", IDataAdapter)

function BedWarHallChatFriendAdapter:getJsonName()
  return ""
end

function BedWarHallChatFriendAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIBedWarHallChatFriendItem")
end

function BedWarHallChatFriendAdapter:getItemWidth()
  return {1, 0}
end

function BedWarHallChatFriendAdapter:getItemHeight()
  return {0, 81}
end

return BedWarHallChatFriendAdapter

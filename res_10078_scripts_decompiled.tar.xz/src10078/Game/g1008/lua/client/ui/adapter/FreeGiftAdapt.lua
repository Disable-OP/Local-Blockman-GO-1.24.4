local FreeGiftAdapt = class("FreeGiftAdapt", IDataAdapter)

function FreeGiftAdapt:setItemSize(width, height)
  self.width = width
  self.height = height
end

function FreeGiftAdapt:getWindowClass()
  return UIHelper.requireGUIWindow("GUIFreeGiftItem")
end

function FreeGiftAdapt:getJsonName()
  return "BedWarFreeGiftItem.json"
end

function FreeGiftAdapt:getItemWidth()
  return {
    0,
    self.width
  }
end

function FreeGiftAdapt:getItemHeight()
  return {
    0,
    self.height
  }
end

return FreeGiftAdapt

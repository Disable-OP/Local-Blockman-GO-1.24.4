local BedWarHallChatEmojiAdapter = class("BedWarHallChatEmojiAdapter", IDataAdapter)

function BedWarHallChatEmojiAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function BedWarHallChatEmojiAdapter:getJsonName()
  return "BedWarHallChatEmojiItem.json"
end

function BedWarHallChatEmojiAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIBedWarHallChatEmojiItem")
end

function BedWarHallChatEmojiAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function BedWarHallChatEmojiAdapter:getItemHeight()
  return {
    0,
    self.width
  }
end

return BedWarHallChatEmojiAdapter

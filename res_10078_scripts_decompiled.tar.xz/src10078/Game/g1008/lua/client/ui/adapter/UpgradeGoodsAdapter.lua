local UpgradeGoodsAdapter = class("UpgradeGoodsAdapter", IDataAdapter)

function UpgradeGoodsAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function UpgradeGoodsAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIUpgradeGoods")
end

function UpgradeGoodsAdapter:getJsonName()
  return "BedWarUpgradeGoods.json"
end

function UpgradeGoodsAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function UpgradeGoodsAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return UpgradeGoodsAdapter

local ResultPlayerAdapter = class("ResultPlayerAdapter", IDataAdapter)

function ResultPlayerAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function ResultPlayerAdapter:getJsonName()
  return "ResultPlayerItem.json"
end

function ResultPlayerAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIResultPlayerItem")
end

function ResultPlayerAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function ResultPlayerAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return ResultPlayerAdapter

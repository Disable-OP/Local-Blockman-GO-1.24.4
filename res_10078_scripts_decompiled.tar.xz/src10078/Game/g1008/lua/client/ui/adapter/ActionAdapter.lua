local ActionAdapter = class("ActionAdapter", IDataAdapter)

function ActionAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function ActionAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIActionItem")
end

function ActionAdapter:getJsonName()
  return "ActionItem.json"
end

function ActionAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function ActionAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return ActionAdapter

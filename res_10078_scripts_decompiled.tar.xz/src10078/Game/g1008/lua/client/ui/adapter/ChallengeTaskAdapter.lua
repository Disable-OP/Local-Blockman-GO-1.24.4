local ChallengeTaskAdapter = class("ChallengeTaskAdapter", IDataAdapter)

function ChallengeTaskAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function ChallengeTaskAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIChallengeTaskItem")
end

function ChallengeTaskAdapter:getJsonName()
  return "ChallengeTaskItem.json"
end

function ChallengeTaskAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function ChallengeTaskAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return ChallengeTaskAdapter

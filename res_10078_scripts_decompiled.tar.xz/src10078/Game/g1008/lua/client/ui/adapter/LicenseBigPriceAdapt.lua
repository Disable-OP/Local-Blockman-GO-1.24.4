local LicenseBigPriceAdapt = class("LicenseBigPriceAdapt", IDataAdapter)

function LicenseBigPriceAdapt:setItemSize(width, height)
  self.width = width
  self.height = height
end

function LicenseBigPriceAdapt:getWindowClass()
  return UIHelper.requireGUIWindow("GUILicenseGrandPriceItem")
end

function LicenseBigPriceAdapt:getJsonName()
  return "BedWarLicenseGrandItem.json"
end

function LicenseBigPriceAdapt:getItemWidth()
  return {
    0,
    self.width
  }
end

function LicenseBigPriceAdapt:getItemHeight()
  return {
    0,
    self.height
  }
end

return LicenseBigPriceAdapt

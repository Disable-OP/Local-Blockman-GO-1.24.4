local RecommendItemAdapter = class("RecommendItemAdapter", IDataAdapter)

function RecommendItemAdapter:setItemSize(width, height)
  self.width = width
  self.height = height
end

function RecommendItemAdapter:getWindowClass()
  return UIHelper.requireGUIWindow("GUIFriendRecommendItem")
end

function RecommendItemAdapter:getJsonName()
  return "BedWarFriendRecommend.json"
end

function RecommendItemAdapter:getItemWidth()
  return {
    0,
    self.width
  }
end

function RecommendItemAdapter:getItemHeight()
  return {
    0,
    self.height
  }
end

return RecommendItemAdapter

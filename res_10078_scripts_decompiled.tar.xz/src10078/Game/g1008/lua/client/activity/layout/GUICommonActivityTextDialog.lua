local UICommonActivityTextDialog = class("UICommonActivityTextDialog", IGUILayout)

function UICommonActivityTextDialog:onLoad()
  self.tvTitle = self:getChildWindow("CommonActivityTextDialog-Title", GUIType.StaticText)
  self.tvText = self:getChildWindow("CommonActivityTextDialog-Text", GUIType.StaticText)
  local btnBackClose = self:getChildWindow("CommonActivityTextDialog-Back-Close", GUIType.Button)
  btnBackClose:registerEvent(GUIEvent.ButtonClick, function()
    self:hide()
  end)
  local btnClose = self:getChildWindow("CommonActivityTextDialog-Close", GUIType.StaticImage)
  btnClose:registerEvent(GUIEvent.Click, function()
    self:hide()
  end)
end

function UICommonActivityTextDialog:showText(title, text)
  self.tvTitle:SetText(Lang:getString(title))
  self.tvText:SetText(Lang:getString(text))
  self:show()
end

return UICommonActivityTextDialog

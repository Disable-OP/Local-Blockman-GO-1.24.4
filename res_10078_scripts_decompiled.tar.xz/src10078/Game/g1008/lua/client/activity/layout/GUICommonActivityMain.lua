local UICommonActivityMain = class("UICommonActivityMain", IGUILayout)
local UIUtils = T(Global, "UIUtils")

function UICommonActivityMain:onLoad()
  self.btnEnterButton = self:getChildWindow("CommonActivityMain-Enter-Button", GUIType.Button)
  self.btnEnterButton:registerEvent(GUIEvent.ButtonClick, function()
    CommonActivityReportUtil.reportClickCommonActivity()
    GUICommonActivityLayout:show()
  end)
  self.ivEnterEffect = self:getChildWindow("CommonActivityMain-Enter-Effect", GUIType.StaticImage)
  self.ivRedPoint = self:getChildWindow("CommonActivityMain-Red-Point", GUIType.StaticImage)
  self.ivRedPoint:SetVisible(false)
end

function UICommonActivityMain:checkTabsRedPoint()
  LuaTimer:schedule(function()
    if GUICommonActivityLayout:isHaveRedPoint() then
      UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity, 1)
      self.ivRedPoint:SetVisible(true)
    else
      UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity, 0)
      self.ivRedPoint:SetVisible(false)
    end
  end, 1)
end

return UICommonActivityMain

require("client.activity.window.GUICommonActivityTab")
require("client.activity.window.GUICommonActivityPanel")
require("client.activity.window.GUIMustLotteryPanel")
require("client.activity.window.GUILuckyLotteryPanel")
local PanelCreator = {
  [CommonActivityType.MustLottery] = GUIMustLotteryPanel,
  [CommonActivityType.LuckyLottery] = GUILuckyLotteryPanel
}
local UICommonActivityLayout = class("UICommonActivityLayout", IGUILayout)

function UICommonActivityLayout:onLoad()
  local llRoot = self:getChildWindow("CommonActivityLayout", GUIType.Layout)
  local llContent = self:getChildWindow("CommonActivityLayout-Content", GUIType.Layout)
  local size = llContent:GetPixelSize()
  local btnBackClose = self:getChildWindow("CommonActivityLayout-Back-Close", GUIType.Button)
  btnBackClose:registerEvent(GUIEvent.ButtonClick, function()
    GUICommonActivityLayout:hide(true)
  end)
  local tvTitle = self:getChildWindow("CommonActivityLayout-Title", GUIType.StaticText)
  tvTitle:SetText(Lang:getString("common.activity.title"))
  local ivClose = self:getChildWindow("CommonActivityLayout-Close", GUIType.StaticImage)
  ivClose:registerEvent(GUIEvent.Click, function()
    GUICommonActivityLayout:hide(true)
  end)
  local ivGCubeIcon = self:getChildWindow("CommonActivityLayout-GCube", GUIType.Layout)
  ivGCubeIcon:registerEvent(GUIEvent.Click, function()
    ClientHelper.onRecharge(1)
  end)
  local btnGCubeAdd = self:getChildWindow("CommonActivityLayout-GCube-Add", GUIType.Button)
  btnGCubeAdd:registerEvent(GUIEvent.ButtonClick, function()
    ClientHelper.onRecharge(1)
  end)
  self.tvGCube = self:getChildWindow("CommonActivityLayout-GCube-Value", GUIType.StaticText)
  local llTabs = self:getChildWindow("CommonActivityLayout-Tabs", GUIType.Layout)
  self.lvTabs = IGUIListView.new("CommonActivityLayout-Tabs-List", llTabs)
  self.lvTabs:setItemSpace(4)
  self.llPanels = self:getChildWindow("CommonActivityLayout-Panels", GUIType.Layout)
  self.panels = {}
  self.llTip = self:getChildWindow("CommonActivityLayout-Tip", GUIType.Layout)
  self.tvTipText = self:getChildWindow("CommonActivityLayout-Tip-Text", GUIType.StaticText)
  self.llTip:SetVisible(false)
  CommonDataEvents:registerCallBack("TipNeedBackPack", function()
    CommonActivityRewardPreview.builder().setCenterTip(Lang:getString("common.activity.tip.needBackPack")).setTitleText(Lang:getString("common.activity.tip.title")).show()
  end)
end

function UICommonActivityLayout:isShowAnim()
  return false
end

function UICommonActivityLayout:onTick()
  self.tvGCube:SetText(PlayerWallet.getMoneyByCoinId(MoneyType.Diamonds))
  for _, panel in pairs(self.panels) do
    if panel:isShow() then
      panel:onTick()
    end
  end
end

function UICommonActivityLayout:showActivity(activityId)
  for _, item in pairs(self.lvTabs.items) do
    item:setSelected(item.activityId == activityId)
  end
  for _activityId, panel in pairs(self.panels) do
    panel.root:SetVisible(activityId == _activityId)
    if panel:isShow() then
      panel:onShow()
    end
  end
end

function UICommonActivityLayout:trySelectFirst()
  if self.lvTabs:getItemCount() <= 0 then
    return
  end
  local tab = self.lvTabs.items[1]
  self:showActivity(tab.activityId)
end

function UICommonActivityLayout:addActivity(activity)
  GUICommonActivityMain:show()
  local tab = GUICommonActivityTab.new("GameActivityTab.json")
  tab:onDataChanged(activity)
  self.lvTabs:addItem(tab)
  local creator = PanelCreator[activity.type] or GUICommonActivityPanel
  local panel = creator.new(activity.panelUIJson, activity)
  if panel.root then
    self.llPanels:AddChildWindow(panel.root)
    self.panels[activity.id] = panel
  end
  if self.lvTabs:getItemCount() == 1 then
    self:trySelectFirst()
  end
end

function UICommonActivityLayout:removeActivity(activity)
  local tab = self.lvTabs:getItem("activityId", activity.id)
  if not tab then
    return
  end
  local needChangeSelected = tab:isSelected()
  self.lvTabs:removeItem(tab)
  local panel = self.panels[activity.id]
  if panel then
    GUIManager:destroyGUIWindow(panel.root)
    panel:destroy()
    self.panels[activity.id] = nil
  end
  if needChangeSelected then
    self:trySelectFirst()
    CommonActivityRewardPreview.builder().setTitleText("common.activity.tip.title").setCenterTip(Lang:getString("common.activity.end.tip")).show()
  end
  if self.lvTabs:getItemCount() == 0 then
    GUIManager:removeShowQueue(GUICommonActivityLayout)
    GUICommonActivityMain:hide()
    GUICommonActivityLayout:hide(true)
    GUICommonActivityTextDialog:hide()
  end
end

function UICommonActivityLayout:showTip(tip, duration)
  duration = duration or 1500
  tip = Lang:getString(tip)
  self.tvTipText:SetText(tip)
  self.llTip:SetWidth({
    0,
    self.tvTipText:GetFont():GetTextExtent(tip, 1) + 50
  })
  self.llTip:SetVisible(true)
  LuaTimer:cancel(self.tipTimer)
  self.tipTimer = LuaTimer:schedule(function()
    self.llTip:SetVisible(false)
  end, duration)
end

function UICommonActivityLayout:checkRedPoint(activityId)
  LuaTimer:schedule(function()
    for _activityId, panel in pairs(self.panels) do
      if (activityId == nil or activityId == _activityId) and panel:isNeedRedPoint() then
        for _, item in pairs(self.lvTabs.items) do
          if item.activityId == _activityId and (not item:isSelected() or not self:isShow()) then
            item:setRedPoint(true)
          end
        end
      end
    end
  end, 1)
  if not self:isShow() then
    GUICommonActivityMain:checkTabsRedPoint()
  end
end

function UICommonActivityLayout:isHaveRedPoint()
  for _, item in pairs(self.lvTabs.items) do
    if item:isHaveRedPoint() == true then
      return true
    end
  end
  return false
end

function UICommonActivityLayout:hide(force)
  if not force then
    return
  end
  Events.CommonActivityLayoutHideEvent:invoke()
  self.super.hide(self)
end

return UICommonActivityLayout

require("client.activity.window.GUICommonActivityRewardItem")
local dialog
local GUICommonActivityShowReward = class("GUICommonActivityShowReward", IGUILayout)

function GUICommonActivityShowReward:onLoad()
  self.contents = {}
  self.contentView = nil
  self.customParams = nil
  self.leftClickListener = nil
  self.rightClickListener = nil
  self.closeClickListener = nil
  self.llRewardBox = self:getChildWindow("CommonActivityShowReward-Reward-Box", GUIType.Layout)
  self.llRewards = self:getChildWindow("CommonActivityShowReward-Rewards", GUIType.Layout)
  self.tvTitleText = self:getChildWindow("CommonActivityShowReward-Title", GUIType.StaticText)
  self.tvBottomTip = self:getChildWindow("CommonActivityShowReward-Bottom-Tip", GUIType.StaticText)
  self.btnLeftButton = self:getChildWindow("CommonActivityShowReward-Left", GUIType.Button)
  self.btnRightButton = self:getChildWindow("CommonActivityShowReward-Right", GUIType.Button)
  self.tvLeftBtnText = self:getChildWindow("CommonActivityShowReward-Left-Text", GUIType.StaticText)
  self.tvRightBtnText = self:getChildWindow("CommonActivityShowReward-Right-Text", GUIType.StaticText)
  self.ivLeftIcon = self:getChildWindow("CommonActivityShowReward-Left-Money-Icon", GUIType.StaticImage)
  self.ivRightIcon = self:getChildWindow("CommonActivityShowReward-Right-Money-Icon", GUIType.StaticImage)
  self.tvLeftBtnPrice = self:getChildWindow("CommonActivityShowReward-Left-Price", GUIType.StaticText)
  self.tvRightBtnPrice = self:getChildWindow("CommonActivityShowReward-Right-Price", GUIType.StaticText)
  self.btnLeftButton:registerEvent(GUIEvent.ButtonClick, function()
    if self.leftClickListener ~= nil then
      local close = self.leftClickListener()
      if not close then
        self:hide(true)
      end
    else
      self:hide(true)
    end
    SoundUtil.playSound(SoundType.ClosePanel)
  end)
  self.btnRightButton:registerEvent(GUIEvent.ButtonClick, function()
    if self.rightClickListener ~= nil then
      local close = self.rightClickListener()
      if not close then
        self:hide(true)
      end
    else
      self:hide(true)
    end
    SoundUtil.playSound(SoundType.ClosePanel)
  end)
  self.leftButtonPos = self.btnLeftButton:GetXPosition()
  self.rightButtonPos = self.btnRightButton:GetXPosition()
  self.items = {}
end

function GUICommonActivityShowReward:setDefault()
  self.customParams = nil
  self.leftClickListener = nil
  self.rightClickListener = nil
  self.closeClickListener = nil
  for _, item in pairs(self.items) do
    item:destroy()
  end
  self.items = {}
  self.llRewards:CleanupChildren()
  LuaTimer:cancel(self.showRewardKey)
  self.tvTitleText:SetText(Lang:getString("common.activity.showReward.title"))
  self.tvBottomTip:SetVisible(false)
  self:setLeftButton(Lang:getString("common.activity.tip.tryAgain"))
  self.ivLeftIcon:SetVisible(false)
  self.tvLeftBtnPrice:SetText("")
  self:setRightButton(Lang:getString("common.activity.sure"))
  self.ivRightIcon:SetVisible(false)
  self.tvRightBtnPrice:SetText("")
end

function GUICommonActivityShowReward:hide(force)
  if not force then
    return
  end
  if self:isShow() then
    self.root:SetVisible(false)
    self:onHide()
  end
end

function GUICommonActivityShowReward:onHide()
  self:setDefault()
end

function GUICommonActivityShowReward:builder()
  self:setDefault()
end

function GUICommonActivityShowReward:addRewardListItem(rewardList, allRewardCount, isOneReward)
  LuaTimer:cancel(self.showRewardKey)
  allRewardCount = allRewardCount or #rewardList
  local size = math.min(84, (self.llRewardBox:GetPixelSize().x - (allRewardCount - 1) * 22 - 20) / allRewardCount)
  if isOneReward == nil then
    isOneReward = #rewardList == 1
  end
  local lineCount = 6
  if 6 < allRewardCount then
    lineCount = math.floor(allRewardCount / 2 + 0.5)
  end
  
  local function addItem(item)
    local count = self.llRewards:GetChildCount()
    local col = count % lineCount
    local row = math.floor(count / lineCount)
    item:setArea({
      0,
      col * (size + 20)
    }, {
      0,
      row * (size + 15)
    }, {0, size}, {0, size})
    self.llRewards:AddChildWindow(item.root)
    table.insert(self.items, item)
  end
  
  local function fun()
    local rewardInfo = table.remove(rewardList, 1)
    if rewardInfo then
      if rewardInfo.type and rewardInfo.type == "extra" then
        local rewardItem = GUICommonActivityRewardItem.new()
        rewardItem:setLuckyValue(rewardInfo)
        addItem(rewardItem)
      else
        local reward = CommonActivityRewardConfig:getRewardById(rewardInfo.rewardId)
        if reward then
          if rewardInfo.isGrandPrize == true then
            LuaTimer:cancel(self.showRewardKey)
            GUICommonActivityGrandPrize:init(reward, function()
              self:addRewardListItem(rewardList, allRewardCount, isOneReward)
            end)
            if isOneReward then
              LuaTimer:schedule(function()
                self:hide()
              end, 1)
            end
          end
          local rewardItem = GUICommonActivityRewardItem.new()
          rewardItem:setLotteryResult(reward)
          rewardItem:SetEffectMask("set:common_activity.json image:img_9_mask_popup")
          addItem(rewardItem)
        end
      end
    end
  end
  
  if isOneReward then
    fun()
  else
    self.showRewardKey = LuaTimer:scheduleTimer(fun, 150, #rewardList)
  end
end

function GUICommonActivityShowReward:setRewardView(rewardList)
  GUICommonActivityGrandPrize:removeCallBack()
  local rewardNum = #rewardList
  local col = 6
  if 6 < rewardNum then
    col = math.floor(rewardNum / 2 + 0.5)
  end
  local size = math.min(84, (self.llRewardBox:GetPixelSize().x - (rewardNum - 1) * 22) / math.min(col, rewardNum)) + 22
  local height = math.ceil(rewardNum / col) * 84 + (math.ceil(rewardNum / col) - 1) * 28
  self.llRewards:SetArea({0, 0}, {0, 0}, {
    0,
    size * math.min(col, rewardNum) - 22
  }, {0, height})
  self.btnLeftButton:SetTouchable(false)
  self.btnRightButton:SetTouchable(false)
  LuaTimer:cancel(self.btnKey)
  self.btnKey = LuaTimer:schedule(function()
    self.btnLeftButton:SetTouchable(true)
    self.btnRightButton:SetTouchable(true)
  end, 150 * rewardNum)
  self:addRewardListItem(rewardList)
end

function GUICommonActivityShowReward:setUI()
  if self.btnLeftButton:IsVisible() and self.btnRightButton:IsVisible() then
    self.btnLeftButton:SetXPosition(self.leftButtonPos)
    self.btnRightButton:SetXPosition(self.rightButtonPos)
  elseif self.btnLeftButton:IsVisible() then
    self.btnLeftButton:SetXPosition({0, 0})
  elseif self.btnRightButton:IsVisible() then
    self.btnRightButton:SetXPosition({0, 0})
  end
  if self.tvBottomTip:IsVisible() then
    self.llRewards:SetYPosition({0, -20})
  else
    self.llRewards:SetYPosition({0, 0})
  end
end

function GUICommonActivityShowReward:setLeftButton(text, icon, price)
  if not text or #text == 0 then
    self.tvLeftBtnText:SetText("")
    self.btnLeftButton:SetVisible(false)
  else
    self.btnLeftButton:SetVisible(true)
    self.tvLeftBtnText:SetText(Lang:getString(text))
  end
  if not icon or #icon == 0 then
    self.ivLeftIcon:SetVisible(false)
    self.ivLeftIcon:SetImage("")
    self.tvLeftBtnPrice:SetText("")
  else
    self.ivLeftIcon:SetVisible(true)
    self.ivLeftIcon:SetImage(icon)
    self.tvLeftBtnPrice:SetText(price)
  end
end

function GUICommonActivityShowReward:setRightButton(text, icon, price)
  if not text or #text == 0 then
    self.tvRightBtnText:SetText("")
    self.btnRightButton:SetVisible(false)
  else
    self.btnRightButton:SetVisible(true)
    self.tvRightBtnText:SetText(Lang:getString(text))
  end
  if not icon or #icon == 0 then
    self.ivRightIcon:SetVisible(false)
    self.ivRightIcon:SetImage("")
    self.tvRightBtnPrice:SetText("")
  else
    self.ivRightIcon:SetVisible(true)
    self.ivRightIcon:SetImage(icon)
    self.tvRightBtnPrice:SetText(price)
  end
end

CommonActivityShowReward = {}

function CommonActivityShowReward.builder()
  dialog:builder()
  return CommonActivityShowReward
end

function CommonActivityShowReward.setTitleText(title)
  dialog.tvTitleText:SetText(Lang:getString(title))
  return CommonActivityShowReward
end

function CommonActivityShowReward.setBottomTip(tip)
  dialog.tvBottomTip:SetVisible(true)
  dialog.tvBottomTip:SetText(tip)
  return CommonActivityShowReward
end

function CommonActivityShowReward.setRewardView(rewardList)
  dialog:setRewardView(rewardList)
  return CommonActivityShowReward
end

function CommonActivityShowReward.setRewardGroup(groupId)
  local group = CommonActivityRewardConfig:getRewardGroupById(groupId)
  if not group then
    return CommonActivityShowReward
  end
  local result = {}
  for _, item in pairs(group) do
    table.insert(result, {
      rewardId = item.reward.rewardId,
      isGrandPrize = item.isGrandPrize
    })
  end
  dialog:setRewardView(result)
  return CommonActivityShowReward
end

function CommonActivityShowReward.setRightButton(text, icon, price)
  dialog:setRightButton(text, icon, price)
  return CommonActivityShowReward
end

function CommonActivityShowReward.setLeftButton(text, icon, price)
  dialog:setLeftButton(text, icon, price)
  return CommonActivityShowReward
end

function CommonActivityShowReward.setLeftClickListener(listener)
  dialog.leftClickListener = listener
  return CommonActivityShowReward
end

function CommonActivityShowReward.setRightClickListener(listener)
  dialog.rightClickListener = listener
  return CommonActivityShowReward
end

function CommonActivityShowReward.show()
  dialog:setUI()
  dialog:show()
  SoundUtil.playSound(SoundType.OpenPanel)
end

function CommonActivityShowReward.hide()
  dialog:hide(true)
end

function CommonActivityShowReward.isShow()
  if not dialog then
    return false
  end
  return dialog:isShow()
end

function CommonActivityShowReward.setHideLeftButton()
  dialog.btnLeftButton:SetVisible(false)
  dialog.btnRightButton:SetHorizontalAlignment(HorizontalAlignment.Center)
  dialog.btnRightButton:SetXPosition({0, 0})
  return CommonActivityShowReward
end

function CommonActivityShowReward.setHideRightButton()
  dialog.btnRightButton:SetVisible(false)
  dialog.btnLeftButton:SetHorizontalAlignment(HorizontalAlignment.Center)
  dialog.btnLeftButton:SetXPosition({0, 0})
  return CommonActivityShowReward
end

function CommonActivityShowReward.setAlwaysOnTop(isTop)
  return dialog:setAlwaysOnTop(isTop)
end

function initCommonActivityShowReward()
  if dialog ~= nil then
    return
  end
  dialog = GUICommonActivityShowReward.new("GameActivityShowReward.json")
end

require("client.activity.window.GUICommonActivityRewardItem")
local dialog
local UICommonActivityRewardPreview = class("UICommonActivityRewardPreview", IGUILayout)

function UICommonActivityRewardPreview:onLoad()
  self.rewardLayoutPos = nil
  self.sureClickListener = nil
  self.tvTitle = self:getChildWindow("CommonActivityRewardPreview-Title", GUIType.StaticText)
  self.tvTopTip = self:getChildWindow("CommonActivityRewardPreview-Top-Tip", GUIType.StaticText)
  self.tvBottomTip = self:getChildWindow("CommonActivityRewardPreview-Bottom-Tip", GUIType.StaticText)
  self.llReward = self:getChildWindow("CommonActivityRewardPreview-Reward-Layout", GUIType.Layout)
  self.tvTitle:SetText(Lang:getString("common.activity.reward.preview.title"))
  local btnSure = self:getChildWindow("CommonActivityRewardPreview-Sure", GUIType.Button)
  btnSure:SetText(Lang:getString("common.activity.sure"))
  btnSure:registerEvent(GUIEvent.ButtonClick, function()
    if self.sureClickListener ~= nil then
      local close = self.sureClickListener()
      if not close then
        self:hide()
      end
    else
      self:hide()
    end
    SoundUtil.playSound(SoundType.ClosePanel)
  end)
  local btnClose = self:getChildWindow("CommonActivityRewardPreview-Close", GUIType.StaticImage)
  btnClose:registerEvent(GUIEvent.Click, function()
    self:hide()
  end)
  self.gvRewardList = IGUIGridView.new("CommonActivityRewardPreview-Reward-List", self.llReward, nil)
  self.gvRewardList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
  self.gvRewardList.root:SetVerticalAlignment(VerticalAlignment.Center)
  self.gvRewardList.root:SetClipChild(true)
  self.gvRewardList:setArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
  self.gvRewardList:setConfig(16, 16, 5)
  self.rewardLayoutPos = self.llReward:GetYPosition()
end

function UICommonActivityRewardPreview:setTopTip(text)
  if not text or text == "" then
    return
  end
  self.tvTopTip:SetVisible(true)
  self.tvTopTip:SetText(text)
end

function UICommonActivityRewardPreview:setTitle(text)
  if not text or text == "" then
    return
  end
  self.tvTitle:SetText(Lang:getString(text))
end

function UICommonActivityRewardPreview:setBottomText(text)
  if not text or text == "" then
    return
  end
  self.tvBottomTip:SetVisible(true)
  self.tvBottomTip:SetText(text)
end

function UICommonActivityRewardPreview:setRewardView(rewardConfig)
  local rewardNum = #rewardConfig
  local rowNum = math.ceil(rewardNum / 5)
  if rowNum == 1 then
    self.llReward:SetWidth({
      0,
      84 * rewardNum + 16 * (rewardNum - 1)
    })
    self.llReward:SetHeight({0, 84})
  elseif rowNum == 2 then
    self.llReward:SetWidth({0, 486})
    self.llReward:SetHeight({0, 184})
  else
    self.llReward:SetWidth({0, 486})
    self.llReward:SetHeight({0, 244})
  end
  for _, rewardId in pairs(rewardConfig) do
    local reward = CommonActivityRewardConfig:getRewardById(rewardId)
    local rewardItem = GUICommonActivityRewardItem.new()
    rewardItem:setRewardData(reward)
    rewardItem:setWidth({0, 84})
    rewardItem:setHeight({0, 84})
    rewardItem:SetEffectMask("set:common_activity.json image:img_9_mask_popup")
    self.gvRewardList:addItem(rewardItem)
  end
end

function UICommonActivityRewardPreview:setRewardLayoutYPos(pos)
  self.llReward:SetYPosition(pos)
end

function UICommonActivityRewardPreview:setDefault()
  self.gvRewardList:clearItems()
  self.llReward:SetYPosition(self.rewardLayoutPos)
  self.sureClickListener = nil
  self.tvTopTip:SetText("")
  self.tvTopTip:SetVisible(false)
  self.tvBottomTip:SetText("")
  self.tvBottomTip:SetVisible(false)
end

function UICommonActivityRewardPreview:hide()
  if self:isShow() then
    self.root:SetVisible(false)
    self:onHide()
  end
end

function UICommonActivityRewardPreview:onHide()
  self:setDefault()
end

function UICommonActivityRewardPreview:builder()
  self:setDefault()
end

CommonActivityRewardPreview = {}

function CommonActivityRewardPreview.builder()
  dialog:builder()
  return CommonActivityRewardPreview
end

function CommonActivityRewardPreview.setRewardView(rewardList)
  dialog:setRewardView(rewardList)
  return CommonActivityRewardPreview
end

function CommonActivityRewardPreview.setRewardViewByGroupId(groupId)
  local rewardGroup = CommonActivityRewardConfig:getRewardGroupById(groupId)
  if rewardGroup ~= nil then
    local list = {}
    for _, rewardConfig in pairs(rewardGroup) do
      table.insert(list, rewardConfig.reward.rewardId)
    end
    dialog:setRewardView(list)
  end
  return CommonActivityRewardPreview
end

function CommonActivityRewardPreview.setRewardLayoutYPos(pos)
  dialog:setRewardLayoutYPos(pos)
  return CommonActivityRewardPreview
end

function CommonActivityRewardPreview.setTitleText(text)
  dialog:setTitle(text)
  return CommonActivityRewardPreview
end

function CommonActivityRewardPreview.setTopTip(text)
  dialog:setTopTip(text)
  return CommonActivityRewardPreview
end

function CommonActivityRewardPreview.setBottomText(text)
  dialog:setBottomText(text)
  return CommonActivityRewardPreview
end

function CommonActivityRewardPreview.show()
  dialog:show()
  SoundUtil.playSound(SoundType.OpenPanel)
end

function CommonActivityRewardPreview.hide()
  dialog:hide()
end

function CommonActivityRewardPreview.isShow()
  if not dialog then
    return false
  end
  return dialog:isShow()
end

function CommonActivityRewardPreview.setAlwaysOnTop(isTop)
  return dialog:setAlwaysOnTop(isTop)
end

function CommonActivityRewardPreview.setCenterTip(text)
  dialog:setRewardLayoutYPos({0, 40})
  dialog.llReward:SetHeight({0, 0})
  dialog:setTopTip(text)
  return CommonActivityRewardPreview
end

function CommonActivityRewardPreview.setSureClickListener(listener)
  dialog.sureClickListener = listener
  return CommonActivityRewardPreview
end

function initCommonActivityRewardPreview()
  if dialog ~= nil then
    return
  end
  dialog = UICommonActivityRewardPreview.new("GameActivityRewardPreview.json")
end

return UICommonActivityRewardPreview

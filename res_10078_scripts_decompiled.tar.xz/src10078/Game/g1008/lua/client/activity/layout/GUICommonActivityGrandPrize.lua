local UICommonActivityGrandPrize = class("GUICommonActivityGrandPrize", IGUILayout)

function UICommonActivityGrandPrize:onLoad()
  self.stName = self:getChildWindow("CommonActivityGrandPrize-item_name", GUIType.StaticText)
  self.stTip = self:getChildWindow("CommonActivityGrandPrize-tip", GUIType.StaticText)
  self.siIcon = self:getChildWindow("CommonActivityGrandPrize-item", GUIType.StaticImage)
  self.siEffect2 = self:getChildWindow("CommonActivityGrandPrize-effect2", GUIType.StaticImage)
  self.siEffect3 = self:getChildWindow("CommonActivityGrandPrize-effect3", GUIType.StaticImage)
  self.btnSure = self:getChildWindow("CommonActivityGrandPrize-sure", GUIType.Button)
  self.btnSure:SetText(Lang:getString("common.activity.sure"))
  self.btnSure:registerEvent(GUIEvent.ButtonClick, function()
    self:onClick()
  end)
  self.root:registerEvent(GUIEvent.Click, function()
    self:onClick()
  end)
  self.stRibbon = self:getChildWindow("CommonActivityGrandPrize-ribbon_text", GUIType.StaticText)
  self.fun = nil
end

function UICommonActivityGrandPrize:init(reward, fun)
  self.stName:SetText(Lang:getString(reward.name))
  self.siIcon:SetImage(reward.image)
  self.btnSure:SetYPosition({0, 460})
  self.stTip:SetText("")
  self.stRibbon:SetText(Lang:getString("common.activity.tip.completed"))
  self.reward = reward
  self.fun = fun
  GUIManager:addShowQueue(GUICommonActivityGrandPrize, 1)
  self:show()
end

function UICommonActivityGrandPrize:removeCallBack()
  self.fun = nil
end

function UICommonActivityGrandPrize:onClick()
  self:hide()
  if self.fun then
    self.fun()
  end
end

function UICommonActivityGrandPrize:onShow()
  self.siEffect2:SetEffectName("g1008_treasure_02.effect")
  self.siEffect3:SetEffectName("g1008_treasure_03.effect")
  self.btnSure:SetTouchable(false)
  self.canClose = false
  LuaTimer:schedule(function()
    self.btnSure:SetTouchable(true)
    self.canClose = true
  end, 1700)
end

return UICommonActivityGrandPrize

GUIMustLotteryItem = class("GUIMustLotteryItem", IGUIWindow)

function GUIMustLotteryItem:onLoad(parent)
  self.parent = parent
  self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
  self.ivBG = self:getChildWindowByName("MustLotteryItem-BG", GUIType.StaticImage)
  self.ivImage = self:getChildWindowByName("MustLotteryItem-Image", GUIType.StaticImage)
  self.ivImageMask = self:getChildWindowByName("MustLotteryItem-Image-Mask", GUIType.StaticImage)
  self.tvCount = self:getChildWindowByName("MustLotteryItem-Count", GUIType.StaticText)
  self.ivSelected = self:getChildWindowByName("MustLotteryItem-Selected", GUIType.StaticImage)
  self.ivSelectedImg = self:getChildWindowByName("MustLotteryItem-Selected-Img", GUIType.StaticImage)
  self.btnSelected = self:getChildWindowByName("MustLotteryItem-Selected-Click", GUIType.Button)
  self.llMask = self:getChildWindowByName("MustLotteryItem-Mask", GUIType.Layout)
  self.ivMaskIcon = self:getChildWindowByName("MustLotteryItem-Mask-Icon", GUIType.StaticImage)
  self.ivEffect = self:getChildWindowByName("MustLotteryItem-Effect", GUIType.StaticImage)
  self.ivQualityEffect = self:getChildWindowByName("MustLotteryItem-Quality-Effect", GUIType.StaticImage)
  self.ivEffectMask = self:getChildWindowByName("MustLotteryItem-Effect-Mask", GUIType.StaticImage)
  self.llMask:SetVisible(false)
  self.llRoot:registerEvent(GUIEvent.Click, function()
    self.parent:clickItem(self)
  end)
  self.btnSelected:registerEvent(GUIEvent.ButtonClick, function()
    self.parent:selectItem(self)
  end)
  self:setEffect(false)
  self.ivEffectMask:SetImage("set:common_activity.json image:img_9_mask_must")
end

function GUIMustLotteryItem:onDataChanged(data)
  self.isGrandPrize = data.isGrandPrize
  self.groupSeq = data.groupSeq
  self.reward = data.reward
  self:SetIcon(self.reward)
  if self.reward.needMask then
    self.ivImageMask:SetImage("set:game_activity.json image:img_0_mask_" .. self.reward.quality .. "01")
    self.ivImageMask:SetVisible(true)
  end
  if self.reward.numLang ~= "#" then
    self.tvCount:SetText(Lang:getString(self.reward.numLang))
  end
  self.ivBG:SetImage("set:game_activity.json image:img_0_grade1_" .. data.reward.quality)
  if self.isGrandPrize then
    self.ivSelected:SetVisible(false)
  end
  if self.reward.effect ~= "#" then
    self.ivQualityEffect:SetEffectName(self.reward.effect)
    self.ivQualityEffect:SetVisible(false)
  end
end

function GUIMustLotteryItem:setSelected(selected)
  self.ivSelectedImg:SetVisible(selected)
end

function GUIMustLotteryItem:setDelete(deleted)
  self.ivSelected:SetVisible(false)
  self.llMask:SetVisible(deleted)
  if deleted then
    self.ivMaskIcon:SetImage("set:game_activity.json image:btn_0_close02")
    self.ivMaskIcon:SetWidth({0, 34})
    self.ivMaskIcon:SetHeight({0, 34})
  elseif self.isGet then
    self:setGet()
  end
end

function GUIMustLotteryItem:setGet()
  self.isGet = true
  self.llMask:SetVisible(true)
  self.ivMaskIcon:SetImage("set:game_activity.json image:img_0_selected02")
  self.ivMaskIcon:SetWidth({0, 42})
  self.ivMaskIcon:SetHeight({0, 34})
  self.ivEffect:SetVisible(false)
end

function GUIMustLotteryItem:setEffect(effect)
  self.ivEffect:SetVisible(effect)
end

function GUIMustLotteryItem:SetIcon(data)
  if data.imageScale ~= "#" then
    UIHelper:setImageAdjustSize(self.ivImage, data.image, self.ivImage:GetPixelSize().x, self.ivImage:GetPixelSize().y, data.imageScale)
  else
    UIHelper:setImageAdjustSize(self.ivImage, data.image)
  end
  if data.imageXOffset ~= "#" then
    self.ivImage:SetXPosition({
      0,
      data.imageXOffset
    })
  end
  if data.imageYOffset ~= "#" then
    self.ivImage:SetYPosition({
      0,
      data.imageYOffset
    })
  end
end

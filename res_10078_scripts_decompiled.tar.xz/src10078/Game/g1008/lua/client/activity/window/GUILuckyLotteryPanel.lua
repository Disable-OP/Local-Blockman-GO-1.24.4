require("client.activity.window.GUICommonActivityRewardItem")
require("client.activity.window.GUICommonActivityRewardFloat")
GUILuckyLotteryPanel = class("GUILuckyLotteryPanel", GUICommonActivityPanel)

function GUILuckyLotteryPanel:ctor(json_name, ...)
  self.json_name = json_name
  self.super.ctor(self, "GameLuckyTurntablePanel.json", ...)
end

function GUILuckyLotteryPanel:onChildLoad()
  local name = self.json_name:gsub(".json", "-")
  self.llRewardShow = self:getChildWindowByName(name .. "Reward-Show", GUIType.Layout)
  self.llRewardAll = self:getChildWindowByName(name .. "Reward-All", GUIType.Layout)
  self.llRewardRange = self:getChildWindowByName(name .. "Reward-Range", GUIType.Layout)
  self.llClickBox = self:getChildWindowByName(name .. "Click-Box", GUIType.Layout)
  self.stLuckyText = self:getChildWindowByName(name .. "Lucky-Text", GUIType.StaticText)
  self.stLuckyValue = self:getChildWindowByName(name .. "Lucky-Value", GUIType.StaticText)
  self.siLuckyBg = self:getChildWindowByName(name .. "Lucky-Bg", GUIType.StaticImage)
  self.siLuckyStart1 = self:getChildWindowByName(name .. "Lucky-Star-1", GUIType.StaticImage)
  self.siLuckyStart2 = self:getChildWindowByName(name .. "Lucky-Star-2", GUIType.StaticImage)
  self.siLuckyStart3 = self:getChildWindowByName(name .. "Lucky-Star-3", GUIType.StaticImage)
  self.siRewardShowView = self:getChildWindowByName(name .. "Reward-Show-View-Bg", GUIType.StaticImage)
  self.siRewardShowViewTip = self:getChildWindowByName(name .. "Reward-Show-View-Tip", GUIType.StaticText)
  self.siRewardBackShow = self:getChildWindowByName(name .. "Reward-Back-Show-Bg", GUIType.StaticImage)
  self.siRewardBackShowTip = self:getChildWindowByName(name .. "Reward-Back-Show-Tip", GUIType.StaticText)
  self.stRewardShowViewTip = self:getChildWindowByName(name .. "Reward-Show-View-Tip", GUIType.StaticText)
  self.stRewardShowViewTip = self:getChildWindowByName(name .. "Reward-Show-View-Tip", GUIType.StaticText)
  self.stRewardShowViewTip = self:getChildWindowByName(name .. "Reward-Show-View-Tip", GUIType.StaticText)
  self.stRewardBackShowTip = self:getChildWindowByName(name .. "Reward-Back-Show-Tip", GUIType.StaticText)
  self.btnLeft = self:getChildWindowByName(name .. "Left-Btn", GUIType.Button)
  self.siLeftOffBg = self:getChildWindowByName(name .. "Left-Btn-Off-Bg", GUIType.StaticImage)
  self.siLeftCoolDownIcon = self:getChildWindowByName(name .. "Left-Btn-CoolDown-Icon", GUIType.StaticImage)
  self.stLeftOffValue = self:getChildWindowByName(name .. "Left-Btn-Off-Value", GUIType.StaticText)
  self.stLeftBtnTopText = self:getChildWindowByName(name .. "Left-Btn-TopText", GUIType.StaticText)
  self.stLeftBtnValue = self:getChildWindowByName(name .. "Left-Btn-Value", GUIType.StaticText)
  self.stLeftBtnPrice = self:getChildWindowByName(name .. "Left-Btn-Price", GUIType.StaticText)
  self.stLeftBtnCoolDownText = self:getChildWindowByName(name .. "Left-Btn-CoolDown-Text", GUIType.StaticText)
  self.btnRight = self:getChildWindowByName(name .. "Right-Btn", GUIType.Button)
  self.stRightBtnTopText = self:getChildWindowByName(name .. "Right-Btn-TopText", GUIType.StaticText)
  self.stRightBtnValue = self:getChildWindowByName(name .. "Right-Btn-Value", GUIType.StaticText)
  self.stRightBtnPrice = self:getChildWindowByName(name .. "Right-Btn-Price", GUIType.StaticText)
  self.stLuckyText:SetText(Lang:getString("lucky.lottery.ui.luckyValue"))
  self.siRewardShowViewTip:SetText(Lang:getString("lucky.lottery.ui.showView"))
  self.siRewardBackShowTip:SetText(Lang:getString("lucky.lottery.ui.backShow"))
  self.llRewardAll:SetVisible(false)
  self.siLeftOffBg:SetVisible(false)
  self.siLeftCoolDownIcon:SetVisible(false)
  self.wFloatReward = GUICommonActivityRewardFloat.new()
  self.root:AddChildWindow(self.wFloatReward.root)
  self:initEvent()
end

function GUILuckyLotteryPanel:onShow()
  self.wFloatReward:hide()
  if self.isInit then
    return
  end
  self.isInit = true
  self:initList(self.activity.rewardGroupId or 2)
  self:setSingleDrawPrice()
  self:setTenDrawPrice()
  self:setLuckValue(self.activity.luckyValue)
end

function GUILuckyLotteryPanel:initEvent()
  self.btnLeft:registerEvent(GUIEvent.ButtonClick, function()
    self:onLottery(1)
  end)
  self.btnRight:registerEvent(GUIEvent.ButtonClick, function()
    self:onLottery(2)
  end)
  self.siRewardShowView:registerEvent(GUIEvent.Click, function()
    self.llRewardShow:SetVisible(false)
    self.llRewardAll:SetVisible(true)
  end)
  self.siRewardBackShow:registerEvent(GUIEvent.Click, function()
    self.llRewardShow:SetVisible(true)
    self.llRewardAll:SetVisible(false)
  end)
  self.llClickBox:registerEvent(GUIEvent.Click, function()
    self.llRewardShow:SetVisible(false)
    self.llRewardAll:SetVisible(true)
  end)
  self.siLuckyBg:registerEvent(GUIEvent.Click, function()
    self.wFloatReward:showDesc("lucky.lottery.ui.desc", self.siLuckyBg)
    self.wFloatRewardNeedShow = true
  end)
  CommonDataEvents:registerCallBack("LuckyLotteryResult", function(data)
    self:showLotteryResult(data)
  end, JsonBuilderProcessor)
  CommonDataEvents:registerCallBack("LuckyLotteryDiscountCd", function(discountCd)
    self.activity.discountCd = tonumber(discountCd)
    self:setSingleDrawPrice()
    self:setTenDrawPrice()
  end)
  self:registerEvent(Events.CommonActivityLayoutHideEvent, function()
    self.wFloatReward:hide()
  end)
  CommonDataEvents:registerCallBack("TipNeedBackPack", function()
    self.btnLeft:SetTouchable(true)
    self.btnRight:SetTouchable(true)
  end)
end

function GUILuckyLotteryPanel:setSingleDrawPrice()
  local priceConfig = LuckyLotteryPriceConfig:getPriceConfigByGroupId(self.activity.priceGroupId)
  local config = priceConfig[1]
  if not config then
    return
  end
  self.siLeftOffBg:SetVisible(false)
  self.siLeftCoolDownIcon:SetVisible(false)
  self.stLeftBtnValue:SetText("")
  self.stLeftBtnPrice:SetText(config.price)
  self.stLeftBtnTopText:SetText(Lang:getString(config.priceLang))
  if not self.activity.discountCd then
    return
  end
  if config.price > config.discountPrice and self.activity.discountCd <= 0 then
    self.siLeftOffBg:SetVisible(true)
    self.stLeftOffValue:SetText(math.ceil(config.discountPrice / config.price * 100) .. "%")
    self.stLeftBtnValue:SetText(config.price)
    self.stLeftBtnPrice:SetText(config.discountPrice)
    self.stLeftBtnValue:SetWidth({
      0,
      self.stLeftBtnValue:GetFont():GetTextExtent(config.price, 1)
    })
  elseif config.price > config.discountPrice and self.activity.discountCd > 0 then
    self.siLeftCoolDownIcon:SetVisible(true)
    self.stLeftBtnValue:SetWidth({0, 0})
    LuaTimer:cancel(self.LeftBtnKey)
    self.stLeftBtnCoolDownText:SetText(DateUtil.getFormatTime(self.activity.discountCd))
    self.LeftBtnKey = LuaTimer:scheduleTimer(function()
      self.activity.discountCd = self.activity.discountCd - 1
      if self.activity.discountCd <= 0 then
        self.siLeftCoolDownIcon:SetVisible(false)
        self.siLeftOffBg:SetVisible(true)
        self.stLeftOffValue:SetText(math.ceil(config.discountPrice / config.price * 100) .. "%")
        self.stLeftBtnValue:SetText(config.price)
        self.stLeftBtnPrice:SetText(config.discountPrice)
        self.stLeftBtnValue:SetWidth({
          0,
          self.stLeftBtnValue:GetFont():GetTextExtent(config.price, 1)
        })
        GUICommonActivityLayout:checkRedPoint(self.activity.id)
      else
        self.stLeftBtnCoolDownText:SetText(DateUtil.getFormatTime(self.activity.discountCd))
      end
    end, 1000, self.activity.discountCd + 1)
    self:addTimer(self.LeftBtnKey)
  end
end

function GUILuckyLotteryPanel:setTenDrawPrice()
  local priceConfig = LuckyLotteryPriceConfig:getPriceConfigByGroupId(self.activity.priceGroupId)
  local config = priceConfig[2]
  if not config then
    return
  end
  self.stRightBtnValue:SetText("")
  self.stRightBtnPrice:SetText(config.discountPrice)
  self.stRightBtnTopText:SetText(Lang:getString(config.priceLang))
  if config.price > config.discountPrice then
    self.stRightBtnValue:SetText(config.price)
    self.stRightBtnValue:SetWidth({
      0,
      self.stRightBtnValue:GetFont():GetTextExtent(config.price, 1)
    })
  else
    self.stRightBtnValue:SetWidth({0, 0})
  end
end

function GUILuckyLotteryPanel:initList(groupId)
  local rewardGroup = CommonActivityRewardConfig:getRewardGroupById(groupId)
  if not rewardGroup then
    return
  end
  self.lvRewardList = IGUIListView.new("LuckyTurntablePanel-Reward-List-" .. groupId, self.llRewardRange, nil)
  self.lvRewardList:setArea({0, 0}, {0, 0}, {0, 420}, {0, 390})
  self.lvRewardList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
  self.lvRewardList.root:SetVerticalAlignment(VerticalAlignment.Bottom)
  self.lvRewardList.root:SetClipChild(false)
  self.llRewardRange:SetClipChild(true)
  local container = GUIManager:createGUIWindow(GUIType.Layout, "LuckyTurntablePanel-Reward-List-Container-" .. groupId)
  local row = 1
  if #rewardGroup % 4 == 0 then
    row = #rewardGroup / 4
  else
    row = math.floor(#rewardGroup / 4) + 1
  end
  local size = (self.lvRewardList.root:GetPixelSize().x - 30) / 4
  local space = 22
  container:SetWidth({
    0,
    self.lvRewardList.root:GetPixelSize().x
  })
  container:SetHeight({
    0,
    row * size + (row - 1) * space
  })
  self.lvRewardList.root:AddItem(container)
  for _, reward in pairs(rewardGroup) do
    local count = container:GetChildCount()
    local rewardItem = GUICommonActivityRewardItem.new(self)
    rewardItem:setRewardData(reward.reward)
    rewardItem:setArea({
      0,
      (size + 10) * (count % 4)
    }, {
      0,
      (size + 8) * math.floor(count / 4)
    }, {0, size}, {0, size})
    rewardItem:SetEffectMask("set:common_activity.json image:img_9_mask_lucky")
    container:AddChildWindow(rewardItem.root)
  end
end

function GUILuckyLotteryPanel:clickItem(item)
  self.wFloatReward:showReward(item.reward, item.root)
  CommonActivityReportUtil.reportLuckLotteryItemClick(item.reward.rewardId)
end

function GUILuckyLotteryPanel:setLuckValue(luckyValue)
  self.activity.luckyValue = luckyValue
  local stars = LuckyValueConfig:getStarsByLuckyValue(luckyValue)
  self.stLuckyValue:SetText(luckyValue)
  if stars == 0 then
    self.siLuckyStart1:SetImage("set:game_activity.json image:img_0_lucky02")
    self.siLuckyStart2:SetImage("set:game_activity.json image:img_0_lucky02")
    self.siLuckyStart3:SetImage("set:game_activity.json image:img_0_lucky02")
  elseif stars == 1 then
    self.siLuckyStart1:SetImage("set:game_activity.json image:img_0_lucky03")
    self.siLuckyStart2:SetImage("set:game_activity.json image:img_0_lucky02")
    self.siLuckyStart3:SetImage("set:game_activity.json image:img_0_lucky02")
  elseif stars == 2 then
    self.siLuckyStart1:SetImage("set:game_activity.json image:img_0_lucky03")
    self.siLuckyStart2:SetImage("set:game_activity.json image:img_0_lucky03")
    self.siLuckyStart3:SetImage("set:game_activity.json image:img_0_lucky02")
  elseif stars == 3 then
    self.siLuckyStart1:SetImage("set:game_activity.json image:img_0_lucky03")
    self.siLuckyStart2:SetImage("set:game_activity.json image:img_0_lucky03")
    self.siLuckyStart3:SetImage("set:game_activity.json image:img_0_lucky03")
  end
end

function GUILuckyLotteryPanel:onLottery(type)
  local priceConfigGroup = LuckyLotteryPriceConfig:getPriceConfigByGroupId(self.activity.priceGroupId)
  local priceConfig = priceConfigGroup[type]
  local realPrice = LuckyLotteryPriceConfig:getDisCountPrice(self.activity.priceGroupId, type, self.activity.discountCd)
  if self.activity.discountCd ~= nil and self.activity.discountCd <= 0 then
    CommonActivityReportUtil.reportLuckLotteryClick(0.5)
  else
    CommonActivityReportUtil.reportLuckLotteryClick(type)
  end
  PayHelper.checkMoney(priceConfig.moneyType, realPrice, function(success)
    if success then
      self.lotteryTimer = LuaTimer:schedule(function()
        self.btnLeft:SetTouchable(true)
        self.btnRight:SetTouchable(true)
      end, 8000)
      self:addTimer(self.lotteryTimer)
      local data = {}
      data.activityId = self.activity.id
      data.type = type
      self.btnLeft:SetTouchable(false)
      self.btnRight:SetTouchable(false)
      PacketSender:sendLuaCommonData("LuckyLottery", json.encode(data))
    end
  end)
end

function GUILuckyLotteryPanel:showLotteryResult(data)
  LuaTimer:cancel(self.lotteryTimer)
  if tonumber(data.discountCd) >= 0 then
    self.activity.discountCd = data.discountCd
  end
  self.activity.lotteryTimes = data.lotteryTimes
  self:setLuckValue(data.luckyValue)
  self:setSingleDrawPrice()
  self:setTenDrawPrice()
  self.btnLeft:SetTouchable(true)
  self.btnRight:SetTouchable(true)
  local priceConfig = LuckyLotteryPriceConfig:getPriceConfigByGroupId(self.activity.priceGroupId)
  local config = priceConfig[tonumber(data.type)]
  if not config then
    return
  end
  if data.results and #data.results > 1 then
    local specialReward = {
      type = "extra",
      image = "",
      quality = "lucky",
      numLang = tostring(#data.results)
    }
    table.insert(data.results, specialReward)
  end
  CommonActivityShowReward.builder().setRewardView(data.results).setLeftButton("common.activity.tip.tryAgain", config.moneyImage, config.price).setRightButton("common.activity.sure").setLeftClickListener(function()
    self:onLottery(data.type)
  end).show()
end

function GUILuckyLotteryPanel:isNeedRedPoint()
  local isShowRed = false
  local priceConfig = LuckyLotteryPriceConfig:getPriceConfigByGroupId(self.activity.priceGroupId)
  local config = priceConfig[1]
  if config ~= nil and self.activity.discountCd ~= nil and config.price > config.discountPrice and self.activity.discountCd <= 0 then
    isShowRed = true
  end
  local chestGroup = CommonActivityChestConfig:getChestGroupById(self.activity.chestGroupId)
  local getChest = StringUtil.split(self.activity.getChest or "", ",", false, true)
  if chestGroup then
    for _, chest in pairs(chestGroup.chests) do
      if self.activity.lotteryTimes >= chest.times and not TableUtil.tableContain(getChest, chest.chestId) then
        isShowRed = true
        break
      end
    end
  end
  return isShowRed
end

return GUILuckyLotteryPanel

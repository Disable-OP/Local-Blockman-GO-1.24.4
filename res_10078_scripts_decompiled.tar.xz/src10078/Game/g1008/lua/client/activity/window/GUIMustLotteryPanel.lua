require("client.activity.window.GUIMustLotteryItem")
require("client.activity.window.GUICommonActivityRewardFloat")
GUIMustLotteryPanel = class("GUIMustLotteryPanel", GUICommonActivityPanel)

function GUIMustLotteryPanel:ctor(json_name, ...)
  self.json_name = json_name
  self.super.ctor(self, "GameMustLotteryPanel.json", ...)
end

function GUIMustLotteryPanel:onChildLoad()
  self.items = {}
  self.deletes = {}
  local name = self.json_name:gsub(".json", "-")
  self.tvTime = self:getChildWindowByName(name .. "Time", GUIType.StaticText)
  self.btnHelp = self:getChildWindowByName(name .. "Help", GUIType.Button)
  self.llRewards = self:getChildWindowByName(name .. "Rewards", GUIType.Layout)
  self.llCenter = self:getChildWindowByName(name .. "Center", GUIType.Layout)
  self.llLotteryPanel = self:getChildWindowByName(name .. "Lottery-Panel", GUIType.Layout)
  self.ivLotteryPriceIcon = self:getChildWindowByName(name .. "Lottery-Price-Icon", GUIType.StaticImage)
  self.tvLotteryOldPrice = self:getChildWindowByName(name .. "Lottery-Old-Price", GUIType.StaticText)
  self.llLotteryOldPriceLine = self:getChildWindowByName(name .. "Lottery-Old-Price-Line", GUIType.Layout)
  self.tvLotteryNewPrice = self:getChildWindowByName(name .. "Lottery-New-Price", GUIType.StaticText)
  self.llLotteryDiscountHint = self:getChildWindowByName(name .. "Lottery-Discount-Hint", GUIType.Layout)
  self.tvLotteryDiscountText = self:getChildWindowByName(name .. "Lottery-Discount-Text", GUIType.StaticText)
  self.btnLottery = self:getChildWindowByName(name .. "Lottery", GUIType.Button)
  self.btnLotteryText = self:getChildWindowByName(name .. "Lottery-Text", GUIType.StaticText)
  self.tvLotteryDiscountTimes = self:getChildWindowByName(name .. "Lottery-Discount-Times", GUIType.StaticText)
  self.llDeletePanel = self:getChildWindowByName(name .. "Delete-Panel", GUIType.Layout)
  self.tvDeleteHint = self:getChildWindowByName(name .. "Delete-Hint", GUIType.StaticText)
  self.btnDelete = self:getChildWindowByName(name .. "Delete", GUIType.Button)
  self.btnDeleteText = self:getChildWindowByName(name .. "Delete-Text", GUIType.StaticText)
  self.tvCenterHint = self:getChildWindowByName(name .. "Center-Hint", GUIType.StaticText)
  self.tvDeleteHint:SetText(string.format(Lang:getString("must.lottery.delete.hint"), #self.deletes))
  self.btnLotteryText:SetText(Lang:getString("common.activity.lottery"))
  self.btnDeleteText:SetText(Lang:getString("common.activity.delete"))
  self.tvCenterHint:SetText(Lang:getString("must.lottery.center.hint"))
  self:showCenterWindow(self.llDeletePanel)
  self.btnHelp:registerEvent(GUIEvent.ButtonClick, function()
    GUICommonActivityTextDialog:showText("must.lottery.info.title", "must.lottery.info.text")
  end)
  self.btnDelete:registerEvent(GUIEvent.ButtonClick, function()
    self:tryClickDelete()
  end)
  self.btnLottery:registerEvent(GUIEvent.ButtonClick, function()
    self:tryClickLottery()
  end)
  CommonDataEvents:registerCallBack("MustLotteryDelete", function(data)
    if self.activity.id ~= tonumber(data.activityId) then
      return
    end
    self:onMustLotteryDelete(data)
  end, JsonBuilderProcessor)
  CommonDataEvents:registerCallBack("MustLotteryResult", function(data)
    if self.activity.id ~= tonumber(data.activityId) then
      return
    end
    self:onMustLotteryResult(data)
  end, JsonBuilderProcessor)
  self.wFloatReward = GUICommonActivityRewardFloat.new()
  self.root:AddChildWindow(self.wFloatReward.root)
  self:registerEvent(Events.CommonActivityLayoutHideEvent, function()
    self.wFloatReward:hide()
  end)
  CommonDataEvents:registerCallBack("TipNeedBackPack", function()
    self.btnLottery:SetTouchable(true)
  end)
end

function GUIMustLotteryPanel:showCenterWindow(window)
  self.llLotteryPanel:SetVisible(self.llLotteryPanel == window)
  self.llDeletePanel:SetVisible(self.llDeletePanel == window)
  self.tvCenterHint:SetVisible(self.tvCenterHint == window)
end

function GUIMustLotteryPanel:onShow()
  self.wFloatReward:hide()
  if self.isInit then
    return
  end
  self.isInit = true
  local group = CommonActivityRewardConfig:getRewardGroupById(self.activity.rewardGroupId)
  if not group then
    return
  end
  local spaceY = 31
  local spaceX = 11
  local row = 3
  local col = 4
  local width = (self.llRewards:GetPixelSize().x - spaceX * (col - 1)) / col
  local height = (self.llRewards:GetPixelSize().y - spaceY * (row - 1)) / row
  local offsetInfo = {
    {0, 0},
    {1, 0},
    {2, 0},
    {3, 0},
    {3, 1},
    {3, 2},
    {2, 2},
    {1, 2},
    {0, 2},
    {0, 1}
  }
  local curIndex = 1
  for index = 1, 12 do
    local data = group[curIndex]
    if index ~= 6 and index ~= 7 and data then
      local xPos = offsetInfo[curIndex][1] * (width + spaceX)
      local yPos = offsetInfo[curIndex][2] * (height + spaceY)
      local item = GUIMustLotteryItem.new("GameMustLotteryItem.json", self)
      item:setArea({0, xPos}, {0, yPos}, {0, width}, {0, height})
      item:onDataChanged(data)
      if self:isGetItem(item.groupSeq) then
        item:setGet()
      end
      self.llRewards:AddChildWindow(item.root)
      table.insert(self.items, item)
      curIndex = curIndex + 1
    end
  end
  self:onMustLotteryDelete({
    activityId = self.activity.id,
    deleteSeq = self.activity.deleteSeq
  })
  if self:isAllRewardGet() then
    self:showCenterWindow(self.tvCenterHint)
  else
    self:updatePriceUI()
  end
end

function GUIMustLotteryPanel:isDeleteFinished()
  if not self.activity.deleteSeq then
    return false
  end
  local deleteCount = 0
  local deleteSeq = StringUtil.split(self.activity.deleteSeq or "", ",", false, true)
  for _, item in pairs(self.items) do
    if TableUtil.tableContain(deleteSeq, item.groupSeq) then
      deleteCount = deleteCount + 1
    end
  end
  return 2 <= deleteCount
end

function GUIMustLotteryPanel:isDeleteItem(groupSeq)
  local deleteSeq = StringUtil.split(self.activity.deleteSeq or "", ",")
  return TableUtil.tableContain(deleteSeq, tostring(groupSeq))
end

function GUIMustLotteryPanel:isGetItem(groupSeq)
  local getSeq = StringUtil.split(self.activity.getSeq or "", ",")
  return TableUtil.tableContain(getSeq, tostring(groupSeq))
end

function GUIMustLotteryPanel:selectItem(item)
  if self:isDeleteFinished() then
    return
  end
  if item.isGrandPrize then
    return
  end
  if TableUtil.tableContain(self.deletes, item) then
    TableUtil.tableRemove(self.deletes, item)
    item:setSelected(false)
  else
    if #self.deletes >= 2 then
      GUICommonActivityLayout:showTip("must.lottery.delete.full")
      return
    end
    table.insert(self.deletes, item)
    item:setSelected(true)
  end
  self.tvDeleteHint:SetText(string.format(Lang:getString("must.lottery.delete.hint"), #self.deletes))
end

function GUIMustLotteryPanel:clickItem(item)
  self.wFloatReward:showReward(item.reward, item.root)
  CommonActivityReportUtil.reportMustLotteryItemClick(item.reward.rewardId)
end

function GUIMustLotteryPanel:tryClickDelete()
  if self.activity.lastTime == 0 then
    return
  end
  if self:isDeleteFinished() then
    self:showCenterWindow(self.llLotteryPanel)
    return
  end
  if #self.deletes < 2 then
    GUICommonActivityLayout:showTip("must.lottery.delete.less")
    return
  end
  local data = {}
  local deleteList = {}
  data.activityId = self.activity.id
  local deleteSeq = {}
  for _, delete in pairs(self.deletes) do
    table.insert(deleteSeq, delete.groupSeq)
    table.insert(deleteList, delete.reward.rewardId)
  end
  data.deleteSeq = table.concat(deleteSeq, ",")
  CommonActivityRewardPreview.builder().setCenterTip(Lang:getString("must.lottery.delete.sure")).setRewardView(deleteList).setSureClickListener(function()
    PacketSender:sendLuaCommonData("MustLotteryDelete", json.encode(data))
  end).show()
end

function GUIMustLotteryPanel:onMustLotteryDelete(data)
  self.activity.deleteSeq = data.deleteSeq
  if not self:isDeleteFinished() then
    self:showCenterWindow(self.llDeletePanel)
    return
  end
  for _, item in pairs(self.items) do
    item:setDelete(self:isDeleteItem(item.groupSeq))
  end
  self:showCenterWindow(self.llLotteryPanel)
  self:updatePriceUI()
end

function GUIMustLotteryPanel:isAllRewardGet()
  local allSeq = {}
  local deleteSeq = StringUtil.split(self.activity.deleteSeq, ",", false, true)
  local getSeq = StringUtil.split(self.activity.getSeq, ",", false, true)
  TableUtil.mergeArray(getSeq, deleteSeq, allSeq)
  local isAllGet = true
  for _, item in pairs(self.items) do
    if not TableUtil.tableContain(allSeq, item.groupSeq) then
      isAllGet = false
      break
    end
  end
  return isAllGet
end

function GUIMustLotteryPanel:tryClickLottery()
  if self.activity.lastTime == 0 then
    return
  end
  if not self:isDeleteFinished() then
    self:showCenterWindow(self.llDeletePanel)
    return
  end
  if self:isAllRewardGet() then
    self:showCenterWindow(self.tvCenterHint)
    return
  end
  local config = self:getCurrentPrice()
  if not config then
    return
  end
  PayHelper.checkMoney(config.moneyType, config.discountPrice, function(success)
    if success then
      self.lotteryTimer = LuaTimer:schedule(function()
        self.btnLottery:SetTouchable(true)
      end, 8000)
      self:addTimer(self.lotteryTimer)
      local data = {}
      data.activityId = self.activity.id
      self.btnLottery:SetTouchable(false)
      PacketSender:sendLuaCommonData("MustLotteryDoLottery", json.encode(data))
    end
  end)
end

function GUIMustLotteryPanel:onMustLotteryResult(data)
  LuaTimer:cancel(self.lotteryTimer)
  
  local function doShowResult()
    self.btnLottery:SetTouchable(true)
    for _, item in pairs(self.items) do
      if item.groupSeq == data.groupSeq then
        item:setGet()
        CommonActivityShowReward.builder().setRewardView({
          {
            rewardId = data.rewardId,
            isGrandPrize = item.isGrandPrize
          }
        }).setHideLeftButton().setRightButton("common.activity.sure").show()
        break
      end
    end
    if self:isAllRewardGet() then
      self:showCenterWindow(self.tvCenterHint)
    else
      self:updatePriceUI()
    end
  end
  
  local items = self.items
  for _, item in pairs(self.items) do
    item:setEffect(false)
    if self:isGetItem(item.groupSeq) then
      item:setGet()
    end
  end
  self.activity.getSeq = self.activity.getSeq .. "," .. data.groupSeq
  local selectPos = #items
  for pos, item in pairs(items) do
    if item.groupSeq == data.groupSeq then
      selectPos = pos
    end
  end
  local times = #items * 8 + selectPos
  local curPos = 0
  local curTimes = 0
  local period = 30
  local round = -4
  LuaTimer:cancel(self.animTimer)
  self.animTimer = LuaTimer:scheduleTimerWithEnd(function()
    curPos = curPos + 1
    curTimes = curTimes + 1
    for pos, item in pairs(items) do
      item:setEffect(pos == curPos)
    end
    if times - curTimes < 5 then
      period = period + 50
      LuaTimer:resetTimer(self.animTimer, nil, period)
    end
    if curPos >= #items then
      curPos = 0
      round = round + 1
      period = period + 25 * math.max(round, 0)
      LuaTimer:resetTimer(self.animTimer, nil, period)
    end
  end, function()
    for _, item in pairs(items) do
      item:setEffect(item.groupSeq == data.groupSeq)
    end
    self.animTimer = LuaTimer:schedule(function()
      self.animTimer = nil
      doShowResult()
      self.activity.lotteryTimes = data.lotteryTimes
    end, 1000)
    self:addTimer(self.animTimer)
  end, period, times)
  self:addTimer(self.animTimer)
end

function GUIMustLotteryPanel:getCurrentPrice()
  local getSeq = StringUtil.split(self.activity.getSeq, ",", false, true)
  TableUtil.tableRemove(getSeq, 0)
  local config = MustLotteryPriceConfig:getPriceConfig(self.activity.priceGroupId, #getSeq + 1)
  return config
end

function GUIMustLotteryPanel:updatePriceUI()
  local config = self:getCurrentPrice()
  if not config then
    return
  end
  self.tvLotteryOldPrice:SetText(config.price)
  self.tvLotteryDiscountTimes:SetText(Lang:getString(config.hintLang))
  if config.price == config.discountPrice then
    self.tvLotteryNewPrice:SetVisible(false)
    self.llLotteryDiscountHint:SetVisible(false)
    self.llLotteryOldPriceLine:SetVisible(false)
    local offset = self.tvLotteryOldPrice:GetFont():GetTextExtent(tostring(config.price), 1) + 5
    self.ivLotteryPriceIcon:SetXPosition({
      0,
      -offset / 2
    })
  else
    self.tvLotteryNewPrice:SetVisible(true)
    self.llLotteryDiscountHint:SetVisible(true)
    self.llLotteryOldPriceLine:SetVisible(true)
    self.tvLotteryNewPrice:SetText(config.discountPrice)
    local offset = self.tvLotteryOldPrice:GetFont():GetTextExtent(tostring(config.price), 1) + self.tvLotteryNewPrice:GetFont():GetTextExtent(tostring(config.discountPrice), 1) + 13
    self.ivLotteryPriceIcon:SetXPosition({
      0,
      -offset / 2
    })
    local discount = math.floor((config.price - config.discountPrice) * 100 / config.price)
    self.tvLotteryDiscountText:SetText("-" .. discount .. "%")
    self.tvLotteryNewPrice:SetVisible(true)
    self.llLotteryDiscountHint:SetVisible(true)
  end
end

function GUIMustLotteryPanel:isNeedRedPoint()
  local isShowRed = false
  local chestGroup = CommonActivityChestConfig:getChestGroupById(self.activity.chestGroupId)
  local getChest = StringUtil.split(self.activity.getChest or "", ",", false, true)
  if chestGroup then
    for _, chest in pairs(chestGroup.chests) do
      if self.activity.lotteryTimes >= chest.times and not TableUtil.tableContain(getChest, chest.chestId) then
        isShowRed = true
        break
      end
    end
  end
  return isShowRed
end

return GUIMustLotteryPanel

GUICommonActivityRewardFloat = class("GUICommonActivityRewardFloat", IGUIWindow)

function GUICommonActivityRewardFloat:ctor(...)
  self.super.ctor(self, "GameActivityRewardFloat.json", ...)
end

function GUICommonActivityRewardFloat:onLoad()
  self.llContent = self:getChildWindowByName("CommonActivityRewardFloat-Content", GUIType.Layout)
  self.llBackImage = self:getChildWindowByName("CommonActivityRewardFloat-Item-BG", GUIType.Layout)
  self.llBackLayout = self:getChildWindowByName("CommonActivityRewardFloat-BackImage", GUIType.Layout)
  self.llBackLine = self:getChildWindowByName("CommonActivityRewardFloat-Line", GUIType.StaticText)
  self.ivImage = self:getChildWindowByName("CommonActivityRewardFloat-Image", GUIType.StaticImage)
  self.tvCount = self:getChildWindowByName("CommonActivityRewardFloat-Count", GUIType.StaticText)
  self.tvName = self:getChildWindowByName("CommonActivityRewardFloat-Name", GUIType.StaticText)
  self.tvDesc = self:getChildWindowByName("CommonActivityRewardFloat-Desc", GUIType.StaticText)
  self.btnClose = self:getChildWindowByName("CommonActivityRewardFloat-Close", GUIType.Button)
  self:hide()
  self.root:registerEvent(GUIEvent.Click, function(events)
    self:hide()
    Game:handleTouchClick(events.position.x, events.position.y)
  end)
  self.btnClose:registerEvent(GUIEvent.ButtonClick, function(events)
    self:hide()
  end)
end

function GUICommonActivityRewardFloat:showReward(reward, window)
  self.root:SetVisible(true)
  self.llBackLayout:SetVisible(true)
  self.llBackLine:SetVisible(true)
  self.tvDesc:SetArea({0, 0}, {0, -10}, {1, -30}, {1, -120})
  self:setIcon(reward)
  self.tvName:SetText(Lang:getString(reward.name))
  self.tvDesc:SetText(Lang:getString(reward.desc))
  if reward.numLang ~= "#" then
    self.tvCount:SetText(Lang:getString(reward.numLang))
  else
    self.tvCount:SetText("")
  end
  self.llBackImage:SetBackImage("set:game_activity.json image:img_0_grade_" .. reward.quality)
  if window then
    local area1 = window:GetUnclippedOuterRect()
    local area2 = self.root:GetParent():GetUnclippedOuterRect()
    local centerX = area1[1] - area2[1] + (area1[3] - area1[1]) / 2
    local centerY = area1[2] - area2[2] + (area1[4] - area1[2]) / 2
    self.llContent:SetXPosition({0, centerX})
    self.llContent:SetYPosition({
      0,
      centerY - self.llContent:GetPixelSize().y
    })
  end
end

function GUICommonActivityRewardFloat:showDesc(desc, window)
  self.root:SetVisible(true)
  self.llBackLayout:SetVisible(false)
  self.llBackLine:SetVisible(false)
  self.tvDesc:SetArea({0, 0}, {0, -10}, {1, -40}, {1, -40})
  self.tvDesc:SetText(Lang:getString(desc))
  if window then
    local area1 = window:GetUnclippedOuterRect()
    local area2 = self.root:GetParent():GetUnclippedOuterRect()
    local centerX = area1[1] - area2[1] + (area1[3] - area1[1]) / 2
    local centerY = area1[2] - area2[2] + (area1[4] - area1[2]) / 2
    self.llContent:SetXPosition({0, centerX})
    self.llContent:SetYPosition({
      0,
      centerY - self.llContent:GetPixelSize().y
    })
  end
end

function GUICommonActivityRewardFloat:hide()
  self.root:SetVisible(false)
end

function GUICommonActivityRewardFloat:setIcon(reward)
  if reward.imageScale and reward.imageScale ~= "#" then
    UIHelper:setImageAdjustSize(self.ivImage, reward.image, 55, 55, reward.imageScale)
  else
    UIHelper:setImageAdjustSize(self.ivImage, reward.image, 55, 55)
  end
  if reward.imageXOffset ~= "#" then
    self.ivImage:SetXPosition({
      0,
      reward.imageXOffset
    })
  end
  if reward.imageYOffset ~= "#" then
    self.ivImage:SetYPosition({
      0,
      reward.imageYOffset
    })
  end
end

return GUICommonActivityRewardFloat

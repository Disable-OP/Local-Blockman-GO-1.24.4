GUICommonActivityRewardItem = class("GUICommonActivityRewardItem", IGUIWindow)

function GUICommonActivityRewardItem:ctor(...)
  self.super.ctor(self, "GameActivityRewardItem.json", ...)
end

function GUICommonActivityRewardItem:onLoad(parent)
  self.parent = parent
  self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
  self.ivIcon = self:getChildWindowByName("CommonActivityRewardItem-Icon", GUIType.StaticImage)
  self.ivBg = self:getChildWindowByName("CommonActivityRewardItem-Bg", GUIType.StaticImage)
  self.ivMask = self:getChildWindowByName("CommonActivityRewardItem-Mask", GUIType.StaticImage)
  self.ivSelect = self:getChildWindowByName("CommonActivityRewardItem-Select", GUIType.StaticImage)
  self.llEffectClip = self:getChildWindowByName("CommonActivityRewardItem-Effect-Clip", GUIType.Layout)
  self.ivEffect = self:getChildWindowByName("CommonActivityRewardItem-Effect", GUIType.StaticImage)
  self.ivEffectMask = self:getChildWindowByName("CommonActivityRewardItem-Effect-Mask", GUIType.StaticImage)
  self.tvNum = self:getChildWindowByName("CommonActivityRewardItem-Num", GUIType.StaticText)
  self.tvName = self:getChildWindowByName("CommonActivityRewardItem-Name", GUIType.StaticText)
  self.llRoot:registerEvent(GUIEvent.Click, function()
    if self.parent then
      self.parent:clickItem(self)
    end
  end)
  self.ivMask:SetVisible(false)
  self.ivSelect:SetVisible(false)
  self.ivEffect:SetVisible(false)
  self.llEffectClip:SetVisible(false)
end

function GUICommonActivityRewardItem:setRewardData(data, anim)
  self:SetIcon(data)
  if data.needMask then
    self.ivMask:SetImage("set:game_activity.json image:img_0_mask_" .. data.quality)
    self.ivMask:SetVisible(true)
  end
  self.reward = data
  if data.numLang ~= "#" then
    self.tvNum:SetText(Lang:getString(data.numLang))
  end
  if data.effect ~= "#" then
    self.ivEffect:SetEffectName(data.effect)
    self.ivEffect:SetVisible(true)
  end
  self.ivBg:SetImage("set:game_activity.json image:img_0_grade_" .. data.quality)
  if anim then
    self:showAnim(data)
  end
end

function GUICommonActivityRewardItem:showAnim(data)
  local scale = 0
  self.ivIcon:SetArea({0, 0}, {0, 0}, {scale, 0}, {scale, 0})
  self.ivBg:SetArea({0, 0}, {0, 0}, {
    scale * 1.6,
    0
  }, {
    scale * 1.6,
    0
  })
  self.ivMask:SetArea({0, 0}, {0, 0}, {
    scale * 1.6,
    0
  }, {
    scale * 1.6,
    0
  })
  self.llEffectClip:SetArea({0, 0}, {0, 0}, {scale, 0}, {scale, 0})
  self:addTimer(LuaTimer:scheduleTimer(function()
    scale = scale + 0.05
    self.ivIcon:SetArea({0, 0}, {0, 0}, {
      math.min(scale, 0.8),
      0
    }, {
      math.min(scale, 0.8),
      0
    })
    self.ivBg:SetArea({0, 0}, {0, 0}, {
      scale * 1.6,
      0
    }, {
      scale * 1.6,
      0
    })
    self.ivMask:SetArea({0, 0}, {0, 0}, {
      scale * 1.6,
      0
    }, {
      scale * 1.6,
      0
    })
    self.llEffectClip:SetArea({0, 0}, {0, 0}, {scale, 0}, {scale, 0})
    self:SetIcon(data)
  end, 8, 20))
end

function GUICommonActivityRewardItem:setLotteryResult(data)
  if data.effect ~= "#" then
    self.ivEffect:SetEffectName(data.effect)
  end
  if data.needMask then
    self.ivMask:SetImage("set:game_activity.json image:img_0_mask_" .. data.quality)
    self.ivMask:SetVisible(true)
  end
  self.ivEffect:SetVisible(true)
  self:showAnim(data)
  if data.numLang ~= "#" then
    self.tvNum:SetText(Lang:getString(data.numLang))
  end
  self.ivBg:SetImage("set:game_activity.json image:img_0_grade_" .. data.quality)
end

function GUICommonActivityRewardItem:setLuckyValue(data)
  local scale = 0
  self.tvName:SetText(Lang:getString("lucky.lottery.ui.luckyValue"))
  self.tvName:SetArea({0, 0}, {-0.35, 0}, {0, 0}, {0, 0})
  self.tvName:SetTextColor({
    1,
    0.8509803921568627,
    0.30196078431372547,
    1
  })
  self.ivBg:SetArea({0, 0}, {0, 0}, {
    scale * 1.6,
    0
  }, {
    scale * 1.6,
    0
  })
  self.ivEffect:SetArea({0, 0}, {
    -(scale / 2),
    0
  }, {scale, 0}, {scale, 0})
  self:addTimer(LuaTimer:scheduleTimer(function()
    self.ivIcon:SetArea({0, 0}, {0, 0}, {
      math.min(scale, 0.9),
      0
    }, {
      math.min(scale, 0.9),
      0
    })
    self.ivBg:SetArea({0, 0}, {0, 0}, {
      scale * 1.6,
      0
    }, {
      scale * 1.6,
      0
    })
    self.ivEffectMask:SetArea({0, 0}, {0, 0}, {scale, 0}, {scale, 0})
    self.ivEffect:SetArea({0, 0}, {
      -(scale / 2),
      0
    }, {scale, 0}, {scale, 0})
    scale = scale + 0.05
    self:SetIcon(data)
  end, 8, 20))
  if data.numLang ~= "#" then
    self.tvNum:SetText(Lang:getString(data.numLang))
  end
  self.ivBg:SetImage("set:game_activity.json image:img_0_grade_" .. data.quality)
end

function GUICommonActivityRewardItem:onSelect(isSelect)
  self.ivSelect:SetVisible(isSelect)
end

function GUICommonActivityRewardItem:SetIcon(data)
  if data.imageScale and data.imageScale ~= "#" then
    UIHelper:setImageAdjustSize(self.ivIcon, data.image, self.ivIcon:GetPixelSize().x, self.ivIcon:GetPixelSize().y, data.imageScale)
  else
    UIHelper:setImageAdjustSize(self.ivIcon, data.image)
  end
  if data.imageXOffset ~= "#" then
    self.ivIcon:SetXPosition({
      0,
      data.imageXOffset
    })
  end
  if data.imageYOffset ~= "#" then
    self.ivIcon:SetYPosition({
      0,
      data.imageYOffset
    })
  end
end

function GUICommonActivityRewardItem:SetEffectMask(image)
end

return GUICommonActivityRewardItem

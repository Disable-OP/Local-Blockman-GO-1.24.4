GUICommonActivityTab = class("GUICommonActivityTab", IGUIWindow)
local TextColor = {
  Normal = {
    0.7019607843137254,
    0.6901960784313725,
    0.9450980392156862,
    1
  },
  Select = {
    0.15294117647058825,
    0.17647058823529413,
    0.3607843137254902,
    1
  }
}

function GUICommonActivityTab:onLoad()
  self.ivSelected = self:getChildWindowByName("CommonActivityTab-Selected", GUIType.StaticImage)
  self.ivSelected:SetVisible(false)
  self.ivRedPoint = self:getChildWindowByName("CommonActivityTab-Red-Point", GUIType.StaticImage)
  self.ivRedPoint:SetVisible(false)
  self.ivText = self:getChildWindowByName("CommonActivityTab-Text", GUIType.StaticText)
  self.ivTextLine = self:getChildWindowByName("CommonActivityTab-Line", GUIType.Layout)
  self.btnClick = self:getChildWindowByName("CommonActivityTab-Click", GUIType.Button)
  self.btnClick:registerEvent(GUIEvent.ButtonClick, function()
    CommonActivityReportUtil.reportClickTab(self.activityType, self.activityId)
    GUICommonActivityLayout:showActivity(self.activityId)
  end)
end

function GUICommonActivityTab:onDataChanged(activity)
  self.activityType = activity.type
  self.activityId = activity.id
  self.ivText:SetText(Lang:getString(activity.tabLang))
end

function GUICommonActivityTab:setSelected(selected)
  self.ivSelected:SetVisible(selected)
  if selected then
    self:setRedPoint(false)
    self.ivText:SetTextColor(TextColor.Select)
    self.ivTextLine:SetBackgroundColor({
      1,
      1,
      1,
      0
    })
    self.ivText:SetFont(GUIFontManager:Instance():GetFont("HT20"))
  else
    self.ivText:SetTextColor(TextColor.Normal)
    self.ivTextLine:SetBackgroundColor(TextColor.Normal)
    self.ivText:SetFont(GUIFontManager:Instance():GetFont("HT18"))
  end
  self.btnClick:SetTouchable(not selected)
end

function GUICommonActivityTab:isSelected()
  return self.ivSelected:IsVisible()
end

function GUICommonActivityTab:setRedPoint(isShowRed)
  self.ivRedPoint:SetVisible(isShowRed)
  GUICommonActivityMain:checkTabsRedPoint()
end

function GUICommonActivityTab:isHaveRedPoint()
  return self.ivRedPoint:IsVisible()
end

return GUICommonActivityTab

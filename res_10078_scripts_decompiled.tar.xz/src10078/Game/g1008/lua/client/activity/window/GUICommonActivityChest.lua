GUICommonActivityChest = class("GUICommonActivityChests", IGUIWindow)
local TimesTextColor = {
  Normal = {
    1,
    1,
    1,
    1
  },
  Open = {
    0.9764705882352941,
    0.807843137254902,
    0.24705882352941178,
    1
  }
}

function GUICommonActivityChest:ctor(...)
  self.super.ctor(self, "GameActivityChest.json", ...)
end

function GUICommonActivityChest:onLoad(activity)
  self.activity = activity
  self.ivLight = self:getChildWindowByName("CommonActivityChest-Light", GUIType.StaticImage)
  self.ivImage = self:getChildWindowByName("CommonActivityChest-Image", GUIType.StaticImage)
  self.llTimes = self:getChildWindowByName("CommonActivityChest-Times", GUIType.Layout)
  self.tvTimesText = self:getChildWindowByName("CommonActivityChest-Times-Text", GUIType.StaticText)
  self.root:registerEvent(GUIEvent.Click, function()
    CommonActivityReportUtil.reportRewardChestClick(self.activity.id, self.data.chestId)
    self:onClickChest()
  end)
end

function GUICommonActivityChest:onDataChanged(data)
  self.data = data
  UIHelper:setImageAdjustSize(self.ivImage, data.normalImage, 70, 70)
  self.tvTimesText:SetText(string.format(Lang:getString("common.activity.times"), data.times))
  self:updateChest()
end

function GUICommonActivityChest:onClickChest()
  if self.activity.lotteryTimes >= self.data.times then
    local getChest = StringUtil.split(self.activity.getChest, ",", false, true)
    if TableUtil.tableContain(getChest, self.data.chestId) then
      local tipStr = Lang:getString("common.activity.reward.hadReceive")
      self:showRewardPreview(self.data.chestId, tipStr, "common.activity.reward.title.hadReceive")
    else
      local data = {
        activityId = self.activity.id,
        chestId = self.data.chestId
      }
      PacketSender:sendLuaCommonData("CommonActivityOpenChest", json.encode(data))
    end
  else
    local tipStr = string.format(Lang:getString("common.activity.reward.preview"), self.activity.lotteryTimes, tonumber(self.data.times) - tonumber(self.activity.lotteryTimes))
    self:showRewardPreview(self.data.chestId, tipStr, "common.activity.reward.preview.title")
  end
end

function GUICommonActivityChest:showRewardPreview(chestId, tipStr, title)
  local chest = CommonActivityChestConfig:getChestById(chestId)
  if not chest then
    return
  end
  CommonActivityRewardPreview.builder().setRewardViewByGroupId(chest.rewardGroupId).setTopTip(tipStr).setTitleText(title).setRewardLayoutYPos({0, 20}).show()
end

function GUICommonActivityChest:updateChest()
  if self.activity.lotteryTimes >= self.data.times then
    local getChest = StringUtil.split(self.activity.getChest, ",", false, true)
    if TableUtil.tableContain(getChest, self.data.chestId) then
      self.ivLight:SetVisible(false)
      self.tvTimesText:SetTextColor(TimesTextColor.Open)
      UIHelper:setImageAdjustSize(self.ivImage, "set:game_activity.json image:img_0_treasure_chest02", 62, 48)
    else
      self.ivLight:SetVisible(true)
      self.tvTimesText:SetTextColor(TimesTextColor.Open)
      UIHelper:setImageAdjustSize(self.ivImage, "set:game_activity.json image:img_0_treasure_chest01", 62, 48)
    end
  else
    self.ivLight:SetVisible(false)
    self.tvTimesText:SetTextColor(TimesTextColor.Normal)
    UIHelper:setImageAdjustSize(self.ivImage, "set:game_activity.json image:img_0_treasure_chest01", 62, 48)
  end
end

return GUICommonActivityChest

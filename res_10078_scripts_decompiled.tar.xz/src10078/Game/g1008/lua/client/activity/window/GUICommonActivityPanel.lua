require("client.activity.window.GUICommonActivityChestGroup")
GUICommonActivityPanel = class("GUICommonActivityPanel", IGUIWindow)

local function safeSetUI(window, key, ...)
  if window and window[key] then
    window[key](window, ...)
  end
end

function GUICommonActivityPanel:onLoad(activity)
  local name = self.json_name:gsub(".json", "-")
  self.tvTitle = self:getChildWindowByName(name .. "Title", GUIType.StaticText)
  self.tvTitle1 = self:getChildWindowByName(name .. "Title_c", GUIType.StaticText)
  self.tvTitle2 = self:getChildWindowByName(name .. "Title_c_c", GUIType.StaticText)
  if not Root.getFPS then
    self.tvTitle1:SetYPosition({0, -15})
  end
  self.tvTime = self:getChildWindowByName(name .. "Time", GUIType.StaticText)
  self.tvDesc = self:getChildWindowByName(name .. "Desc", GUIType.StaticText)
  self.awActor = self:getChildWindowByName(name .. "Actor", GUIType.ActorWindow)
  self.ivImage = self:getChildWindowByName(name .. "Image", GUIType.StaticImage)
  self.ivImageBox = self:getChildWindowByName(name .. "Image-Box", GUIType.StaticImage)
  self.tvPrice = self:getChildWindowByName(name .. "Price", GUIType.StaticText)
  self.ivPriceIcon = self:getChildWindowByName(name .. "Price-Icon", GUIType.StaticImage)
  self.tvName = self:getChildWindowByName(name .. "Name", GUIType.StaticText)
  self.activity = activity
  self.root = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
  self.root:SetVisible(false)
  safeSetUI(self.tvTitle, "SetText", Lang:getString(activity.titleLang))
  safeSetUI(self.tvTitle1, "SetText", Lang:getString(activity.titleLang))
  safeSetUI(self.tvTitle2, "SetText", Lang:getString(activity.titleLang))
  safeSetUI(self.tvDesc, "SetText", Lang:getString(activity.descLang))
  self.root:SetWidth({1, 0})
  self.root:SetHeight({1, 0})
  self:onChildLoad()
  self:showRewardDetail(activity)
  self:addTimer(LuaTimer:scheduleTimer(function()
    self:onSecondTick()
  end, 1000))
  local llSlideBlock = self:getChildWindowByName(name .. "Actor-Slide-Block", GUIType.Layout)
  safeSetUI(llSlideBlock, "registerEvent", GUIEvent.TouchDown, function(events)
    safeSetUI(self.awActor, "TouchDown", events.position)
  end)
  safeSetUI(llSlideBlock, "registerEvent", GUIEvent.TouchMove, function(events)
    safeSetUI(self.awActor, "TouchMove", events.position)
  end)
  if CommonActivityChestConfig:getChestGroupById(self.activity.chestGroupId) then
    self.wChestGroup = GUICommonActivityChestGroup.new(activity, self)
  end
end

function GUICommonActivityPanel:onSecondTick()
  if not self.activity.lastTime or self.activity.lastTime <= 0 then
    return
  end
  self.activity.lastTime = self.activity.lastTime - 1
  if self.activity.lastTime >= DateUtil.getDaySeconds() then
    local text = string.format(Lang:getString("common.activity.day"), tostring(math.floor(self.activity.lastTime / DateUtil.getDaySeconds())))
    safeSetUI(self.tvTime, "SetText", text)
  else
    safeSetUI(self.tvTime, "SetText", DateUtil.getFormatTime(self.activity.lastTime))
  end
end

function GUICommonActivityPanel:showRewardDetail(activity)
  local reward = CommonActivityRewardConfig:getRewardById(activity.mainRewardId)
  if not reward then
    return
  end
  safeSetUI(self.tvName, "SetText", Lang:getString(reward.name))
  if reward.priceIcon and #reward.priceIcon > 0 then
    if reward.price == -1 then
      safeSetUI(self.ivPriceIcon, "SetImage", "")
      safeSetUI(self.tvPrice, "SetText", "")
    else
      safeSetUI(self.ivPriceIcon, "SetImage", reward.priceIcon)
      safeSetUI(self.tvPrice, "SetText", tostring(reward.price))
      if self.tvPrice then
        local extent = self.tvPrice:GetFont():GetTextExtent(tostring(reward.price), 1)
        safeSetUI(self.ivPriceIcon, "SetXPosition", {
          -0.5,
          -extent / 2
        })
      end
    end
  else
    safeSetUI(self.ivPriceIcon, "SetImage", "")
  end
  if activity.actor and #activity.actor > 7 then
    local pos
    if self.awActor and self.awActor.GetPosition then
      pos = self.awActor:GetPosition()
    end
    safeSetUI(self.ivImage, "SetVisible", false)
    safeSetUI(self.awActor, "SetXPosition", {
      pos.x[1],
      activity.actorXOffset
    })
    safeSetUI(self.awActor, "SetYPosition", {
      pos.y[1],
      activity.actorYOffset
    })
    safeSetUI(self.awActor, "SetWidth", {
      0,
      activity.actorScale
    })
    safeSetUI(self.awActor, "SetActor1", activity.actor, "idle")
    safeSetUI(self.awActor, "SetRotateY", activity.actorRotate)
    for index, actorBody in pairs(activity.actorBody) do
      if activity.actorBodyId[index] then
        safeSetUI(self.awActor, "UseBodyPart", actorBody or "body", activity.actorBodyId[index] or "")
      end
    end
  else
    safeSetUI(self.awActor, "RemoveActor")
    safeSetUI(self.ivImage, "SetVisible", true)
    if activity.imageBox and #activity.imageBox > 10 then
      safeSetUI(self.ivImageBox, "SetImage", activity.imageBox)
    else
      safeSetUI(self.ivImageBox, "SetImage", "")
    end
    if activity.mainRewardImage and 10 < #activity.mainRewardImage then
      UIHelper:setImageAdjustSize(self.ivImage, activity.mainRewardImage, 250, 250)
    else
      safeSetUI(self.ivImage, "SetImage", "")
    end
  end
  GUICommonActivityLayout:checkRedPoint(activity.id)
end

function GUICommonActivityPanel:isNeedRedPoint()
  return false
end

function GUICommonActivityPanel:onChildLoad()
end

function GUICommonActivityPanel:onShow()
end

function GUICommonActivityPanel:isShow()
  return self.root:IsVisible()
end

function GUICommonActivityPanel:onTick()
  if self.wChestGroup then
    self.wChestGroup:onTick()
  end
end

return GUICommonActivityPanel

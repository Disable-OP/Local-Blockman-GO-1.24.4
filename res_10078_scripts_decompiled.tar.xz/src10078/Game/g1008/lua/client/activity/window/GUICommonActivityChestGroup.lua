require("client.activity.window.GUICommonActivityChest")
GUICommonActivityChestGroup = class("GUICommonActivityChestGroup", IGUIWindow)

function GUICommonActivityChestGroup:ctor(...)
  self.super.ctor(self, "GameActivityChestGroup.json", ...)
end

function GUICommonActivityChestGroup:onLoad(activity, parent)
  self.activity = activity
  self.root:SetLevel(51)
  self.root:SetHorizontalAlignment(HorizontalAlignment.Right)
  self.root:SetXPosition({0, -21})
  self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
  self.tvTitle = self:getChildWindowByName("CommonActivityChestGroup-Title", GUIType.StaticText)
  self.tvTimes = self:getChildWindowByName("CommonActivityChestGroup-Times", GUIType.StaticText)
  local llLayout = self:getChildWindowByName("CommonActivityChestGroup-Chests", GUIType.Layout)
  self.lvChests = IGUIListView.new("CommonActivityChestGroup-Chests-List-" .. self.windowId, llLayout)
  local group = CommonActivityChestConfig:getChestGroupById(self.activity.chestGroupId)
  self.lvChests.root:SetClipChild(false)
  for _, chest in pairs(group.chests) do
    local item = GUICommonActivityChest.new(activity)
    item:onDataChanged(chest)
    self.lvChests:addItem(item)
  end
  self.lvChests.root:SetYPosition({0, 4})
  local maxHeight = parent.root:GetPixelSize().y
  local height = math.min(#group.chests * 92 + 78, maxHeight)
  self.root:SetHeight({0, height})
  parent.root:AddChildWindow(self.root)
  self.tvTitle:SetText(Lang:getString("common.activity.chest.reward"))
  self:registerDataCallBack("CommonActivityOpenChestResult", function(data)
    if data.activityId ~= self.activity.id then
      return
    end
    self.activity.getChest = self.activity.getChest .. "," .. data.chestId
    self:updateChests()
    local chest = CommonActivityChestConfig:getChestById(data.chestId)
    if not chest then
      return
    end
    CommonActivityShowReward.builder().setRewardGroup(chest.rewardGroupId).setHideLeftButton().setRightButton("common.activity.sure").show()
  end, JsonBuilderProcessor)
  self:registerDataCallBack("CommonActivityRefreshChest", function(data)
    if data.activityId ~= self.activity.id then
      return
    end
    self.activity.getChest = data.getChest
    self.activity.lotteryTimes = data.lotteryTimes
    self:updateChests()
  end, JsonBuilderProcessor)
end

function GUICommonActivityChestGroup:onTick()
  self.tvTimes:SetText(string.format(Lang:getString("common.activity.times"), "\226\150\162FFFFED7C" .. (self.activity.lotteryTimes or 0)))
  if self.updateLotteryTimes ~= self.activity.lotteryTimes then
    self:updateChests()
  end
end

function GUICommonActivityChestGroup:updateChests()
  for _, item in pairs(self.lvChests.items) do
    item:updateChest()
  end
  self.updateLotteryTimes = self.activity.lotteryTimes
  GUICommonActivityLayout:checkRedPoint(self.activity.id)
end

return GUICommonActivityChestGroup

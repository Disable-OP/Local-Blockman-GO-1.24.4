local function updateBlindBox()
  if not GUIBlindBoxLayout or TableUtil.isEmpty(GUIBlindBoxLayout.items) then
    LuaTimer:schedule(function()
      updateBlindBox()
    end, 50)
    return
  end
  local layout = GUIManager:getWindowByName("BlindBoxLayout-Content", GUIType.Layout)
  layout:SetBackImage("set:game_activity_bg.json image:img_0_board")
  local item1 = GUIBlindBoxLayout.items[4]
  item1.btnQuestion:SetXPosition({0, -25})
  item1.btnQuestion:SetYPosition({0, 65})
  item1.btnOpen:SetYPosition({0, -95})
  item1.tvTimeOrTimes:SetYPosition({0.98, 0})
  item1.ivWorthIcon:SetYPosition({0.9, 0})
  item1.tvName:SetYPosition({0.84, 0})
  item1.tvName:SetFont(GUIFontManager:Instance():GetFont("HT14"))
  local item2 = GUIBlindBoxLayout.items[5]
  item2.btnQuestion:SetYPosition({0, 25})
  item2.btnOpen:SetXPosition({0, 10})
  item2.btnOpen:SetYPosition({0, -95})
  item2.tvTimeOrTimes:SetYPosition({0.98, 0})
  item2.ivWorthIcon:SetYPosition({0.9, 0})
  item2.tvName:SetYPosition({0.84, 0})
  item2.tvName:SetFont(GUIFontManager:Instance():GetFont("HT14"))
  local item3 = GUIBlindBoxLayout.items[6]
  item3.btnQuestion:SetXPosition({0, -30})
  item3.btnQuestion:SetYPosition({0, 30})
  item3.btnOpen:SetXPosition({0, 30})
  item3.btnOpen:SetYPosition({0, -95})
  item3.tvTimeOrTimes:SetYPosition({0.98, 0})
  item3.ivWorthIcon:SetYPosition({0.9, 0})
  item3.tvName:SetYPosition({0.84, 0})
  item3.tvName:SetFont(GUIFontManager:Instance():GetFont("HT14"))
  local btnHelp = GUIManager:getWindowByName("BlindBoxLayout-Help", GUIType.Button)
  btnHelp:SetNormalImage("set:game_activity.json image:btn_0_description")
  btnHelp:SetPushedImage("set:game_activity.json image:btn_0_description")
  local tvHint = GUIManager:getWindowByName("BlindBoxLayout-Hint", GUIType.StaticText)
  tvHint:SetYPosition({0, -10})
  tvHint:SetTextVertAlign(VerticalAlignment.Bottom)
  tvHint:SetTextColor(Color.WHITE)
  local tvTitle = GUIManager:getWindowByName("BlindBoxLayout-Title", GUIType.StaticText)
  tvTitle:SetTextColor(Color.WHITE)
  tvTitle:SetProperty("EnableTextColorRect", "false")
  local llTime = GUIManager:getWindowByName("BlindBoxLayout-Time-Layout", GUIType.Layout)
  llTime:SetArea({0, -30}, {0, -10}, {0, 160}, {0, 38})
  llTime:SetBackImage("set:game_activity.json image:img_9_resources")
  local ivClose = GUIManager:getWindowByName("BlindBoxLayout-Close", GUIType.StaticImage)
  ivClose:SetImage("set:game_activity.json image:btn_0_close02")
  ivClose:SetArea({0, 40}, {0, -10}, {0, 35}, {0, 35})
  GUIBlindBoxLayout.root:SetBackgroundColor({
    0,
    0,
    0,
    0.8
  })
end

local function initClientUI(setting)
  GUIImagesetManager.Instance():CreateFromFile("game_activity.json")
  GUIImagesetManager.Instance():CreateFromFile("game_activity_bg.json")
  local UICommonActivityMain = require("client.activity.layout.GUICommonActivityMain")
  if not Game:isEnableIndie() or setting.IndieParentUI == nil then
    GUICommonActivityMain = UICommonActivityMain.new("GameActivityMain.json", GUIManager:getMainControl())
    UIHelper:setLayoutUIBySetting(GUICommonActivityMain, setting.MainUI)
  else
    GUICommonActivityMain = UICommonActivityMain.new("GameActivityMain.json", GUIManager:getWindowByName(setting.IndieParentUI))
    if setting.IndieMainUI ~= nil then
      UIHelper:setLayoutUIBySetting(GUICommonActivityMain, setting.IndieMainUI)
    else
      UIHelper:setLayoutUIBySetting(GUICommonActivityMain, setting.MainUI)
    end
  end
  local UICommonActivityLayout = require("client.activity.layout.GUICommonActivityLayout")
  GUICommonActivityLayout = UICommonActivityLayout.new("GameActivityLayout.json")
  GUICommonActivityLayout:hide(true)
  UIHelper:setLayoutUIBySetting(GUICommonActivityLayout, setting.LayoutUI)
  GUICommonActivityLayout:setAlwaysOnTop(true)
  LuaTimer:schedule(function()
    local UICommonActivityTextDialog = require("client.activity.layout.GUICommonActivityTextDialog")
    GUICommonActivityTextDialog = UICommonActivityTextDialog.new("GameActivityTextDialog.json")
    GUICommonActivityTextDialog:setAlwaysOnTop(true)
    GUICommonActivityTextDialog:hide()
    require("client.activity.layout.GUICommonActivityShowReward")
    initCommonActivityShowReward()
    CommonActivityShowReward.setAlwaysOnTop(true)
    require("client.activity.layout.GUICommonActivityRewardPreview")
    initCommonActivityRewardPreview()
    CommonActivityRewardPreview.setAlwaysOnTop(true)
    local UICommonActivityGrandPrize = require("client.activity.layout.GUICommonActivityGrandPrize")
    GUICommonActivityGrandPrize = UICommonActivityGrandPrize.new("GameActivityGrandPrize.json")
    GUICommonActivityGrandPrize:setAlwaysOnTop(true)
    GUICommonActivityGrandPrize:hide()
  end, 20)
end

local ShowRule = {
  None = 0,
  EveryDayFirst = 1,
  EveryLogin = 2
}
local CurrentActivityList = {}
local CommonActivityInfo = {isInit = false, setting = nil}
local BlindBoxInfo = {
  isInit = false,
  setting = nil,
  enable = false,
  lastTime = 0,
  dayLastTime = 0,
  blindBoxIds = ""
}

function CommonActivity:init(setting)
  require("engine_client.util.CommonActivityReportUtil")
  CommonActivityInfo.setting = setting
  initClientUI(setting)
  updateBlindBox()
  CurrentActivityList = {}
  CommonDataEvents:registerCallBack("SyncCommonActivity", function(data)
    for _, item in pairs(data) do
      local activity = CommonActivityConfig:getActivityById(item.id)
      if activity then
        for key, value in pairs(item) do
          activity[key] = value
        end
        self:addActivity(activity)
      end
    end
  end, JsonBuilderProcessor)
  CommonDataEvents:registerCallBack("AddCommonActivity", function(data)
    local activity = CommonActivityConfig:getActivityById(data.id)
    if activity then
      for key, value in pairs(data) do
        activity[key] = value
      end
      self:addActivity(activity)
    end
  end, JsonBuilderProcessor)
  CommonDataEvents:registerCallBack("RemoveCommonActivity", function(data)
    local activity = CommonActivityConfig:getActivityById(data.activityId)
    if activity then
      self:removeActivity(activity)
    end
  end, JsonBuilderProcessor)
end

function CommonActivity:addActivity(activity)
  table.insert(CurrentActivityList, activity)
  GUICommonActivityLayout:addActivity(activity)
  if CommonActivityInfo.isInit then
    return
  end
  CommonActivityInfo.isInit = true
  if CommonActivityInfo.setting.ShowRule == ShowRule.EveryLogin then
    GUIManager:addShowQueue(GUICommonActivityLayout)
  end
  if CommonActivityInfo.setting.ShowRule == ShowRule.EveryDayFirst then
    local day = tostring(DateUtil.getYearDay())
    local key = Game.GameType .. "-CommonActivityShowDay-" .. tostring(Game:getPlatformUserId())
    if ClientHelper.getStringForKey(key) ~= day then
      ClientHelper.putStringForKey(key, day)
      GUIManager:addShowQueue(GUICommonActivityLayout)
    end
  end
end

function CommonActivity:removeActivity(activity)
  TableUtil.tableRemove(CurrentActivityList, activity)
  GUICommonActivityLayout:removeActivity(activity)
  GUICommonActivityMain:checkRedPoint()
end

function CommonActivity:getCurrentActivityList()
  return CurrentActivityList
end

function CommonActivity:getCurrentActivityById(activityId)
  for _, activity in pairs(CurrentActivityList) do
    if activity.id == activityId then
      return activity
    end
  end
  return nil
end

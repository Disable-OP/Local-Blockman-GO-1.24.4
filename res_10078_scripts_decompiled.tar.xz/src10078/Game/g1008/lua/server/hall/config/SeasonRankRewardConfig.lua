SeasonRankRewardConfig = {}
SeasonRankRewardConfig.SeasonRankRewards = {}

function SeasonRankRewardConfig:initConfig(rewards)
  for _, reward in pairs(rewards) do
    local data = {}
    data.Id = reward.Id
    data.SeasonId = tonumber(reward.SeasonId)
    local RankRange = StringUtil.split(reward.RankRange, "#")
    data.MinRank = 0
    data.MaxRank = 0
    if #RankRange == 1 then
      data.MinRank = tonumber(RankRange[1])
      data.MaxRank = tonumber(RankRange[1])
    end
    if #RankRange == 2 then
      data.MinRank = tonumber(RankRange[1])
      data.MaxRank = tonumber(RankRange[2])
    end
    data.Reward = RewardConfig:getRewardById(tonumber(reward.RewardId))
    table.insert(self.SeasonRankRewards, data)
  end
end

function SeasonRankRewardConfig:getRewardBySeasonIdAndRank(seasonId, rank)
  for _, reward in pairs(self.SeasonRankRewards) do
    if reward.SeasonId == seasonId and rank >= reward.MinRank and rank <= reward.MaxRank then
      return reward.Reward
    end
  end
end

return SeasonRankRewardConfig

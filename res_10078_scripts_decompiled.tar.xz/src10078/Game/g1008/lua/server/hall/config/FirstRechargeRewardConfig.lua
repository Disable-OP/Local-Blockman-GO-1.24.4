FirstRechargeRewardConfig = {}
FirstRechargeRewardConfig.Rewards = {}

function FirstRechargeRewardConfig:initConfig(rewards)
  for _, reward in pairs(rewards) do
    table.insert(self.Rewards, RewardConfig:getRewardById(tonumber(reward.RewardId)))
  end
end

return FirstRechargeRewardConfig

RuneTroughConfig = {}
RuneTroughConfig.Trough = {}
RuneTroughConfig.AOT_DEFAULT = 0
RuneTroughConfig.AOT_PRO = 1
RuneTroughConfig.AOT_RUNE_LIST = 2

function RuneTroughConfig:initConfig(trough)
  for _, config in pairs(trough) do
    local curTrough = {}
    curTrough.Id = tonumber(config.Id)
    curTrough.Type = tonumber(config.Type)
    curTrough.Level = tonumber(config.Level)
    table.insert(self.Trough, curTrough)
  end
  table.sort(self.Trough, function(a, b)
    return a.Id < b.Id
  end)
end

function RuneTroughConfig:getAllTrough()
  return self.Trough
end

function RuneTroughConfig:getTrough(id)
  for _, config in pairs(RuneTroughConfig.Trough) do
    if config.Id == id then
      return config
    end
  end
  return nil
end

function RuneTroughConfig:getTroughLock(id, level)
  for _, config in pairs(RuneTroughConfig.Trough) do
    if config.Id == id and level >= config.Level then
      return false
    end
  end
  return true
end

function RuneTroughConfig:getFirstUnlockTroughType(level)
  if level then
    for _, config in pairs(RuneTroughConfig.Trough) do
      if level == config.Level then
        return config.Type
      end
    end
  end
  return 1
end

function RuneTroughConfig:getTroughTypeById(troughId)
  for _, config in pairs(RuneTroughConfig.Trough) do
    if config.Id == troughId then
      return config.Type
    end
  end
  return 1
end

return RuneTroughConfig

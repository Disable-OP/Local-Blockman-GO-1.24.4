DailySignInConfig = {}
DailySignInConfig.Items = {}
DailySignInConfig.Status = {
  Finished = 1,
  SignInAgain = 2,
  WaitSignInAgain = 3,
  SignIn = 4,
  WaitSignIn = 5
}

function DailySignInConfig:initConfig(config)
  for _, item in pairs(config) do
    table.insert(self.Items, {
      Id = tonumber(item.Id),
      PriceType = tonumber(item.PriceType),
      Price = tonumber(item.Price),
      Reward = RewardConfig:getRewardById(tonumber(item.RewardId))
    })
  end
  table.sort(self.Items, function(a, b)
    return a.Id < b.Id
  end)
end

function DailySignInConfig:getConfigById(id)
  for day, config in pairs(self.Items) do
    if config.Id == id then
      return config, day
    end
  end
  return nil, 100
end

return DailySignInConfig

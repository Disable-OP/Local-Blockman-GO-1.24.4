SeasonConfig = {}
SeasonConfig.Seasons = {}

function SeasonConfig:initConfig(seasons)
  for _, season in pairs(seasons) do
    local data = {}
    data.Id = tonumber(season.Id)
    data.HonorId = tonumber(season.HonorId)
    data.UpRewards = RewardConfig:getRewardByIds(season.UpRewardIds)
    data.NormalRewards = RewardConfig:getRewardByIds(season.NormalRewardIds)
    table.insert(self.Seasons, data)
  end
end

function SeasonConfig:getSeasonByHonorId(honorId)
  for _, season in pairs(SeasonConfig.Seasons) do
    if season.HonorId == honorId then
      return season
    end
  end
end

return SeasonConfig

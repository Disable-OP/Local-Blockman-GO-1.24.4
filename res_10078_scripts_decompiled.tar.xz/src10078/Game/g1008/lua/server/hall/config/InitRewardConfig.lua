InitRewardConfig = {}
InitRewardConfig.Rewards = {}

function InitRewardConfig:initConfig(rewards)
  for _, config in pairs(rewards) do
    table.insert(self.Rewards, {
      Id = tonumber(config.Id),
      Reward = RewardConfig:getRewardById(tonumber(config.RewardId))
    })
  end
end

function InitRewardConfig:initPlayer(player)
  if not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  if player.init_reward_finished then
    return
  end
  player.init_reward_finished = true
  for _, reward in pairs(self.Rewards) do
    GameReward:onPlayerGetReward(player, reward.Reward)
  end
end

return InitRewardConfig

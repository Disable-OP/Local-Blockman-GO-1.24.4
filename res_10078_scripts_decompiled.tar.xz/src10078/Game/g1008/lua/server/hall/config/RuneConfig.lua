RuneConfig = {}
RuneConfig.Rune = {}

function RuneConfig:initConfig(runeConfig)
  for _, config in pairs(runeConfig) do
    local curRune = {}
    curRune.Id = tonumber(config.Id)
    curRune.Type = tonumber(config.Type)
    curRune.Level = tonumber(config.Level)
    curRune.Weight = tonumber(config.Weight)
    curRune.SellKey = tonumber(config.SellKey)
    curRune.canSell = tonumber(config.canSell)
    table.insert(self.Rune, curRune)
  end
end

function RuneConfig:getTrough(id)
  for _, config in pairs(RuneConfig.Rune) do
    if config.Id == id then
      return config
    end
  end
  return nil
end

function RuneConfig:getParam(id)
  for _, config in pairs(RuneConfig.Rune) do
    if config.Id == id then
      return config.Param1, config.Param2
    end
  end
  return nil, nil
end

return RuneConfig

SuperPlayerRewardConfig = {}
SuperPlayerRewardConfig.Rewards = {}

function SuperPlayerRewardConfig:initConfig(rewards)
  for _, reward in pairs(rewards) do
    table.insert(self.Rewards, {
      Type = tonumber(reward.Type),
      Reward = RewardConfig:getRewardById(tonumber(reward.RewardId))
    })
  end
end

function SuperPlayerRewardConfig:getAwayRewards()
  local rewards = {}
  for _, reward in pairs(self.Rewards) do
    if reward.Type == 1 then
      table.insert(rewards, reward.Reward)
    end
  end
  return rewards
end

function SuperPlayerRewardConfig:getDailyRewards()
  local rewards = {}
  for _, reward in pairs(self.Rewards) do
    if reward.Type == 2 then
      table.insert(rewards, reward.Reward)
    end
  end
  return rewards
end

return SuperPlayerRewardConfig

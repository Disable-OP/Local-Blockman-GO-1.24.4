TiroSignInConfig = {}
TiroSignInConfig.Items = {}
TiroSignInConfig.Status = {
  Received = 1,
  WaitReceived = 2,
  CantReceived = 3
}

function TiroSignInConfig:initConfig(config)
  for _, item in pairs(config) do
    table.insert(self.Items, {
      Id = tonumber(item.Id),
      Reward = RewardConfig:getRewardById(tonumber(item.RewardId))
    })
  end
  table.sort(self.Items, function(a, b)
    return a.Id < b.Id
  end)
end

return TiroSignInConfig

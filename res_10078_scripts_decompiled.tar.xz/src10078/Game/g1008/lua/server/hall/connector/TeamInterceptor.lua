local TeamInterceptor = class("TeamInterceptor", require("engine_base.connector.IConnectorMsgInterceptor"))
local ConnectorInterceptor = T(Global, "ConnectorInterceptor")
local Game2ConnectorMsgType = {CreateTeam = 20001}
local MaxMemberSetting = {
  g1008 = 4,
  g1061 = 8,
  g1062 = 2
}

function TeamInterceptor:init()
  self.range = {20000, 29999}
end

function TeamInterceptor:initMsgFunc()
  self:registerMsgFunc(Game2ConnectorMsgType.CreateTeam, self.onCreateTeam)
end

function TeamInterceptor:onCreateTeam(_, _, data)
  data = json.decode(data)
  data.maxMember = MaxMemberSetting[data.gameType] or 4
  return json.encode(data)
end

ConnectorInterceptor:registerInterceptor(T(Global, "TeamInterceptor", TeamInterceptor.new()))

WatchADHelper = {}

function WatchADHelper:init()
  local refreshTime
  if DateUtil.getDayLastTime(os.time(), true) - os.time() > 86400 - 3600 * GameConfig.taskRefreshTime then
    refreshTime = DateUtil.getDayLastTime(os.time(), true) + 3600 * GameConfig.taskRefreshTime - 86400 - os.time()
  else
    refreshTime = DateUtil.getDayLastTime(os.time(), true) + 3600 * GameConfig.taskRefreshTime - os.time()
  end
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    self:synWatchAdData(player)
  end
  LuaTimer:cancel(self.dailyKey or 0)
  self.dailyKey = LuaTimer:schedule(function()
    self:init()
  end, refreshTime * 1000)
end

function WatchADHelper:synWatchAdData(player)
  if tonumber(player.free_gift_refresh_time) < tonumber(DateUtil.getYearDay()) then
    for _, gift in pairs(player.free_gift) do
      local giftConfig = FreeGiftConfig:getGiftById(gift.Id)
      gift.Times = giftConfig and giftConfig.Times or 0
      player.get_free_ticket_times = -1
    end
    player.free_gift_refresh_time = DateUtil.getYearDay()
  end
  GamePacketSender:sendFreeGiftData(player.rakssid, json.encode(player.free_gift))
  GamePacketSender:sendCubeStoreGetTicketTimes(player.rakssid, player.get_free_ticket_times)
end

function WatchADHelper:onPlayerGetFreeGift(player, id)
  local hadWatch = false
  local config = FreeGiftConfig:getGiftById(id)
  if not config then
    return
  end
  for _, gift in pairs(player.free_gift) do
    if gift.Id == id then
      if gift.Times == 0 then
        return
      end
      if gift.CDEndTime > os.time() + 3 then
        return
      end
      gift.Times = gift.Times - 1
      gift.CDEndTime = os.time() + config.CD
      hadWatch = true
    end
  end
  if not hadWatch then
    local data = {}
    data.Id = id
    data.Times = config.Times - 1
    data.CDEndTime = os.time() + config.CD
    table.insert(player.free_gift, data)
  end
  local rewardConfig = RewardConfig:getRewardById(config.RewardId)
  if not rewardConfig then
    return
  end
  if rewardConfig.RewardType ~= Define.RewardType.CUSTOM_SHOP then
    local Reward = {
      RewardId = rewardConfig.RewardId,
      Count = rewardConfig.Count,
      RewardType = rewardConfig.RewardType,
      Time = rewardConfig.Time,
      RedressRewardId = rewardConfig.RedressRewardId
    }
    GameReward:onPlayerGetReward(player, Reward)
  end
  GamePacketSender:sendGetFreeGiftReward(player.rakssid, id)
end

function WatchADHelper:onGetCubeStoreFreeTicket(player, params)
  local goods = StoreConfig:getGoodsById(tonumber(params))
  if player.get_free_ticket_times == -1 then
    player.get_free_ticket_times = goods.Price
  end
  if player.get_free_ticket_times < 1 then
    return
  end
  player.get_free_ticket_times = player.get_free_ticket_times - 1
  player:addTicket(goods.Count)
  LuaTimer:schedule(function()
    CommonPacketSender:sendBuyGoodsSuccess(player.rakssid, goods.Id)
    GamePacketSender:sendCubeStoreGetTicketTimes(player.rakssid, player.get_free_ticket_times)
  end, 100)
end

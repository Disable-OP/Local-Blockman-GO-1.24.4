function GMHelper:cleanYaoShi(player)
  player.yaoshi = 0
  
  player:syncHallInfo()
end

function GMHelper:addMovieTicket(player)
  player:addTicket(1000)
end

function GMHelper:resetADTimes(player)
  player.free_upgrade_time = tostring(0)
  GameLicense:updatePlayerData(player)
  player.free_gift_refresh_time = tostring(0)
  WatchADHelper:synWatchAdData(player)
  player.challenge_ad = true
  TreasureChallenge:resetTreasureAd(player)
end

function GMHelper:addExp(player)
  local _, is_max = ExpConfig:getMaxExp(player.level)
  if not is_max then
    player:addExp(50)
  end
end

function GMHelper:receiveAdReward(player, type, params)
  CustomListener.onWatchAdvertFinished(player.rakssid, type, params or "", 1)
end

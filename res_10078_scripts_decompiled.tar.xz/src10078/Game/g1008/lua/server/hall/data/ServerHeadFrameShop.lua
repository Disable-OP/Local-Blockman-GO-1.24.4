local HeadFrameShop = T(Global, "HeadFrameShop")
local HeadFrameShopConfig = T(Global, "HeadFrameShopConfig")
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

local function checkPlayerAndHeadFrame(userId, goodsId)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local goods = HeadFrameShopConfig:getShopConfigById(goodsId)
  if not goods then
    return
  end
  return player, goods
end

function HeadFrameShop:init()
  EventObservable:registerDataCallBack("BuyHeadFrame", function(userId, goodsId)
    local player, goods = checkPlayerAndHeadFrame(userId, goodsId)
    if not player then
      return
    end
    HeadFrameShop:onBuyHeadFrame(player, goods)
  end)
  EventObservable:registerDataCallBack("EquipHeadFrame", function(userId, goodsId)
    local player, goods = checkPlayerAndHeadFrame(userId, goodsId)
    if not player then
      return
    end
    HeadFrameShop:onEquipHeadFrame(player, goods)
  end)
end

HeadFrameShop:init()

function HeadFrameShop:onSyncPlayerAllGoods(player)
  if TableUtil.getTableSize(player.headFrameData) > 0 then
    GamePacketSender:sendHeadFrameDataData(player.rakssid, TableUtil.copyTable(player.headFrameData))
  end
end

local function onBuyHeadFrameSuccess(player, goods)
  local reward = RewardConfig:getRewardById(tonumber(goods.RewardId))
  if not reward then
    return
  end
  table.insert(player.headFrameData, reward.RewardId)
  GamePacketSender:sendBuyHeadFrameSuccess(player.rakssid, reward.RewardId)
end

function HeadFrameShop:onBuyHeadFrame(player, goods)
  if goods.Price <= 0 then
    return
  end
  local reward = RewardConfig:getRewardById(tonumber(goods.RewardId))
  if not reward then
    return
  end
  if TableUtil.tableContain(player.headFrameData, reward.RewardId) then
    return
  end
  if not MoneyUtil:checkHasMoney(player, goods.CoinId, goods.Price) then
    return
  end
  PayHelper.payDiamondsSync(player.userId, goods.Id, goods.Price, function()
    onBuyHeadFrameSuccess(player, goods)
    return true
  end)
end

function HeadFrameShop:onEquipHeadFrame(player, goods)
  if goods.Default then
    PlayerCustomInfoUtil:reportCustomInfo(player.userId, "int", Define.PlayerCustomInfo.CurHeadFrame, 0, "2")
    HeadFrameShop:onEquipHeadFrameSuccess(player, 0)
    return
  end
  local reward = RewardConfig:getRewardById(tonumber(goods.RewardId))
  if not reward then
    return
  end
  if not TableUtil.tableContain(player.headFrameData, reward.RewardId) then
    return
  end
  local CurHeadFrame = reward.RewardId
  PlayerCustomInfoUtil:reportCustomInfo(player.userId, "int", Define.PlayerCustomInfo.CurHeadFrame, CurHeadFrame, "2")
  HeadFrameShop:onEquipHeadFrameSuccess(player, CurHeadFrame)
end

function HeadFrameShop:onEquipHeadFrameSuccess(player, frameId)
  GamePacketSender:sendEquipHeadFrameSuccess(player.rakssid, frameId)
end

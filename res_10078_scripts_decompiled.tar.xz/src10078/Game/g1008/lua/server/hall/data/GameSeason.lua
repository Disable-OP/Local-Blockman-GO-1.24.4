GameSeason = {}
GameSeason.UserSeasonInfoCache = {}

function GameSeason:getUserSeasonInfo(userId, isLast, retryTime)
  WebService:GetUserSeasonInfo(userId, isLast, function(data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
      return
    end
    if not data then
      if 0 < retryTime then
        GameSeason:getUserSeasonInfo(userId, isLast, retryTime - 1)
      end
      return
    end
    player.honorId = data.segment
    player.honor = data.integral
    if isLast then
      GameSeason:onGetUserLastSeasonInfo(player, data)
    else
      GameSeason:onGetUserCurrentSeasonInfo(player, data)
    end
  end)
end

function GameSeason:onGetUserCurrentSeasonInfo(player, data)
  local honorId = data.segment
  local rank = data.rank
  local honor = data.integral
  local days = math.floor(data.timeRemains / 86400)
  GameSeason.UserSeasonInfoCache[tostring(player.userId)] = {
    honorId = honorId,
    rank = rank,
    honor = honor
  }
  GamePacketSender:sendBedWarCurrentSeasonInfo(player.rakssid, honorId, rank, honor, days)
  if player.hasReportSeasonRank == false or player.lastReportSeasonRankId == -1 then
    ReportUtil.reportSeasonRank(player)
  end
  if honorId > player.maxHonorId then
    player.maxHonorId = honorId
  end
  if data.needReward == 1 then
    GameSeason:getUserSeasonInfo(player.userId, true, 3)
  end
end

function GameSeason:onGetUserLastSeasonInfo(player, data)
  local honorId = data.segment
  local rank = data.rank
  local honor = data.integral
  GamePacketSender:sendBedWarLastSeasonInfo(player.rakssid, honorId, rank, honor)
  GameSeason:doPlayerSeasonReward(player, honorId, rank)
  WebService:UpdateUserSeasonReward(player.userId)
end

function GameSeason:doPlayerSeasonReward(player, honorId, rank)
  local curHonorId = honorId
  local season_info = GameSeason.UserSeasonInfoCache[tostring(player.userId)]
  if season_info then
    curHonorId = season_info.honorId
  end
  local season = SeasonConfig:getSeasonByHonorId(honorId)
  if not season then
    return
  end
  local rewards = {}
  if honorId < curHonorId then
    rewards = TableUtil.copyTable(season.UpRewards)
  else
    rewards = TableUtil.copyTable(season.NormalRewards)
  end
  local rankReward = SeasonRankRewardConfig:getRewardBySeasonIdAndRank(season.Id, rank)
  if rankReward ~= nil then
    table.insert(rewards, rankReward)
  end
  for _, reward in pairs(rewards) do
    GameReward:onPlayerGetReward(player, reward)
  end
  ReportUtil.reportSeasonRank(player)
end

function GameSeason:onPlayerQuit(player)
  GameSeason.UserSeasonInfoCache[tostring(player.userId)] = nil
end

return GameSeason

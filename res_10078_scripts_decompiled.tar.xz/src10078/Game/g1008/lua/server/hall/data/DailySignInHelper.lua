DailySignInHelper = {}

function DailySignInHelper:initPlayer(player)
  if not player.daily_sign_in_data then
    player.daily_sign_in_data = {
      week_key = 0,
      record = {}
    }
  end
  self:syncDailySignInData(player)
end

function DailySignInHelper:syncDailySignInData(player)
  local key = DateUtil.getYearWeek()
  if player.daily_sign_in_data.week_key ~= key then
    player.daily_sign_in_data.week_key = key
    player.daily_sign_in_data.record = {}
  end
  local data = {}
  local items = DailySignInConfig.Items
  local wday = DateUtil.getWeekDay()
  local hasSignInAgain = false
  for day, config in pairs(items) do
    local item = {
      Id = config.Id
    }
    if day < wday then
      if not player.daily_sign_in_data.record[tostring(config.Id)] then
        if not hasSignInAgain then
          item.Status = DailySignInConfig.Status.SignInAgain
          hasSignInAgain = true
        else
          item.Status = DailySignInConfig.Status.WaitSignInAgain
        end
      else
        item.Status = DailySignInConfig.Status.Finished
      end
    end
    if day == wday then
      if not player.daily_sign_in_data.record[tostring(config.Id)] then
        item.Status = DailySignInConfig.Status.SignIn
      else
        item.Status = DailySignInConfig.Status.Finished
      end
    end
    if day > wday then
      item.Status = DailySignInConfig.Status.WaitSignIn
    end
    table.insert(data, item)
  end
  GamePacketSender:sendBedWarDailySignInData(player.rakssid, json.encode(data))
end

function DailySignInHelper:onPlayerSignIn(player, id)
  if player.daily_sign_in_data.record[tostring(id)] then
    return
  end
  local item, iday = DailySignInConfig:getConfigById(id)
  if item == nil then
    return
  end
  local wday = DateUtil.getWeekDay()
  if iday > wday then
    return
  end
  if iday < wday then
    if not player.daily_sign_in_data.get_first then
      self:onPlayerSignInSuccess(player, id)
    else
      local params = {
        id = item.Id,
        price = item.Price
      }
      local data = DataBuilder.new():fromTable(params):getData()
      GamePacketSender:sendBedWarReissueDailySignIn(player.rakssid, data)
    end
  end
  if iday == wday then
    self:onPlayerSignInSuccess(player, id)
  end
end

function DailySignInHelper:onPlayerConfirmSignInAgain(player, id, useTicket)
  local item = DailySignInConfig:getConfigById(id)
  if item == nil then
    return
  end
  if useTicket and player:subTicket(1) then
    self:onPlayerSignInSuccess(player, id)
    return
  end
  if not MoneyUtil:checkHasMoney(player, item.PriceType, item.Price, 0) then
    if item.PriceType == Define.Money.KEY then
      player:sendPacket({
        pid = "CheckMoneyTip",
        type = item.PriceType,
        price = item.Price
      })
    end
    return
  end
  if item.PriceType == Define.Money.DIAMOND then
    player:consumeDiamonds(40000 + item.Id, item.Price, Define.SignInAgain .. "#" .. item.Id)
  end
  if item.PriceType == Define.Money.KEY then
    player:subYaoShi(item.Price, "key_ConfirmSignInAgain", id)
    self:onPlayerSignInSuccess(player, id)
  end
  if item.PriceType == Define.Money.TICKET and player:subTicket(item.Price) then
    self:onPlayerSignInSuccess(player, id)
  end
end

function DailySignInHelper:onPlayerConfirmSignInAgainLackOfMoney(player, id)
  local item = DailySignInConfig:getConfigById(id)
  if item == nil then
    return
  end
  if not MoneyUtil:checkHasMoney(player, Define.Money.DIAMOND, item.Price, 0) then
    return
  end
  player:consumeDiamonds(50000 + item.Id, item.Price, Define.SignInAgain .. "#" .. item.Id)
end

function DailySignInHelper:onPlayerSignInSuccess(player, id)
  if player.daily_sign_in_data.record[tostring(id)] then
    return
  end
  local item = DailySignInConfig:getConfigById(id)
  if item == nil then
    return
  end
  player.daily_sign_in_data.record[tostring(id)] = true
  player.daily_sign_in_data.get_first = true
  local rewardId = GameReward:onPlayerGetReward(player, item.Reward)
  DailySignInHelper:syncDailySignInData(player)
  if rewardId ~= nil then
    GamePacketSender:sendBedWarRewardResult(player.rakssid, rewardId)
    ReportUtil.reportDailySignIn(player, id)
    return true
  end
end

return DailySignInHelper

GameGuide = {}
GameGuide.Status = {
  UnLock = 0,
  UnTrigger = 1,
  Showed = 2,
  Done = 3
}

function GameGuide:recoverGuide(player, guideData)
  local running_guides = guideData.running_guides or {}
  local finish_ids = guideData.finish_ids or {}
  for _, guide in pairs(running_guides) do
    local config = GuideConfig:getGuideConfigById(guide.Id)
    if config and config.ResetId > 0 and config.ResetId ~= guide.Id then
      if GuideConfig:isGuideFirstOfChain(config.ResetId) then
        table.insert(player.running_guides, {
          Id = config.ResetId,
          Status = self.Status.UnTrigger
        })
      else
        table.insert(player.running_guides, {
          Id = config.ResetId,
          Status = self.Status.Showed
        })
      end
    else
      table.insert(player.running_guides, {
        Id = guide.Id,
        Status = guide.Status
      })
    end
  end
  player.finish_ids = finish_ids
end

function GameGuide:updateStatus(player, guide)
  self:removeGuide(player, guide.Id)
  if guide.Status == self.Status.Done then
    ReportUtil.reportGuide(player, guide.Id)
    self:doEvent(player, guide.Id)
    if GuideConfig:isGuideFirstOfChain(guide.Id) then
      for _, id in pairs(player.finish_ids) do
        if id == guide.Id then
          return
        end
      end
      table.insert(player.finish_ids, guide.Id)
    end
    return
  end
  table.insert(player.running_guides, {
    Id = guide.Id,
    Status = guide.Status
  })
end

function GameGuide:removeGuide(player, guideId)
  for key, guide in pairs(player.running_guides) do
    if guide.Id == guideId then
      table.remove(player.running_guides, key)
      return
    end
  end
end

function GameGuide:doEvent(player, guideId)
  local config = GuideConfig:getEventByGuideId(guideId)
  if config and config.Type == GuideConfig.EventType.FlashTo then
    player:teleportPos({
      x = config.Pos[1],
      y = config.Pos[2],
      z = config.Pos[3]
    })
  end
end

function GameGuide:sendDataToClient(player)
  if not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  local data = {}
  data.lv = player.level
  data.under_way = player.running_guides
  data.done = {}
  for _, id in pairs(player.finish_ids) do
    table.insert(data.done, {Id = id})
  end
  HostApi.sendUpdateGuideData(player.rakssid, json.encode(data))
end

return GameGuide

GameActivity = {}

function GameActivity:initPlayerData(player)
  if player.activity_data == nil then
    player.activity_data = {
      first_recharge = false,
      tiro_sign_in_id = 0,
      tiro_sign_in_key = 0,
      super_player_daily = 0
    }
  end
  GameActivity:syncFirstRechargeData(player)
  GameActivity:syncSuperPlayerData(player)
  GameActivity:syncTiroSignInData(player)
end

function GameActivity:syncFirstRechargeData(player)
  if player.activity_data.first_recharge then
    GamePacketSender:sendBedWarFirstRechargeData(player.rakssid, false, false)
    return
  end
  WebService:HasRecharge(player.userId, function(status)
    if status == 1 then
      GamePacketSender:sendBedWarFirstRechargeData(player.rakssid, true, true)
    end
  end)
end

function GameActivity:receiveFirstRechargeRewards(player)
  if player.activity_data.first_recharge then
    return
  end
  local rewards = FirstRechargeRewardConfig.Rewards
  local ids = GameActivity:doRewards(player, rewards)
  player.activity_data.first_recharge = true
  GameActivity:syncFirstRechargeData(player)
  GamePacketSender:sendBedWarRewardResult(player.rakssid, ids)
end

function GameActivity:syncSuperPlayerData(player)
  WebService:GetUserProps(player.userId, "g1008", function(props)
    local sp
    for _, prop in pairs(props) do
      if prop.propsId == "bed.war.super.player" then
        sp = prop
      end
    end
    if sp == nil then
      GamePacketSender:sendBedWarSuperPlayerData(player.rakssid, 0, false, false)
      return
    end
    sp.remainder = sp.remainder or 0
    sp.times = sp.times or 0
    local days = sp.remainder
    local canGetAway = 0 < sp.times
    local canGetDaily = false
    local key = DateUtil.getYearDay()
    if 0 < days and player.activity_data.super_player_daily ~= key then
      canGetDaily = true
    end
    player.spDays = days
    player.spGetAway = canGetAway
    GamePacketSender:sendBedWarSuperPlayerData(player.rakssid, days, canGetAway, canGetDaily)
  end)
end

local function doSuperPlayerReward(player, times)
  times = times or 0
  local canGetAway = false
  local canGetDaily = false
  local key = DateUtil.getYearDay()
  if player.spGetAway then
    canGetAway = true
  end
  if 0 < player.spDays and player.activity_data.super_player_daily ~= key then
    canGetDaily = true
  end
  local ids = ""
  if canGetAway then
    ids = ids .. GameActivity:doRewards(player, SuperPlayerRewardConfig:getAwayRewards())
  end
  if canGetDaily then
    ids = ids .. GameActivity:doRewards(player, SuperPlayerRewardConfig:getDailyRewards())
  end
  player.activity_data.super_player_daily = key
  player.spGetAway = 0 < times
  GamePacketSender:sendBedWarSuperPlayerData(player.rakssid, player.spDays, player.spGetAway, false)
  if #ids == 0 then
    return
  end
  GamePacketSender:sendBedWarRewardResult(player.rakssid, ids)
end

function GameActivity:receiveSuperPlayerRewards(player)
  if player.spGetAway then
    local userId = player.userId
    WebService:ConsumeProps(player.userId, "g1008", "bed.war.super.player", function(data, code)
      if not data then
        return
      end
      local c_player = PlayerManager:getPlayerByUserId(userId)
      if not c_player then
        return
      end
      doSuperPlayerReward(c_player, data.times)
    end)
  else
    doSuperPlayerReward(player, 0)
  end
end

function GameActivity:syncTiroSignInData(player)
  local items = TiroSignInConfig.Items
  local data = {}
  for _, config in pairs(items) do
    local item = {
      Id = config.Id,
      Status = TiroSignInConfig.Status.CantReceived
    }
    if item.Id <= player.activity_data.tiro_sign_in_id then
      item.Status = TiroSignInConfig.Status.Received
    end
    table.insert(data, item)
  end
  local key = DateUtil.getYearDay()
  if key ~= player.activity_data.tiro_sign_in_key then
    for _, item in pairs(data) do
      if item.Id > player.activity_data.tiro_sign_in_id then
        item.Status = TiroSignInConfig.Status.WaitReceived
        break
      end
    end
  end
  GamePacketSender:sendBedWarTiroSignInData(player.rakssid, json.encode(data))
end

function GameActivity:receiveTiroSignInRewards(player)
  local key = DateUtil.getYearDay()
  if key == player.activity_data.tiro_sign_in_key then
    return
  end
  local items = TiroSignInConfig.Items
  local item
  for _, config in pairs(items) do
    if config.Id > player.activity_data.tiro_sign_in_id then
      item = config
      break
    end
  end
  if item == nil then
    return
  end
  local rewardId = GameReward:onPlayerGetReward(player, item.Reward)
  if rewardId then
    GamePacketSender:sendBedWarRewardResult(player.rakssid, rewardId)
  end
  player.activity_data.tiro_sign_in_key = key
  player.activity_data.tiro_sign_in_id = item.Id
  ReportUtil.reportTiroSignIn(player, item.Id)
  GameActivity:syncTiroSignInData(player)
end

function GameActivity:doRewards(player, rewards)
  local ids = ""
  for _, reward in pairs(rewards) do
    ids = ids .. tostring(reward.Id) .. "#"
    GameReward:onPlayerGetReward(player, reward)
  end
  return ids
end

return GameActivity

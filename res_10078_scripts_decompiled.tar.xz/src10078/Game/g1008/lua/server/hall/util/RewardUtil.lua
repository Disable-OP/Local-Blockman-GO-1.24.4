RewardUtil = {}
RewardUtil.RewardType = {RUNE_CHIP = 2, LOTTERY_CHEST = 3}

function RewardUtil:tryConsumeRewards(player)
  if not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  for _, reward in pairs(player.rewards) do
    if reward.Type == RewardUtil.RewardType.RUNE_CHIP then
      RewardUtil:addPlayerRuneChip(player, reward.Id, reward.Count)
    end
    if reward.Type == RewardUtil.RewardType.LOTTERY_CHEST then
      RewardUtil:addPlayerLotteryChest(player, reward.Id, reward.Count)
    end
  end
  for _, reward in pairs(player.props_rewards) do
    GameReward:onPlayerGetReward(player, reward)
  end
  player.rewards = {}
  player.props_rewards = {}
end

function RewardUtil:addPlayerRuneChip(player, id, count)
  GameReward:onPlayerRewardRune(player, id, count)
end

function RewardUtil:addPlayerLotteryChest(player, id, count)
  GameReward:addPlayerLotteryChest(player, id, count)
end

return RewardUtil

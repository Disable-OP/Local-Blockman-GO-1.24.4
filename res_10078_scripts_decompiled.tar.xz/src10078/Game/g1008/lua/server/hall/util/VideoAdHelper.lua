VideoAdHelper = {}

function VideoAdHelper:syncBoxLotteryAd(player, isOpenBox)
  isOpenBox = isOpenBox or false
  if player.video_ad_data == nil then
    player.video_ad_data = {box_lottery_key = 0}
  end
  local key = DateUtil.getYearDay()
  if player.video_ad_data.box_lottery_key ~= key then
    GamePacketSender:sendBedWarBoxLotteryAd(player.rakssid, true, isOpenBox)
  else
    GamePacketSender:sendBedWarBoxLotteryAd(player.rakssid, false, isOpenBox)
  end
end

function VideoAdHelper:doBoxLotteryAdReward(player)
  local key = DateUtil.getYearDay()
  if player.video_ad_data.box_lottery_key == key then
    return
  end
  player.video_ad_data.box_lottery_key = key
  RewardUtil:addPlayerLotteryChest(player, 1, 1)
  VideoAdHelper:syncBoxLotteryAd(player, true)
  return true
end

return VideoAdHelper

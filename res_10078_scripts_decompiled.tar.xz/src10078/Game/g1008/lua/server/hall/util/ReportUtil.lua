local NewReportUtil = require("common.util.NewReportUtil")
require("common.util.AnalyticsReportUtil")
local ReportTrackTime = 300
ReportUtil = {}

local function getPlayerLevelInterval(player)
  if player.level == 1 then
    return "1"
  elseif player.level == 2 then
    return "2"
  elseif player.level >= 3 and player.level <= 7 then
    return "3_7"
  elseif player.level >= 8 and player.level <= 15 then
    return "8_15"
  elseif player.level >= 16 then
    return "16"
  end
end

local function getPlayerDayPart(player)
  if player.play_days > 30 then
    return "Day30a"
  else
    return "Day" .. player.play_days
  end
end

local function getSuperPlayerPart(player)
  if player.spDays > 0 then
    return "SuperPlayer"
  else
    return "NoSuperPlayer"
  end
end

local function getPlayerSeasonScoreRange(honorId)
  if honorId == 0 then
    return "1000_1099"
  elseif honorId == 1 then
    return "1100_1299"
  elseif honorId == 2 then
    return "1300_1599"
  elseif honorId == 3 then
    return "1600_2099"
  elseif honorId == 4 then
    return "2100"
  else
    return "2100"
  end
end

function ReportUtil.reportDailySignIn(player, id)
  local parts = {
    "g1046DailySignIn",
    "PlayerLv" .. player.level,
    getPlayerDayPart(player),
    "Id" .. id
  }
  GameAnalytics:design(player.userId, player.level, parts)
end

function ReportUtil.reportTiroSignIn(player, id)
  local parts = {
    "g1046TiroSignIn",
    "PlayerLv" .. player.level,
    "Id" .. id
  }
  GameAnalytics:design(player.userId, player.level, parts)
end

function ReportUtil.reportGuide(player, guideId)
  local parts = {
    "H_GuideSetting",
    "Id" .. guideId
  }
  GameAnalytics:design(player.userId, player.level, parts)
end

function ReportUtil.reportBuySuperPlayer(player)
  local parts = {
    "g1046SuperPlayer",
    "PlayerLv" .. player.level,
    getPlayerDayPart(player)
  }
  GameAnalytics:design(player.userId, player.level, parts)
end

function ReportUtil.reportStartGame(player)
  local parts = {
    "g1046StartGame",
    "PlayerLv" .. player.level,
    getPlayerDayPart(player)
  }
  GameAnalytics:design(player.userId, player.level, parts)
end

function ReportUtil.reportWatchAdFinish(player, AdKey)
  local app = "MainApp"
  if player.enableIndie then
    app = "IndieApp"
  end
  local parts = {
    "g1046WatchAd",
    app,
    AdKey,
    getPlayerDayPart(player)
  }
  GameAnalytics:design(player.userId, player.level, parts)
end

function ReportUtil.reportSeasonRank(player)
  local seasonInfo = GameSeason.UserSeasonInfoCache[tostring(player.userId)]
  if seasonInfo == nil then
    return
  end
  local manager = GameServer:getRoomManager()
  if not manager:isUserAttrExisted(player.userId) then
    return
  end
  local attr = manager:getUserAttrInfo(player.userId)
  if player.hasReportSeasonRank == false or player.lastReportSeasonRankId == -1 then
    GameAnalytics:design(player.userId, 1, {
      "Player_RankId",
      attr.regionId,
      getPlayerSeasonScoreRange(seasonInfo.honorId)
    })
    player.hasReportSeasonRank = true
    player.lastReportSeasonRankId = seasonInfo.honorId
    return
  end
  if player.hasReportSeasonRank == true and seasonInfo.honorId ~= player.lastReportSeasonRankId then
    GameAnalytics:design(player.userId, 1, {
      "Player_RankId",
      attr.regionId,
      getPlayerSeasonScoreRange(seasonInfo.honorId)
    })
    GameAnalytics:design(player.userId, -1, {
      "Player_RankId",
      attr.regionId,
      getPlayerSeasonScoreRange(player.lastReportSeasonRankId)
    })
    player.lastReportSeasonRankId = seasonInfo.honorId
  end
end

function ReportUtil.reportStartTreasure(player, id)
  GameAnalytics:design(player.userId, 1, {
    "H_Treasure_start",
    tostring(id),
    getPlayerLevelInterval(player)
  })
end

function ReportUtil.reportGiveUpTreasure(player, isSuccess, id)
  if isSuccess then
    GameAnalytics:design(player.userId, 1, {
      "H_Treasure_waiver",
      tostring(id),
      getPlayerLevelInterval(player)
    })
  else
    GameAnalytics:design(player.userId, 0, {
      "H_Treasure_waiver",
      tostring(id),
      getPlayerLevelInterval(player)
    })
  end
end

function ReportUtil.reportFinishTreasure(player, id)
  GameAnalytics:design(player.userId, 1, {
    "H_Treasure_finish",
    tostring(id),
    getPlayerLevelInterval(player)
  })
end

function ReportUtil.reportFinishTreasureTime(player, id, days)
  GameAnalytics:design(player.userId, 1, {
    "H_Treasure_finish",
    tostring(id),
    tostring(days)
  })
end

function ReportUtil.reportFinishTreasureTask(player, taskId)
  GameAnalytics:design(player.userId, 1, {
    "Treasure_task",
    tostring(taskId)
  })
end

function ReportUtil.reportBuyLicenseSuccess(player, buyType)
  local Interval = GameLicense:calculateLevelInterval(player.license_level)
  GameAnalytics:design(player.userId, 1, {
    "H_License_buyUp",
    buyType,
    getPlayerLevelInterval(player),
    Interval
  })
end

function ReportUtil.reportPlayerLicenseLvUp(player, level)
  if level == 1 then
    GameAnalytics:design(player.userId, 1, {"License_Lv", 1})
    return
  end
  local Interval, IntervalChange = GameLicense:calculateLevelInterval(level)
  if IntervalChange then
    GameAnalytics:design(player.userId, -1, {"License_Lv", IntervalChange})
    GameAnalytics:design(player.userId, 1, {"License_Lv", Interval})
  end
end

function ReportUtil.reportPlayerBuyLevel(player, level)
  GameAnalytics:design(player.userId, 1, {
    "H_License_buyLv",
    level
  })
end

function ReportUtil.reportPlayerFinishTask(player, taskId)
  local Interval = GameLicense:calculateLevelInterval(player.license_level)
  GameAnalytics:design(player.userId, 1, {
    "H_License_Task",
    taskId,
    Interval
  })
end

function ReportUtil.reportPlayerFinishSeasonTask(player, taskId)
  local Interval = GameLicense:calculateLevelInterval(player.license_level)
  GameAnalytics:design(player.userId, 1, {
    "H_License_SeasonTask",
    taskId,
    Interval
  })
end

function ReportUtil.reportPlayerExchange(player, itemId)
  local Interval = GameLicense:calculateLevelInterval(player.license_level)
  GameAnalytics:design(player.userId, 1, {
    "H_License_swap",
    itemId,
    getPlayerLevelInterval(player),
    Interval
  })
end

function ReportUtil.reportPlayerCostKey(player, number, source, itemId)
  if not source or not itemId then
    return
  end
  GameAnalytics:design(player.userId, number, {
    "PlayerCostKey",
    source,
    itemId
  })
end

function ReportUtil.reportNewPlayerHadOpenLicense(player)
  if player.license_isNew == true and player.hadOpenLicense == false then
    player.license_isNew = os.date("%Y-%m-%d")
    GameAnalytics:design(player.userId, 1, {
      "License_NewOpen",
      "AllNum"
    })
  elseif player.license_isNew == true and player.hadOpenLicense == true then
    player.license_isNew = false
    GameAnalytics:design(player.userId, 1, {
      "License_NewOpen",
      "AllNum"
    })
    GameAnalytics:design(player.userId, 1, {
      "License_NewOpen",
      "OpenNum"
    })
  elseif player.license_isNew == os.date("%Y-%m-%d") and player.hadOpenLicense == true then
    player.license_isNew = false
    GameAnalytics:design(player.userId, 1, {
      "License_NewOpen",
      "OpenNum"
    })
  end
end

function ReportUtil.reportPlayerLoginLicenseLevel(player)
  GameAnalytics:design(player.userId, 1, {
    "onLoginLicenseLevel",
    player.license_level
  })
end

function ReportUtil.reportDailyPlayerLevel(player)
  GameAnalytics:design(player.userId, 1, {
    "Player_Level",
    player.level
  })
end

function ReportUtil.reportUseCube(player, goodId, cubeCount)
  local isInFiveMinuteRecharge = os.time() - player.lastRechargeReportTime < 300
  NewReportUtil.report(player, "UseCube", {
    NewReportUtil.getLevelData,
    NewReportUtil.getCountryData,
    NewReportUtil.getGameTimesData,
    NewReportUtil.isFirstConsume,
    NewReportUtil.getHonorData,
    NewReportUtil.getRuneCountData,
    NewReportUtil.getKeyCountData,
    NewReportUtil.getLicenseBuyTypeData,
    NewReportUtil.getLicenseRemainDaysData,
    NewReportUtil.getLicenseLevelData,
    NewReportUtil.getGameRecordData,
    NewReportUtil.getDiamondData,
    NewReportUtil.getTotalGameTimeData,
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {key = "good_id", value = goodId})
      callback(dataList)
    end,
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {key = "good_price", value = cubeCount})
      callback(dataList)
    end
  }, isInFiveMinuteRecharge and player.lastRechargeReportId or nil, function(reportId, reportTime)
    local goods = StoreConfig:getGoodsById(goodId)
    if goods and goods.Type == GoodsType.Key and reportTime - player.lastBuyKeyReportTime >= 300 then
      player.lastBuyKeyReportTime = reportTime
      player.lastBuyKeyReportId = reportId
    end
  end)
  player.have_cube_order = true
end

function ReportUtil.reportRechargeCube(player, productId)
  NewReportUtil.report(player, "RechargeCube", {
    NewReportUtil.getLevelData,
    NewReportUtil.getCountryData,
    NewReportUtil.getGameTimesData,
    NewReportUtil.isFirstRecharge,
    NewReportUtil.getHonorData,
    NewReportUtil.getRuneCountData,
    NewReportUtil.getKeyCountData,
    NewReportUtil.getLicenseBuyTypeData,
    NewReportUtil.getLicenseRemainDaysData,
    NewReportUtil.getLicenseLevelData,
    NewReportUtil.getGameRecordData,
    NewReportUtil.getDiamondData,
    NewReportUtil.getTotalGameTimeData,
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {
        key = "recharge_productId",
        value = productId
      })
      callback(dataList)
    end
  }, nil, function(reportId, reportTime)
    if os.time() - player.lastRechargeReportTime > 300 then
      player.lastRechargeReportTime = reportTime
      player.lastRechargeReportId = reportId
    end
  end)
end

function ReportUtil.reportCostKey(player, type, price)
  type = type or "undefined"
  price = price or 0
  if price <= 0 then
    return
  end
  local isInFiveMinuteBuyKey = os.time() - player.lastBuyKeyReportTime < 300
  NewReportUtil.report(player, "UseKey", {
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {key = "good_type", value = type})
      callback(dataList)
    end,
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {key = "good_price", value = price})
      callback(dataList)
    end
  }, isInFiveMinuteBuyKey and player.lastBuyKeyReportId or nil)
end

return ReportUtil

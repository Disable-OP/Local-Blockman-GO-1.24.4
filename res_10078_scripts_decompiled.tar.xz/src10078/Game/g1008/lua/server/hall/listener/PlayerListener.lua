local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
PlayerListener = {}
local PropPacketManager = require("common.manager.PropPacketManager")

function PlayerListener:init()
  BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
  BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
  BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
  BaseListener.registerCallBack(CEvents.PlayerAttackedEvent, self.onPlayerHurt)
  BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)
  CEvents.SendGuideInfoEvent:registerCallBack(self.onSendGuideInfo)
  CEvents.PlayerDropItemEvent:registerCallBack(function()
    return false
  end)
  CEvents.AddExpEvent:registerCallBack(self.onAddExp)
  CEvents.AddRuneEvent:registerCallBack(self.onAddRune)
  CEvents.ToolDurableEvent:registerCallBack(function()
    return false
  end)
  Events.PlayerOpenRuneEvent:registerCallBack(self.onPlayerOpenRune)
  Events.PlayerChangeRuneEvent:registerCallBack(self.onPlayerChangeRune)
  Events.PlayerOneKeyUnloadRuneEvent:registerCallBack(self.onPlayerOneKeyUnloadRune)
  Events.PlayerOneKeyEquipRuneEvent:registerCallBack(self.onPlayerOneKeyEquipRune)
  Events.PlayerOneKeyReclaimRuneEvent:registerCallBack(self.onPlayerOneKeyReclaimRune)
  Events.PlayerReclaimRuneEvent:registerCallBack(self.onPlayerReclaimRune)
  Events.PlayerUnlockRuneEvent:registerCallBack(self.onPlayerUnlockRune)
  Events.PlayerStartGameEvent:registerCallBack(self.onPlayerStartGame)
  Events.PlayerLicenseReceiveRewardEvent:registerCallBack(self.onPlayerReceiveReward)
  Events.PlayerLicenseBuyLevelEvent:registerCallBack(self.onPlayerBuyLevel)
  Events.PlayerBuyLicenseEvent:registerCallBack(self.onPlayerBuyLicense)
  Events.PlayerExchangeRewardEvent:registerCallBack(self.onPlayerExchangeReward)
  Events.PlayerReceiveTaskReward:registerCallBack(self.onPlayerReceiveTaskReward)
  Events.PlayerUseActionEvent:registerCallBack(self.onPlayerUseAction)
  Events.PlayerSendChatEvent:registerCallBack(self.onPlayerSendChat)
  Events.PayDiamondsSuccessEvent:registerCallBack(self.onPayDiamondsSuccess)
end

function PlayerListener.onAddExp(rakssid, exp)
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  player:addExp(exp)
end

function PlayerListener.onAddRune(rakssid, runeId, runeNum)
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  player:addRune(runeId, runeNum)
end

function PlayerListener.onPlayerLogin(clientPeer)
  local player = GamePlayer.new(clientPeer)
  player:init()
  ServerReportEvent.player_login(player)
  return GameOverCode.Success, player, 1
end

function PlayerListener.onPlayerLogout(player)
  ReportUtil.reportNewPlayerHadOpenLicense(player)
  PlayerCustomInfoUtil:reportOnQuit(player)
  GameMatch:onPlayerQuit(player)
  GameInfoManager:clearInfo("PlayerInfo", player.userId)
  ServerReportEvent.player_logout(player)
end

function PlayerListener.onPlayerReady(player)
  DbUtil:getPlayerData(player)
  HostApi.sendPlaySound(player.rakssid, 10039)
  HostApi.setDisarmament(player.rakssid, true)
  GameInfoManager.Instance():onPlayerReady(player)
  MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:gamename()))
  CommonPacketSender:sendBedWarPlayerReady(player.rakssid)
  HostApi.setAllowUseItemStatus(player.rakssid, 0)
  AddMaxHPPrivilege:onPlayerRespawn(player)
  ServerReportEvent.player_ready(player)
  return 43200
end

function PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
  return false
end

function PlayerListener.onPlayerOpenRune(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  player:sendOpenRune()
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
  if x == 0 and y == 0 and z == 0 then
    return true
  end
  local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
  if player == nil then
    return true
  end
  if y <= GameConfig.deathLineY then
    HostApi.resetPos(player.rakssid, GameConfig.initPos.x, GameConfig.initPos.y, GameConfig.initPos.z)
  end
  player:onMove(x, y, z)
  return true
end

function PlayerListener.onSendGuideInfo(rakssid, guideId, guideStatus)
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return false
  end
  local guide = {Id = guideId, Status = guideStatus}
  GameGuide:updateStatus(player, guide)
end

function PlayerListener.onPlayerChangeRune(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  local builder = DataBuilder.new():fromData(data)
  local troughId = builder:getNumberParam("troughId")
  local curRuneId = builder:getNumberParam("curRuneId")
  local targetRuneId = builder:getNumberParam("targetRuneId")
  player:changeRune(troughId, curRuneId, targetRuneId)
end

function PlayerListener.onPlayerOneKeyUnloadRune(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  local troughType = DataBuilder.new():fromData(data):getNumberParam("troughType")
  player:oneKeyUnload(troughType)
end

function PlayerListener.onPlayerOneKeyEquipRune(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  local troughType = DataBuilder.new():fromData(data):getNumberParam("troughType")
  player:oneKeyAssemble(troughType)
end

function PlayerListener.onPlayerOneKeyReclaimRune(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  local runeType = DataBuilder.new():fromData(data):getNumberParam("runeType")
  player:reclaimAll(runeType)
end

function PlayerListener.onPlayerReclaimRune(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  local runeId = DataBuilder.new():fromData(data):getNumberParam("runeId")
  player:reclaim(runeId)
end

function PlayerListener.onPlayerUnlockRune(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  if player.yaoshi < GameConfig.unlockRuneTroughPrice then
    player:sendPacket({
      pid = "CheckMoneyTip",
      type = Define.Money.KEY,
      price = GameConfig.unlockRuneTroughPrice
    })
    return
  end
  local runeType = DataBuilder.new():fromData(data):getNumberParam("runeType")
  player:subYaoShi(GameConfig.unlockRuneTroughPrice, "key_UnlockRune", runeType)
  player:runeUnlock(runeType)
end

function PlayerListener.onPlayerStartGame(userId, gameType)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  ReportUtil.reportStartGame(player)
end

function PlayerListener.onPlayerReceiveReward(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local Lv = DataBuilder.new():fromData(data):getNumberParam("Lv")
  local rewardId = DataBuilder.new():fromData(data):getNumberParam("rewardId")
  local rewardType = DataBuilder.new():fromData(data):getParam("rewardType")
  local getAll = DataBuilder.new():fromData(data):getBoolParam("getAll")
  local season = DataBuilder.new():fromData(data):getNumberParam("season")
  GameLicense:onPlayerGetReward(userId, Lv, getAll, season, rewardId, rewardType)
end

function PlayerListener.onPlayerBuyLevel(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local season = DataBuilder.new():fromData(data):getNumberParam("season")
  local level = DataBuilder.new():fromData(data):getNumberParam("level")
  local free = DataBuilder.new():fromData(data):getNumberParam("free")
  GameLicense:onPlayerBuyLevel(player, season, level, free)
end

function PlayerListener.onPlayerBuyLicense(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local season = DataBuilder.new():fromData(data):getNumberParam("season")
  local buyType = DataBuilder.new():fromData(data):getNumberParam("buyType")
  GameLicense:onPlayerBuy(player, season, buyType)
end

function PlayerListener.onPlayerExchangeReward(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local season = DataBuilder.new():fromData(data):getNumberParam("season")
  local itemId = DataBuilder.new():fromData(data):getNumberParam("itemId")
  local rewardNum = DataBuilder.new():fromData(data):getNumberParam("rewardNum")
  GameLicense:onPlayerExchange(userId, itemId, season, rewardNum)
end

function PlayerListener.onPlayerUseAction(userId, actionId)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  CommonPacketSender:sendUseActionToAll(player:getEntityId(), actionId)
end

function PlayerListener.onPlayerReceiveTaskReward(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local taskId = DataBuilder.new():fromData(data):getNumberParam("taskId")
  GameLicense:onPlayerReceiveSeasonTaskReward(player, taskId)
end

function PlayerListener.onPlayerSendChat(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local text = DataBuilder.new():fromData(data):getNumberParam("text")
  GamePacketSender:sendChatToAll(userId, text)
end

function PlayerListener.onPayDiamondsSuccess(userId, uniqueId, diamonds)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return false
  end
  ReportUtil.reportUseCube(player, uniqueId, diamonds)
end

return PlayerListener

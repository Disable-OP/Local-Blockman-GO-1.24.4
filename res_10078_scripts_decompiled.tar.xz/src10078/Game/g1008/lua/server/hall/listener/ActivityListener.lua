ActivityListener = {}

function ActivityListener:init()
  Events.BedWarReceivedFirstRechargeEvent:registerCallBack(self.onBedWarReceivedFirstRecharge)
  Events.BedWarTiroSignInEvent:registerCallBack(self.onBedWarTiroSignIn)
  Events.BedWarReceivedSuperPlayerEvent:registerCallBack(self.onBedWarReceivedSuperPlayer)
  Events.BedWarDailySignInEvent:registerCallBack(self.onBedWarDailySignIn)
  Events.CloseVideoAdTipEvent:registerCallBack(self.onCloseVideoAdTip)
  Events.SignInAgainEvent:registerCallBack(self.onSignInAgain)
end

function ActivityListener.onBedWarReceivedFirstRecharge(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  if not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  GameActivity:receiveFirstRechargeRewards(player)
end

function ActivityListener.onBedWarTiroSignIn(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  if not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  GameActivity:receiveTiroSignInRewards(player)
end

function ActivityListener.onBedWarReceivedSuperPlayer(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  if not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  GameActivity:receiveSuperPlayerRewards(player)
end

function ActivityListener.onBedWarDailySignIn(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  if not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  local id = DataBuilder.new():fromData(data):getNumberParam("Id")
  DailySignInHelper:onPlayerSignIn(player, id)
end

function ActivityListener.onCloseVideoAdTip(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  local builder = DataBuilder.new():fromData(data)
  local Type = builder:getNumberParam("Type")
  local Key = tonumber(builder:getParam("Params"))
  local isClickSure = builder:getBoolParam("IsClickSure")
  if Type == Define.AdType.FreeSignInAgain then
    if isClickSure then
      DailySignInHelper:onPlayerConfirmSignInAgain(player, Key)
    end
    return
  else
  end
end

function ActivityListener.onSignInAgain(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  local builder = DataBuilder.new():fromData(data)
  local id = builder:getNumberParam("id")
  local useTicket = builder:getBoolParam("useTicket")
  DailySignInHelper:onPlayerConfirmSignInAgain(player, id, useTicket)
end

return ActivityListener

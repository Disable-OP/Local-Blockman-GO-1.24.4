CustomListener = {}

function CustomListener:init()
  CEvents.ConsumeTipMsgEvent:registerCallBack(self.onConsumeTipMsg)
  CEvents.ConsumeDiamondsEvent:registerCallBack(self.onConsumeDiamonds)
  CEvents.RechargeResultEvent:registerCallBack(self.onRechargeResult)
  CEvents.WatchAdvertFinishedEvent:registerCallBack(self.onWatchAdvertFinished)
  Events.RefreshPropsEvent:registerCallBack(self.onRefreshProps)
  Events.CommonReceiveRewardEvent:registerCallBack(self.onCommonReceiveReward)
  Events.ReceiveSumRechargeEvent:registerCallBack(self.onReceiveSumRecharge)
end

function CustomListener.onConsumeTipMsg(rakssid, extra, isRight)
  if isRight == false then
    return
  end
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  local info = StringUtil.split(extra, "#")
  if #info == 2 then
    local extra1 = tostring(info[1])
    local extra2 = tonumber(info[2])
    if extra1 == Define.OpenLotteryChest then
      GameChestLottery:onPlayerConfirmPayLottery(player, extra2)
      return
    end
  end
end

function CustomListener.onConsumeDiamonds(rakssid, isSuccess, message, extra)
  if isSuccess == false then
    return
  end
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  local info = StringUtil.split(extra, "#")
  if #info == 2 then
    local extra1 = tostring(info[1])
    local extra2 = tonumber(info[2])
    if extra1 == Define.OpenLotteryChest then
      GameChestLottery:onPlayerLottery(player, extra2, true)
      return
    elseif extra1 == Define.SignInAgain then
      DailySignInHelper:onPlayerSignInSuccess(player, extra2)
      return
    end
  end
end

function CustomListener.onRechargeResult(rakssid, type, result, productId)
  if result ~= 1 then
    return
  end
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  GameActivity:syncFirstRechargeData(player)
  if type == 1 then
    ReportUtil.reportRechargeCube(player, productId)
  end
  if type == 3 then
    GameActivity:syncSuperPlayerData(player)
    ReportUtil.reportBuySuperPlayer(player)
  end
end

function CustomListener.onWatchAdvertFinished(rakssid, type, params, code)
  if code ~= 1 then
    return
  end
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  if type == Define.AdType.BoxLottery then
    if VideoAdHelper:doBoxLotteryAdReward(player) then
      ReportUtil.reportWatchAdFinish(player, "BoxLottery")
    end
    return
  elseif type == Define.AdType.FreeSignInAgain then
    if DailySignInHelper:onPlayerSignInSuccess(player, tonumber(params)) then
      ReportUtil.reportWatchAdFinish(player, "FreeSignInAgain")
    end
    return
  elseif type == Define.AdType.FreeCube then
    player.free_cube_data.times = player.free_cube_data.times + 1
    if player.free_cube_data.times >= 2 then
      GamePacketSender:sendBedWarFreeCubeLimit(player.rakssid)
    end
    return
  elseif type == Define.AdType.FreeGift then
    WatchADHelper:onPlayerGetFreeGift(player, tonumber(params))
    return
  elseif type == Define.AdType.License then
    GameLicense:onPlayerBuyLevel(player, nil, player.license_level, true)
  elseif type == Define.AdType.Challenge then
    TreasureChallenge:onPlayerWatchTreasureAd(player)
  elseif type == Define.AdType.CubeStoreFreeTicket then
    WatchADHelper:onGetCubeStoreFreeTicket(player, params)
  end
end

function CustomListener.onRefreshProps(userId, data)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player == nil then
    return
  end
  if not DbUtil:IsGetAllDataFinished(player) then
    LuaTimer:schedule(function(userId, data)
      CustomListener.onRefreshProps(userId, data)
    end, 10000, nil, userId, data)
    return
  end
  WebService:GetUserAttr(player.userId, function(data, code)
    if data ~= nil then
      local c_player = PlayerManager:getPlayerByUserId(userId)
      if not c_player then
        return
      end
      c_player:useAppProps()
      c_player.staticAttr.props = {}
    end
  end)
end

function CustomListener.onReceiveSumRecharge(player, type, rewardId, count)
  if type == "CustomShop" then
    local goods = CustomShopConfig:getGoodsConfig(rewardId)
    if goods then
      CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.SumRecharge)
    end
    return
  end
  if type == "Key" then
    player:addYaoShi(count)
    return
  end
end

function CustomListener.onCommonReceiveReward(player, propsType, propsId, propsCount, expireTime)
  if propsType == "CustomShop" then
    local goods = CustomShopConfig:getGoodsConfig(tonumber(propsId))
    if goods then
      CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.SumRecharge)
    end
    return
  end
  if propsType == "Key" then
    player:addYaoShi(propsCount)
    return
  end
  if propsType == "YaoShi" then
    player:addYaoShi(propsCount)
    return
  end
  if propsType == "Privilege" then
    Privilege.addPrivilegeTime(player, tonumber(propsId), expireTime)
    return
  end
  if propsType == "Ticket" then
    GameReward:onPlayerRewardTicket(player, tonumber(propsId), propsCount)
  end
  if propsType == "Horn" then
    GameReward:onPlayerRewardHorn(player, tonumber(propsId), propsCount)
  end
  if propsType == "Chest" then
    GameReward:addPlayerLotteryChest(player, tonumber(propsId), propsCount)
  end
  if propsType == "Rune" then
    GameReward:onPlayerRewardRune(player, tonumber(propsId), propsCount)
  end
  if propsType == "RewardSetting" then
    local reward = RewardConfig:getRewardById(propsId)
    if not reward then
      return
    end
    reward.Count = propsCount
    GameReward:onPlayerGetReward(player, reward)
  end
end

return CustomListener

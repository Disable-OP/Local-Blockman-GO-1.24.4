GamePacketSender = {}

function GamePacketSender:sendBedWarTiroSignInData(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "TiroSignIn", data)
end

function GamePacketSender:sendBedWarDailySignInData(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "DailySignIn", data)
end

function GamePacketSender:sendBedWarSuperPlayerData(rakssid, days, canGetAway, canGetDaily)
  local params = {
    days = days,
    canGetAway = canGetAway,
    canGetDaily = canGetDaily
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "SuperPlayer", data)
end

function GamePacketSender:sendBedWarFirstRechargeData(rakssid, showUI, canReceive)
  local params = {showUI = showUI, canReceive = canReceive}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "FirstRecharge", data)
end

function GamePacketSender:sendBedWarRewardResult(rakssid, rewardIds)
  if rewardIds == "" then
    return
  end
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if not player then
    return
  end
  local params = {rewardIds = rewardIds}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "RewardResult", data)
end

function GamePacketSender:sendBedWarBoxLotteryAd(rakssid, isShowAd, isOpenBox)
  local params = {isShowAd = isShowAd, isOpenBox = isOpenBox}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "BoxLotteryAd", data)
end

function GamePacketSender:sendBedWarReissueDailySignIn(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "ReissueDailySignIn", data)
end

function GamePacketSender:sendBedWarHallInfo(rakssid, level, curExp, maxExp, isMax, key)
  local params = {
    level = level,
    curExp = curExp,
    maxExp = maxExp,
    isMax = isMax,
    key = key
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendServerCommonData(rakssid, "BedWarHallData", "HallInfo", data)
end

function GamePacketSender:sendBedWarShowSeasonRank(rakssid)
  PacketSender:sendServerCommonData(rakssid, "BedWarHallData", "ShowSeasonRank", "")
end

function GamePacketSender:sendBedWarCurrentSeasonInfo(rakssid, honorId, rank, honor, endTime)
  local params = {
    honorId = honorId,
    rank = rank,
    honor = honor,
    endTime = endTime
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendServerCommonData(rakssid, "BedWarHallData", "CurrentSeasonInfo", data)
end

function GamePacketSender:sendBedWarLastSeasonInfo(rakssid, honorId, rank, honor)
  local params = {
    honorId = honorId,
    rank = rank,
    honor = honor
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendServerCommonData(rakssid, "BedWarHallData", "LastSeasonInfo", data)
end

function GamePacketSender:sendBedWarRuneData(rakssid, data)
  PacketSender:sendServerCommonData(rakssid, "BedWarHallData", "RuneData", data)
end

function GamePacketSender:sendBedWarRuneNextTrough(rakssid)
  PacketSender:sendServerCommonData(rakssid, "BedWarHallData", "RuneNextTrough", "")
end

function GamePacketSender:sendBedWarFreeCubeLimit(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "FreeCubeLimit")
end

function GamePacketSender:sandBedWarLicenseExchangeSuccess(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BedWarLicenseExchange", data)
end

function GamePacketSender:sendBedWarLicense(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BedWarLicenseData", data)
end

function GamePacketSender:sandBedWarLicensePaySuccess(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BedWarLicensePaySuccess", data)
end

function GamePacketSender:sendBedWarLicenseExchangeSuccess(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BedWarLicenseExchangeSuccess", data)
end

function GamePacketSender:sendLicenseTaskRefreshAll(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "LicenseTaskRefreshAll")
end

function GamePacketSender:sendLicenseFinishTask(rakssid, EXP, level, weekEXP)
  local params = {
    EXP = EXP,
    level = level,
    weekLimit = weekEXP
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LicenseFinishTask", data)
end

function GamePacketSender:sendLicenseWeekEXP(rakssid, WeekEXP)
  local params = {WeekEXP = WeekEXP}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LicenseWeekEXP", data)
end

function GamePacketSender:sendChatToAll(userId, text)
  local params = {userId = userId, text = text}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:broadCastLuaCommonData("Chat", data)
end

function GamePacketSender:sendLicenseCleanTask(rakssid, type)
  local params = {Type = type}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LicenseCleanTask", data)
end

function GamePacketSender:sendIndieDailyLogin(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "IndieDailyLogin")
end

function GamePacketSender:sendFreeGiftData(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "InitFreeGiftData", data)
end

function GamePacketSender:sendGetFreeGiftReward(rakssid, id)
  local params = {id = id}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "GetFreeGiftReward", data)
end

function GamePacketSender:sendWatchLicenseADSuccess(rakssid, level, curEXP, freeUpgradeTime)
  local params = {
    curLV = level,
    curEXP = curEXP,
    freeTime = freeUpgradeTime
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "WatchLicenseADSuccess", data)
end

function GamePacketSender:sendCubeStoreGetTicketTimes(rakssid, times)
  local params = {times = times}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "CubeStoreGetTicketTimes", data)
end

function GamePacketSender:sendHeadFrameDataData(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "HeadFrameDataData", json.encode(data))
end

function GamePacketSender:sendBuyHeadFrameSuccess(rakssid, id)
  PacketSender:sendLuaCommonData(rakssid, "BuyHeadFrameSuccess", json.encode({id}))
end

function GamePacketSender:sendEquipHeadFrameSuccess(rakssid, id)
  local params = {id = id}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "EquipHeadFrameSuccess", data)
end

return GamePacketSender

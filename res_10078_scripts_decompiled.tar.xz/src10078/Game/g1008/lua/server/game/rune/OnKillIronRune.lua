OnKillIronRune = class("OnKillIronRune")

function OnKillIronRune:ctor(config)
  self.probability = tonumber(config.Value1)
  self.num = tonumber(config.Value2)
end

function OnKillIronRune:onKill(player, runeProbability)
  local random_num = HostApi.random("onKill", 1, 10000)
  if random_num <= runeProbability.probability then
    player:addItem(ItemID.INGOT_IRON, self.num)
  end
end

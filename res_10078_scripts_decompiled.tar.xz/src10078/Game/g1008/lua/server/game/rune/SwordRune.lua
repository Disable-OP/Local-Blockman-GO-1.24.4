SwordRune = class("SwordRune")

function SwordRune:ctor(config)
  self.damage = tonumber(config.Value1)
end

function SwordRune:onAttack(attacker, hurtValue, damageType)
  local itemId = attacker:getHeldItemId()
  local class = ""
  local item = Item.getItemById(itemId)
  if item then
    class = item:getClassName()
  end
  if damageType == "player" and class == "ItemSword" then
    hurtValue.value = hurtValue.value + self.damage
  end
end

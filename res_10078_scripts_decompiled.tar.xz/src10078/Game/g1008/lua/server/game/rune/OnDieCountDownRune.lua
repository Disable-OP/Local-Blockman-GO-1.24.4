OnDieCountDownRune = class("OnDieCountDownRune")

function OnDieCountDownRune:ctor(config)
  self.time = tonumber(config.Value1)
end

function OnDieCountDownRune:onInit(player)
  if not player or self.time == 0 then
    return
  end
  local time = tonumber(player.info:getValue("runeSubSpawnTime")) + self.time
  player.info:setValue("runeSubSpawnTime", time)
end

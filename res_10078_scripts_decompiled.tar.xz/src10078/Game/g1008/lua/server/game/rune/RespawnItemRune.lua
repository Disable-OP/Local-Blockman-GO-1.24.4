RespawnItemRune = class("RespawnItemRune")

function RespawnItemRune:ctor(config)
  self.itemId = tonumber(config.Value1)
  self.num = tonumber(config.Value2)
end

function RespawnItemRune:onRespawn(player)
  player:tryAddItem(self.itemId, self.num)
end

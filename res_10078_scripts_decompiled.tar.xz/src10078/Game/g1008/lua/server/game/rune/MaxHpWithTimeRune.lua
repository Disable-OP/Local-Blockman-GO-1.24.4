MaxHpWithTimeRune = class("MaxHpWitchTimeRune")

function MaxHpWithTimeRune:ctor(config)
  self.addHp = tonumber(config.Value1)
  self.time = tonumber(config.Value2)
  self.lastAddHpTicks = 0
  self.respawnAddHp = 0
end

function MaxHpWithTimeRune:onTick(player, ticks)
  if ticks % self.time == 0 then
    if self.lastAddHpTicks ~= ticks then
      self.respawnAddHp = self.respawnAddHp + self.addHp
      self.lastAddHpTicks = ticks
    end
    player:changeMaxHealthSingle(player:getMaxHealth() + self.addHp)
  end
end

function MaxHpWithTimeRune:onRespawn(player)
  player:changeMaxHealthSingle(player:getMaxHealth() + self.respawnAddHp)
end

OnKillHpRune = class("OnKillHpRune")

function OnKillHpRune:ctor(config)
  self.probability = tonumber(config.Value1)
  self.num = tonumber(config.Value2)
end

function OnKillHpRune:onKill(player, probability)
  local random_num = HostApi.random("onKill", 1, 10000)
  if random_num <= probability.probability and not player.banCureBuff then
    player:addHealth(self.num)
  end
end

SuckBloodRune = class("SuckBloodRune")

function SuckBloodRune:ctor(config)
  self.ratio = tonumber(config.Value1)
end

function SuckBloodRune:onAttack(player, hurtValue)
  if self.ratio > 0 and not player.banCureBuff then
    local suckBloodValue = hurtValue.value * self.ratio / 10000
    player:addHealth(suckBloodValue)
  end
end

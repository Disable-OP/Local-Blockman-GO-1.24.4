AutoAddHpRune = class("AutoAddHpRune")

function AutoAddHpRune:ctor(config)
  self.addHp = tonumber(config.Value1)
  self.time = tonumber(config.Value2)
end

function AutoAddHpRune:onTick(player, ticks)
  if ticks % self.time == 0 and not player.banCureBuff then
    player:addHealth(self.addHp)
  end
end

CritRune = class("CritRune")

function CritRune:ctor(config)
  self.probability = tonumber(config.Value1)
end

function CritRune:onAttack(player, runeProbability, hurtValue)
  local random_num = HostApi.random("crit", 1, 10000)
  local critExtraHurtPro = GameConfig.critExtraHurtPro
  critExtraHurtPro = critExtraHurtPro + runeProbability.probability
  if random_num <= critExtraHurtPro then
    hurtValue.value = hurtValue.value + GameConfig.critExtraHurt
    HostApi.sendAttackScore(player.rakssid, GameConfig.critExtraHurt)
  end
end

OnKillWoolRune = class("OnKillWoolRune")

function OnKillWoolRune:ctor(config)
  self.probability = tonumber(config.Value1)
  self.num = tonumber(config.Value2)
end

function OnKillWoolRune:onKill(player, runeProbability)
  local random_num = HostApi.random("onKill", 1, 10000)
  if random_num <= runeProbability.probability then
    player:tryAddItem(BlockID.CLOTH, self.num)
  end
end

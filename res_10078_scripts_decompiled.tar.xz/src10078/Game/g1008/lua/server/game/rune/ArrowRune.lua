ArrowRune = class("ArrowRune")

function ArrowRune:ctor(config)
  self.damage = tonumber(config.Value1)
end

function ArrowRune:onAttack(attacker, hurtValue, damageType)
  if not attacker then
    return
  end
  if damageType == "arrow" then
    hurtValue.value = hurtValue.value + self.damage
  end
end

MaxHpWithBeginRune = class("MaxHpWitchBeginRune")

function MaxHpWithBeginRune:ctor(config)
  self.addHp = tonumber(config.Value1)
  self.time = tonumber(config.Value2) * 60
  self.isInvalid = false
end

function MaxHpWithBeginRune:onTick(player, ticks)
  if self.isInvalid then
    return
  end
  if ticks <= self.time then
    if player.isRespawn then
      player:changeMaxHealth(player:getMaxHealth() + self.addHp)
    end
  else
    if not player.isRespawn then
      player:changeMaxHealth(player:getMaxHealth() - self.addHp)
    end
    LuaTimer:schedule(function()
      self.isInvalid = true
    end, 0)
  end
end

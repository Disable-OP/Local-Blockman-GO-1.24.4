ReduceHurtRune = class("ReduceHurtRune")

function ReduceHurtRune:ctor(config)
  self.defence = tonumber(config.Value1)
end

function ReduceHurtRune:onHurted(hurter, hurtValue)
  hurtValue.value = hurtValue.value - hurtValue.value * self.defence / 10000
end

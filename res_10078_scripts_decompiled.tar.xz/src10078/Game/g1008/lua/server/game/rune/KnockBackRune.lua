KnockBackRune = class("KnockBackRune")

function KnockBackRune:ctor(config)
  self.distance = tonumber(config.Value1)
end

function KnockBackRune:onInit(player)
  player.info:setValue("runeAddKnockBackValue", tonumber(player.info:getValue("runeAddKnockBackValue")) + self.distance)
end

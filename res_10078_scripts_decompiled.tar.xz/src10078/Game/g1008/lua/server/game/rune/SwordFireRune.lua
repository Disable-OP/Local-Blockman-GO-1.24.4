SwordFireRune = class("SwordFireRune")

function SwordFireRune:ctor(config)
  self.probability = tonumber(config.Value1)
end

function SwordFireRune.onAattack(attacker, runeProbability, hurtValue, damageType, hurter)
  local itemId = attacker:getHeldItemId()
  local class = ""
  local item = Item.getItemById(itemId)
  if item then
    class = item:getClassName()
  end
  if damageType == "player" and class == "ItemSword" then
    local random_num = HostApi.random("sword fire", 1, 10000)
    local swordFirePro = GameConfig.swordFirePro
    swordFirePro = swordFirePro + runeProbability
    if random_num <= swordFirePro and hurter.entityPlayerMP ~= nil then
      hurter.entityPlayerMP:setOnFire(GameConfig.fire_time)
    end
  end
end

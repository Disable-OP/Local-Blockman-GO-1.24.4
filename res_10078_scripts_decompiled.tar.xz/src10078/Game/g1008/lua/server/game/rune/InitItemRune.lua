InitItemRune = class("InitItemRune")

function InitItemRune:ctor(config)
  self.itemId = tonumber(config.Value1)
  self.num = tonumber(config.Value2)
end

function InitItemRune:onInit(player)
  player:tryAddItem(self.itemId, self.num)
  if self.itemId == ItemID.SHEARS or self.itemId == ItemID.PICKAXE_WOOD or self.itemId == ItemID.AXE_WOOD then
    player:addInitItems(self.itemId)
  end
end

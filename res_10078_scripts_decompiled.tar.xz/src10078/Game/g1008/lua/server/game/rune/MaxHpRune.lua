MaxHpRune = class("MaxHpRune")

function MaxHpRune:ctor(config)
  self.addHp = tonumber(config.Value1)
end

function MaxHpRune:onInit(player)
  player:changeMaxHealth(player:getMaxHealth() + self.addHp)
end

function MaxHpRune:onRespawn(player)
  player:changeMaxHealth(player:getMaxHealth() + self.addHp)
end

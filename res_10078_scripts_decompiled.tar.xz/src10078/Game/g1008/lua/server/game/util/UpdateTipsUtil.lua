UpdateTipsUtil = {}

function UpdateTipsUtil:sendTips(player)
  if player.updateTipsVersion ~= GameConfig.updateTipsVersion then
  end
  do return end
  local image_1 = "status" .. "1," .. "set:new_gui_material.json image:run" .. "," .. "0.44," .. "0.1," .. "0.12," .. "0.2"
  local c_params = {
    AdType = Define.AdType.UpdateTips,
    Title = "update_tips_title",
    SureButtonTxt = "gui_dialog_tip_btn_sure",
    ImagesReport = image_1,
    TextsReport = "text" .. "1," .. "update_tips_text," .. "0.05," .. "0.35," .. "0.9," .. "0"
  }
  local c_data = DataBuilder.new():fromTable(c_params):getData()
  GamePacketSender:sendBedWarTipAd(player.rakssid, c_data)
end

function UpdateTipsUtil:sendFeedback(player)
  if player.updateTipsVersion ~= GameConfig.updateTipsVersion then
  end
  do return end
  local c_params = {
    AdType = Define.AdType.UpdateFeedback,
    Title = "gui_dialog_tip_title_tip",
    SureButtonTxt = "feedback_agree",
    SureIcon = "set:update_tips.json image:agree",
    CancelButtonTxt = "feedback_disagree",
    CancelIcon = "set:update_tips.json image:disagree",
    TextsReport = "text" .. "1," .. "feedback_tips_text," .. "0.05," .. "0.27," .. "0.9," .. "0"
  }
  local c_data = DataBuilder.new():fromTable(c_params):getData()
  GamePacketSender:sendBedWarTipAd(player.rakssid, c_data)
end

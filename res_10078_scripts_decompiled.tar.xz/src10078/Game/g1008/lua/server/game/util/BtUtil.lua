BtUtil = {}
local AirMap = {
  [tostring(BlockID.AIR)] = true,
  [tostring(BlockID.TALL_GRASS)] = true
}
local NotStandMap = {
  [tostring(BlockID.WATERLILY)] = true,
  [tostring(BlockID.FENCE)] = true,
  [tostring(BlockID.WATER_MOVING)] = true,
  [tostring(BlockID.WATER_STILL)] = true,
  [tostring(BlockID.PLANT_RED)] = true,
  [tostring(BlockID.PLANT_YELLOW)] = true,
  [tostring(BlockID.COBBLESTONE_WALL)] = true,
  [tostring(BlockID.STAIND_GLASS_PANE)] = true
}
local canBreakMap = {
  [tostring(BlockID.CLOTH)] = true,
  [tostring(BlockID.WHITE_STONE)] = true,
  [tostring(BlockID.STAIND_GLASS)] = true,
  [tostring(BlockID.GLASS)] = true,
  [tostring(BlockID.PLANKS)] = true,
  [tostring(BlockID.OBSIDIAN)] = true,
  [tostring(BlockID.SLIME)] = true
}

function BtUtil.canBreakBlock(blockId)
  if 256 < blockId then
    return true
  end
  return canBreakMap[tostring(blockId)] or false
end

local pathArray = {}
local BlockIdMap = {}

function BtUtil.calculateDistance(pos1, pos2)
  return math.sqrt((pos1.x - pos2.x) * (pos1.x - pos2.x) + (pos1.y - pos2.y) * (pos1.y - pos2.y) + (pos1.z - pos2.z) * (pos1.z - pos2.z))
end

local function getBlockId(pos)
  local blockId
  if BlockIdMap[VectorUtil.hashVector3(pos)] == nil then
    blockId = EngineWorld:getBlockId(pos)
    BlockIdMap[VectorUtil.hashVector3(pos)] = blockId
  else
    blockId = BlockIdMap[VectorUtil.hashVector3(pos)]
  end
  return blockId
end

local function getStagePath(starPos, endPos)
  local StagePoint
  local distance = BtUtil.calculateDistance(starPos, endPos)
  local vec3 = VectorUtil.sub3(endPos, starPos)
  local vecPos = VectorUtil.newVector3(vec3.x / (distance / 5), vec3.y, vec3.z / (distance / 5))
  StagePoint = VectorUtil.add3(starPos, vecPos)
  StagePoint = VectorUtil.toVector3i(StagePoint)
  while getBlockId(StagePoint) ~= 0 do
    if vec3.x >= 0 then
      StagePoint.x = StagePoint.x + 1
    else
      StagePoint.x = StagePoint.x - 1
    end
    if vec3.z >= 0 then
      StagePoint.z = StagePoint.z + 1
    else
      StagePoint.z = StagePoint.z - 1
    end
  end
  return StagePoint
end

local pathFinder = PathPlannerManager.Instance():newPathPlanner("BedwarPathPlanner")

local function startFindPath2(startPos, endPos)
  pathArray = {}
  pathFinder:findPath(startPos, endPos, 100)
  local size = pathFinder:getPathSize()
  if size == 1 then
    return
  end
  for i = size - 1, 0, -1 do
    local pos = pathFinder:getPosInPath(i)
    table.insert(pathArray, pos)
  end
end

function BtUtil.getCurPath(starPos, endPos)
  if BtUtil.calculateDistance(starPos, endPos) > 6 then
    endPos = getStagePath(starPos, endPos)
  end
  startFindPath2(starPos, endPos)
  return pathArray
end

function BtUtil.checkBlockCanMove(pos)
  local blockId = getBlockId(pos)
  return AirMap[tostring(blockId)] or not BtUtil.isScenesBlock(pos, blockId) and (blockId == BlockID.AIR or blockId == BlockID.TALL_GRASS or blockId == BlockID.WATER_MOVING or blockId == BlockID.WATER_STILL or blockId == BlockID.WATERLILY or blockId == BlockID.BED or BtUtil.canBreakBlock(blockId))
end

function BtUtil.isScenesBlock(blockPos, blockId)
  if blockId ~= BlockID.AIR and blockId ~= BlockID.BED then
    return not EngineWorld:isBlockChange(blockPos)
  end
  return false
end

local NewReportUtil = require("common.util.NewReportUtil")
require("common.util.AnalyticsReportUtil")
local ReportTrackTime = 300
ReportUtil = {}

local function getPlayerLevelInterval(player)
  if player.level == 1 then
    return "1"
  elseif player.level == 2 then
    return "2"
  elseif player.level >= 3 and player.level <= 7 then
    return "3_7"
  elseif player.level >= 8 and player.level <= 15 then
    return "8_15"
  elseif player.level >= 16 then
    return "16"
  end
end

local function getPlayerGameTime()
  local minute = RewardManager:getGameRunningTime() / 60
  if minute <= 1 then
    return "0_1_minutes"
  elseif 1 < minute and minute <= 3 then
    return "1_3_minutes"
  elseif 3 < minute and minute <= 6 then
    return "3_6_minutes"
  elseif 6 < minute and minute <= 10 then
    return "6_10_minutes"
  elseif 10 < minute and minute <= 15 then
    return "10_15_minutes"
  elseif 15 < minute and minute <= 20 then
    return "15_20_minutes"
  elseif 20 < minute and minute <= 30 then
    return "20_30_minutes"
  else
    return "30_INF_minutes"
  end
end

local function getPlayerDayPart(player)
  if player.play_days > 30 then
    return "Day30a"
  else
    return "Day" .. player.play_days
  end
end

local function getRefreshTimes(times)
  if 20 < times then
    return "Times20a"
  else
    return "Times" .. times
  end
end

function ReportUtil.reportWatchAdFinish(player, AdKey)
  local app = "MainApp"
  if player.enableIndie then
    app = "IndieApp"
  end
  local parts = {
    "g1046WatchAd",
    app,
    AdKey,
    getPlayerDayPart(player)
  }
  GameAnalytics:design(player.userId, player.level, parts)
end

function ReportUtil.reportLotteryOpenCard(player, lotteryTimes)
  local app = "MainApp"
  if player.enableIndie then
    app = "IndieApp"
  end
  local parts = {
    "g1046LotteryOpenCard",
    lotteryTimes,
    getPlayerDayPart(player)
  }
  GameAnalytics:design(player.userId, player.level, parts)
end

function ReportUtil.reportLotteryRefreshTimes(player)
  local app = "MainApp"
  if player.enableIndie then
    app = "IndieApp"
  end
  local info = GameLottery.LotteryInfo[tostring(player.userId)]
  if not info then
    return
  end
  local times = info.lotteryRefreshTimes
  local parts = {
    "g1046LotteryRefreshTimes",
    app,
    getRefreshTimes(times),
    getPlayerDayPart(player)
  }
  GameAnalytics:design(player.userId, player.level, parts)
  if 50 < times then
    ReportUtil.reportLotteryMVP(player)
  end
end

function ReportUtil.reportLotteryMVP(player)
  local app = "MainApp"
  if player.enableIndie then
    app = "IndieApp"
  end
  local info = GameLottery.LotteryInfo[tostring(player.userId)]
  if not info then
    return
  end
  local parts = {
    "g1046LotteryMVP",
    app,
    "Uid" .. tostring(player.userId),
    info.lotteryRefreshTimes
  }
  GameAnalytics:design(player.userId, player.yaoshi, parts)
end

function ReportUtil.reportKillNum(player, level, killNum)
  if not player.isPartyUser then
    GameAnalytics:design(player.userId, 1, {
      "Player_kill",
      level,
      killNum
    })
  end
end

function ReportUtil.reportDeathNum(player, level, deathNum)
  if not player.isPartyUser then
    GameAnalytics:design(player.userId, 1, {
      "Player_death",
      level,
      deathNum
    })
  end
end

function ReportUtil.reportDeathPeriod(player, damageType, itemId)
  if not player.isPartyUser and BlackBoard:getValue("GameType") == "PlayerGame" then
    if damageType == "player" then
      GameAnalytics:design(player.userId, 1, {
        "Player_deathtime",
        getPlayerGameTime(),
        "PlayerKill",
        tostring(itemId)
      })
    else
      GameAnalytics:design(player.userId, 1, {
        "Player_deathtime",
        getPlayerGameTime(),
        "Other",
        tostring(damageType)
      })
    end
  end
end

function ReportUtil.reportLogout(player)
  if not player.isPartyUser then
    GameAnalytics:design(player.userId, 1, {
      "Playerout_time",
      getPlayerGameTime()
    })
  end
end

function ReportUtil.reportBedDamage(player)
  if not player.isPartyUser then
    GameAnalytics:design(player.userId, 1, {
      "Bed_DamageTime",
      getPlayerGameTime()
    })
  end
end

function ReportUtil.reportEndTime(player)
  if not player.isPartyUser and not AIManager:isAI(player.rakssid) then
    GameAnalytics:design(player.userId, 1, {
      "Playerend_time",
      getPlayerGameTime()
    })
  end
end

function ReportUtil.reportBuyShopGood(player, goodId)
  if not player.isPartyUser then
    GameAnalytics:design(player.userId, 1, {"Buy_items", goodId})
  end
end

function ReportUtil.reportBuyShopGoodPeriod(player, goodId)
  if not player.isPartyUser then
    GameAnalytics:design(player.userId, 1, {
      "Buy_itemsTime",
      getPlayerGameTime(),
      goodId
    })
  end
end

function ReportUtil.reportBuyMerchant(player, goodId)
  if not player.isPartyUser then
    GameAnalytics:design(player.userId, 1, {
      "Up_Merchant",
      goodId
    })
  end
end

function ReportUtil.reportBuyMerchantPeriod(player, goodId)
  if not player.isPartyUser then
    GameAnalytics:design(player.userId, 1, {
      "Up_MerchantTime",
      getPlayerGameTime(),
      goodId
    })
  end
end

function ReportUtil.reportDeathReason(player, level, damageType, itemId)
  if not player.isPartyUser then
    if BlackBoard:getValue("GameType") == "PlayerGame" then
      if damageType == "player" then
        GameAnalytics:design(player.userId, 1, {
          "Player_deathReason",
          level,
          "PlayerKill",
          tostring(itemId)
        })
      else
        GameAnalytics:design(player.userId, 1, {
          "Player_deathReason",
          level,
          "Other",
          tostring(damageType)
        })
      end
    else
      if AIManager:isAI(player.rakssid) == true then
        return
      end
      if damageType == "player" then
        GameAnalytics:design(player.userId, 1, {
          "AI_killplayers",
          getPlayerGameTime(),
          "PlayerKill",
          tostring(itemId)
        })
      else
        GameAnalytics:design(player.userId, 1, {
          "AI_killplayers",
          getPlayerGameTime(),
          "Other",
          tostring(damageType)
        })
      end
    end
  end
end

function ReportUtil.reportAIDamageBed(isAIBed)
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    if player and AIManager:isAI(player.rakssid) == false then
      if isAIBed then
        GameAnalytics:design(player.userId, 1, {
          "AI_damageBed",
          "AI_Bed"
        })
        break
      end
      GameAnalytics:design(player.userId, 1, {
        "AI_damageBed",
        "Player_Bed"
      })
      break
    end
  end
end

function ReportUtil.reportAIGameEndTime()
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    if player and AIManager:isAI(player.rakssid) == false then
      GameAnalytics:design(player.userId, 1, {
        "AI_endtime",
        getPlayerGameTime()
      })
      break
    end
  end
end

function ReportUtil.reportPlayerKillAI(player, honor, num)
  if not player.isPartyUser then
    if 1000 <= honor or honor <= 1099 then
      GameAnalytics:design(player.userId, 1, {
        "Player_killAI",
        "1000_1099",
        tostring(num)
      })
    elseif 1100 <= honor or honor <= 1199 then
      GameAnalytics:design(player.userId, 1, {
        "Player_killAI",
        "1100_1199",
        tostring(num)
      })
    end
  end
end

function ReportUtil.reportPlayerDamageAIBed(player, honor)
  if not player.isPartyUser then
    if 1000 <= honor or honor <= 1099 then
      GameAnalytics:design(player.userId, 1, {
        "Player_damageAI",
        "1000_1099"
      })
    elseif 1100 <= honor or honor <= 1199 then
      GameAnalytics:design(player.userId, 1, {
        "Player_damageAI",
        "1100_1199"
      })
    end
  end
end

function ReportUtil.reportPlayerRank(player, rank)
  if player.rakssid ~= nil and not player.isPartyUser and AIManager:isAI(player.rakssid) ~= true then
    GameAnalytics:design(player.userId, 1, {
      "AI_playerRank",
      tostring(rank)
    })
  end
end

function ReportUtil.reportTotalPacketInfo(player)
  local gameType = BlackBoard:getValue("GameType")
  if not gameType then
    return
  end
  if AIManager:isAI(player.rakssid) then
    return
  end
  local data = DataBuilder.new():fromData(ServerNetwork.Instance():getSendTotalPacketInfo())
  local TotalPacketCount = data:getNumberParam("TotalPacketCount")
  local TotalPacketByte = data:getNumberParam("TotalPacketByte")
  GameAnalytics:design(player.userId, TotalPacketCount, {
    "TotalPacketInfo",
    gameType,
    "PacketCount"
  })
  GameAnalytics:design(player.userId, TotalPacketByte, {
    "TotalPacketInfo",
    gameType,
    "PacketByte"
  })
  GameAnalytics:design(player.userId, os.time() - GameMatch.startGameTime, {
    "TotalPacketInfo",
    gameType,
    "GameTime"
  })
end

function ReportUtil.reportUpdateFeedback(player, isAgree)
  if player.rakssid ~= nil and AIManager:isAI(player.rakssid) ~= true then
    local value = 0
    if isAgree then
      value = 1
    end
    GameAnalytics:design(player.userId, value, {
      "UpdateFeedback",
      "Version" .. GameConfig.updateTipsVersion
    })
  end
end

function ReportUtil.reportBuyCommandSuccess(player, id)
  if player.rakssid ~= nil then
    GameAnalytics:design(player.userId, 1, {
      "get_command",
      tostring(id)
    })
  end
end

function ReportUtil.reportStartTreasure(player, id)
  GameAnalytics:design(player.userId, 1, {
    "G_Treasure_start",
    tostring(id),
    getPlayerLevelInterval(player)
  })
end

function ReportUtil.reportGiveUpTreasure(player, isSuccess, id)
  if isSuccess then
    GameAnalytics:design(player.userId, 1, {
      "G_Treasure_waiver",
      tostring(id),
      getPlayerLevelInterval(player)
    })
  else
    GameAnalytics:design(player.userId, 0, {
      "G_Treasure_waiver",
      tostring(id),
      getPlayerLevelInterval(player)
    })
  end
end

function ReportUtil.reportFinishTreasure(player, id)
  GameAnalytics:design(player.userId, 1, {
    "G_Treasure_finish",
    tostring(id),
    getPlayerLevelInterval(player)
  })
end

function ReportUtil.reportFinishTreasureTime(player, id, days)
  GameAnalytics:design(player.userId, 1, {
    "G_Treasure_finish",
    tostring(id),
    tostring(days)
  })
end

function ReportUtil.reportFinishTreasureTask(player, taskId)
  GameAnalytics:design(player.userId, 1, {
    "Treasure_task",
    tostring(taskId)
  })
end

function ReportUtil.reportBuyLicenseSuccess(player, buyType)
  local Interval = GameLicense:calculateLevelInterval(player.license_level)
  GameAnalytics:design(player.userId, 1, {
    "G_License_buyUp",
    buyType,
    getPlayerLevelInterval(player),
    Interval
  })
end

function ReportUtil.reportPlayerLicenseLvUp(player, level)
  if level == 1 then
    GameAnalytics:design(player.userId, 1, {"License_Lv", 1})
    return
  end
  local Interval, IntervalChange = GameLicense:calculateLevelInterval(level)
  if IntervalChange then
    GameAnalytics:design(player.userId, -1, {"License_Lv", IntervalChange})
    GameAnalytics:design(player.userId, 1, {"License_Lv", Interval})
  end
end

function ReportUtil.reportPlayerBuyLevel(player, level)
  GameAnalytics:design(player.userId, 1, {
    "G_License_buyLv",
    level
  })
end

function ReportUtil.reportPlayerFinishTask(player, taskId)
  local Interval = GameLicense:calculateLevelInterval(player.license_level)
  GameAnalytics:design(player.userId, 1, {
    "G_License_Task",
    taskId,
    Interval
  })
end

function ReportUtil.reportPlayerFinishSeasonTask(player, taskId)
  local Interval = GameLicense:calculateLevelInterval(player.license_level)
  GameAnalytics:design(player.userId, 1, {
    "G_License_SeasonTask",
    taskId,
    Interval
  })
end

function ReportUtil.reportPlayerExchange(player, itemId)
  local Interval = GameLicense:calculateLevelInterval(player.license_level)
  GameAnalytics:design(player.userId, 1, {
    "G_License_swap",
    itemId,
    getPlayerLevelInterval(player),
    Interval
  })
end

function ReportUtil.reportPlayerCostKey(player, number, source, itemId)
  if not source or not itemId then
    return
  end
  GameAnalytics:design(player.userId, number, {
    "PlayerCostKey",
    source,
    itemId
  })
end

function ReportUtil.reportNewPlayerHadOpenLicense(player)
  if player.rakssid ~= nil and AIManager:isAI(player.rakssid) then
    return
  end
  if player.license_isNew == true and player.hadOpenLicense == false then
    player.license_isNew = os.date("%Y-%m-%d")
    GameAnalytics:design(player.userId, 1, {
      "License_NewOpen",
      "AllNum"
    })
  elseif player.license_isNew == true and player.hadOpenLicense == true then
    player.license_isNew = false
    GameAnalytics:design(player.userId, 1, {
      "License_NewOpen",
      "AllNum"
    })
    GameAnalytics:design(player.userId, 1, {
      "License_NewOpen",
      "OpenNum"
    })
  elseif player.license_isNew == os.date("%Y-%m-%d") and player.hadOpenLicense == true then
    player.license_isNew = false
    GameAnalytics:design(player.userId, 1, {
      "License_NewOpen",
      "OpenNum"
    })
  end
end

function ReportUtil.reportPlayerLoginLicenseLevel(player)
  if player.rakssid ~= nil and AIManager:isAI(player.rakssid) ~= true then
    GameAnalytics:design(player.userId, 1, {
      "onLoginLicenseLevel",
      player.license_level
    })
  end
end

function ReportUtil.reportDailyPlayerLevel(player)
  if AIManager:isAI(player.rakssid) ~= true then
    GameAnalytics:design(player.userId, 1, {
      "Player_Level",
      player.level
    })
  end
end

function ReportUtil.reportSettlementResult(player)
  local todayKey = DateUtil.getYearDay()
  if todayKey ~= player.resultDayKey then
    player.resultDayKey = DateUtil.getYearDay()
    GameAnalytics:design(player.userId, 1, {
      "Result_One_Day",
      player.level
    })
  end
  if player.resultGameFirst then
    player.resultGameFirst = false
    GameAnalytics:design(player.userId, 1, {
      "Result_One_Game",
      player.level
    })
  end
end

function ReportUtil.reportSettlementShare(player)
  local todayKey = DateUtil.getYearDay()
  if todayKey ~= player.shareDayKey then
    player.shareDayKey = todayKey
    GameAnalytics:design(player.userId, 1, {
      "Share_One_Day",
      player.level
    })
  end
  if player.shareGameFirst then
    player.shareGameFirst = false
    GameAnalytics:design(player.userId, 1, {
      "Share_One_Game",
      player.level
    })
  end
end

function ReportUtil.reportUseCube(player, goodId, cubeCount)
  local isInFiveMinuteRecharge = os.time() - player.lastRechargeReportTime < 300
  NewReportUtil.report(player, "UseCube", {
    NewReportUtil.getLevelData,
    NewReportUtil.getCountryData,
    NewReportUtil.getGameTimesData,
    NewReportUtil.isFirstConsume,
    NewReportUtil.getHonorData,
    NewReportUtil.getRuneCountData,
    NewReportUtil.getKeyCountData,
    NewReportUtil.getLicenseBuyTypeData,
    NewReportUtil.getLicenseRemainDaysData,
    NewReportUtil.getLicenseLevelData,
    NewReportUtil.getGameRecordData,
    NewReportUtil.getDiamondData,
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {key = "good_id", value = goodId})
      callback(dataList)
    end,
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {key = "good_price", value = cubeCount})
      callback(dataList)
    end,
    NewReportUtil.getGameTimeData,
    NewReportUtil.isHaveBedData,
    NewReportUtil.getTeammateLifeCountData,
    NewReportUtil.getPlayerLifeCountData,
    NewReportUtil.getHealthData,
    NewReportUtil.getKillDieData,
    NewReportUtil.isDieInMinuteData,
    NewReportUtil.getTeamHonorRankData,
    NewReportUtil.getTotalGameTimeData
  }, isInFiveMinuteRecharge and player.lastRechargeReportId or nil, function(reportId, reportTime)
    local goods = StoreConfig:getGoodsById(goodId)
    if goods and goods.Type == GoodsType.Key and reportTime - player.lastBuyKeyReportTime >= 300 then
      player.lastBuyKeyReportTime = reportTime
      player.lastBuyKeyReportId = reportId
    end
    if RespawnConfig:checkIdIsRespawnOrKeepItem(goodId) then
      player.buyRespawnReportId = reportId
    end
  end)
  player.have_cube_order = true
end

function ReportUtil.reportRespawnByCube(player)
  if player.buyRespawnReportId then
    NewReportUtil.report(player, "RespawnByCube", {
      NewReportUtil.getIvnStackCountData,
      NewReportUtil.getArmorData,
      NewReportUtil.getMaxWeaponLevel
    }, player.buyRespawnReportId)
  end
  player.buyRespawnReportId = nil
end

function ReportUtil.reportRechargeCube(player, productId)
  NewReportUtil.report(player, "RechargeCube", {
    NewReportUtil.getLevelData,
    NewReportUtil.getCountryData,
    NewReportUtil.getGameTimesData,
    NewReportUtil.isFirstRecharge,
    NewReportUtil.getHonorData,
    NewReportUtil.getRuneCountData,
    NewReportUtil.getKeyCountData,
    NewReportUtil.getLicenseBuyTypeData,
    NewReportUtil.getLicenseRemainDaysData,
    NewReportUtil.getLicenseLevelData,
    NewReportUtil.getGameRecordData,
    NewReportUtil.getDiamondData,
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {
        key = "recharge_productId",
        value = productId
      })
      callback(dataList)
    end,
    NewReportUtil.getGameTimeData,
    NewReportUtil.isHaveBedData,
    NewReportUtil.getTeammateLifeCountData,
    NewReportUtil.getPlayerLifeCountData,
    NewReportUtil.getHealthData,
    NewReportUtil.getKillDieData,
    NewReportUtil.isDieInMinuteData,
    NewReportUtil.getTeamHonorRankData,
    NewReportUtil.getTotalGameTimeData
  }, nil, function(reportId, reportTime)
    if os.time() - player.lastRechargeReportTime > 300 then
      player.lastRechargeReportTime = reportTime
      player.lastRechargeReportId = reportId
    end
  end)
end

function ReportUtil.reportCostKey(player, type, price)
  type = type or "undefined"
  price = price or 0
  if price <= 0 then
    return
  end
  local isInFiveMinuteBuyKey = os.time() - player.lastBuyKeyReportTime < 300
  NewReportUtil.report(player, "UseKey", {
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {key = "good_type", value = type})
      callback(dataList)
    end,
    function(_, callback)
      local dataList = {}
      table.insert(dataList, {key = "good_price", value = price})
      callback(dataList)
    end
  }, isInFiveMinuteBuyKey and player.lastBuyKeyReportId or nil)
end

function ReportUtil.reportPlaceBlock(player)
  local event_map = {}
  event_map.placeBlockNumByButton = player.placeBlockNumByButton
  event_map.placeBlockNumByOther = player.placeBlockNum - player.placeBlockNumByButton
  GameAnalytics:newDesign(player.userId, "PlaceBlock", event_map)
end

return ReportUtil

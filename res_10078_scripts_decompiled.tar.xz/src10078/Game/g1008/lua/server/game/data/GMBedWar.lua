function GMHelper:addGameItem(player, itemId)
  player:addItem(itemId, 64)
end

function GMHelper:teleTeamPos(player, teamId)
  local config = TeamConfig:getTeam(teamId)
  if config then
    player:teleportPos(config.initPos)
  end
end

function GMHelper:destroyBed(player, teamId)
  local team = GameMatch.Teams[teamId]
  if not team then
    return
  end
  if not team.isHaveBed then
    return
  end
  for _, bedPos in pairs(team.bedPos) do
    EngineWorld:setBlock(bedPos, 0)
  end
  team:destroyBed(player)
  player:onDestroyBed(team)
end

function GMHelper:destroyAllBed(player)
  for _, team in pairs(GameMatch.Teams) do
    if team.isHaveBed then
      for _, bedPos in pairs(team.bedPos) do
        EngineWorld:setBlock(bedPos, 0)
      end
      team:destroyBed(player)
      player:onDestroyBed(team)
    end
  end
end

function GMHelper:killSelf(player)
  player:subHealth(10000)
end

function GMHelper:killPlayer(player)
  local players = PlayerManager:getPlayers()
  for _, _player in pairs(players) do
    if _player.realLife and _player.teamId ~= player.teamId then
      _player:subHealth(10000)
      break
    end
  end
end

function GMHelper:killAllPlayer(player)
  local players = PlayerManager:getPlayers()
  for _, _player in pairs(players) do
    if _player.realLife and _player.teamId ~= player.teamId then
      _player:subHealth(10000)
    end
  end
end

function GMHelper:addExp(player)
  local _, is_max = ExpConfig:getMaxExp(player.level)
  if not is_max then
    player:addExp(50)
  end
end

function GMHelper:startGame(player)
  GameConfig.startPlayers = TableUtil.getTableSize(PlayerManager:getPlayers())
  GameConfig.waitingPlayerTime = 1
  GameConfig.waitingPlayerTime2 = 1
  GameConfig.prepareTime = 1
end

function GMHelper:changeHelmet(player)
  local helmetIds = {
    701,
    705,
    709,
    713,
    2056,
    2060,
    2064,
    2068
  }
  for helmetId = 717, 736 do
    table.insert(helmetIds, helmetId)
  end
  for helmetId = 2257, 2280 do
    table.insert(helmetIds, helmetId)
  end
  for helmetId = 737, 760 do
    table.insert(helmetIds, helmetId)
  end
  local inv = player:getInventory()
  local itemId = inv:getItemStackInfo(100).id
  for pos, helmetId in pairs(helmetIds) do
    if itemId == helmetId then
      pos = pos % #helmetIds
      pos = pos + 1
      player.entityPlayerMP:replaceArmorItemWithEnchant(helmetIds[pos] or 0, 1, 0, {})
      break
    end
  end
end

function GMHelper:cleanYaoShi(player)
  player.yaoshi = 0
  CommonPacketSender:sendBedWarPlayerMoneyCount(player.rakssid, Define.Money.KEY, player.yaoshi)
end

function GMHelper:addMonster(player)
  MonsterManager:createMonster(player:getPosition(), Define.MonsterType.ServerMonster)
end

function GMHelper:clearMonster(player)
  MonsterManager:clearMonster()
end

function GMHelper:addBanCureBuff(player)
  BuffManager:createBuff(player.userId, 1)
end

function GMHelper:addBackHomeBuff(player)
  BuffManager:createBuff(player.userId, 2)
end

function GMHelper:SnowBallInsect(player)
  if MonsterManager:createMonster(player:getPosition(), Define.MonsterType.SnowBallInsect, player) == false then
    MessagesManage:sendSystemTipsToPlayer(player.rakssid, Messages:msgSummonsNumLimit())
  end
end

function GMHelper:equipSkatingShoes(player)
  player:tryAddItem(1000, 1)
end

function GMHelper:equipNinjaShoes(player)
  player:tryAddItem(Define.ItemId.NinjaShoes, 1)
end

function GMHelper:addFishHook(player)
  player:tryAddItem(346, 1)
end

function GMHelper:addCrossbow(player)
  player:addGunItem(3576, 1, 0, 1000)
end

function GMHelper:addCrossbowArrow(player, gunId, buyCount)
  buyCount = buyCount or 1
  local needCount = 0
  local info = InventoryUtil:getPlayerInventoryInfo(player)
  local setting = GunSetting.getGunSetting(gunId)
  local maxBulletNum = tonumber(setting.maxBulletNum)
  for _, gun in pairs(info.gun) do
    if gun.id == gunId then
      needCount = needCount + (maxBulletNum - gun.bullets)
    end
  end
  if buyCount > needCount then
    MessagesManage:sendSystemTipsToPlayer(player.rakssid, Messages:msgCanNotBuyCrossbowArrow())
    return false
  end
  for _, gun in pairs(info.gun) do
    local curBullets = gun.bullets
    if gun.id == gunId and maxBulletNum > curBullets then
      local addCount = 0
      if buyCount > maxBulletNum - curBullets then
        addCount = maxBulletNum - curBullets
      else
        addCount = buyCount
      end
      player:replaceItem(gunId, 1, 0, gun.stackIndex, curBullets + addCount)
      buyCount = buyCount - addCount
      if buyCount <= 0 then
        return true
      end
    end
  end
end

function GMHelper:addWaterBall(player)
  player:tryAddItem(595, 1)
end

function GMHelper:addBridgeEgg(player)
  player:tryAddItem(594, 1)
end

function GMHelper:addEnderDragon(player)
  player:tryAddItem(593, 1)
end

function GMHelper:addWithered(player)
  player:tryAddItem(592, 1)
end

function GMHelper:addBackPearl(player)
  player:tryAddItem(591, 1)
end

function GMHelper:addHollowBlock(player)
  player:tryAddItem(590, 1)
end

function GMHelper:addDoubleDummy(player)
  player:tryAddItem(ItemID.DOUBLE_DUMMY, 1)
end

function GMHelper:add585(player)
  player:tryAddItem(585, 1)
end

function GMHelper:add584(player)
  player:tryAddItem(584, 1)
end

function GMHelper:add583(player)
  player:tryAddItem(583, 1)
end

function GMHelper:resetSurvey(player)
  player.had_survey = false
  for itemId, times in pairs(player.game_survey) do
    GamePacketSender:sendSurveyUseItemTimes(player.rakssid, itemId, times)
  end
  player.game_survey = {}
  player.survey_player_times = 0
  SurveyManager:onPlayerLogin(player)
end

function GMHelper:addOldHorn100(player)
  SeasonManager:addUserHonor(player.userId, 100, player.level)
end

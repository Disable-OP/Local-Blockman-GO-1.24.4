GameResourcePoint = class("GameResourcePoint")

function GameResourcePoint:ctor(pointId)
  self.pointId = pointId
  self.resourceConfigs = {}
  self.curLevel = {}
  self.producePos = self.producePos or {}
  self.spawnKey = {}
  local pointConfig = ResourcePointConfig:getConfigById(pointId)
  self.producePos[1] = pointConfig.producePos1
  self.producePos[2] = pointConfig.producePos2
  for _, typeId in pairs(pointConfig.resourceList) do
    table.insert(self.resourceConfigs, ResourceTypeConfig:getConfigByType(typeId))
    self.curLevel[tostring(typeId)] = 1
  end
end

function GameResourcePoint:getProducePos()
  return self.producePos[1]
end

function GameResourcePoint:onUpgrade()
  for index, _ in pairs(self.curLevel) do
    self.curLevel[index] = self.curLevel[index] + 1
  end
  self:setSpawnLuaTimer()
end

function GameResourcePoint:onGameStart()
  for _, config in pairs(self.resourceConfigs) do
    self:onPointLevelUp(config, 1)
    self:setSpawnLuaTimer()
  end
end

function GameResourcePoint:onPointLevelUp(config, curLevel)
  if config.levelUp[curLevel + 1] ~= nil then
    LuaTimer:schedule(function()
      if config.levelUp[curLevel] ~= nil then
        self.curLevel[config.type] = curLevel + 1
        self:setSpawnLuaTimer()
        self:onPointLevelUp(config, self.curLevel[config.type])
      end
    end, config.levelUp[curLevel + 1] * 1000)
  end
end

function GameResourcePoint:setSpawnLuaTimer()
  for _, key in pairs(self.spawnKey) do
    LuaTimer:cancel(key)
  end
  local initPos = self:getProducePos()
  for _, config in pairs(self.resourceConfigs) do
    local level = self.curLevel[tostring(config.type)]
    local key = LuaTimer:scheduleTimer(function()
      local motion = VectorUtil.newVector3(0, 0, 0)
      local entityId = EngineWorld:addEntityItem(config.itemId, config.output[level], 0, config.life[level], initPos, motion)
      GameResourceManager:addResourceCache(config.itemId, entityId)
    end, tonumber(config.interval[level]) * 1000)
    table.insert(self.spawnKey, key)
  end
end

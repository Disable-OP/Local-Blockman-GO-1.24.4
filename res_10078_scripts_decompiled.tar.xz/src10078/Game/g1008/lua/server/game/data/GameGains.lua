GameGains = {}

function GameGains:onPlayerUpgrade(player, gainId, level)
  local team = GameMatch.Teams[player:getTeamId()]
  if not team or not team.info then
    return false
  end
  local gains = GainsConfig:getTeamGains()
  for _, gain in pairs(gains) do
    if gain.id == tostring(gainId) then
      if level <= tonumber(team.info:getValue(gain.id)) then
        return false
      else
        team.info:setValue(gain.id, level)
        gain:onPlayerUpgrade(player)
        return true
      end
    end
  end
  return false
end

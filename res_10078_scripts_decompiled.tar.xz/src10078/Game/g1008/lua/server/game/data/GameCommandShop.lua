GameCommandShop = {}

local function checkPlayerAndCommand(userId, messageId)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local command = CommandSettingConfig:getConfigById(messageId)
  if not command then
    return
  end
  return player, command
end

function GameCommandShop:init()
  EventObservable:registerDataCallBack("BuyCommandGoods", function(userId, messageId)
    local player, command = checkPlayerAndCommand(userId, messageId)
    if not player then
      return
    end
    GameCommandShop:onBuyCommand(player, command)
  end)
end

function GameCommandShop:onBuyCommand(player, command)
  if player.command_list[tostring(command.id)] ~= nil then
    return
  end
  if command.currencyId == Define.Money.DIAMOND then
    if not MoneyUtil:checkHasMoney(player, Define.Money.DIAMOND, command.price) then
      return
    end
    PayHelper.payDiamondsSync(player.userId, command.id, command.price, function()
      self:onBuySuccess(player, command.id)
    end)
  elseif command.currencyId == Define.Money.KEY then
    if not MoneyUtil:checkHasMoney(player, Define.Money.KEY, command.price) then
      return
    end
    if player:subYaoShi(command.price, "key_CommandShop", command.id) then
      self:onBuySuccess(player, command.id)
    end
  end
end

function GameCommandShop:onBuySuccess(player, commandId)
  player.command_list[tostring(commandId)] = commandId
  GameCommandShop:onPlayerCommandListChange(player, {commandId})
  GamePacketSender:sendBuyCommandSuccess(player.rakssid, commandId)
  ReportUtil.reportBuyCommandSuccess(player, commandId)
end

function GameCommandShop:onSyncPlayerCommandList(player)
  local result = {}
  for _, commandId in pairs(player.command_list) do
    table.insert(result, commandId)
  end
  if 0 < #result then
    self:onPlayerCommandListChange(player, result)
  end
end

function GameCommandShop:onPlayerCommandListChange(player, commandList)
  GamePacketSender:sendCommandListData(player.rakssid, commandList)
end

GameTeamResource = class("GameTeamResource", GameResourcePoint)

function GameTeamResource:ctor(pointId)
  self.pointId = pointId
  self.resourceConfigs = {}
  self.curLevel = {}
  self.producePos = self.producePos or {}
  self.spawnKey = {}
  local pointConfig = ResourcePointConfig:getConfigById(pointId)
  self.producePos[1] = pointConfig.producePos1
  self.producePos[2] = pointConfig.producePos2
  self.resourcesInfo = {}
  for _, type in pairs(pointConfig.resourceList) do
    local config = ResourceTypeConfig:getConfigByType(type)
    table.insert(self.resourceConfigs, config)
    self.curLevel[tostring(type)] = 1
  end
  self.playerInArea = {}
  self:initPointRange()
end

function GameTeamResource:initPointRange()
  self.minX = math.min(self.producePos[1].x, self.producePos[2].x)
  self.maxX = math.max(self.producePos[1].x, self.producePos[2].x)
  self.minY = math.min(self.producePos[1].y, self.producePos[2].y)
  self.maxY = math.max(self.producePos[1].y, self.producePos[2].y)
  self.minZ = math.min(self.producePos[1].z, self.producePos[2].z)
  self.maxZ = math.max(self.producePos[1].z, self.producePos[2].z)
end

function GameTeamResource:onGameStart()
  self:setSpawnLuaTimer()
end

function GameTeamResource:setSpawnLuaTimer()
  GamePacketSender:onTeamResourceUpgrade(self.pointId)
  for _, key in pairs(self.spawnKey) do
    LuaTimer:cancel(key)
  end
  for _, config in pairs(self.resourceConfigs) do
    local level = self.curLevel[tostring(config.type)]
    local key = LuaTimer:scheduleTimer(function()
      if #self.playerInArea >= 1 then
        for _, c_player in pairs(self.playerInArea) do
          local player = PlayerManager:getPlayerByUserId(c_player)
          if player then
            player:addItem(config.itemId, config.output[level], 0)
          end
        end
      else
        local itemInfo = {
          itemId = config.itemId,
          buildTime = os.time(),
          lifeTime = config.life[level]
        }
        table.insert(self.resourcesInfo, itemInfo)
      end
    end, tonumber(config.interval[level]) * 1000, 100000)
    table.insert(self.spawnKey, key)
  end
end

function GameTeamResource:onGameStart()
  self:setSpawnLuaTimer()
end

function GameTeamResource:onPlayerIntoTeamResource(player)
  local haveGet = false
  for _, info in pairs(self.resourcesInfo) do
    if info.lifeTime >= os.time() - info.buildTime then
      haveGet = true
      player:addItem(info.itemId, 1, 0)
    end
  end
  self.resourcesInfo = {}
  GamePacketSender:sendPlayerIntoTeamResource(player.userId, self.pointId)
  return haveGet
end

BanCureBuff = class("BanCureBuff", BaseBuff)

function BanCureBuff:onCreate()
  local player = PlayerManager:getPlayerByUserId(self.ownerId)
  player.banCureBuff = true
end

function BanCureBuff:onTimesUp()
  local player = PlayerManager:getPlayerByUserId(self.ownerId)
  player.banCureBuff = false
end

return BanCureBuff

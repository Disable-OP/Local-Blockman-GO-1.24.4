BaseBuff = class()

function BaseBuff:ctor(config, ownerId, id)
  self.ownerId = tostring(ownerId)
  self.id = id
  self.type = config.type
  self.duration = config.duration
  self.value = config.value
  self.timeInterval = config.timeInterval
  self.endValue = config.endValue
  self.deadDisappear = config.deadDisappear
  self.overlayRule = config.overlayRule
  self.createTime = os.time()
  self.lifetime = 0
  self.resetAddTime = 0
  self:onCreate(ownerId)
  table.insert(BuffManager.playersBuff[tostring(ownerId)][self.type], self)
  self:synBuffTimeInfo(self.id, self.ownerId, self.duration)
end

function BaseBuff:onTick(tick)
  self.lifetime = self.lifetime + 1
  self.resetAddTime = self.resetAddTime + 1
  if self.timeInterval ~= 0 and self.lifetime % self.timeInterval == 0 then
    self:onAction()
  end
  if self.lifetime >= self.duration then
    self:onTimesUp()
    self:onRemove()
  end
end

function BaseBuff:onCreate(ownerId)
end

function BaseBuff:onTimesUp()
end

function BaseBuff:onInterrupt()
end

function BaseBuff:onAction()
end

function BaseBuff:onPlayerDead()
  if self.deadDisappear == 1 then
    self:synBuffTimeInfo(self.id, self.ownerId, 0)
  end
end

function BaseBuff:addTime(time)
  self.duration = self.duration + time
  self:synBuffTimeInfo(self.id, self.ownerId, self.duration)
end

function BaseBuff:onRemove()
  BuffManager:removeBuff(self.ownerId, self.type, self.id)
  self:synBuffTimeInfo(self.id, self.ownerId, 0)
end

function BaseBuff:resetTime()
  self.duration = self.duration + self.resetAddTime
  self:synBuffTimeInfo(self.id, self.ownerId, self.resetAddTime)
  self.resetAddTime = 0
end

function BaseBuff:synBuffTimeInfo(buffId, userId, duration)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player then
    GamePacketSender:sendBuffInfo(player.rakssid, buffId, self.type, duration)
  end
end

return BaseBuff

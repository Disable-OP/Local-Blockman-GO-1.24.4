SpeedBuff = class("AddSpeedBuff", BaseBuff)

function SpeedBuff:onCreate()
  local buffConfig = BuffConfig:getBuffByType(BuffManager.BuffType.Speed)
  local player = PlayerManager:getPlayerByUserId(self.ownerId)
  if player and buffConfig then
    player:changeSpeed(buffConfig.value)
  end
end

function SpeedBuff:onTimesUp()
  local buffConfig = BuffConfig:getBuffByType(BuffManager.BuffType.Speed)
  local player = PlayerManager:getPlayerByUserId(self.ownerId)
  if player and buffConfig then
    player:changeSpeed(-buffConfig.value)
  end
end

return SpeedBuff

BackHomeBuff = class("BackHomeBuff", BaseBuff)

function BackHomeBuff:onInterrupt()
  self:onRemove()
end

function BackHomeBuff:onTimesUp()
  local player = PlayerManager:getPlayerByUserId(self.ownerId)
  if not player then
    return
  end
  local teamId = player:getTeamId()
  local config = TeamConfig:getTeam(teamId)
  if config then
    player:teleportPos(config.initPos)
    player:removeItem(ItemID.BackHomeReel, 1)
  end
end

return BackHomeBuff

BackHallManager = {}
BackHallManager.players = {}

function BackHallManager:addPlayer(player)
  EngineUtil.sendEnterOtherGame(player.rakssid, "g1046", player.userId)
  self.players[tostring(player.userId)] = {
    time = os.time()
  }
end

function BackHallManager:onTick()
  self:checkPlayers()
  self:tryPlayerMatching()
end

function BackHallManager:checkPlayers()
  for userId, player in pairs(self.players) do
    if PlayerManager:getPlayerByUserId(player.userId) == nil then
      self.players[userId] = nil
    end
  end
end

function BackHallManager:tryPlayerMatching()
  for userId, player in pairs(self.players) do
    if os.time() - player.time > 10 then
      player.time = os.time()
      local c_player = PlayerManager:getPlayerByUserId(userId)
      if c_player ~= nil then
        EngineUtil.sendEnterOtherGame(c_player.rakssid, "g1046", c_player.userId)
      end
    end
  end
end

return BackHallManager

local SurveyManager = {}
local SurveyMinUseItems = 8
local SurveyMinPlayGames = 5

function SurveyManager:onPlayerLogin(player)
  if player.had_survey or AIManager:isAI(player.rakssid) then
    return
  end
  local allTask = SurveyConfig:getAllTask()
  for _, task in pairs(allTask) do
    if task.type == Define.SurveyTaskType.UseItem then
      if player.game_survey[tostring(task.itemId)] == nil then
        player.game_survey[tostring(task.itemId)] = 0
      elseif player.game_survey[tostring(task.itemId)] > 0 then
        GamePacketSender:sendSurveyUseItemTimes(player.rakssid, task.itemId, player.game_survey[tostring(task.itemId)])
      end
    end
  end
  GamePacketSender:sendShowSurveyEntrance(player.rakssid)
end

function SurveyManager:onPlayerGetItem(player, itemId)
  if player.had_survey or AIManager:isAI(player.rakssid) then
    return
  end
  if player.game_survey and player.game_survey[tostring(itemId)] then
    player.game_survey[tostring(itemId)] = player.game_survey[tostring(itemId)] + 1
    GamePacketSender:sendSurveyUseItemTimes(player.rakssid, itemId, player.game_survey[tostring(itemId)])
  end
end

function SurveyManager:onPlayerPushSurveySuccess(player)
  if player.had_survey or AIManager:isAI(player.rakssid) then
    return
  end
  player.had_survey = true
  player:addFakeDiamonds(100)
end

function SurveyManager:onGameEnd(player)
  if player.had_survey or AIManager:isAI(player.rakssid) or player.survey_player_times == nil then
    return
  end
  player.survey_player_times = player.survey_player_times + 1
  local curUseItemNum = SurveyConfig:getNeedUseItemTaskNum()
  local totalUseItemNum = 0
  for _, useTimes in pairs(player.game_survey) do
    if 0 < useTimes then
      totalUseItemNum = totalUseItemNum + 1
    end
  end
  if curUseItemNum == totalUseItemNum or curUseItemNum >= SurveyMinUseItems and player.survey_player_times >= SurveyMinPlayGames then
    GamePacketSender:sendShowSurvey(player.rakssid)
  end
end

return SurveyManager

BuffManager = {}
BuffManager.BuffType = {
  BanCure = 1,
  BackHome = 2,
  Speed = 3,
  LockHollowBlock = 4
}
BuffManager.BuffMap = {
  [BuffManager.BuffType.BanCure] = BanCureBuff,
  [BuffManager.BuffType.BackHome] = BackHomeBuff,
  [BuffManager.BuffType.Speed] = SpeedBuff,
  [BuffManager.BuffType.LockHollowBlock] = BaseBuff
}
BuffManager.playersBuff = {}
BuffManager.buffId = 0

function BuffManager:createBuff(userId, buffType)
  local buffConfig = BuffConfig:getBuffByType(buffType)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not buffConfig or not player then
    return
  end
  local Buff = self.BuffMap[buffConfig.type]
  if not Buff then
    return
  end
  if not self.playersBuff[tostring(userId)] then
    self.playersBuff[tostring(userId)] = {}
  end
  if not self.playersBuff[tostring(userId)][buffType] or TableUtil.getTableSize(self.playersBuff[tostring(userId)][buffType]) == 0 then
    self.buffId = self.buffId + 1
    self.playersBuff[tostring(userId)][buffType] = {}
    Buff.new(buffConfig, userId, self.buffId)
  elseif buffConfig.overlayType == 1 then
    for _, buff in pairs(self.playersBuff[tostring(userId)][buffType]) do
      buff:resetTime()
    end
  elseif buffConfig.overlayType == 2 then
    for _, buff in pairs(self.playersBuff[tostring(userId)][buffType]) do
      buff:addTime(buffConfig.duration)
    end
  elseif buffConfig.overlayType == 3 then
    self.buffId = self.buffId + 1
    Buff.new(buffConfig, userId, self.buffId)
  end
end

function BuffManager:checkBuff(userId, buffType)
  self.playersBuff[tostring(userId)] = self.playersBuff[tostring(userId)] or {}
  local buff_list = self.playersBuff[tostring(userId)][buffType]
  if buff_list and 0 < #buff_list then
    return true
  end
  return false
end

function BuffManager:onTick(tick)
  for _, playerBuffs in pairs(self.playersBuff) do
    for _, buffs in pairs(playerBuffs) do
      for index, buff in pairs(buffs) do
        buff:onTick(tick)
      end
    end
  end
end

function BuffManager:onPlayerDead(userId)
  for UID, playerBuffs in pairs(self.playersBuff) do
    if UID == tostring(userId) then
      for BID, buffs in pairs(playerBuffs) do
        local buffConfig = BuffConfig:getBuffByType(BID)
        if buffConfig.deadDisappear == 1 then
          for _, buff in pairs(buffs) do
            buff:onRemove()
          end
        end
      end
    end
  end
end

function BuffManager:onPlayerByInterrupt(userId)
  local player = PlayerManager:getPlayerByUserId(userId)
  if player then
    player:breakSinging()
  end
  for UID, playerBuffs in pairs(self.playersBuff) do
    if UID == tostring(userId) then
      for BID, buffs in pairs(playerBuffs) do
        for _, buff in pairs(buffs) do
          buff:onInterrupt()
        end
      end
    end
  end
end

function BuffManager:cleanPlayerBuff(userId)
  for Index, playerBuffs in pairs(self.playersBuff) do
    if Index == tostring(userId) then
      playerBuffs = {}
    end
  end
end

function BuffManager:removeBuff(userId, buffType, buffId)
  local buffConfig = BuffConfig:getBuffByType(buffType)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not buffConfig or not player then
    return
  end
  if TableUtil.getTableSize(self.playersBuff[tostring(userId)][buffType]) == 1 then
    self.playersBuff[tostring(userId)][buffType] = {}
  else
    for index, buff in pairs(self.playersBuff[tostring(userId)][buffType]) do
      if buff.id == buffId then
        self.playersBuff[tostring(userId)][buffType][index] = nil
        table.remove(self.playersBuff[tostring(userId)][buffType], index)
        break
      end
    end
  end
end

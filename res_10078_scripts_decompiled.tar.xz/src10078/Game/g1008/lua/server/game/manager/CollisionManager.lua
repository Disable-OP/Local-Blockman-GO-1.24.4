CollisionManager = {}
CollisionManager.Collisions = {}
CollisionManager.CollisionType = {
  Mount = 1,
  Player = 2,
  Block = 3
}
CollisionManager.CollisionRange = {
  {
    x = 3,
    y = 3,
    z = 3
  },
  {
    x = 0.4,
    y = 0.9,
    z = 0.4
  },
  {
    x = 0.5,
    y = 0.5,
    z = 0.5
  }
}

function CollisionManager:addCollision(entityId, position, type, needArea, teamId, userId)
  local collision = Collision.new(entityId, position, type, needArea or false, teamId or 0, userId or 0)
  self.Collisions[tostring(entityId)] = collision
end

function CollisionManager:removeCollision(entityId)
  if self.Collisions[tostring(entityId)] ~= nil then
    self.Collisions[tostring(entityId)] = nil
  end
end

function CollisionManager:checkCollision(ticks)
  for _, collision in pairs(self.Collisions) do
    if collision ~= nil then
      collision:checkCollisionArea(ticks)
    end
  end
end

function CollisionManager:getCollisionRangeByType(type)
  local range = self.CollisionRange[type]
  if range == nil then
    range = self.CollisionRange[self.CollisionType.Block]
  end
  return range
end

return CollisionManager

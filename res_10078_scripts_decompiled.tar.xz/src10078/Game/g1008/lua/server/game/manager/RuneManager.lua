RuneManager = {}
RuneManager.playersRune = {}

local function callRuneFunction(player, funcName, probability, ...)
  local runes = RuneManager.playersRune[tostring(player.userId)]
  if not runes then
    return
  end
  local sumProbability = {}
  for _, rune in pairs(runes) do
    if probability and rune.probability ~= nil and rune[funcName] ~= nil then
      if sumProbability[tonumber(rune.id)] == nil then
        sumProbability[tonumber(rune.id)] = {
          probability = rune.probability
        }
      else
        sumProbability[tonumber(rune.id)].probability = sumProbability[rune.id].probability + rune.probability
      end
    else
      local func = rune[funcName]
      if type(func) == "function" then
        func(rune, player, ...)
      end
    end
  end
  if probability then
    for id, p in pairs(sumProbability) do
      for _, rune in pairs(runes) do
        if rune.id == id then
          local func = rune[funcName]
          if type(func) == "function" then
            func(rune, player, p, ...)
          end
          break
        end
      end
    end
  end
end

function RuneManager:onPlayerInitRune(player)
  local playerRune = {}
  for i, rune in pairs(player.equip_rune) do
    table.insert(playerRune, RuneSetting.runesConfig[tonumber(rune.id)])
  end
  self.playersRune[tostring(player.userId)] = playerRune
  RuneManager:onInit(player)
end

function RuneManager:onAttack(player, Value, damageType, hurter)
  callRuneFunction(player, "onAttack", true, Value, damageType, hurter)
end

function RuneManager:onInit(player)
  callRuneFunction(player, "onInit")
end

function RuneManager:onKill(player)
  callRuneFunction(player, "onKill", true)
end

function RuneManager:onTick(player, ticks)
  callRuneFunction(player, "onTick", false, ticks)
end

function RuneManager:onHurted(player, value)
  callRuneFunction(player, "onHurted", false, value)
end

function RuneManager:onRespawn(player)
  callRuneFunction(player, "onRespawn")
end

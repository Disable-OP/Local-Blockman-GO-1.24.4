local SkillManager = {}
SkillManager.SkillType = {
  WaterBall = "1",
  BridgeEgg = "6",
  EnderDragon = "8",
  Withered = "9",
  BackPearl = "10",
  FireBomb = "11",
  EnderPearl = "12",
  DropTNTSkill = "15",
  RescueSkill = "17",
  VoodooPotion = "18",
  TownPortal = "19",
  IronPuppet = "20",
  SnowBallInsect = "21",
  Alarm = "22",
  DoubleDummy = "23",
  DiamondMine = "24",
  FrozenClip = "25",
  DoubleDummyTeleport = "26"
}
SkillManager.SkillMapping = {}
SkillManager.SkillMapping[SkillManager.SkillType.WaterBall] = require("game.skill.WaterBallSkill")
SkillManager.SkillMapping[SkillManager.SkillType.BridgeEgg] = require("game.skill.BridgeEggSkill")
SkillManager.SkillMapping[SkillManager.SkillType.EnderDragon] = require("game.skill.EnderDragonSkill")
SkillManager.SkillMapping[SkillManager.SkillType.Withered] = require("game.skill.WitheredSkill")
SkillManager.SkillMapping[SkillManager.SkillType.BackPearl] = require("game.skill.BackPearlSkill")
SkillManager.SkillMapping[SkillManager.SkillType.FireBomb] = require("game.skill.FireBombSkill")
SkillManager.SkillMapping[SkillManager.SkillType.EnderPearl] = require("game.skill.EnderPearlSkill")
SkillManager.SkillMapping[SkillManager.SkillType.DropTNTSkill] = require("game.skill.DropTNTSkill")
SkillManager.SkillMapping[SkillManager.SkillType.RescueSkill] = require("game.skill.RescueSkill")
SkillManager.SkillMapping[SkillManager.SkillType.VoodooPotion] = require("game.skill.VoodooPotionsSkill")
SkillManager.SkillMapping[SkillManager.SkillType.TownPortal] = require("game.skill.TownPortalSkill")
SkillManager.SkillMapping[SkillManager.SkillType.IronPuppet] = require("game.skill.IronPuppetSkill")
SkillManager.SkillMapping[SkillManager.SkillType.SnowBallInsect] = require("game.skill.SnowBallInsectSkill")
SkillManager.SkillMapping[SkillManager.SkillType.Alarm] = require("game.skill.AlarmSkill")
SkillManager.SkillMapping[SkillManager.SkillType.DoubleDummy] = require("game.skill.DoubleDummySkill")
SkillManager.SkillMapping[SkillManager.SkillType.DiamondMine] = require("game.skill.DiamondMineSkill")
SkillManager.SkillMapping[SkillManager.SkillType.FrozenClip] = require("game.skill.FrozenClipSkill")
SkillManager.SkillMapping[SkillManager.SkillType.DoubleDummyTeleport] = require("game.skill.DoubleDummyTeleportSkill")
SkillManager.HashCode = 1
SkillManager.Skills = {}

function SkillManager:createSkill(config, player, position, itemEntityId)
  if not GameMatch.allowPvp then
    return
  end
  local skill = SkillManager.SkillMapping[config.type]
  if skill ~= nil then
    AnalyticsReportUtil.onPlayerUseItem(player, config.itemId)
    skill.new(config, player, position, itemEntityId)
  else
    print("skill is nil, type: " .. config.type)
  end
end

function SkillManager:addSkill(skill)
  local uniqueId = tostring(self.HashCode)
  skill.uniqueId = uniqueId
  self.Skills[uniqueId] = skill
  self.HashCode = self.HashCode + 1
end

function SkillManager:onTick(tick)
  for uniqueId, skill in pairs(self.Skills) do
    skill:onTick(tick)
  end
end

function SkillManager:removeSkill(skill)
  if skill.uniqueId then
    self.Skills[skill.uniqueId] = nil
  end
end

function SkillManager:clearSkill()
  for i, skill in pairs(self.Skills) do
    skill = nil
  end
  self.Skills = {}
  self.HashCode = 1
end

function SkillManager:checkTopAreaIsAir(position)
  local first = VectorUtil.newVector3i(position.x, position.y + 1, position.z)
  local second = VectorUtil.newVector3i(position.x, position.y + 2, position.z)
  if EngineWorld:getBlockId(first) == BlockID.AIR and EngineWorld:getBlockId(second) == BlockID.AIR then
    return true, first
  end
  return false, first
end

return SkillManager

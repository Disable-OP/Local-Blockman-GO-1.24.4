MonsterManager = {}
local MonsterMap = {
  [Define.MonsterType.IronGolem] = require("game.entity.summon.IronGolem"),
  [Define.MonsterType.SnowBallInsect] = require("game.entity.summon.SnowBallInsect"),
  [Define.MonsterType.Alarm] = require("game.entity.summon.Alarm"),
  [Define.MonsterType.DoubleDummy] = require("game.entity.summon.DoubleDummy"),
  [Define.MonsterType.DiamondMine] = require("game.entity.summon.DiamondMine"),
  [Define.MonsterType.FrozenClip] = require("game.entity.summon.FrozenClip")
}
local Monsters = {}
LuaTimer:scheduleTimer(function()
  for _, monster in pairs(Monsters) do
    monster:onUpdate()
  end
end, 100)

function MonsterManager:createMonster(position, type, player, ...)
  local config = MonsterConfig:getConfigByType(type)
  if config and self:getMonsterNum(type, player) < config.maxNum then
    local monsterClass = MonsterMap[type]
    if monsterClass then
      monsterClass.new(position, config, player, ...)
      return true
    end
  end
  player:sendPacket({
    pid = "ShowGameTip",
    lang = "prop.common.tip.num.limit"
  })
  return false
end

function MonsterManager:addMonster(monster)
  Monsters[tostring(monster.entityId)] = monster
end

function MonsterManager:removeMonster(monster)
  Monsters[tostring(monster.entityId)] = nil
end

function MonsterManager:getMonster(entityId)
  return Monsters[tostring(entityId)]
end

function MonsterManager:getMonsterNum(type, player)
  local num = 0
  for _, monster in pairs(Monsters) do
    if type == monster.config.type and monster.creator == player then
      num = num + 1
    end
  end
  return num
end

function MonsterManager:checkInBlock(player, itemId, blockPos)
  for _, monster in pairs(Monsters) do
    monster:checkInBlock(player, itemId, blockPos)
  end
end

function MonsterManager:clearMonster()
  local monsters = {}
  for _, monster in pairs(Monsters) do
    table.insert(monsters, monster)
  end
  for _, monster in pairs(monsters) do
    monster:setDead()
  end
  Monsters = {}
end

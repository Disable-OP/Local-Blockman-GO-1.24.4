GameResourceManager = {}
GameResourceManager.ResourcePoint = {}
GameResourceManager.ResourceCache = {
  [ItemID.DIAMOND] = {},
  [ItemID.EMERALD] = {}
}

function GameResourceManager:newPublicResource(pointId)
  local point = GameResourcePoint.new(pointId)
  self.ResourcePoint[tostring(pointId)] = point
end

function GameResourceManager:newTeamResource(pointId)
  local point = GameTeamResource.new(pointId)
  self.ResourcePoint[tostring(pointId)] = point
end

function GameResourceManager:synTeamResource(player)
  local result = {}
  for i, resource in pairs(self.ResourcePoint) do
    if resource.resourcesInfo then
      local temp = {
        curLevel = resource.curLevel
      }
      result[resource.pointId] = temp
    end
  end
  GamePacketSender:sendWatcherResource(player.rakssid, json.encode(result))
end

function GameResourceManager:onTick(ticks)
  for _, point in pairs(self.ResourcePoint) do
    point:onTick(ticks)
  end
end

function GameResourceManager:onGameStart()
  local configs = ResourcePointConfig:getAllConfig()
  for _, config in pairs(configs) do
    if config.pointType == 1 then
      self:newPublicResource(config.id)
    elseif config.pointType == 2 then
    end
  end
  for _, point in pairs(self.ResourcePoint) do
    point:onGameStart()
  end
end

function GameResourceManager:UpgradeResource(pointId)
  if self.ResourcePoint[tostring(pointId)] ~= nil then
    self.ResourcePoint[tostring(pointId)]:onUpgrade()
  end
end

function GameResourceManager:onGameStageChange(GameStage)
  if 1 < GameStage then
    MessagesManage:sendSystemTipsToAll(Messages:msgGameStageChange(GameStage))
  end
end

function GameResourceManager:onPlayerMove(player, x, y, z)
  local haveGet = false
  for _, point in pairs(self.ResourcePoint) do
    if point.__cname == "GameTeamResource" then
      local isInRange
      for _, userId in pairs(point.playerInArea) do
        if player.userId == userId then
          isInRange = true
          break
        end
      end
      if x >= point.minX - 0.5 and x <= point.maxX + 0.5 and z >= point.minZ - 0.5 and z <= point.maxZ + 0.5 and y >= point.minY - 1 and y <= point.maxY + 1 then
        if not isInRange then
          haveGet = #point.playerInArea == 0 and point:onPlayerIntoTeamResource(player) or haveGet
          table.insert(point.playerInArea, player.userId)
        end
      else
        for index, userId in pairs(point.playerInArea) do
          if player.userId == userId then
            table.remove(point.playerInArea, index)
            if #point.playerInArea == 0 then
              GamePacketSender:onNotPlayerIntoTeamResource(point.pointId)
            end
            break
          end
        end
      end
    end
  end
  return haveGet
end

function GameResourceManager:addResourceCache(itemId, entityId)
  local caches = self.ResourceCache[itemId]
  if not caches then
    return
  end
  caches[entityId] = true
end

function GameResourceManager:onPickUpItem(player, entityId, itemId, itemNum)
  local caches = self.ResourceCache[itemId]
  if not caches then
    return
  end
  if not caches[entityId] then
    return
  end
  local key = "collect_diamonds"
  if itemId == ItemID.EMERALD then
    key = "collect_gem"
  end
  player.taskController:packingProgressData(Define.TaskType.Fright.PickResource, itemId, itemNum)
  local count = tonumber(player.info:getValue(key))
  player.info:setValue(key, count + itemNum)
  caches[entityId] = nil
end

function GameResourceManager:onPlayerLogout(player)
  GameResourceManager:onPlayerMove(player, 0, 0, 0)
end

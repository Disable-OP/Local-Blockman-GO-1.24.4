GamePacketSender = {}

function GamePacketSender:sendMapId(rakssid, mapId)
  PacketSender:sendLuaCommonData(rakssid, "MapId", mapId)
end

function GamePacketSender:sendBedWarKeyAdDeadSummary(rakssid, key)
  local params = {key = key}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "KeyAdSettlementSingle", data)
end

function GamePacketSender:sendBedWarPlayerLevel(rakssid, level)
  PacketSender:sendLuaCommonData(rakssid, "PlayerLevel", level)
end

function GamePacketSender:sendBedWarOpenLottery(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "OpenLottery", "")
end

function GamePacketSender:sendBedWarLotteryResult(rakssid, rewardId, price, seq)
  local params = {
    rewardId = rewardId,
    price = price,
    seq = seq
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LotteryResult", data)
end

function GamePacketSender:sendWatchLicenseADSuccess(rakssid, level, curEXP, freeUpgradeTime)
  local params = {
    curLV = level,
    curEXP = curEXP,
    freeTime = freeUpgradeTime
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "WatchLicenseADSuccess", data)
end

function GamePacketSender:sendBedWarRefreshResult(rakssid, commonItem, coreItem, refreshPrice, lotteryPrice)
  local rewardId = ""
  local allItem = commonItem
  for _, reward in pairs(coreItem or {}) do
    table.insert(allItem, 1, reward)
  end
  for _, Id in pairs(allItem) do
    rewardId = rewardId .. "#" .. tostring(Id)
  end
  local params = {
    reward = rewardId,
    refreshPrice = refreshPrice,
    lotteryPrice = lotteryPrice
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LotteryRefreshResult", data)
end

function GamePacketSender:sendBedWarTipAd(rakssid, data)
  PacketSender:sendServerCommonData(rakssid, "VideoAdTipData", "", data)
end

function GamePacketSender:sendBedWarShortMessage(rakssid, senderId, messageId)
  local params = {senderId = senderId, Id = messageId}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "Message", data)
end

function GamePacketSender:sendBedWarShortMessageToAll(senderId, messageId)
  local params = {senderId = senderId, Id = messageId}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:broadCastLuaCommonData("Message", data)
end

function GamePacketSender:sendBedWarChat(rakssid, userId, text)
  local params = {userId = userId, Chat = text}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "Chat", data)
end

function GamePacketSender:sendBedWarChatToAll(userId, text)
  local params = {userId = userId, Chat = text}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:broadCastLuaCommonData("Chat", data)
end

function GamePacketSender:sendBedWarSystemTips(rakssid, tipType, tipsText)
  local params = {
    tipType = tipType,
    text = tipsText or ""
  }
  PacketSender:sendLuaCommonData(rakssid, "SystemTips", json.encode(params))
end

function GamePacketSender:sendBedWarSystemTipsToAll(tipType, tipsText)
  local params = {tipType = tipType, text = tipsText}
  PacketSender:broadCastLuaCommonData("SystemTips", json.encode(params))
end

function GamePacketSender:sendBedWarKillBroadCast(killerId, deadId, type, helpers)
  local params = {
    killerId = tostring(killerId),
    deadId = tostring(deadId),
    type = type,
    helpers = helpers or ""
  }
  PacketSender:broadCastLuaCommonData("Kill", json.encode(params))
end

function GamePacketSender:sendMoveLimitCheck(rakssid)
  local params = {
    runLimitCheck = GameConfig.runLimitCheck,
    sprintLimitCheck = GameConfig.sprintLimitCheck
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "MoveLimitCheck", data)
end

function GamePacketSender:sendSignalBomb(senderId, pos, id, teamId)
  local params = {
    posX = math.floor(pos.x * 10) / 10,
    posY = math.floor(pos.y * 10) / 10,
    posZ = math.floor(pos.z * 10) / 10,
    id = id,
    senderId = senderId
  }
  local data = DataBuilder.new():fromTable(params):getData()
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    if player.teamId == teamId then
      PacketSender:sendLuaCommonData(player.rakssid, "SendSignal", data)
    end
  end
end

function GamePacketSender:sendBuyKeepItem(rakssid, time, price)
  local params = {time = time, price = price}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "BuyKeepItem", data)
end

function GamePacketSender:sendBuyRespawn(rakssid, time, price)
  local params = {time = time, price = price}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "BuyRespawn", data)
end

function GamePacketSender:sendBuyCommandSuccess(rakssid, goodsId)
  PacketSender:sendLuaCommonData(rakssid, "BuyCommandSuccess", tostring(goodsId))
end

function GamePacketSender:sendCommandListData(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "commandList", json.encode(data))
end

function GamePacketSender:sendBedWarLevelUp(rakssid, oldLv, newLv)
  local params = {oldLv = oldLv, newLv = newLv}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LevelUpData", data)
end

function GamePacketSender:sendPlaySound(rakssid, soundType)
  local params = {type = soundType}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "playSound", data)
end

function GamePacketSender:sendPlaySound3d(rakssid, soundType, pos)
  local params = {
    type = soundType,
    x = math.floor(pos.x * 10) / 10,
    y = math.floor(pos.y * 10) / 10,
    z = math.floor(pos.z * 10) / 10
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "playSound3d", data)
end

function GamePacketSender:broadcastSound(soundType, pos)
  local players = PlayerManager:getPlayers()
  if pos then
    for _, player in pairs(players) do
      GamePacketSender:sendPlaySound3d(player.rakssid, soundType, pos)
    end
  else
    for _, player in pairs(players) do
      GamePacketSender:sendPlaySound(player.rakssid, soundType)
    end
  end
end

function GamePacketSender:sendLotteryReplaceTip(rakssid, oldItemId, newItemId)
  local param = {oldId = oldItemId, newId = newItemId}
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData(rakssid, "ReplaceTip", data)
end

function GamePacketSender:sendBedWarLotteryFreeRefresh(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "FreeRefresh")
end

function GamePacketSender:onTeamResourceUpgrade(pointId)
  PacketSender:broadCastLuaCommonData("ResourceUpgrade", tostring(pointId))
end

function GamePacketSender:sendPlayerIntoTeamResource(userId, pointId)
  local param = {userId = userId, pointId = pointId}
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:broadCastLuaCommonData("PlayerIntoTeamResource", data)
end

function GamePacketSender:onNotPlayerIntoTeamResource(pointId)
  local param = {pointId = pointId}
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:broadCastLuaCommonData("NotPlayerTeamResource", data)
end

function GamePacketSender:sandBedWarLicenseExchangeSuccess(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BedWarLicenseExchange", data)
end

function GamePacketSender:sendBedWarLicense(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BedWarLicenseData", data)
end

function GamePacketSender:sandBedWarLicensePaySuccess(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BedWarLicensePaySuccess", data)
end

function GamePacketSender:sendBedWarLicenseExchangeSuccess(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BedWarLicenseExchangeSuccess", data)
end

function GamePacketSender:sendLicenseTaskRefreshAll(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "LicenseTaskRefreshAll")
end

function GamePacketSender:sendLicenseFinishTask(rakssid, EXP, level, weekEXP)
  local params = {
    EXP = EXP,
    level = level,
    weekLimit = weekEXP
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LicenseFinishTask", data)
end

function GamePacketSender:sendLicenseWeekEXP(rakssid, WeekEXP)
  local params = {WeekEXP = WeekEXP}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LicenseWeekEXP", data)
end

function GamePacketSender:sendLicenseCleanTask(rakssid, type)
  local params = {Type = type}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LicenseCleanTask", data)
end

function GamePacketSender:sendBuffInfo(rakssid, buffId, type, duration)
  local params = {
    buffId = buffId,
    type = type,
    duration = duration
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "BuffInfo", data)
end

function GamePacketSender:sendMonsterSpeed(entityId, speed)
  local builder = DataBuilder.new()
  builder:addParam("entityId", entityId)
  builder:addParam("speed", speed)
  PacketSender:sendLuaCommonDataToTrackingPlayers(entityId, "MonsterSpeed", builder:getListData())
end

function GamePacketSender:setFrameInterval(entityId, frameInterval)
  local builder = DataBuilder.new()
  builder:addParam("entityId", entityId)
  builder:addParam("frameInterval", frameInterval)
  PacketSender:sendLuaCommonDataToTrackingPlayers(entityId, "MonsterFrameInterval", builder:getListData())
end

function GamePacketSender:sendMonsterPosition(entityId, position, stepInAir)
  local builder = DataBuilder.new()
  builder:addParam("entityId", entityId)
  builder:addVector3Param("position", position)
  if stepInAir then
    builder:addParam("stepInAir", "1")
  end
  PacketSender:sendLuaCommonDataToTrackingPlayers(entityId, "MonsterPos", builder:getListData())
end

function GamePacketSender:sendMonsterAction(entityId, action)
  local builder = DataBuilder.new()
  builder:addParam("entityId", entityId)
  builder:addParam("action", action)
  PacketSender:sendLuaCommonDataToTrackingPlayers(entityId, "MonsterAction", builder:getListData())
end

function GamePacketSender:sendMonsterHP(entityId, hp)
  local builder = DataBuilder.new()
  builder:addParam("entityId", entityId)
  builder:addParam("hp", hp)
  PacketSender:sendLuaCommonDataToTrackingPlayers(entityId, "MonsterHP", builder:getListData())
end

function GamePacketSender:sendMonsterDie(entityId)
  local builder = DataBuilder.new()
  builder:addParam("entityId", entityId)
  PacketSender:sendLuaCommonDataToTrackingPlayers(entityId, "MonsterDie", builder:getListData())
end

function GamePacketSender:sendMonsterKnockBack(entityId, distance, yaw)
  local builder = DataBuilder.new()
  builder:addParam("entityId", entityId)
  builder:addParam("distance", distance)
  builder:addParam("yaw", yaw)
  PacketSender:sendLuaCommonDataToTrackingPlayers(entityId, "MonsterKnockBack", builder:getListData())
end

function GamePacketSender:sendWatcherResource(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "synWatcherResource", data)
end

function GamePacketSender:sendBedWarPlayerMotion(rakssid, motion)
  local data = DataBuilder.new():addVector3Param("Motion", motion):getData()
  PacketSender:sendLuaCommonData(rakssid, "PlayerMotionData", data)
end

function GamePacketSender:sendIsEquipNinjaShoes(rakssid, isEquip)
  local param = {isEquip = isEquip}
  if isEquip then
    param.height = GameConfig.NinjaShoesJumpHeight
  end
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData(rakssid, "IsEquipNinjaShoes", data)
end

function GamePacketSender:sendShowSurvey(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "ShowSurvey")
end

function GamePacketSender:sendShowSurveyEntrance(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "ShowSurveyEntrance")
end

function GamePacketSender:sendSurveyUseItemTimes(rakssid, itemId, times)
  local param = {itemId = itemId, times = times}
  local data = DataBuilder.new():fromTable(param):getData()
  PacketSender:sendLuaCommonData(rakssid, "SurveyUseItemTimes", data)
end

return GamePacketSender

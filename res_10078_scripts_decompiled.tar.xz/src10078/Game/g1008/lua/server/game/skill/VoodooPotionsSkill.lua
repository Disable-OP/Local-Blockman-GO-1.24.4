local VoodooPotionsSkill = class("VoodooPotionsSkill", require("game.skill.BaseSkill"))

function VoodooPotionsSkill:onPlayerEffected(player)
  BuffManager:createBuff(player.userId, BuffManager.BuffType.BanCure)
  BuffManager:createBuff(player.userId, BuffManager.BuffType.Speed)
end

return VoodooPotionsSkill

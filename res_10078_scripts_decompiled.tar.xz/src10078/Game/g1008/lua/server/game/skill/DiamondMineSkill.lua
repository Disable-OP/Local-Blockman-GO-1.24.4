local DiamondMineSkill = class("DiamondMineSkill", require("game.skill.BaseSkill"))

function DiamondMineSkill:doAction()
  local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
  if not self_player then
    return
  end
  local createPos = VectorUtil.newVector3i(self.initPos.x, self.initPos.y + 1, self.initPos.z)
  if EngineWorld:getBlockId(createPos) ~= 0 then
    return
  end
  if MonsterManager:createMonster(VectorUtil.newVector3(createPos.x + 0.5, createPos.y, createPos.z + 0.5), Define.MonsterType.DiamondMine, self_player) then
    self_player:removeItem(self.itemId, 1)
  end
end

return DiamondMineSkill

local RescueSkill = class("RescueSkill", require("game.skill.BaseSkill"))

function RescueSkill:doAction()
  local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
  if not self_player then
    return
  end
  local position = self.initPos
  if self_player:getEntityPlayer():canPlayerFallEx() then
    local dest = self_player.entityPlayerMP.fallDistance
    local total = 0
    local motion = 0
    while true do
      motion = (motion / 0.98 + 0.08) / 0.98
      total = total + motion
      if dest <= total then
        break
      end
    end
    self_player.entityPlayerMP:ignoreInTheAirCheatCheckInDuration(10000)
    GamePacketSender:sendBedWarPlayerMotion(self_player.rakssid, VectorUtil.newVector3(0, motion, 0))
    self_player.entityPlayerMP.fallDistance = 0
    local startPos = VectorUtil.newVector3i(math.floor(position.x - 2), math.floor(position.y - 1), math.floor(position.z - 2))
    local endPos = VectorUtil.newVector3i(math.floor(position.x + 2), math.floor(position.y - 1), math.floor(position.z + 2))
    for x = startPos.x, endPos.x do
      for z = startPos.z, endPos.z do
        local blockPos = VectorUtil.newVector3i(math.floor(x), startPos.y, math.floor(z))
        local blockId = EngineWorld:getBlockId(blockPos)
        if blockId == 0 then
          EngineWorld:setBlock(blockPos, BlockID.SLIME, 0, 3, true)
        end
      end
    end
    LuaTimer:schedule(function(startX, endX, startPosZ, endZ, Y)
      for x = startX, endX do
        for z = startPosZ, endZ do
          local blockPos = VectorUtil.newVector3i(x, Y, z)
          local blockId = EngineWorld:getBlockId(blockPos)
          if blockId == BlockID.SLIME and EngineWorld:isBlockChange(blockPos) then
            EngineWorld:setBlock(blockPos, 0, 0, 3, true)
          end
        end
      end
    end, tonumber(self.duration) * 1000, nil, startPos.x, endPos.x, startPos.z, endPos.z, startPos.y)
  else
    MessagesManage:sendSystemTipsToPlayer(self_player.rakssid, Messages:msgNotUseRescue())
  end
end

return RescueSkill

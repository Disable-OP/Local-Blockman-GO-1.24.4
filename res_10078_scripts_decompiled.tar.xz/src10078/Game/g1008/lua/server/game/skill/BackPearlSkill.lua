local BackPearlSkill = class("BackPearlSkill", require("game.skill.BaseSkill"))

function BackPearlSkill:onPlayerEffected(player)
  local backTime = tonumber(self.config.param[1])
  if not backTime then
    return
  end
  self.oldPos = player:getPosition()
  self:telePos(player)
  LuaTimer:cancel(player.backPearTimer or 0)
  player.backPearTimer = LuaTimer:schedule(function(userId, pos)
    local pPlayer = PlayerManager:getPlayerByUserId(userId)
    if pPlayer == nil or pPlayer.isLife == false then
      return
    end
    AnalyticsReportUtil.reportBackPearlResult(pPlayer, false)
    pPlayer.backPearTimer = 0
    if player.useHollowBlock or player:ifOnMount() then
      return
    end
    pPlayer:teleportPos(VectorUtil.newVector3(pos.x, pos.y, pos.z))
  end, backTime, nil, player.userId, self.oldPos)
end

return BackPearlSkill

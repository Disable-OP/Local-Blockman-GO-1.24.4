local DoubleDummySkill = class("DoubleDummySkill", require("game.skill.BaseSkill"))

function DoubleDummySkill:doAction()
  local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
  if not self_player then
    return
  end
  local createPos1 = VectorUtil.newVector3i(self.initPos.x, self.initPos.y + 1, self.initPos.z)
  local createPos2 = VectorUtil.newVector3i(self.initPos.x, self.initPos.y + 2, self.initPos.z)
  if EngineWorld:getBlockId(createPos1) ~= 0 or EngineWorld:getBlockId(createPos2) ~= 0 then
    return
  end
  self_player:removeItem(self.itemId, 1)
  if not MonsterManager:createMonster(VectorUtil.newVector3(createPos1.x + 0.5, createPos1.y, createPos1.z + 0.5), Define.MonsterType.DoubleDummy, self_player) then
    self_player:addItem(self.itemId, 1)
  end
end

return DoubleDummySkill

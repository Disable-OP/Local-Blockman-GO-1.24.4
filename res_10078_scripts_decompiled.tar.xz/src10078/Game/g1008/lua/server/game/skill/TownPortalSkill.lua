local TownPortalSkill = class("TownPortalSkill", require("game.skill.BaseSkill"))

function TownPortalSkill:onPlayerEffected(player)
  BuffManager:createBuff(player.userId, BuffManager.BuffType.BackHome)
end

return TownPortalSkill

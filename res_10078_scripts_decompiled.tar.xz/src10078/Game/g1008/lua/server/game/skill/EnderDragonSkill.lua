local EnderDragonSkill = class("EnderDragonSkill", require("game.skill.BaseSkill"))
local dragon_hp = 40
local dragon_duration = 30
local dragon_mount_id = 1

function EnderDragonSkill:createSkillEffect(name, time)
end

function EnderDragonSkill:onPlayerEffected(player)
  local mount_skill = SkillConfig:getSkill(570)
  if not mount_skill then
    return
  end
  local position = VectorUtil.add3(player:getPosition(), VectorUtil.newVector3(0, 2, 0))
  GameEnderDragon.new(dragon_mount_id, position, dragon_hp, self.duration, 570, player)
  player:startSinging(self.duration * 1000, false, Define.SingingIcon.EnderDragon)
end

return EnderDragonSkill

local IronPuppetSkill = class("SnowBallInsectSkill", require("game.skill.BaseSkill"))

function IronPuppetSkill:doAction()
  local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
  if not self_player then
    return
  end
  if MonsterManager:createMonster(self.initPos, Define.MonsterType.IronGolem, self_player) then
    self_player:removeItem(self.itemId, 1)
  end
end

return IronPuppetSkill

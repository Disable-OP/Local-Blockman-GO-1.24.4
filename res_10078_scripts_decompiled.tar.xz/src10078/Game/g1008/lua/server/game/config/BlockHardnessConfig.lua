local function init()
  local config = FileUtil.getConfigFromCsv("BlockHardnessConfig.csv")
  
  for _, item in pairs(config) do
    HostApi.setBlockAttr(tonumber(item.blockid), tonumber(item.hardness))
  end
end

init()

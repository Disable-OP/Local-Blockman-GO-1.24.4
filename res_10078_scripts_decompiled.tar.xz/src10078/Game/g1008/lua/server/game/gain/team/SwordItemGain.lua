SwordItemGain = {}

function SwordItemGain:init(config)
  self.id = config.Id
  self.name = config.Name
  self.gains = config.Gains
  self.initLv = config.InitLv or 0
end

function SwordItemGain:onPlayerUpgrade(player)
  local team = GameMatch.Teams[player:getTeamId()]
  if not team then
    return
  end
  MessagesManage:sendSystemTipsToTeam(team.id, Messages:msgEnLvUp(player:getTeamColorName()))
  local players = PlayerManager:getPlayers()
  for _, _player in pairs(players) do
    if _player:getTeamId() == team.id and _player.realLife then
      local inv = _player:getInventory()
      for index = 0, 35 do
        local info = inv:getItemStackInfo(index)
        if info.id ~= 0 then
          local item = Item.getItemById(info.id)
          if item then
            local class = item:getClassName()
            if class == "ItemSword" then
              local enchantList = ItemEnchantment:getItemEnchantmentList(inv, index)
              inv:decrStackSize(index, info.num)
              _player:tryAddItem(info.id, info.num, 0, enchantList)
            end
          end
        end
      end
    end
  end
end

function SwordItemGain:onPlayerGetSword(player, enchantList)
  local team = GameMatch.Teams[player:getTeamId()]
  if not team or not team.info then
    return enchantList
  end
  enchantList = enchantList or {}
  local level = tonumber(team.info:getValue(self.id))
  local gain = self.gains[level]
  if not gain then
    return enchantList
  end
  for _, enchant in pairs(enchantList) do
    if enchant[1] == gain.EnchantId then
      enchant[2] = math.max(gain.EnchantLv, enchant[2])
      return enchantList
    end
  end
  table.insert(enchantList, {
    gain.EnchantId,
    gain.EnchantLv
  })
  return enchantList
end

function SwordItemGain:removeSwordGain(enchantList)
  for _, gain in pairs(self.gains) do
    for pos, enchant in pairs(enchantList) do
      if gain.EnchantId == enchant[1] and gain.EnchantLv == enchant[2] then
        table.remove(enchantList, pos)
        break
      end
    end
  end
end

IronForgeGain = {}

function IronForgeGain:init(config)
  self.id = config.Id
  self.name = config.Name
  self.maxLv = config.MaxLv
  self.initLv = config.InitLv or 0
end

function IronForgeGain:onGameStart()
  if self.initLv == 0 then
    return
  end
  local currentLv = 0
  while currentLv < self.initLv do
    currentLv = currentLv + 1
    for _, team in pairs(GameMatch.Teams) do
      team:upgradeIron()
    end
  end
end

function IronForgeGain:onPlayerUpgrade(player)
  local team = GameMatch.Teams[player:getTeamId()]
  if not team then
    return
  end
  local level = tonumber(team.info:getValue(self.id))
  if level <= self.maxLv then
    team:upgradeIron()
  end
  MessagesManage:sendSystemTipsToTeam(team.id, Messages:msgIronMoney(), player:getTeamColorName())
end

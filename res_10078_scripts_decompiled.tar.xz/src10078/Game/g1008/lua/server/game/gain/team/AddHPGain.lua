AddHPGain = {}

function AddHPGain:init(config)
  self.id = config.Id
  self.name = config.Name
  self.gains = config.Gains
  self.initLv = config.InitLv or 0
end

function AddHPGain:onGameStart()
  if self.initLv == 0 then
    return
  end
  for teamId, _ in pairs(GameMatch.Teams) do
    local name = HotSpringConfig:getSchemetic(teamId)
    local pos = HotSpringConfig:getSchemeticPos(teamId)
    EngineWorld:createSchematic(name, pos, false, false, false)
  end
end

function AddHPGain:onPlayerUpgrade(player)
  local team = GameMatch.Teams[player:getTeamId()]
  if not team then
    return
  end
  if tonumber(team.info:getValue(self.id)) == 1 then
    local name = HotSpringConfig:getSchemetic(player:getTeamId())
    local pos = HotSpringConfig:getSchemeticPos(player:getTeamId())
    EngineWorld:createSchematic(name, pos, false, false, false)
    MessagesManage:sendSystemTipsToTeam(team.id, Messages:msgShopBuyHotSpringSuc(player:getTeamColorName()))
  else
    MessagesManage:sendSystemTipsToTeam(team.id, Messages:msgHotSpringLvUp(player:getTeamColorName()))
  end
end

function AddHPGain:onTick(ticks)
  if not GameMatch:isGameStart() then
    return
  end
  for _, team in pairs(GameMatch.Teams) do
    local level = tonumber(team.info:getValue(self.id))
    local gain = self.gains[level]
    if gain and ticks % gain.Interval == 0 then
      local players = PlayerManager:getPlayers()
      for _, player in pairs(players) do
        if player.realLife and player:getTeamId() == team.id and team:isInHpArea(player) and not player.banCureBuff then
          player:addHealth(gain.AddHP)
        end
      end
    end
  end
end

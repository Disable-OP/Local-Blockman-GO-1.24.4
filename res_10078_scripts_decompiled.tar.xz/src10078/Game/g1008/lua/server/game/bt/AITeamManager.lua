AITeamManager = {}
local Teams = {}

function AITeamManager:newAi(groupId, teamId, platformId, name)
  local team = Teams[tostring(teamId)] or {}
  team.teamId = teamId
  if not team.configs then
    team.configs = TableUtil.copyTable(AIPlayerConfig:getConfigs(groupId, teamId))
    table.sort(team.configs, function(a, b)
      return a.weight < b.weight
    end)
  end
  AITeamManager:addAItoTeam(team, platformId, name)
  Teams[tostring(teamId)] = team
end

function AITeamManager:addAItoTeam(team, platformId, name)
  IsAIGame = true
  for _, config in pairs(team.configs) do
    if not config.isUsed then
      config.ai = GamePlayerAI.new(platformId, name, team.teamId, config)
      config.isUsed = true
      break
    end
  end
end

function AITeamManager:onAIDie(player)
  local dieAI = AIManager:getAIByRakssid(player.rakssid)
  if dieAI then
    dieAI:logout()
  end
  local team = Teams[tostring(player.teamId)]
  if team and team.configs then
    while #team.configs > 0 and team.configs[#team.configs].ai == nil do
      table.remove(team.configs, #team.configs)
    end
    for index, config in pairs(team.configs) do
      if tostring(config.ai.rakssid) == tostring(player.rakssid) and index < #team.configs then
        config.ai = team.configs[#team.configs].ai
        config.ai:updateConfig(config)
        table.remove(team.configs, #team.configs)
        break
      end
    end
  end
end

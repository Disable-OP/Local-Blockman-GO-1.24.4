LogicListener = {}
LogicListener.goldAppleTimeId = {}
LogicListener.goldAppleAddHpTimeId = {}
LogicListener.goldAppleFreshTimeId = {}
LogicListener.blockAirCache = {}

function LogicListener:init()
  CEvents.ItemSkillSpHandleEvent:registerCallBack(self.onItemSkillSpHandle)
  CEvents.ItemSkillAttackEvent:registerCallBack(self.onItemSkillAttack)
  CEvents.ItemSkillConsumptionItemEvent:registerCallBack(self.onItemSkillConsumptionItem)
  CEvents.SkillThrowableMoveEvent:registerCallBack(self.onSkillThrowableMove)
  CEvents.EntityItemSpawnEvent:registerCallBack(self.onEntityItemSpawn)
  CEvents.UseItemBucketEvent:registerCallBack(self.onUseItemBucket)
  CEvents.FoodEatenEvent:registerCallBack(self.onFoodEaten)
  CEvents.ToolDurableEvent:registerCallBack(self.onToolDurable)
  CEvents.EntityLivingBaseFallNoNeedCalBlockIdEvent:registerCallBack(self.onEntityLivingBaseFallNoNeedCalBlockId)
  CEvents.UseItemBucketInBlockEvent:registerCallBack(self.onUseItemBucketInBlock)
  CEvents.PotionConvertGlassBottleEvent:registerCallBack(self.onPotionConvertGlassBottleEvent)
end

function LogicListener.onEntityItemSpawn(itemId, itemMeta, behavior, discard)
  if behavior == "player.drop" then
    return ItemHelper:canSpawnEntity(itemId)
  end
  return true
end

function LogicListener.onItemSkillAttack(entityId, itemId, position, itemEntityId)
  local player = PlayerManager:getPlayerByEntityId(entityId)
  if player == nil then
    return
  end
  if player.isLife == false then
    return
  end
  local skill = SkillConfig:getSkill(itemId)
  if skill ~= nil then
    if skill.isPlaceBlock then
      position = player.PlaceBlockPos or position
      player.PlaceBlockPos = nil
    end
    SkillManager:createSkill(skill, player, position, itemEntityId)
  end
end

function LogicListener.onItemSkillConsumptionItem(rakssid, itemId)
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  local skill = SkillConfig:getSkill(itemId)
  if skill and skill.isConsume then
    player:removeItem(itemId, 1)
    if itemId == ItemID.FLARE_BOMB then
      GamePacketSender:broadcastSound(SoundConfig.shootFire, player:getPosition())
    end
  end
end

function LogicListener.onUseItemBucket(entityId, itemId)
  local player = PlayerManager:getPlayerByEntityId(entityId)
  if player == nil then
    return true
  end
  if ItemID.BUCKET_WATER == itemId or ItemID.BUCKET_MILK == itemId or ItemID.POTION_INVISIBILITY == itemId or ItemID.POTION_JUMP == itemId or ItemID.POTION_MOVESPEED == itemId then
    return false
  end
  return true
end

function LogicListener.onPotionConvertGlassBottleEvent(entityId, itemId)
  return false
end

function LogicListener.onFoodEaten(entityId, itemId)
  local player = PlayerManager:getPlayerByEntityId(entityId)
  if player == nil then
    return true
  end
  if ItemID.GOLD_APPLE == itemId then
    player:resetApple()
    player.entityPlayerMP:appleFresh(-1)
    local hash = tostring(tostring(player.rakssid) .. os.time())
    local hpCountDown = tonumber(GameConfig.goldApple[1].hpCountDown)
    local armorDuration = tonumber(GameConfig.goldApple[1].armorDuration)
    local armoraddDuration = tonumber(GameConfig.goldApple[1].armoraddDuration)
    LogicListener.goldAppleAddHpTimeId[hash] = LuaTimer:scheduleTimer(function()
      if not player.banCureBuff then
        player:addHealth(tonumber(GameConfig.goldApple[1].addHpValue))
      end
    end, hpCountDown * 1000, armorDuration / hpCountDown)
    player.maxApple = tonumber(GameConfig.goldApple[1].addarmor)
    player.curApple = tonumber(GameConfig.goldApple[1].addarmor)
    player:updateApple()
    LogicListener.goldAppleTimeId[hash] = LuaTimer:schedule(function()
      if player.entityPlayerMP ~= nil then
        player.entityPlayerMP:changeApple(0, 0)
        player.curApple = 0
        player.maxApple = 0
      end
      if LogicListener.goldAppleTimeId[hash] ~= nil then
        LuaTimer:cancel(LogicListener.goldAppleTimeId[hash])
        LogicListener.goldAppleTimeId[hash] = nil
      end
    end, armoraddDuration * 1000, nil)
    local freshTime = armoraddDuration - 3
    if 0 < freshTime then
      LogicListener.goldAppleFreshTimeId[hash] = LuaTimer:schedule(function()
        if player.entityPlayerMP ~= nil then
          player.entityPlayerMP:appleFresh(3)
        end
        if LogicListener.goldAppleFreshTimeId[hash] ~= nil then
          LuaTimer:cancel(LogicListener.goldAppleFreshTimeId[hash])
          LogicListener.goldAppleFreshTimeId[hash] = nil
        end
      end, freshTime * 1000, nil)
    end
    return false
  end
  return true
end

function LogicListener.onToolDurable(itemId, itemDamage)
  if not GameMatch.allowPvp then
    return false
  end
  return ItemHelper:canDamage(itemId)
end

function LogicListener.onEntityLivingBaseFallNoNeedCalBlockId(entityId)
  local player = PlayerManager:getPlayerByEntityId(entityId)
  if player == nil then
    return true
  end
  return false
end

function LogicListener.onUseItemBucketInBlock(entityId, itemId, vec3i)
  local player = PlayerManager:getPlayerByEntityId(entityId)
  if player == nil then
    return false
  end
  if itemId == ItemID.BUCKET_WATER then
    local localVec3i = vec3i
    localVec3i.y = localVec3i.y + 1
    local isInArea = TeamConfig:isInTeamArea(localVec3i)
    if isInArea == true then
      MessagesManage:sendSystemTipsToPlayer(player.rakssid, Messages:msgBlockPlaceTip())
      if LogicListener.blockAirCache[VectorUtil.hashVector3(vec3i)] == nil then
        EngineWorld:setBlock(vec3i, 0, 1, 3, true)
        LogicListener.blockAirCache[VectorUtil.hashVector3(vec3i)] = true
      else
        EngineWorld:setBlock(vec3i, 0, 0, 3, true)
        LogicListener.blockAirCache[VectorUtil.hashVector3(vec3i)] = nil
      end
      return false
    end
  end
  return true
end

function LogicListener.onSkillThrowableMove(entityId, itemId, position)
  local skill = SkillConfig:getSkill(itemId)
  if skill and skill.type == SkillManager.SkillType.BridgeEgg then
    local blockPos = VectorUtil.toBlockVector3(position.x, position.y - 2, position.z)
    local isInArea = TeamConfig:isInTeamArea(blockPos)
    if isInArea then
      return
    end
    if EngineWorld:getBlockId(blockPos) ~= BlockID.AIR then
      return
    end
    EngineWorld:setBlock(blockPos, BlockID.CLOTH, 0)
  end
end

function LogicListener.onItemSkillSpHandle(entityId, itemId, position)
  local player = PlayerManager:getPlayerByEntityId(entityId)
  if player == nil then
    return false
  end
  if player.isLife == false then
    return false
  end
  local skill = SkillConfig:getSkill(itemId)
  if skill == nil then
    return false
  end
  if player:ifOnMount() then
    MessagesManage:sendSystemTipsToPlayer(player.rakssid, Messages:msgOnMontCanNotUseSkill())
    return false
  end
  return true
end

return LogicListener

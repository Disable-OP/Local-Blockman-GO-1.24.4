CustomListener = {}

function CustomListener:init()
  CEvents.WatchAdvertFinishedEvent:registerCallBack(self.onWatchAdvertFinished)
  Events.ReceiveSumRechargeEvent:registerCallBack(self.onReceiveSumRecharge)
  Events.CommonReceiveRewardEvent:registerCallBack(self.onCommonReceiveReward)
  CEvents.RechargeResultEvent:registerCallBack(self.onRechargeResult)
end

function CustomListener.onWatchAdvertFinished(rakssid, type, params, code)
  if code ~= 1 then
    return
  end
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  if type == Define.AdType.DoubleKey then
    if not player.isRewardDoubleKey then
      player.isRewardDoubleKey = true
      player.rewardKey = player.rewardKey or 0
      player:addYaoShi(player.rewardKey)
      player.rewardKey = player.rewardKey * 2
      GamePacketSender:sendBedWarKeyAdDeadSummary(player.rakssid, player.rewardKey)
      ReportUtil.reportWatchAdFinish(player, "DoubleKey")
    end
  elseif type == Define.AdType.RankHonourProtect then
    SettlementManager:sendSingleSettlement(player, false, true)
  elseif type == Define.AdType.License then
    GameLicense:onPlayerBuyLevel(player, nil, player.license_level, true)
  elseif type == Define.AdType.Challenge then
    TreasureChallenge:onPlayerWatchTreasureAd(player)
  end
end

function CustomListener.onCommonReceiveReward(player, propsType, propsId, propsCount, expireTime)
  if propsType == "CustomShop" then
    local goods = CustomShopConfig:getGoodsConfig(tonumber(propsId))
    if goods then
      CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.SumRecharge)
    end
    return
  end
  if propsType == "Key" then
    player:addYaoShi(propsCount)
    return
  end
  if propsType == "YaoShi" then
    player:addYaoShi(propsCount)
    return
  end
  if propsType == "Privilege" then
    Privilege.addPrivilegeTime(player, tonumber(propsId), expireTime)
    return
  end
  if propsType == "Ticket" then
    GameReward:onPlayerRewardTicket(player, tonumber(propsId), propsCount)
  end
  if propsType == "Horn" then
    GameReward:onPlayerRewardHorn(player, tonumber(propsId), propsCount)
  end
  if propsType == "Chest" then
    GameReward:addPlayerLotteryChest(player, tonumber(propsId), propsCount)
  end
  if propsType == "Rune" then
    GameReward:onPlayerRewardRune(player, tonumber(propsId), propsCount)
  end
  if propsType == "RewardSetting" then
    local reward = RewardConfig:getRewardById(propsId)
    if not reward then
      return
    end
    reward.Count = propsCount
    GameReward:onPlayerGetReward(player, reward)
  end
end

function CustomListener.onReceiveSumRecharge(player, type, rewardId, count)
  if type == "CustomShop" then
    local goods = CustomShopConfig:getGoodsConfig(rewardId)
    if goods then
      CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.SumRecharge)
    end
    return
  end
  if type == "Key" then
    player:addYaoShi(count)
    return
  end
end

function CustomListener.onRechargeResult(rakssid, type, result, productId)
  if result ~= 1 then
    return
  end
  local player = PlayerManager:getPlayerByRakssid(rakssid)
  if player == nil then
    return
  end
  if type == 1 then
    ReportUtil.reportRechargeCube(player, productId)
  end
end

return CustomListener

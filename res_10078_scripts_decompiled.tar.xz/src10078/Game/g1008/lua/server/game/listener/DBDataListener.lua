DBDataListener = {}

function DBDataListener:init()
  DBManager:setPlayerDBSaveFunction(function(player, immediate)
    DbUtil:savePlayerData(player, immediate)
  end)
end

return DBDataListener

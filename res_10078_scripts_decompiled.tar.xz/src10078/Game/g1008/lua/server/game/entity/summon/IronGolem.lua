local IronGolem = class("IronGolem", require("game.entity.summon.ServerMonster"))
local Status = {
  idle = 1,
  follow = 2,
  attack = 3
}

function IronGolem:onCreate()
  self.attackTime = os.time()
  self:setSpeed(self.config.patrolSpeed)
end

function IronGolem:onLogicUpdate()
  local status = self:getNowStatus()
  if status == Status.idle then
    self:onIdle()
  elseif status == Status.follow then
    self:onFollow()
    self.idlePos = nil
  elseif status == Status.attack then
    self:onAttack()
    self.idlePos = nil
  end
end

function IronGolem:isCanAttack()
  if os.difftime(os.time(), self.attackTime) > self.config.attackInterval then
    self.attackTime = os.time()
    return true
  end
  return false
end

function IronGolem:getNowStatus()
  if not self.enemy then
    return Status.idle
  end
  local enemyPlayer = PlayerManager:getPlayerByUserId(self.enemy.userId)
  if not enemyPlayer or enemyPlayer.lifeStatus == false or enemyPlayer.entityPlayerMP == nil or enemyPlayer.entityPlayerMP:isPotionActive(14) == true then
    self.enemy = nil
    return Status.idle
  end
  self.enemy.dis = BtUtil.calculateDistance(self.entity.position, enemyPlayer:getPosition())
  if self.enemy.dis < self.config.attackRadius and self:isCanAttack() then
    return Status.attack
  elseif self.enemy.dis < self.config.followRadius then
    return Status.follow
  end
  return Status.idle
end

function IronGolem:onIdle()
  self:findEnemy()
  self:setSpeed(self.config.patrolSpeed)
  if not self.idlePos then
    local pos = self.entity:getPosition()
    self.idlePos = VectorUtil.newVector3i(pos.x, pos.y, pos.z)
  end
  if not self.toPos then
    self:tryToPosition(VectorUtil.newVector3i(self.idlePos.x + math.random(-1, 1), self.idlePos.y, self.idlePos.z + math.random(-1, 1)))
  end
end

function IronGolem:onFollow()
  local position = PlayerManager:getPlayerByUserId(self.enemy.userId):getPosition()
  self:tryToPosition(position)
  self:setSpeed(self.config.followSpeed)
end

function IronGolem:onAttack()
  self:playAction("attack")
  PlayerManager:getPlayerByUserId(self.enemy.userId):subHealth(self.config.attack)
end

function IronGolem:findEnemy()
  local players = PlayerManager:getPlayers()
  local dangerEnemy
  for _, player in pairs(players) do
    if player.lifeStatus == true and player.entityPlayerMP ~= nil and player.entityPlayerMP:isPotionActive(14) == false and player.teamId ~= self.teamId then
      local distance = BtUtil.calculateDistance(self.entity.position, player:getPosition())
      if dangerEnemy == nil then
        dangerEnemy = {
          userId = player.userId,
          dis = distance
        }
      elseif distance < dangerEnemy.dis then
        dangerEnemy = {
          userId = player.userId,
          dis = distance
        }
      end
    end
  end
  self.enemy = dangerEnemy
  if dangerEnemy.dis < self.config.followRadius then
    self.enemy = dangerEnemy
  end
end

return IronGolem

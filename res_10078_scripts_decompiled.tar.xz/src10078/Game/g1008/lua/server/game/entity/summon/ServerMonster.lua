local setting = MonsterSetting.new()
setting.monsterId = 1
setting.monsterBtTree = "EmptyAI"
setting.monsterType = 2
HostApi.addMonsterSetting(setting)
ServerHelper.putBoolPrefs("IsCreatureCollision", false)
ServerHelper.putIntPrefs("CreatureAISyncMoveTicks", 1000000000)
local ServerMonster = class("ServerMonster", BaseBtTree)

function ServerMonster:ctor(position, config, creator)
  self.liveTime = 0
  self.config = config
  self.creator = creator
  self.frameInterval = config.frameTime or 1000
  self.curFrameInterval = 0
  self.realSpeed = config.patrolSpeed or 2
  self.speed = self.realSpeed / (1000 / self.frameInterval)
  self.curPos = position
  self.curPath = {}
  self.canMoveDis = 0
  self.lockMove = false
  self.teamId = self.creator and self.creator.teamId or 0
  self.curHp = config.hp
  local faceYaw = self:getYaw(creator:getPosition(), position)
  self.entityId = EngineWorld:addCreatureNpc(position, 1, faceYaw, config.actor, function(entity)
    self.entity = entity
    self.entity:setCustomProperties(json.encode({
      userId = tostring(creator.userId),
      type = self.config.type
    }))
    self.entity:setCanFly(true)
    self.entity:setBoolProperty("banClicked", self.config.banClicked or false)
    self.entity:setBoolProperty("banAABBCheck", self.config.banAABBCheck or false)
    self.entity:setBoolProperty("ignoreWaterPush", true)
    self:onCreate()
  end)
  MonsterManager:addMonster(self)
  GamePacketSender:sendMonsterHP(self.entityId, self.curHp)
  self:setCountdownToDeath(config.lifeTime)
end

function ServerMonster:onCreate()
end

function ServerMonster:setSpeed(speed)
  if self.realSpeed ~= speed then
    self.realSpeed = speed
    self.speed = self.realSpeed / (1000 / self.frameInterval)
    GamePacketSender:sendMonsterSpeed(self.entityId, self.speed)
  end
end

function ServerMonster:setFrameTime(frameInterval)
  self.frameInterval = frameInterval
  self.speed = self.realSpeed / (1000 / self.frameInterval)
  GamePacketSender:sendFrameInterval(self.entityId, self.frameInterval)
end

function ServerMonster:onUpdate()
  self.curFrameInterval = self.curFrameInterval + 100
  if self.curFrameInterval < self.frameInterval then
    return
  end
  self.curFrameInterval = self.curFrameInterval - self.frameInterval
  self:checkSubHp()
  if EngineWorld:getEntity(self.entityId) == nil then
    self:setDead()
  end
  if not self.entity then
    return
  end
  self:onMoveUpdate()
  self:onLogicUpdate()
end

function ServerMonster:checkSubHp()
  if self.config.recoveryHp == 0 then
    return
  end
  local real_recovery_hp = self.config.recoveryHp * self.frameInterval / 1000
  self:subHp(-real_recovery_hp)
end

local function canMove(position)
  for offsetY = 1, 5 do
    if EngineWorld:getBlockId(VectorUtil.getNegY(position, offsetY)) ~= 0 then
      return true
    end
  end
  return false
end

function ServerMonster:onMoveUpdate()
  if self.lockMove then
    self.lockMove = false
    return
  end
  if #self.curPath == 0 and self.toPos ~= nil then
    self.curPath = BtUtil.getCurPath(self.entity.position, self.toPos)
    if #self.curPath <= 2 then
      self.curPath = {}
      self.toPos = nil
    else
      table.remove(self.curPath, 1)
    end
  end
  self.canMoveDis = self.canMoveDis + self.speed
  local needSync = false
  local position
  while 0 < self.canMoveDis and #self.curPath > 0 do
    self.canMoveDis = self.canMoveDis - 1
    position = self.curPath[#self.curPath]
    if not canMove(position) then
      self.curPath = {}
      self.toPos = nil
      return
    end
    needSync = true
    if #self.curPath > 1 then
      local nextPos = self.curPath[#self.curPath - 1]
      if position.y ~= nextPos.y then
        self.curPath = {}
        self.lockMove = true
        position.x = position.x + 0.5
        position.z = position.z + 0.5
        GamePacketSender:sendMonsterPosition(self.entityId, position)
        if nextPos.y > position.y and EngineWorld:getBlockId(VectorUtil.getNegY(nextPos)) ~= 0 then
          position.y = nextPos.y
          GamePacketSender:sendMonsterPosition(self.entityId, position, true)
        end
        if nextPos.y < position.y and EngineWorld:getBlockId(VectorUtil.getPosY(nextPos)) == 0 then
          local oldPos = TableUtil.copyTable(nextPos)
          nextPos.x = nextPos.x + 0.5
          nextPos.z = nextPos.z + 0.5
          nextPos.y = position.y
          GamePacketSender:sendMonsterPosition(self.entityId, nextPos, true)
          nextPos = oldPos
        end
        nextPos.x = nextPos.x + 0.5
        nextPos.z = nextPos.z + 0.5
        GamePacketSender:sendMonsterPosition(self.entityId, nextPos)
        self.entity:setPosition(nextPos)
        return
      end
    end
    table.remove(self.curPath, #self.curPath)
  end
  if needSync then
    position.x = position.x + 0.5
    position.z = position.z + 0.5
    self.entity:setPosition(position)
    GamePacketSender:sendMonsterPosition(self.entityId, position)
  end
end

function ServerMonster:onLogicUpdate()
end

function ServerMonster:setDead(killer)
  self.entity = nil
  MonsterManager:removeMonster(self)
  GamePacketSender:sendMonsterDie(self.entityId)
  LuaTimer:cancel(self.deathTimeKey or 0)
  LuaTimer:schedule(function()
    EngineWorld:removeEntity(self.entityId)
  end, self.config.dieDelay)
end

function ServerMonster:setCountdownToDeath(time)
  if time == -1 then
    return
  end
  self.deathTimeKey = LuaTimer:schedule(function()
    self:setDead()
  end, time * 1000)
end

function ServerMonster:tryToPosition(position)
  self.toPos = position
end

function ServerMonster:playAction(action)
  GamePacketSender:sendMonsterAction(self.entityId, action)
end

function ServerMonster:subHp(damage, attacker)
  if self.curHp - damage <= 0 then
    self.curHp = 0
  else
    self.curHp = self.curHp - damage
  end
  if self.curHp == 0 then
    self:setDead(attacker)
  end
  GamePacketSender:sendMonsterHP(self.entityId, self.curHp)
end

function ServerMonster:checkInBlock(player, itemId, blockPos)
end

function ServerMonster:onAttacked(player, damage)
  if self.teamId == player.teamId then
    return false
  end
  local yaw = player:getYaw()
  GamePacketSender:sendMonsterKnockBack(self.entityId, self.config.Repelled, yaw)
  self:subHp(damage)
  return true
end

function ServerMonster:getYaw(facePos, fromPos)
  local entity_pos = fromPos or self.entity:getPosition()
  local vector = math.atan2(facePos.x - entity_pos.x, facePos.z - entity_pos.z)
  return vector / math.pi * -180
end

function ServerMonster:knockBackPlayer(player, strength)
  local yaw = self:getYaw(player:getPosition())
  local x = math.sin(yaw * MathUtil.DEG2RAD)
  local z = -math.cos(yaw * MathUtil.DEG2RAD)
  if player.entityPlayerMP ~= nil then
    player.entityPlayerMP:knockBack(player.entityPlayerMP, strength, x, z)
  end
end

function ServerMonster:getPlayersInRange(range)
  local players = {}
  for _, player in pairs(PlayerManager:getPlayers()) do
    local distance = BtUtil.calculateDistance(self.entity.position, player:getPosition())
    if range > distance then
      table.insert(players, player)
    end
  end
  return players
end

return ServerMonster

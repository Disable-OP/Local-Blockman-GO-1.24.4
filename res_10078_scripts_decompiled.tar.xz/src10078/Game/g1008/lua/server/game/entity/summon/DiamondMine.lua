local DiamondMine = class("DiamondMine", require("game.entity.summon.ServerMonster"))

function DiamondMine:onCreate()
  self.check_range = tonumber(self.config.param[1])
  self.boom_damage = tonumber(self.config.param[2])
  self.boom_range = tonumber(self.config.param[3])
  self.alarm_list = {}
end

function DiamondMine:onLogicUpdate()
  self:checkEnemy()
end

function DiamondMine:checkInBlock(player, itemId, blockPos)
  if not self.entity then
    return
  end
  local pos = self.entity:getPosition()
  if math.floor(pos.x) ~= blockPos.x or math.floor(pos.y) ~= blockPos.y or math.floor(pos.z) ~= blockPos.z then
    return
  end
  LuaTimer:schedule(function()
    local BlockId = EngineWorld:getBlockId(blockPos)
    if BlockId ~= BlockID.AIR then
      self:setDead(player)
    end
  end, 0)
end

function DiamondMine:checkEnemy()
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    if player.teamId ~= self.creator.teamId and player.lifeStatus == true and player.entityPlayerMP ~= nil and player.entityPlayerMP:isPotionActive(14) == false then
      local distance = BtUtil.calculateDistance(self.entity.position, player:getPosition())
      if distance < self.check_range then
        self:trigger(player.userId)
        break
      end
    end
  end
end

function DiamondMine:trigger()
  local entity_pos = self.entity:getPosition()
  for _, player in pairs(self:getPlayersInRange(self.boom_range)) do
    local hurtValue = {
      value = self.boom_damage
    }
    if Events.PlayerAttackedEvent:invoke(player.entityPlayerMP, self.creator.entityPlayerMP, "player", hurtValue) then
      self:knockBackPlayer(player, 0.3)
      player:subHealth(hurtValue.value)
    end
  end
  entity_pos.y = entity_pos.y + 0.6
  EngineWorld:addSimpleEffect("g1008_diamond_mines.effect", entity_pos, 0, 1000, 0, self.boom_range * 1.5)
  self:setDead(self)
end

function DiamondMine:onAttacked(player, damage)
  return false
end

function DiamondMine:setDead(killer)
  if self.entity == nil then
    return
  end
  self.super.setDead(self)
  local dieType = 0
  if killer ~= nil then
    if killer == self then
      dieType = 3
    elseif killer.teamId ~= self.creator.teamId then
      dieType = 1
    else
      dieType = 2
    end
  end
  AnalyticsReportUtil.reportDiamondMineDie(self.creator, dieType)
end

return DiamondMine

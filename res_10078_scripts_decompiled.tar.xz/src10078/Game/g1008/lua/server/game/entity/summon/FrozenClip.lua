local FrozenClip = class("FrozenClip", require("game.entity.summon.ServerMonster"))

function FrozenClip:onCreate()
  self.check_range = tonumber(self.config.param[1])
  self.frozen_damage = tonumber(self.config.param[2])
  self.frozen_duration = tonumber(self.config.param[3])
  self.alarm_list = {}
end

function FrozenClip:onLogicUpdate()
  self:checkEnemy()
end

function FrozenClip:checkInBlock(player, _, blockPos)
  if not self.entity then
    return
  end
  local pos = self.entity:getPosition()
  if math.floor(pos.x) ~= blockPos.x or math.floor(pos.y) ~= blockPos.y or math.floor(pos.z) ~= blockPos.z then
    return
  end
  LuaTimer:schedule(function()
    local BlockId = EngineWorld:getBlockId(blockPos)
    if BlockId ~= BlockID.AIR then
      self:setDead(player)
    end
  end, 0)
end

function FrozenClip:checkEnemy()
  local players = PlayerManager:getPlayers()
  local target
  for _, player in pairs(players) do
    if player.teamId ~= self.creator.teamId and player.lifeStatus == true and player.entityPlayerMP ~= nil and player.entityPlayerMP:isPotionActive(14) == false then
      local distance = BtUtil.calculateDistance(self.entity.position, player:getPosition())
      if distance < self.check_range then
        if not target or distance < target.distance then
          target = {
            userId = player.userId,
            distance = distance
          }
        end
        break
      end
    end
  end
  if target then
    self:trigger(target.userId)
  end
end

function FrozenClip:trigger(userId)
  local target_player = PlayerManager:getPlayerByUserId(userId)
  if target_player then
    local hurtValue = {
      value = self.frozen_damage
    }
    if Events.PlayerAttackedEvent:invoke(target_player.entityPlayerMP, self.creator.entityPlayerMP, "player", hurtValue) then
      target_player:subHealth(hurtValue.value)
      target_player:setOnFrozen(self.frozen_duration * 1000)
    end
    self:setDead(self)
  end
end

function FrozenClip:onAttacked(player, damage)
  return false
end

function FrozenClip:setDead(killer)
  if self.entity == nil then
    return
  end
  self.super.setDead(self)
  local dieType = 0
  if killer ~= nil then
    if killer == self then
      dieType = 3
    elseif killer.teamId ~= self.creator.teamId then
      dieType = 1
    else
      dieType = 2
    end
  end
  AnalyticsReportUtil.reportFrozenClipDie(self.creator, dieType)
end

return FrozenClip

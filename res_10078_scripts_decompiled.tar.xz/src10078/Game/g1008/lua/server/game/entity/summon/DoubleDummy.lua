local DoubleDummy = class("DoubleDummy", require("game.entity.summon.ServerMonster"))

function DoubleDummy:ctor(position, config, creator, ...)
  local configs = MonsterConfig:getConfigsByType(config.type)
  for _, new_config in pairs(configs) do
    local teamId = tonumber(new_config.param[1])
    if teamId == creator.teamId then
      config = new_config
      break
    end
  end
  self.super.ctor(self, position, config, creator, ...)
end

function DoubleDummy:onCreate()
  self.creator.double_dummy = self
  self.alarm_list = {}
  self.teleportSkill = SkillConfig:getSkillByType(SkillManager.SkillType.DoubleDummyTeleport)
  self.creator:addItem(self.teleportSkill.itemId, 1)
  self.creator:sendPacket({
    pid = "UpdateItemCd",
    itemId = self.teleportSkill.itemId,
    totalTime = math.floor(self.config.hp / math.abs(self.config.recoveryHp))
  })
  self.entity:setCanFly(false)
end

function DoubleDummy:onLogicUpdate()
  if self.entity then
    local checkRange = VectorUtil.newVector3(self.config.param[2], self.config.param[3], self.config.param[4])
    local entityList = EngineWorld:getEntitiesWithinAABBExcludingEntityReturnJson(self.entity, checkRange)
    for _, entityId in pairs(json.decode(entityList)) do
      local entity = EngineWorld:getEntity(entityId)
      local entityItem = DynamicCast.dynamicCastEntity(EntityType.Item, entity)
      if entity and entity:getClassName() == "EntityItem" then
        local info = entityItem:getItemStack():getItemStackInfo()
        if Define.PickUpItemMap[info.id] then
          EngineWorld:removeEntity(entityId)
          self.creator:addItem(info.id, info.num, info.meta)
          self.haveGet = true
        end
      end
    end
    local pos = self.entity:getPosition()
    local haveGet = GameResourceManager:onPlayerMove(self.creator, pos.x, pos.y, pos.z)
    self.haveGet = self.haveGet or haveGet
    if pos.y < GameConfig.useHollowBlockHeight then
      self:subHp(9999)
    end
  end
end

function DoubleDummy:trigger()
  self.creator:teleportPos(self.entity:getPosition())
  self:setDead(self.creator)
end

function DoubleDummy:onAttacked(player, damage)
  if self.teamId == player.teamId then
    return false
  end
  self:subHp(damage, player)
  self.creator:sendPacket({
    pid = "UpdateItemCd",
    itemId = self.teleportSkill.itemId,
    totalTime = math.floor(self.config.hp / math.abs(self.config.recoveryHp)),
    curTime = math.floor(self.curHp / math.abs(self.config.recoveryHp))
  })
  return true
end

function DoubleDummy:setDead(killer)
  AnalyticsReportUtil.reportDoubleDummyDie(self.creator, killer)
  AnalyticsReportUtil.reportDoubleResource(self.creator, self.haveGet)
  self.super.setDead(self)
  self.creator.double_dummy = nil
  self.creator:removeItem(self.teleportSkill.itemId, 1)
end

return DoubleDummy

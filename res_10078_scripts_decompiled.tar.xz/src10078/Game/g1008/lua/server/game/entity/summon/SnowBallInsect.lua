local SnowBallInsect = class("SnowBallInsect", require("game.entity.summon.ServerMonster"))
InsectStatus = {
  idle = "1",
  follow = "2",
  attack = "3"
}

function SnowBallInsect:onCreate()
  self.attackTime = os.time()
  self:setSpeed(self.config.patrolSpeed)
end

function SnowBallInsect:onLogicUpdate()
  local status = self:getNowStatus()
  if status == InsectStatus.idle then
    self:onIdle()
  elseif status == InsectStatus.follow then
    self:onFollow()
  elseif status == InsectStatus.attack then
    self:onAttack()
  end
end

function SnowBallInsect:isCanAttack()
  if os.difftime(os.time(), self.attackTime) > self.config.attackInterval then
    self.attackTime = os.time()
    return true
  end
  return false
end

function SnowBallInsect:getNowStatus()
  if not self.enemy then
    return InsectStatus.idle
  end
  local enemyPlayer = PlayerManager:getPlayerByUserId(self.enemy.userId)
  if not enemyPlayer or enemyPlayer.lifeStatus == false or enemyPlayer.entityPlayerMP == nil or enemyPlayer.entityPlayerMP:isPotionActive(14) == true then
    self.enemy = nil
    return InsectStatus.idle
  end
  self.enemy.dis = BtUtil.calculateDistance(self.entity.position, enemyPlayer:getPosition())
  if self.enemy.dis < self.config.attackRadius and self:isCanAttack() then
    return InsectStatus.attack
  elseif self.enemy.dis < self.config.followRadius then
    return InsectStatus.follow
  end
end

function SnowBallInsect:onIdle()
  self:findEnemy()
  self:setSpeed(self.config.patrolSpeed)
end

function SnowBallInsect:onFollow()
  local position = PlayerManager:getPlayerByUserId(self.enemy.userId):getPosition()
  self:tryToPosition(position)
  self:setSpeed(self.config.followSpeed)
end

function SnowBallInsect:onAttack()
  self:playAction("attack")
  local player = PlayerManager:getPlayerByUserId(self.enemy.userId)
  if not player then
    return
  end
  local hurtValue = {
    value = self.config.attack
  }
  if Events.PlayerAttackedEvent:invoke(player, self.creator, "explosion", hurtValue) then
    player:subHealth(hurtValue.value)
  end
end

function SnowBallInsect:findEnemy()
  local players = PlayerManager:getPlayers()
  local dangerEnemy
  for _, player in pairs(players) do
    if player.lifeStatus == true and player.entityPlayerMP ~= nil and player.entityPlayerMP:isPotionActive(14) == false and player.teamId ~= self.teamId then
      local distance = BtUtil.calculateDistance(self.entity.position, player:getPosition())
      if dangerEnemy == nil then
        dangerEnemy = {
          userId = player.userId,
          dis = distance
        }
      elseif distance < dangerEnemy.dis then
        dangerEnemy = {
          userId = player.userId,
          dis = distance
        }
      end
    end
  end
  self.enemy = dangerEnemy
  if dangerEnemy.dis < self.config.followRadius then
    self.enemy = dangerEnemy
  end
end

return SnowBallInsect

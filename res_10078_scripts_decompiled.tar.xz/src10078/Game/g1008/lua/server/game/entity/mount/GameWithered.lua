GameWithered = class("GameWither", GameMount)
local lastTntTime = 10
local witheredVelocity = 2

function GameWithered:onCreate(id, position, player)
  self.entityId = EngineWorld:addFloatingMount(position, player:getYaw(), id, function(entity)
    player.entityPlayerMP:getOnFloatingMount(entity)
  end)
  self.lastFreeSkillTime = lastTntTime
  player.onWithered = true
end

function GameWithered:takeOffMount()
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player or not player.entityPlayerMP then
    return
  end
  player.entityPlayerMP:getOffFloatingMount()
end

function GameWithered:getSkillPosition(entity)
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  local position = entity:getPosition()
  position.y = position.y + witheredVelocity
  return position
end

function GameWithered:onMountNotEnoughTime()
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  MsgSender.sendCenterTipsToTarget(player.rakssid, 5, Messages:msgNotEnoughTimeWithered())
end

local oldOnDead = GameWithered.onDead

function GameWithered:onDead()
  oldOnDead(self)
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  player:endSinging()
  player.lastUseWithered = os.time()
  LuaTimer:schedule(function()
    player.onWithered = false
  end, 5000)
  AnalyticsReportUtil.reportWitheredKills(player, self.killNum)
  AnalyticsReportUtil.reportWitheredLifeTime(player, os.time() - self.createTime)
  AnalyticsReportUtil.reportWitheredBreakBlock(player, self.breakBlockNum)
end

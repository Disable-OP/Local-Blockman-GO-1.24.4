GameEnderDragon = class("GameEnderDragon", GameMount)
local velocity = 6

local function getOffsetPosition(pitch, yaw)
  local x = -math.sin(yaw * MathUtil.DEG2RAD) * math.cos(pitch * MathUtil.DEG2RAD)
  local y = -math.sin(pitch * MathUtil.DEG2RAD)
  local z = math.cos(yaw * MathUtil.DEG2RAD) * math.cos(pitch * MathUtil.DEG2RAD)
  local distance = math.sqrt(x * x + y * y + z * z)
  if distance < 1.0E-5 then
    distance = 1.0E-5
  end
  x = x / distance
  y = y / distance
  z = z / distance
  x = x * velocity
  y = y * 10
  z = z * velocity
  return VectorUtil.newVector3(x, y, z)
end

function GameEnderDragon:onCreate(id, position, player)
  self.entityId = EngineWorld:addFlyingMount(position, player:getYaw(), id, function(entity)
    player.entityPlayerMP:getOnFlyingMount(entity)
  end)
  local entity = EngineWorld:getEntity(self.entityId)
  if not entity then
    return
  end
  CollisionManager:addCollision(self.entityId, entity:getPosition(), CollisionManager.CollisionType.Mount, true, player:getTeamId(), player.userId)
end

function GameEnderDragon:onSkillEntityCreate(entity)
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  local offset = getOffsetPosition(player:getPitch(), player:getYaw())
  local position = entity:getPosition()
  position.x = position.x + offset.x
  position.y = position.y + offset.y
  position.z = position.z + offset.z
  entity:setPosition(position)
  entity:setNotCustomSpeed(false)
end

function GameEnderDragon:takeOffMount()
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player or not player.entityPlayerMP then
    return
  end
  player.entityPlayerMP:getOffFlyingMount()
end

function GameEnderDragon:onMountNotEnoughTime()
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  MsgSender.sendCenterTipsToTarget(player.rakssid, 5, Messages:msgNotEnoughTimeEnderDragon())
end

local oldOnDead = GameEnderDragon.onDead

function GameEnderDragon:onDead()
  CollisionManager:removeCollision(self.entityId)
  oldOnDead(self)
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  player:endSinging()
  player.lastUseEnderDragon = os.time()
  AnalyticsReportUtil.reportEnderDragonKills(player, self.killNum)
  AnalyticsReportUtil.reportEnderDragonLifeTime(player, os.time() - self.createTime)
  AnalyticsReportUtil.reportEnderDragonBreakBlock(player, self.breakBlockNum)
end

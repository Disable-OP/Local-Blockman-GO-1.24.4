GameMount = class()

function GameMount:ctor(id, position, hp, lifeTime, itemId, player)
  self.hp = hp
  self.maxHp = hp
  self.lifeTime = lifeTime
  self.oldPlayerHp = 0
  self.entityId = 0
  self.userId = player.userId
  self.skill = SkillConfig:getSkill(itemId)
  self.lastFreeSkillTime = 0
  self:onCreate(id, position, player)
  if self.skill ~= nil then
    self.skillCd = self.skill.freeCd * 1000
  else
    self.skillCd = -1
  end
  self.freeSkillTime = 0
  self.createTime = os.time()
  self.killNum = 0
  self.breakBlockNum = 0
  EntityManager:addMount(self)
  self:onPlayerTakeOn(player)
  player.mount = self
end

function GameMount:onPlayerTakeOn(player)
  local oldMaxHp = player:getMaxHealth()
  local newMaxHp = oldMaxHp + self.maxHp
  self.oldPlayerHp = player:getHealth()
  local newHp = self.oldPlayerHp + self.maxHp
  player:changeMaxHealth(newMaxHp)
  player:setHealth(newHp)
end

function GameMount:onPlayerTakeOff()
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  local oldMaxHp = player:getMaxHealth()
  local newMaxHp = oldMaxHp - self.maxHp
  player:changeMaxHealth(newMaxHp)
  player:setHealth(self.oldPlayerHp)
end

function GameMount:onCreate(id, position, player)
end

function GameMount:onTick()
  local duration = os.time() - self.createTime
  if self.lifeTime ~= -1 then
    if duration >= self.lifeTime then
      self:onDead()
      return
    end
    if self.lifeTime - duration == 10 then
      self:onMountNotEnoughTime()
    end
  end
  if self.skillCd < 0 or self.lifeTime - duration <= self.lastFreeSkillTime then
    return
  end
  self.freeSkillTime = self.freeSkillTime + 1000
  if self.freeSkillTime >= self.skillCd then
    self.freeSkillTime = self.freeSkillTime - self.skillCd
    self:onReleaseSkill()
  end
end

function GameMount:onMountNotEnoughTime()
end

function GameMount:onHurt(damage)
  self.hp = self.hp - damage
  if self.hp <= 0 then
    self:onDead()
  else
    self:broadCastPacket({
      pid = "MountHurt",
      entityId = self.entityId
    })
    local player = PlayerManager:getPlayerByUserId(self.userId)
    if not player then
      return
    end
    player:subHealth(damage, true)
  end
end

function GameMount:onReleaseSkill()
  local entity = EngineWorld:getEntity(self.entityId)
  if not entity then
    return
  end
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  if self.skill.moveSpeed > 0 or 0 < self.skill.dropSpeed then
    EngineWorld:addSkillThrowable(player, function(entity)
      entity:setHeadingFromThrower(player.entityPlayerMP, player:getPitch(), player:getYaw(), 0, 2, 0)
      entity:setSkillId(self.skill.id)
      entity:setSkillDuration(self.skill.duration)
      entity:setReleaseDistance(self.skill.distance)
      entity:setMoveSpeed(self.skill.moveSpeed)
      entity:setDropSpeed(self.skill.dropSpeed)
      entity:setAtlasName(self.skill.atlasName)
      entity:setItemIconName(self.skill.iconName)
      entity:setItemSkillId(self.skill.itemId)
      entity:setEffectName(self.skill.effectName)
      entity:setPositionAndRotation(player:getPosition(), player:getPitch(), player:getYaw())
      self:onSkillEntityCreate(entity)
    end)
  else
    SkillManager:createSkill(self.skill, player, self:getSkillPosition(entity))
  end
end

function GameMount:onSkillEntityCreate(entity)
end

function GameMount:getSkillPosition(entity)
  return entity:getPosition()
end

function GameMount:onDead()
  if self.entityId == 0 then
    return
  end
  EntityManager:removeMount(self)
  self.entityId = 0
  EngineWorld:removeEntity(self.entityId)
  self:onPlayerTakeOff()
  self:takeOffMount()
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  player.mount = nil
end

function GameMount:takeOffMount()
end

function GameMount:broadCastPacket(packet)
  if not packet or not packet.pid then
    return
  end
  for _, player in pairs(PlayerManager:getPlayers()) do
    player:sendPacket(packet)
  end
end

function GameMount:onKillPlayer()
  self.killNum = self.killNum + 1
end

function GameMount:onBreakBlock(num)
  self.breakBlockNum = self.breakBlockNum + num
end

Collision = class()
Collision.Blocks = {}

function Collision:ctor(entityId, position, type, needArea, teamId, userId)
  self.entityId = entityId
  self.position = VectorUtil.newVector3(math.ceil(position.x), math.ceil(position.y), math.ceil(position.z))
  self.type = type
  self.range = CollisionManager:getCollisionRangeByType(type)
  self.teamId = teamId or 0
  self.playerUserId = userId or 0
  self:setRange()
  if needArea then
    self.area = CollisionArea.new(self.position, 5)
  end
end

function Collision:checkCollisionArea()
  if self.area == nil or self.type ~= CollisionManager.CollisionType.Mount then
    return
  end
  local entity = EngineWorld:getEntity(self.entityId)
  if not entity then
    return
  end
  self:resetPos(entity:getPosition())
  local blocks = self.area:getBlockInArea()
  for _, block in pairs(blocks) do
    if self:isCollide(Collision.new(0, block.pos, CollisionManager.CollisionType.Block, false)) then
      self:addBlockTime(block)
    end
  end
  local players = self.area:getPlayerInArea()
  for _, player in pairs(players) do
    if self:isCollide(Collision.new(0, player.pos, CollisionManager.CollisionType.Player, false)) then
      local c_player = PlayerManager:getPlayerByUserId(player.userId)
      if c_player ~= nil and not c_player:ifOnMount() and c_player.isLife == true and not c_player.isBleed and c_player:getTeamId() ~= self.teamId then
        c_player:subHealth(GameConfig.DragonHurt)
        c_player.entityPlayerMP:knockBack(c_player.entityPlayerMP, 0.5, 0.2, 0.2)
        c_player.isBleed = true
        LuaTimer:schedule(function(userId)
          local pPlayer = PlayerManager:getPlayerByUserId(userId)
          if pPlayer == nil then
            return
          end
          pPlayer.isBleed = false
        end, GameConfig.DragonHurtTime * 1000, nil, c_player.userId)
      end
    end
  end
  self:checkBlocks()
end

function Collision:resetPos(position)
  self.position = VectorUtil.newVector3(math.ceil(position.x), math.ceil(position.y), math.ceil(position.z))
  self:setRange()
  self.area:resetArea(self.position)
end

function Collision:setRange()
  self.minX = self.position.x - self.range.x
  self.maxX = self.position.x + self.range.x
  self.minY = self.position.y - self.range.y
  self.maxY = self.position.y + self.range.y
  self.minZ = self.position.z - self.range.z
  self.maxZ = self.position.z + self.range.z
end

function Collision:isCollide(collision)
  if collision == nil then
    return false
  end
  return (self.minX >= collision.minX and self.minX <= collision.maxX or collision.minX >= self.minX and collision.minX <= self.maxX) and (self.minY >= collision.minY and self.minY <= collision.maxY or collision.minY >= self.minY and collision.minY <= self.maxY) and (self.minZ >= collision.minZ and self.minZ <= collision.maxZ or collision.minZ >= self.minZ and collision.minZ <= self.maxZ)
end

function Collision:addBlockTime(block)
  local cache = self.Blocks[block.hash]
  if cache == nil then
    cache = {
      pos = block.pos,
      time = 0
    }
  end
  cache.time = cache.time + 1000
  self.Blocks[block.hash] = cache
end

function Collision:checkBlocks()
  local removes = {}
  for hash, block in pairs(self.Blocks) do
    if block.time >= GameConfig.breakBlockTime then
      EngineWorld:setBlockToAir(block.pos)
      EngineWorld:addSimpleEffect("fragment_block.effect", VectorUtil.toVector3(block.pos), 0, 1000, 0, 2)
      local mount = EntityManager:getMount(self.entityId)
      if mount then
        mount:onHurt(GameConfig.breakBlockHurt)
        mount:onBreakBlock(1)
      end
      table.insert(removes, hash)
    end
  end
  for _, hash in pairs(removes) do
    self.Blocks[hash] = nil
  end
end

return Collision

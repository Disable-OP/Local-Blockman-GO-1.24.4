CollisionArea = class()

function CollisionArea:ctor(center, range, withPos)
  if withPos ~= nil then
    self:initAreaWithPos(center, range)
    return
  end
  self.center = center
  self.range = range
  self:initArea(self.range)
end

function CollisionArea:initAreaWithPos(startPos, endPos)
  self.startPos = startPos
  self.endPos = endPos
  self.minX = self.startPos.x
  self.maxX = self.endPos.x
  self.minY = self.startPos.y
  self.maxY = self.endPos.y
  self.minZ = self.startPos.z
  self.maxZ = self.endPos.z
end

function CollisionArea:resetArea(position, range)
  self.center = position
  self.range = range or self.range
  self:initArea(self.range)
end

function CollisionArea:initArea(range)
  self.minX = self.center.x - range
  self.maxX = self.center.x + range
  self.minY = self.center.y - range - 0.5
  self.maxY = self.center.y + range + 0.5
  self.minZ = self.center.z - range
  self.maxZ = self.center.z + range
end

function CollisionArea:isInArea(pos)
  return pos.x >= self.minX and pos.x <= self.maxX and pos.y >= self.minY and pos.y <= self.maxY and pos.z >= self.minZ and pos.z <= self.maxZ
end

function CollisionArea:getBlockInArea()
  local result = {}
  for i = self.center.x - self.range, self.center.x + self.range do
    for j = self.center.z - self.range, self.center.z + self.range do
      for q = self.center.y - self.range, self.center.y + self.range do
        local position = VectorUtil.newVector3i(i, q, j)
        local blockId = EngineWorld:getBlockId(position)
        if blockId ~= BlockID.AIR and blockId ~= BlockID.CHEST and blockId ~= BlockID.OBSIDIAN and EngineWorld:isBlockChange(position) then
          table.insert(result, {
            hash = VectorUtil.hashVector3(position),
            pos = position
          })
        end
      end
    end
  end
  return result
end

function CollisionArea:getPlayerInArea()
  local result = {}
  local players = PlayerManager:copyPlayers()
  for _, player in pairs(players) do
    if not player:ifOnMount() and player.isLife == true and self:isInArea(player:getPosition()) then
      table.insert(result, {
        pos = player:getPosition(),
        userId = player.userId
      })
    end
  end
  return result
end

return CollisionArea

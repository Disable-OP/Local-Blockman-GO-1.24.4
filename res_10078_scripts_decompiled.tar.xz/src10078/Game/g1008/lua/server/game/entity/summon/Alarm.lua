local Alarm = class("Alarm", require("game.entity.summon.ServerMonster"))

function Alarm:onCreate()
  self.createTime = os.time()
  self.check_range = tonumber(self.config.param[1])
  self.entity:addCustomEffect("", "g1008_radar.effect", -1, self.check_range / 10)
  self.alarm_list = {}
end

function Alarm:onLogicUpdate()
  self:checkEnemy()
end

function Alarm:checkEnemy()
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    if not self.alarm_list[tostring(player.userId)] and player.teamId ~= self.creator.teamId and player.lifeStatus == true and player.entityPlayerMP ~= nil and player.entityPlayerMP:isPotionActive(14) == false then
      local distance = BtUtil.calculateDistance(self.entity.position, player:getPosition())
      if distance < self.check_range then
        self:sendWarning(player.userId)
        break
      end
    end
  end
end

function Alarm:sendWarning(userId)
  local warningTime = self.config.param[2]
  if not warningTime then
    return
  end
  if not self.findEnemyTime then
    self.findEnemyTime = os.time()
  end
  self.alarm_list[tostring(userId)] = 1
  self.creator:sendPacket({
    pid = "AlarmWarning",
    time = warningTime,
    userId = tostring(userId)
  })
end

function Alarm:onAttacked(player, damage)
  if self.teamId == player.teamId then
    return false
  end
  self:subHp(damage, player)
  return true
end

function Alarm:setDead(killer)
  self.super.setDead(self)
  if self.findEnemyTime then
    AnalyticsReportUtil.reportAlarmWarning(self.creator, self.findEnemyTime - self.createTime)
  else
    AnalyticsReportUtil.reportAlarmWarning(self.creator, -1)
  end
  AnalyticsReportUtil.reportAlarmDie(self.creator, killer ~= nil)
  self.creator:sendPacket({
    pid = "AlarmDisappear"
  })
end

return Alarm

require("common.web.BedWarWeb")
require("common.connector.MessageInterceptor")
BaseListener.registerCallBack(CEvents.GameInitEvent, function(config)
  if GameType == "g1046" then
    require("hall.BedWarServer")
  else
    require("game.BedWarServer")
  end
  require("common.BedWarServer")
  BedWarServer.onGameInit(config)
end)

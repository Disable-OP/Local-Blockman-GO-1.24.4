GameLicense = {}
GameLicense.not_buy = 0
GameLicense.had_buy = 1
GameLicense.had_buyLuxury = 2

function GameLicense:calculateLevelInterval(level)
  local Interval = 0
  local IntervalChange = false
  if level == 1 then
    Interval = "1"
  elseif 2 <= level and level <= 5 then
    if level == 2 then
      IntervalChange = "1"
    end
    Interval = "2_5"
  elseif 6 <= level and level <= 10 then
    if level == 6 then
      IntervalChange = "2_5"
    end
    Interval = "6_10"
  elseif 11 <= level and level <= 20 then
    if level == 11 then
      IntervalChange = "6_10"
    end
    Interval = "11_20"
  elseif 21 <= level and level <= 25 then
    if level == 21 then
      IntervalChange = "11_20"
    end
    Interval = "21_25"
  elseif 26 <= level and level <= 30 then
    if level == 26 then
      IntervalChange = "21_25"
    end
    Interval = "26_30"
  elseif 31 <= level and level <= 45 then
    if level == 31 then
      IntervalChange = "26_30"
    end
    Interval = "31_45"
  elseif 46 <= level and level <= 60 then
    if level == 46 then
      IntervalChange = "31_45"
    end
    Interval = "46_60"
  elseif 61 <= level and level <= 70 then
    if level == 31 then
      IntervalChange = "46_60"
    end
    Interval = "61_70"
  elseif 71 <= level and level <= 80 then
    if level == 71 then
      IntervalChange = "61_70"
    end
    Interval = "71_80"
  elseif 81 <= level then
    if level == 81 then
      IntervalChange = "71_80"
    end
    Interval = "81_120"
  end
  return Interval, IntervalChange
end

function GameLicense:initSeason()
  self.seasonDate, self.exchangeDate, self.seasonEndDate, self.periodDate = LicenseConfig:calculateSeason()
  if self.seasonDate == -1 then
    self.week = 0
  else
    self.week = LicenseConfig:calculateWeek(self.seasonDate)
  end
  local refreshTime = self.seasonEndDate - os.time()
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    self:updatePlayerData(player)
  end
  LuaTimer:cancel(self.seasonKey or 0)
  self.seasonKey = LuaTimer:schedule(function()
    self:initSeason()
  end, refreshTime * 1000)
end

function GameLicense:init()
  Events.PlayerTaskProcessChangeEvent:registerCallBack(function(userId, key, task)
    if key ~= "curLicenseDailyTask" and key ~= "curLicenseSeasonTask" then
      return
    end
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
      return
    end
    if task.status == Define.TaskStatus.FINISHED then
      self:onTaskFinish(player, task, key)
      if key == "curLicenseDailyTask" then
        ReportUtil.reportPlayerFinishTask(player, task.taskId)
      elseif key == "curLicenseSeasonTask" then
        ReportUtil.reportPlayerFinishSeasonTask(player, task.taskId)
      end
    end
    local finishNum
    for _, finishTask in pairs(player.finish_task or {}) do
      if finishTask.taskId == task.taskId then
        finishNum = finishTask.finishNum
      end
    end
    if key == "curLicenseDailyTask" then
      CommonPacketSender:sendLicenseDailyTaskInfo(player.rakssid, task, finishNum)
    elseif key == "curLicenseSeasonTask" then
      CommonPacketSender:sendLicenseSeasonTaskInfo(player.rakssid, task, player.changeTaskId)
    end
    player.changeTaskId = -1
  end)
  EventObservable:registerDataCallBack("OpenLicense", function(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
      return
    end
    player.hadOpenLicense = true
  end)
end

GameLicense:init()

function GameLicense:initSeasonTask(player, key, refresh)
  if not player then
    return
  end
  if refresh then
    GamePacketSender:sendLicenseCleanTask(player.rakssid, "season")
    player.taskController:clearDailyTasks(key)
  end
  if player.taskController.dailyTasks[key] == nil or TableUtil.getTableSize(player.taskController.dailyTasks[key]) == 0 or refresh then
    local seasonConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
    if not seasonConfig then
      return
    end
    local taskGroup = seasonConfig.SeasonTaskGroup
    local tasks = TaskConfig:getTaskByGroupId(taskGroup)
    if not tasks then
      return
    end
    for _, taskConfig in pairs(tasks) do
      if taskConfig.TaskTypeId == Define.TaskType.GrowUp.DailyLogin and player.play_day_key == DateUtil.getYearDay() then
        local task = player.taskController:addDailyTask("curLicenseSeasonTask", taskConfig.Id)
        local progress = {
          Type = Define.TaskType.GrowUp.DailyLogin,
          GameType = BaseMain:getGameType(),
          Remarks = 0,
          Value = 1
        }
        task:matching(progress)
        Events.PlayerTaskProcessChangeEvent:invoke(player.userId, "curLicenseSeasonTask", task)
      else
        player.taskController:addDailyTask(key, taskConfig.Id)
      end
    end
  end
end

function GameLicense:onPlayerReceiveSeasonTaskReward(player, taskId)
  if not player then
    return
  end
  player.taskController:continueSeasonTask("curLicenseSeasonTask", taskId)
end

function GameLicense:onTaskFinish(player, task, key)
  if not (key ~= "curLicenseSeasonTask" and player) or GameType == "g1046" then
    return
  end
  self:onFinishTaskAddEXP(player, task.taskId, key)
  self:addTaskToFinishList(player, task.taskId)
end

function GameLicense:onFinishTaskAddEXP(player, taskId, key)
  local task = TaskConfig:getTaskById(taskId)
  if not task then
    return
  end
  local weekConfig = LicenseConfig:getWeekConfig(self.seasonDate, self.week)
  if not weekConfig then
    return
  end
  if key == "curLicenseDailyTask" and player.license_week_exp >= weekConfig.EXPLimit then
    return
  end
  local extraEXP = 0
  if key == "curLicenseDailyTask" then
    if player.license_week_exp + task.Reward > weekConfig.EXPLimit then
      extraEXP = player.license_week_exp + task.Reward - weekConfig.EXPLimit
    end
    player.license_week_exp = player.license_week_exp + task.Reward - extraEXP
  end
  local curEXP = player.license_exp + task.Reward
  local curLV = player.license_level
  self:onPlayerGetEXP(player, curEXP, curLV, self.seasonDate)
end

function GameLicense:addTaskToFinishList(player, taskId)
  local hadTask = false
  if not player.finish_task then
    return
  end
  for _, finishTask in pairs(player.finish_task) do
    if finishTask.taskId == taskId then
      hadTask = true
      finishTask.finishNum = finishTask.finishNum + 1
    end
  end
  if not hadTask then
    local task = {taskId = taskId, finishNum = 1}
    table.insert(player.finish_task, task)
  end
end

local function syncPlayerLicenseData(player)
  player.license_level = math.max(player.license_level, 1)
  local dress = GameLicense:getHadDress(player)
  local data = {}
  data.season_data = GameLicense.seasonDate
  data.license_buy = player.license_buy
  data.license_exp = player.license_exp
  data.license_level = player.license_level
  data.had_horn = player.had_horn
  data.free_upgrade_time = player.free_upgrade_time
  data.get_free_reward = player.get_free_reward
  data.get_pay_reward = player.get_pay_reward
  data.exchange_reward = player.exchange_reward
  data.had_get_dress = dress
  data.license_week = player.license_week
  data.show_effect_task = player.show_effect_task
  data.license_week_exp = player.license_week_exp
  GamePacketSender:sendBedWarLicense(player.rakssid, json.encode(data))
  CommonPacketSender:sendBedWarPlayerMoneyCount(player.rakssid, Define.Money.HORN, player.had_horn)
  player.show_effect_task = {}
end

local function resetPlayerLicenseData(player)
  player.license_season = GameLicense.seasonDate
  player.license_week = 0
  player.license_week_exp = 0
  player.license_buy = 0
  player.license_exp = 0
  player.free_upgrade_time = 0
  if GameLicense.seasonDate > 0 then
    player.license_level = 1
  end
  player.get_free_reward = {}
  player.get_pay_reward = {}
  player.exchange_reward = {}
  player.finish_task = {}
  player.show_effect_task = {}
  syncPlayerLicenseData(player)
end

function GameLicense:resetLicense(player)
  player.taskController:clearDailyTasks("curLicenseSeasonTask")
  player.taskController:clearDailyTasks("curLicenseDailyTask")
  resetPlayerLicenseData(player)
end

function GameLicense:updatePlayerData(player)
  if self.seasonDate == -1 then
    player.taskController:clearDailyTasks("curLicenseSeasonTask")
    player.taskController:clearDailyTasks("curLicenseDailyTask")
    return
  end
  if self.seasonDate ~= player.license_season then
    if player.license_season > 0 then
      self:initPlayerRewardList(player, player.license_season)
      self:onPlayerGetReward(player.userId, nil, true, player.license_season, nil, nil)
    end
    resetPlayerLicenseData(player)
    self:initSeasonTask(player, "curLicenseSeasonTask", true)
    ReportUtil.reportPlayerLicenseLvUp(player, player.license_level)
  else
    syncPlayerLicenseData(player)
    self:initSeasonTask(player, "curLicenseSeasonTask", false)
  end
  self:initPlayerRewardList(player, self.seasonDate)
  if self.week ~= player.license_week or #player.taskController:getDailyTasks("curLicenseDailyTask") == 0 then
    player.license_week = self.week
    player.license_week_exp = 0
    local weekConfig = LicenseConfig:getWeekConfig(self.seasonDate, self.week)
    if weekConfig then
      GamePacketSender:sendLicenseCleanTask(player.rakssid, "week")
      player.taskController:refreshDailyTaskByTaskGroup(weekConfig.TaskGroup, true)
    end
    syncPlayerLicenseData(player)
  end
end

function GameLicense:onPlayerBuy(player, season, buyType)
  if self.seasonDate == -1 then
    return
  end
  if player.license_buy ~= GameLicense.not_buy then
    return
  end
  local licenseConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
  if not licenseConfig then
    return
  end
  if buyType == GameLicense.had_buy then
    PayHelper.payDiamondsSync(player.userId, licenseConfig.LicenseId, licenseConfig.LicensePrice, function()
      player.license_buy = GameLicense.had_buy
      self:onBuySuccess(player, licenseConfig.LicenseId)
      ReportUtil.reportBuyLicenseSuccess(player, "common")
    end)
  elseif buyType == GameLicense.had_buyLuxury then
    PayHelper.payDiamondsSync(player.userId, licenseConfig.LuxuryId, licenseConfig.LuxuryPrice, function()
      local curEXP = player.license_exp + licenseConfig.LuxuryRewardEXP
      local curLV = player.license_level
      player.license_buy = 2
      self:onPlayerGetEXP(player, curEXP, curLV, self.seasonDate, true)
      ReportUtil.reportBuyLicenseSuccess(player, "luxury")
      self:onBuySuccess(player, buyType)
    end)
  end
end

function GameLicense:onPlayerGetEXP(player, curEXP, curLV, season, getAll)
  if self.seasonDate == -1 then
    return
  end
  if self:isMaxLevel(player, self.seasonDate) then
    return
  end
  local LVConfig = LicenseConfig:getRewardConfigBySeason(self.seasonDate)
  if not LVConfig then
    return
  end
  if not LVConfig[curLV] then
    return
  end
  local needEXP = LVConfig[curLV].NeedEXP
  if not needEXP then
    return
  end
  while curEXP >= needEXP do
    curEXP = curEXP - needEXP
    curLV = curLV + 1
    ReportUtil.reportPlayerLicenseLvUp(player, curLV)
    if GameLicense:isMaxLevel(player, season, curLV) then
      break
    end
    needEXP = LVConfig[curLV].NeedEXP
  end
  player.license_level = curLV
  player.license_exp = curEXP
  if getAll then
    self:onPlayerGetReward(player.userId, nil, true, self.seasonDate, nil, nil)
  end
  GamePacketSender:sendLicenseFinishTask(player.rakssid, player.license_exp, player.license_level, player.license_week_exp)
end

function GameLicense:isMaxLevel(player, season, curLV)
  local LVConfig = LicenseConfig:getRewardConfigBySeason(season)
  if not LVConfig then
    return
  end
  local Lv = curLV or player.license_level
  if Lv == #LVConfig then
    return true
  end
  return false
end

function GameLicense:onBuySuccess(player, buyType)
  local data = {
    curEXP = player.license_exp,
    curLV = player.license_level,
    hadBuy = buyType
  }
  GamePacketSender:sandBedWarLicensePaySuccess(player.rakssid, json.encode(data))
end

function GameLicense:onPlayerBuyLevel(player, season, level, free)
  if self.seasonDate == -1 then
    return
  end
  if player.license_level ~= level then
    return
  end
  local rewardIdList = LicenseConfig:getRewardConfigBySeason(self.seasonDate)
  if not rewardIdList then
    return
  end
  local buyLevelPrice
  for _, reward in pairs(rewardIdList) do
    if reward.Lv == player.license_level then
      buyLevelPrice = reward.BuyLevel
    end
  end
  local seasonConfig = LicenseConfig:getSeasonConfigBySeason(self.seasonDate)
  if not seasonConfig then
    return
  end
  local BuyLevelId = seasonConfig.BuyLevelId
  if free then
    if tostring(player.free_upgrade_time) == DateUtil.getYearDay() then
      return
    end
    player.free_upgrade_time = DateUtil.getYearDay()
    player.license_level = player.license_level + 1
    GamePacketSender:sendWatchLicenseADSuccess(player.rakssid, player.license_level, player.license_exp, player.free_upgrade_time)
    ReportUtil.reportPlayerLicenseLvUp(player, player.license_level)
  else
    PayHelper.payDiamondsSync(player.userId, BuyLevelId, buyLevelPrice, function()
      player.license_level = player.license_level + 1
      ReportUtil.reportPlayerBuyLevel(player, player.license_level)
      GameLicense:onBuySuccess(player, player.license_buy)
      ReportUtil.reportPlayerLicenseLvUp(player, player.license_level)
    end)
  end
end

function GameLicense:initPlayerRewardList(player, season)
  if not player then
    return
  end
  local freeList = player.get_free_reward
  local payList = player.get_pay_reward
  local getFreeList = {}
  local getPayList = {}
  player.license_freeReward = getFreeList
  player.license_payReward = getPayList
  local rewardList = LicenseConfig:getRewardConfigBySeason(season)
  if #rewardList == 0 then
    return
  end
  for _, reward in pairs(rewardList) do
    getFreeList[reward.Lv] = {
      FreeReward = reward.FreeReward,
      FreeNum = reward.FreeNum,
      FreeStatue = 1,
      Lv = reward.Lv
    }
    getPayList[reward.Lv] = {
      PayReward = reward.PayReward,
      PayNum = reward.PayNum,
      PayStatue = 1,
      Lv = reward.Lv
    }
  end
  for _, freeReward in pairs(freeList) do
    if getFreeList[freeReward.Lv] and freeReward.rewardId == getFreeList[freeReward.Lv].FreeReward then
      getFreeList[freeReward.Lv].FreeStatue = 2
    end
  end
  for _, payReward in pairs(payList) do
    if getPayList[payReward.Lv] and payReward.rewardId == getPayList[payReward.Lv].PayReward then
      getPayList[payReward.Lv].PayStatue = 2
    end
  end
end

function GameLicense:getHadDress(player)
  local exchangeReward = LicenseConfig:getExchangeConfigBySeason(self.seasonDate)
  local hadGet = player.dress or {}
  local hadGetCustom = player.custom_goods or {}
  local result = {}
  for i, reward in pairs(exchangeReward) do
    local rewardConfig = RewardConfig:getRewardById(reward.ItemId)
    if not rewardConfig then
      return
    end
    if rewardConfig then
      if rewardConfig.RewardType == Define.RewardType.DRESS then
        for _, dress in pairs(hadGet) do
          if rewardConfig.RewardId == dress.Id then
            table.insert(result, reward.ItemId)
          end
        end
      end
      if rewardConfig.RewardType == Define.RewardType.CUSTOM_SHOP then
        for _, types in pairs(hadGetCustom) do
          for _, good in pairs(types) do
            if good[1] == rewardConfig.RewardId then
              table.insert(result, reward.ItemId)
            end
          end
        end
      end
    end
  end
  return result
end

function GameLicense:onPlayerGetReward(userId, Lv, getAll, season, rewardId, rewardType)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local result = {}
  local freeList = player.license_freeReward
  local payList = player.license_payReward
  local playerLevel = math.min(TableUtil.getTableSize(freeList), player.license_level)
  if getAll then
    for i = 1, playerLevel do
      if freeList[i] and freeList[i].FreeStatue == 1 and playerLevel >= freeList[i].Lv and freeList[i].FreeReward ~= "#" then
        freeList[i].FreeStatue = 2
        local freeData = {
          rewardId = freeList[i].FreeReward,
          Lv = freeList[i].Lv
        }
        table.insert(player.get_free_reward, freeData)
        local data = {
          rewardId = freeList[i].FreeReward,
          rewardType = "free",
          Lv = freeList[i].Lv
        }
        table.insert(result, data)
        self:PlayerGetReward(player, freeList[i].FreeReward, freeList[i].FreeNum)
      end
      if payList[i] and payList[i].PayStatue == 1 and playerLevel >= payList[i].Lv and player.license_buy ~= 0 and payList[i].PayReward ~= "#" then
        payList[i].PayStatue = 2
        local payData = {
          rewardId = payList[i].PayReward,
          Lv = freeList[i].Lv
        }
        table.insert(player.get_pay_reward, payData)
        local data = {
          rewardId = payList[i].PayReward,
          rewardType = "pay",
          Lv = payList[i].Lv
        }
        table.insert(result, data)
        self:PlayerGetReward(player, payList[i].PayReward, payList[i].PayNum)
      end
    end
  elseif rewardType == "free" then
    if freeList[Lv] and freeList[Lv].FreeReward == rewardId and freeList[Lv].FreeStatue == 1 and playerLevel >= freeList[Lv].Lv then
      freeList[Lv].FreeStatue = 2
      local freeData = {
        rewardId = freeList[Lv].FreeReward,
        Lv = freeList[Lv].Lv
      }
      table.insert(player.get_free_reward, freeData)
      local data = {
        rewardId = freeList[Lv].FreeReward,
        rewardType = "free",
        Lv = freeList[Lv].Lv
      }
      table.insert(result, data)
      self:PlayerGetReward(player, freeList[Lv].FreeReward, freeList[Lv].FreeNum)
    end
  elseif payList[Lv] and payList[Lv].PayReward == rewardId and payList[Lv].PayStatue == 1 and playerLevel >= payList[Lv].Lv and player.license_buy ~= 0 then
    payList[Lv].PayStatue = 2
    local payData = {
      rewardId = payList[Lv].PayReward,
      Lv = freeList[Lv].Lv
    }
    table.insert(player.get_pay_reward, payData)
    local data = {
      rewardId = payList[Lv].PayReward,
      rewardType = "pay",
      Lv = payList[Lv].Lv
    }
    table.insert(result, data)
    self:PlayerGetReward(player, payList[Lv].PayReward, payList[Lv].PayNum)
  end
  if 0 < #result then
    PacketSender:sendLuaCommonData(player.rakssid, "BedWarLicenseGetRewardSuccess", json.encode(result))
  end
end

function GameLicense:addRewardsStatus(player)
  local List = LicenseConfig:getRewardConfigBySeason(self.seasonDate)
  local rewardIdList = TableUtil.copyTable(List or {})
  local hadGetFree = player.get_free_reward
  local hadGetPay = player.get_pay_reward
  for _, reward in pairs(rewardIdList) do
    if reward.Lv > player.license_level then
      reward.FreeStatue = 0
      reward.PayStatue = 0
    else
      local boolFreeHadGet = false
      for _, hadGet in pairs(hadGetFree) do
        if hadGet.rewardId == reward.FreeReward and hadGet.Lv == reward.Lv then
          boolFreeHadGet = true
        end
      end
      if boolFreeHadGet then
        reward.FreeStatue = 2
      else
        reward.FreeStatue = 1
      end
      if player.license_buy ~= 0 then
        local boolPayHadGet = false
        for _, hadGet in pairs(hadGetPay) do
          if hadGet.rewardId == reward.PayReward and hadGet.Lv == reward.Lv then
            boolPayHadGet = true
          end
        end
        if boolPayHadGet then
          reward.PayStatue = 2
        else
          reward.PayStatue = 1
        end
      else
        reward.PayStatue = 0
      end
    end
  end
  return rewardIdList
end

function GameLicense:PlayerGetReward(player, rewardId, rewardNum)
  local rewardConfig = RewardConfig:getRewardById(rewardId)
  if not rewardConfig then
    return
  end
  if rewardConfig.RewardType ~= Define.RewardType.CUSTOM_SHOP then
    local Reward = {
      RewardId = rewardConfig.RewardId,
      Count = rewardNum,
      RewardType = rewardConfig.RewardType,
      Time = rewardConfig.Time * rewardNum,
      RedressRewardId = rewardConfig.RedressRewardId
    }
    GameReward:onPlayerGetReward(player, Reward)
  else
    local goods = CustomShopConfig:getGoodsConfig(rewardConfig.RewardId)
    if goods then
      CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.License)
    end
  end
end

function GameLicense:onPlayerExchange(userId, itemId, season, rewardNum)
  if self.exchangeDate == -1 then
    return
  end
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local exchangeList = LicenseConfig:getExchangeConfigBySeason(self.exchangeDate)
  local exchangeConfig
  for _, exchange in pairs(exchangeList) do
    if exchange.ItemId == itemId then
      exchangeConfig = exchange
      break
    end
  end
  if not exchangeConfig then
    return
  end
  if player.had_horn < exchangeConfig.Price * rewardNum or player.license_level < exchangeConfig.LVLimit then
    return
  end
  local exchangeData
  for _, hadExchange in pairs(player.exchange_reward) do
    if hadExchange.itemId == itemId then
      exchangeData = hadExchange
      break
    end
  end
  if not exchangeData then
    exchangeData = {itemId = itemId, num = 0}
    table.insert(player.exchange_reward, exchangeData)
  end
  if rewardNum > exchangeConfig.BuyLimit - exchangeData.num then
    return
  end
  exchangeData.num = exchangeData.num + rewardNum
  self:PlayerGetReward(player, itemId, rewardNum * exchangeConfig.Num)
  player.had_horn = player.had_horn - rewardNum * exchangeConfig.Price
  CommonPacketSender:sendBedWarPlayerMoneyCount(player.rakssid, Define.Money.HORN, player.had_horn)
  local result = {itemId = itemId, num = rewardNum}
  ReportUtil.reportPlayerExchange(player, itemId)
  GamePacketSender:sendBedWarLicenseExchangeSuccess(player.rakssid, json.encode(result))
end

function GameLicense:onPlayerLogout(player)
  local effectTask = player.taskController:consumeAndRecycleTask("curLicenseDailyTask")
  player.show_effect_task = effectTask
end

GameStore = {}
local StoreLimitRecord = {}
local PropPacketManager = require("common.manager.PropPacketManager")

local function init()
  CommonDataEvents:registerCallBack("BuyGoods", function(userId, goodsId)
    GameStore:onPlayerBuyGoods(userId, goodsId, true)
  end)
end

init()

local function rollBackOrder(player, goods)
  local currency = StoreConfig:getCurrencyConfig(goods.CurrencyId)
  if not currency then
    return
  end
  if currency.ItemId > 0 then
    player:addItem(currency.ItemId, goods.Price)
  end
end

local function checkHasHighLevelGoods(player, goods)
  if goods.LevelGroup == "#" then
    return false
  end
  local inv = player:getInventory()
  if goods.Type == GoodsType.Item then
    for index = 1, 36 do
      local info = inv:getItemStackInfo(index - 1)
      if info.id ~= 0 then
        local _goods = StoreConfig:getGoodsByItemId(info.id)
        if _goods and _goods.LevelGroup == goods.LevelGroup and _goods.Level >= goods.Level then
          return true
        end
      end
    end
  end
  if goods.Type == GoodsType.Armor then
    for index = 101, 104 do
      local info = inv:getItemStackInfo(index - 1)
      if info.id ~= 0 then
        local _goods = StoreConfig:getGoodsByItemId(info.id)
        if _goods and _goods.LevelGroup == goods.LevelGroup and _goods.Level >= goods.Level then
          return true
        end
      end
    end
  end
  if goods.Type == GoodsType.Upgrade then
    local team = GameMatch.Teams[player:getTeamId()]
    if not team or not team.info then
      return true
    end
    if tonumber(team.info:getValue(goods.ItemId)) >= goods.Level then
      return true
    end
  end
  return false
end

local function onBuyGoodsSuccess(player, goods)
  local count = GoodsStorePrivilege:onBuyGoods(player, goods)
  if goods.Type == GoodsType.Item then
    if goods.Level == 1 then
      player:addInitItems(goods.ItemId)
    end
    AnalyticsReportUtil.onPlayerBuyItem(player, goods.ItemId, count)
    player:tryAddItem(goods.ItemId, count, 0, TableUtil.copyTable(goods.EnchantList))
  elseif goods.Type == GoodsType.Armor then
    AnalyticsReportUtil.onPlayerBuyItem(player, goods.ItemId, count)
    player:tryAddItem(goods.ItemId, count, 0, TableUtil.copyTable(goods.EnchantList))
  elseif goods.Type == GoodsType.Upgrade then
    local success = GameGains:onPlayerUpgrade(player, goods.ItemId, goods.Level)
    if not success then
      rollBackOrder(player, goods)
    end
  elseif goods.Type == GoodsType.Privilege then
    Privilege.addPrivilegeTime(player, goods.ItemId)
    local currency = StoreConfig:getCurrencyConfig(goods.CurrencyId)
    if currency and currency.RealId == Define.Money.KEY then
      ReportUtil.reportPlayerCostKey(player, goods.Price, "key_BuyPrivilege", goods.Id)
    end
  elseif goods.Type == GoodsType.Key then
    player:addYaoShi(count)
  elseif goods.Type == GoodsType.Horn then
    player:addHorn(count)
  elseif goods.Type == GoodsType.Ticket then
    player:addTicket(count)
  elseif goods.Type == GoodsType.BulletClip then
    GMHelper:addCrossbowArrow(player, goods.ItemId, count)
  elseif goods.Type == GoodsType.PropPacket then
    PropPacketManager:onAddItem(player, goods.ItemId, count)
  end
  LuaTimer:schedule(function()
    CommonPacketSender:sendBuyGoodsSuccess(player.rakssid, goods.Id)
  end, 100)
end

function GameStore:checkCanBuyGoods(player, goods, needMoney, callback)
  if goods.Price < 0 then
    callback(false)
    return
  end
  if player:isDead() then
    return
  end
  if goods.Type == GoodsType.Item then
    local inv = player:getInventory()
    if not inv then
      callback(false)
      return
    end
    if not inv:isCanAddItem(goods.ItemId, 0, goods.Count) then
      callback(false)
      return
    end
  end
  if (goods.Type == GoodsType.Item or goods.Type == GoodsType.Armor or goods.Type == GoodsType.Upgrade) and checkHasHighLevelGoods(player, goods) then
    callback(false)
    return
  end
  local currency = StoreConfig:getCurrencyConfig(goods.CurrencyId)
  if not currency then
    callback(false)
    return
  end
  if goods.LimitCount ~= -1 and needMoney then
    local record = StoreLimitRecord[tostring(player.userId)] or {}
    StoreLimitRecord[tostring(player.userId)] = record
    local limit = record[tostring(goods.Id)] or goods.LimitCount
    if limit == 0 then
      return false
    end
    record[tostring(goods.Id)] = limit - 1
  end
  if 0 < currency.ItemId then
    local inv = player:getInventory()
    if inv:getItemNum(currency.ItemId) < goods.Price and needMoney then
      callback(false)
      return
    end
    if needMoney then
      player:removeItem(currency.ItemId, goods.Price)
    end
    callback(true)
  else
    if not MoneyUtil:checkHasMoney(player, currency.RealId, goods.Price) and needMoney then
      callback(false)
      return
    end
    if needMoney then
      MoneyUtil:consumeMoney(player, goods.Id, currency.RealId, goods.Price, function()
        callback(true)
      end, "key_Privilege")
    else
      callback(true)
    end
  end
end

function GameStore:onPlayerBuyGoods(userId, goodsId, needMoney)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return false
  end
  local goods = StoreConfig:getGoodsById(goodsId)
  if not goods then
    return false
  end
  local isSuccess = false
  self:checkCanBuyGoods(player, goods, needMoney, function(canBuy)
    if canBuy then
      onBuyGoodsSuccess(player, goods)
      isSuccess = true
    end
  end)
  return isSuccess
end

function GameStore:onPlayerLotteryReplace(userId, goodsId)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return false
  end
  local goods = StoreConfig:getGoodsById(goodsId)
  if not goods then
    return false
  end
  onBuyGoodsSuccess(player, goods)
end

TreasureChallenge = {}
TreasureChallenge.currRewardId = {}
TreasureChallenge.challengeConfig = {}

local function recyclePlayerRune(player, rune_id)
  if not DbUtil:IsGetAllDataFinished(player) then
    return false
  end
  if rune_id == 0 then
    return false
  end
  for key, rune in pairs(player.rune) do
    if rune.runeId == rune_id then
      rune.num = 0
      table.remove(player.rune, key)
      break
    end
  end
  for _, trough in pairs(player.equip_rune) do
    if trough.id == rune_id then
      trough.id = 0
    end
  end
  return true
end

local function addChallengeProgress(player, points)
  for _, iReward in pairs(player.challenges[TreasureChallengeConfig.times]) do
    if iReward.status == Define.ChallengeStatus.Experiencing then
      iReward.havePoints = iReward.havePoints + points
      CommonPacketSender:sendChallengePoints(player.rakssid, TreasureChallengeConfig.times, TreasureChallenge.currRewardId[tostring(player.userId)], iReward.havePoints)
      if iReward.havePoints >= iReward.needPoints then
        TreasureChallenge:onFinishChallenge(player, TreasureChallengeConfig.times, iReward.rewardId)
      end
      return
    end
  end
end

function TreasureChallenge:init()
  self.challengeConfig = TreasureChallengeConfig:getCurrentChallenge()
  EventObservable:registerDataCallBack("StartChallenge", function(userId, rewardId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
      return
    end
    self:onReceiveNewChallenge(player, rewardId)
  end)
  EventObservable:registerDataCallBack("openNewChallenge", function(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
      return
    end
    player.needNewChallengeTip = false
  end)
  EventObservable:registerDataCallBack("GiveUpChallenge", function(userId, rewardId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
      return
    end
    self:onGiveUpChallenge(player, rewardId, false)
  end)
  EventObservable:registerDataCallBack("FinishTask", function(userId, rewardId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
      return
    end
    self:onFinishTask(player, rewardId)
  end)
  Events.PlayerTaskProcessChangeEvent:registerCallBack(function(userId, key, task)
    if key ~= "currChallengeTask" then
      return
    end
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player or not self.challengeConfig then
      return
    end
    if task.createTime < self.challengeConfig.startDate then
      player.taskController:clearDailyTasks("currChallengeTask")
      return
    end
    self:onTaskProcessChange(player, task)
  end)
end

function TreasureChallenge:onReceiveNewChallenge(player, rewardId)
  if self.currRewardId[tostring(player.userId)] ~= 0 or not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  for _, iReward in pairs(player.challenges[TreasureChallengeConfig.times] or {}) do
    if tonumber(rewardId) == iReward.rewardId then
      if iReward.itemType == 1 then
        local goods = CustomShopConfig:getGoodsConfig(iReward.itemId)
        if goods then
          local group = player.custom_goods[tostring(goods.TabId)] or {}
          player.custom_goods[tostring(goods.TabId)] = group
          for _, _goods in pairs(group) do
            if _goods[CustomGoodsIndex.Id] == goods.Id and _goods[CustomGoodsIndex.Time] ~= 0 then
              CommonPacketSender:sendAlreadyOwnedReward(player.rakssid)
              return
            end
          end
        end
      elseif iReward.itemType == 3 then
        local newId = DressConfig:getNewIdByOldId(iReward.itemId)
        local goods = CustomShopConfig:getGoodsConfig(newId)
        if goods then
          local group = player.custom_goods[tostring(goods.TabId)] or {}
          player.custom_goods[tostring(goods.TabId)] = group
          for _, _goods in pairs(group) do
            if _goods[CustomGoodsIndex.Id] == goods.Id and _goods[CustomGoodsIndex.Time] ~= 0 then
              CommonPacketSender:sendAlreadyOwnedReward(player.rakssid)
              return
            end
          end
        end
      end
    end
  end
  player.taskController:clearDailyTasks("currChallengeTask")
  for _, iReward in pairs(player.challenges[TreasureChallengeConfig.times] or {}) do
    if tonumber(rewardId) == iReward.rewardId then
      self.currRewardId[tostring(player.userId)] = tonumber(rewardId)
      iReward.status = Define.ChallengeStatus.Experiencing
      iReward.receiveDate = os.time()
      local taskGroup = TaskConfig:getTaskByGroupId(iReward.taskGroupId)
      for _, iTask in pairs(taskGroup) do
        if iTask.TaskTypeId == 101 then
          local task = player.taskController:addDailyTask("currChallengeTask", iTask.Id)
          local progress = {
            Type = 101,
            GameType = BaseMain:getGameType(),
            Remarks = 0,
            Value = 1
          }
          task:matching(progress)
          Events.PlayerTaskProcessChangeEvent:invoke(player.userId, "currChallengeTask", task)
        else
          player.taskController:addDailyTask("currChallengeTask", iTask.Id)
        end
      end
      if iReward.itemType == 1 then
        local goods = CustomShopConfig:getGoodsConfig(iReward.itemId)
        if goods then
          CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.TreasureChallenge)
        end
      elseif iReward.itemType == 2 then
        player:addRune(iReward.itemId, iReward.num)
      elseif iReward.itemType == 3 then
        local newId = DressConfig:getNewIdByOldId(iReward.itemId)
        local goods = CustomShopConfig:getGoodsConfig(newId)
        if goods then
          CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.TreasureChallenge)
        end
      end
      ReportUtil.reportStartTreasure(player, iReward.rewardId)
    end
  end
  CommonPacketSender:sendReceiveNewChallenge(player.rakssid, tonumber(rewardId))
end

function TreasureChallenge:onGiveUpChallenge(player, rewardId, isSeason)
  if not DbUtil:IsGetAllDataFinished(player) then
    return
  end
  for _, challenge in pairs(player.challenges) do
    for _, iReward in pairs(challenge) do
      if tonumber(rewardId) == iReward.rewardId and iReward.status == Define.ChallengeStatus.Experiencing then
        if not isSeason and os.time() - iReward.receiveDate < GameConfig.taskGiveUpCD * 3600 then
          local seconds = GameConfig.taskGiveUpCD * 3600 - (os.time() - iReward.receiveDate)
          local hour = math.floor(seconds / 3600)
          local sec = math.floor(seconds % 3600 / 600)
          ReportUtil.reportGiveUpTreasure(player, false, rewardId)
          CommonPacketSender:sendCanNotGiveUpChallenge(player.rakssid, hour, sec)
          return
        end
        iReward.status = Define.ChallengeStatus.NotAccepted
        iReward.havePoints = 0
        self.currRewardId[tostring(player.userId)] = 0
        player.taskController:clearDailyTasks("currChallengeTask")
        if iReward.itemType == 1 then
          local goods = CustomShopConfig:getGoodsConfig(iReward.itemId)
          if goods then
            CustomShop:onRecycleGoods(player, goods, true)
          end
        elseif iReward.itemType == 2 then
          recyclePlayerRune(player, iReward.itemId)
        elseif iReward.itemType == 3 then
          local newId = DressConfig:getNewIdByOldId(iReward.itemId)
          local goods = CustomShopConfig:getGoodsConfig(newId)
          if goods then
            CustomShop:onRecycleGoods(player, goods, true)
          end
        end
        ReportUtil.reportGiveUpTreasure(player, true, rewardId)
      end
    end
  end
  CommonPacketSender:sendGiveUpChallenge(player.rakssid, rewardId)
end

function TreasureChallenge:onChallengeTimeout(player)
  for _, challenge in pairs(player.challenges) do
    for _, iReward in pairs(challenge) do
      if iReward.status == Define.ChallengeStatus.NotAccepted or iReward.status == Define.ChallengeStatus.Experiencing then
        player.needNewChallengeTip = true
        self:onGiveUpChallenge(player, iReward.rewardId, true)
      end
    end
  end
  player.challenges = {}
  CommonPacketSender:sendChallengeTimeout(player.rakssid)
end

function TreasureChallenge:onFinishChallenge(player, times, rewardId)
  local reward = player.challenges[times][tostring(rewardId)]
  reward.status = Define.ChallengeStatus.Completed
  CommonPacketSender:onPlayerFinishChallenge(player.rakssid, rewardId)
  player.taskController:clearDailyTasks("currChallengeTask")
  local days
  local nowDate = os.date("*t")
  local oldDate = os.date("*t", reward.receiveDate)
  if nowDate.year == oldDate.year then
    days = nowDate.day - oldDate.day
  else
    days = nowDate.day + (365 - oldDate.day)
  end
  ReportUtil.reportFinishTreasureTime(player, rewardId, days)
  ReportUtil.reportFinishTreasure(player, rewardId)
  if reward.itemType == 2 and recyclePlayerRune(player, reward.itemId) then
    local realRuneId = TreasureChallengeConfig:getRealRune(reward.itemId)
    player:addRune(realRuneId, reward.num)
  end
  self.currRewardId[tostring(player.userId)] = 0
end

function TreasureChallenge:onFinishTask(player, taskId)
  local tasks = player.taskController:getDailyTasks("currChallengeTask")
  for _, record in pairs(tasks) do
    if record.taskId == tonumber(taskId) and record:receiveTaskReward(player) then
      addChallengeProgress(player, record.reward)
      Events.PlayerTaskProcessChangeEvent:invoke(player.userId, "currChallengeTask", record)
      ReportUtil.reportFinishTreasureTask(player, taskId)
      return
    end
  end
end

function TreasureChallenge:onTaskProcessChange(player, task)
  CommonPacketSender:sendChallengeTaskInfo(player.rakssid, TreasureChallengeConfig.times, self.currRewardId[tostring(player.userId)], task)
end

function TreasureChallenge:onPlayerOpenTreasureChallenge(player, config)
  local TreasureChallenge = {}
  if not config then
    return
  end
  for _, iReward in pairs(config.rewardList) do
    local reward = {
      rewardId = iReward.rewardId,
      itemId = iReward.itemId,
      status = Define.ChallengeStatus.NotAccepted,
      needPoints = iReward.needPoints,
      itemType = iReward.itemType,
      num = iReward.itemNum,
      taskGroupId = iReward.taskGroupId,
      havePoints = 0,
      receiveDate = 0
    }
    TreasureChallenge[tostring(iReward.rewardId)] = reward
  end
  player.challenges[TreasureChallengeConfig.times] = TreasureChallenge
end

function TreasureChallenge:initPlayerChallengeConfig(player)
  if not self.challengeConfig then
    return
  end
  for _, iReward in pairs(self.challengeConfig.rewardList) do
    local reward = player.challenges[TreasureChallengeConfig.times][tostring(iReward.rewardId)]
    if not reward then
      reward = {}
      reward.rewardId = iReward.rewardId
      reward.itemId = iReward.itemId
      reward.status = Define.ChallengeStatus.NotAccepted
      reward.receiveDate = 0
    else
      reward.rewardId = reward.rewardId or 0
      reward.itemId = reward.itemId or 0
      reward.status = reward.status or 0
      reward.receiveDate = reward.receiveDate or 0
    end
    reward.itemId = iReward.itemId
    reward.needPoints = iReward.needPoints
    reward.itemType = iReward.itemType
    reward.num = iReward.itemNum
    reward.taskGroupId = iReward.taskGroupId
    if reward.itemType == 2 then
      local isReal, temRuneId = TreasureChallengeConfig:isRealRuneId(reward.itemId)
      if isReal then
        reward.itemId = temRuneId
      end
    end
  end
end

function TreasureChallenge:onPlayerReady(player)
  if not self.challengeConfig then
    return
  end
  self.currRewardId[tostring(player.userId)] = 0
  if player.needNewChallengeTip then
    CommonPacketSender:sendNewChallengeTip(player.rakssid)
  end
  if player.challenge_ad then
    CommonPacketSender:sendShowTreasureAd(player.rakssid, true, GameConfig.challengeAdProgress)
  end
  if player.challenges[TreasureChallengeConfig.times] == nil then
    self:onTimesChange(player, self.challengeConfig)
  else
    self:initPlayerChallengeConfig(player)
    self:syncTreasureChallengeTimes(player)
    self:syncTreasureChallengeInfo(player)
    for _, iReward in pairs(player.challenges[TreasureChallengeConfig.times]) do
      if iReward.status == Define.ChallengeStatus.Experiencing then
        self.currRewardId[tostring(player.userId)] = iReward.rewardId
      end
    end
  end
end

function TreasureChallenge:refreshChallengeTask(player)
  player.taskController:refreshDailyTasks("currChallengeTask")
end

function TreasureChallenge:onPlayerLogout(player)
  table.remove(self.currRewardId, tostring(player.userId))
end

function TreasureChallenge:syncTreasureChallengeInfo(player)
  local data = {}
  for _, iReward in pairs(player.challenges[TreasureChallengeConfig.times]) do
    local reward = {
      rewardId = iReward.rewardId,
      status = iReward.status,
      havePoints = iReward.havePoints
    }
    table.insert(data, reward)
  end
  CommonPacketSender:sendSyncTreasureChallengeInfo(player.rakssid, data)
end

function TreasureChallenge:syncTreasureChallengeTimes(player)
  CommonPacketSender:syncTreasureChallengeTimes(player.rakssid, TreasureChallengeConfig.times)
end

function TreasureChallenge:onTimesChange(player, challengeConfig)
  self:onChallengeTimeout(player)
  self:onPlayerOpenTreasureChallenge(player, challengeConfig)
  CommonPacketSender:sendChallengeTimesChange(player.rakssid, TreasureChallengeConfig.times)
  if player.needNewChallengeTip then
    CommonPacketSender:sendNewChallengeTip(player.rakssid)
  end
end

function TreasureChallenge:setRefreshTimer()
  local lastTime = DateUtil.getDayLastTime(os.time(), true) - os.time()
  LuaTimer:cancel(self.challengeKey)
  self.challengeKey = LuaTimer:schedule(function()
    self.challengeConfig = TreasureChallengeConfig:getCurrentChallenge()
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
      player.taskController:refreshDailyTasks("currChallengeTask")
    end
    self:setRefreshTimer()
  end, lastTime * 1000)
end

function TreasureChallenge:setSeasonRefreshTimer()
  self.challengeConfig = TreasureChallengeConfig:getCurrentChallenge()
  if not self.challengeConfig then
    return
  end
  local endTime = self.challengeConfig.endDate - os.time()
  self:setRefreshTimer()
  LuaTimer:cancel(self.seasonChangeKey)
  self.seasonChangeKey = LuaTimer:schedule(function()
    self.challengeConfig = TreasureChallengeConfig:getCurrentChallenge()
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
      self:onTimesChange(player, self.challengeConfig)
    end
    self:setSeasonRefreshTimer()
  end, endTime * 1000)
end

function TreasureChallenge:resetTreasureAd(player)
  player.challenge_ad = true
  CommonPacketSender:sendShowTreasureAd(player.rakssid, true, GameConfig.challengeAdProgress)
end

function TreasureChallenge:onPlayerWatchTreasureAd(player)
  if player.challenge_ad == true then
    player.challenge_ad = false
    addChallengeProgress(player, GameConfig.challengeAdProgress)
    CommonPacketSender:sendShowTreasureAd(player.rakssid, false, GameConfig.challengeAdProgress)
  end
end

return TreasureChallenge

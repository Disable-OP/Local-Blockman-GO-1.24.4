GameTask = class()

local function include(table, value)
  for _, v in pairs(table) do
    if v == value then
      return true
    end
  end
  return false
end

function GameTask:ctor(id, progress, status, createTime)
  self.taskId = id
  self.progress = progress or 0
  self.status = status or Define.TaskStatus.PROGRESSING
  self.nextTaskId = 0
  self.taskTypeId = 0
  self.progressType = 0
  self.goalNum = 0
  self.remarks = ""
  self.activeValue = 0
  self.gameTypes = ""
  self.rewardIds = ""
  self.showAd = false
  self.createTime = createTime or os.time()
  self:initDetailFromConfig()
end

function GameTask:initDetailFromConfig()
  local config = TaskConfig.TaskList[self.taskId]
  if config == nil then
    return
  end
  self.groupId = config.GroupId
  self.reward = config.Reward
  self.nextTaskId = config.NextTaskId
  self.taskTypeId = config.TaskTypeId
  self.progressType = config.ProgressType
  self.goalNum = config.GoalNum
  self.remarks = config.Remarks
  self.activeValue = config.ActiveValue
  self.gameTypes = config.GameTypes
  self.rewardIds = config.RewardIds
  self.showAd = config.ShowAd
end

function GameTask:matching(progress)
  if self:isMatching(progress) then
    self.progress = self.progress + progress.Value
    if include(Define.TaskType.Achievement, progress.Type) then
      self.progress = progress.Value
    end
    if self:isFinishTask() then
      self.status = Define.TaskStatus.FINISHED
    end
    return true
  end
  return false
end

function GameTask:isMatching(progress)
  local isTaskTypeMatching = true
  local isGameTypeMatching = true
  local isRemarksMatching = true
  if progress.Type == self.taskTypeId then
    if #self.gameTypes > 0 then
      isGameTypeMatching = false
      for _, gameType in pairs(self.gameTypes) do
        if tostring(gameType) == tostring(progress.GameType) then
          isGameTypeMatching = true
        end
      end
    end
    if 0 < #self.remarks then
      isRemarksMatching = false
      for _, remark in pairs(self.remarks) do
        if tostring(remark) == tostring(progress.Remarks) then
          isRemarksMatching = true
          break
        end
      end
    end
  else
    isTaskTypeMatching = false
  end
  return isTaskTypeMatching and isGameTypeMatching and isRemarksMatching
end

function GameTask:isFinishTask()
  if self.goalNum > self.progress then
    return false
  end
  return true
end

function GameTask:receiveTaskReward(player)
  if self:isFinishTask() and Define.TaskStatus.FINISHED == self.status then
    self.status = Define.TaskStatus.RECEIVED
    if self.nextTaskId ~= 0 then
      self:changeToNextTask()
    end
    return true
  end
  return false
end

function GameTask:changeToNextTask()
  self.status = Define.TaskStatus.PROGRESSING
  self.taskId = self.nextTaskId
  local oldTypeId = self.taskTypeId
  self:initDetailFromConfig()
  if oldTypeId ~= self.taskTypeId then
    self.progress = 0
  end
  if self:isFinishTask() then
    self.status = Define.TaskStatus.FINISHED
  end
end

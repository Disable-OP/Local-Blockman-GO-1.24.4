function GMHelper:resetLicense(player)
  GameLicense:resetLicense(player)
end

function GMHelper:addTaskProgress(player)
  player.taskController:packingProgressData(Define.TaskType.GrowUp.DailyLogin, nil, 100)
  player.taskController:packingProgressData(Define.TaskType.GrowUp.CostCoin, Define.Money.KEY, 100)
  player.taskController:packingProgressData(Define.TaskType.Fright.CompleteGame, nil, 100)
  player.taskController:packingProgressData(Define.TaskType.Fright.GameRank, 1, 100)
  player.taskController:packingProgressData(Define.TaskType.Fright.DestroyBed, nil, 100)
  player.taskController:packingProgressData(Define.TaskType.Fright.Kill, nil, 100)
  player.taskController:packingProgressData(Define.TaskType.Fright.AttackDamage, nil, 100)
  player.taskController:packingProgressData(Define.TaskType.Fright.PlaceBlock, nil, 100)
end

function GMHelper:addProgressingTaskProgress(player)
  for _, task_progress in pairs(player.task_progresses) do
    task_progress.Value = task_progress.Value + 100
  end
  player.taskController:consumeTaskProcesses(player)
end

function GMHelper:resetTreasureChallenge(player)
  player.taskController:clearDailyTasks("currChallengeTask")
  TreasureChallenge.currRewardId[tostring(player.userId)] = 0
  TreasureChallenge:onPlayerOpenTreasureChallenge(player, TreasureChallengeConfig:getCurrentChallenge())
  TreasureChallenge:syncTreasureChallengeInfo(player)
end

function GMHelper:refreshDailyTreasureChallenge(player)
  local tasks = player.taskController:getDailyTasks("currChallengeTask")
  if not tasks then
    return
  end
  local taskIdList = {}
  for index = #tasks, 1, -1 do
    local record = tasks[index]
    local config = TaskConfig:getTaskById(record.taskId)
    if config.RefreshCycle == 1 then
      table.remove(tasks, index)
      table.insert(taskIdList, 1, config.Id)
    end
  end
  for _, taskId in pairs(taskIdList) do
    player.taskController:addDailyTask("currChallengeTask", taskId)
  end
end

function GMHelper:refreshWeekTreasureChallenge(player)
  local tasks = player.taskController:getDailyTasks("currChallengeTask")
  if not tasks then
    return
  end
  local taskIdList = {}
  for index = #tasks, 1, -1 do
    local record = tasks[index]
    local config = TaskConfig:getTaskById(record.taskId)
    if config.RefreshCycle == 2 then
      table.remove(tasks, index)
      table.insert(taskIdList, 1, config.Id)
    end
  end
  for _, taskId in pairs(taskIdList) do
    player.taskController:addDailyTask("currChallengeTask", taskId)
  end
end

function GMHelper:finishCurrentChallenge(player)
  for _, iReward in pairs(player.challenges[TreasureChallengeConfig.times]) do
    if iReward.status == Define.ChallengeStatus.Experiencing then
      iReward.havePoints = iReward.needPoints
      CommonPacketSender:sendChallengePoints(player.rakssid, TreasureChallengeConfig.times, TreasureChallenge.currRewardId[tostring(player.userId)], iReward.havePoints)
      TreasureChallenge:onFinishChallenge(player, TreasureChallengeConfig.times, iReward.rewardId)
      return
    end
  end
end

function GMHelper:addHorn(player)
  player.had_horn = player.had_horn + 1000
  CommonPacketSender:sendBedWarPlayerMoneyCount(player.rakssid, Define.Money.HORN, player.had_horn)
end

function GMHelper:cleanLicenseDailyTask(player)
  player.taskController:clearDailyTasks("curLicenseDailyTask")
end

function GMHelper:cleanSeasonTask(player)
  player.taskController:clearDailyTasks("curLicenseSeasonTask")
end

function GMHelper:add1000FakeDiamonds(player)
  player:addFakeDiamonds(1000)
end

function GMHelper:removeFakeDiamonds(player)
  player:subFakeDiamonds(player.fakeDiamonds)
end

function GMHelper:addCommonChip(player)
  player:addCommonChip(10000)
end

function GMHelper:clearCommonChip(player)
  player:subCommonChip(player.commonChip)
end

GameTaskController = class()

function GameTaskController:ctor(player)
  self.userId = player.userId
  self.dailyTasks = {}
  player.daily_tasks = player.daily_tasks or {}
  player.task_progresses = player.task_progresses or {}
  self.finishInit = false
end

function GameTaskController:init()
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  if DbUtil:IsGetAllDataFinished(player) then
    self:initDailyTasks(player)
    self:consumeTaskProcesses(player)
    self:packingAchievementData(player)
    self.finishInit = true
  end
end

function GameTaskController:initDailyTasks(player)
  local daily_tasks = player.daily_tasks or {}
  for key, tasks in pairs(daily_tasks) do
    for taskId, task in pairs(tasks) do
      self:addDailyTask(key, tonumber(taskId), task.progress, task.status, task.time)
    end
  end
end

function GameTaskController:packingAchievementData()
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
end

function GameTaskController:packingProgressData(taskTypeId, remarks, value)
  local data = {
    Type = taskTypeId,
    GameType = BaseMain:getGameType(),
    Remarks = remarks,
    Value = value or 1
  }
  self:saveTaskProcesses(data)
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  self:consumeTaskProcesses(player)
end

function GameTaskController:saveTaskProcesses(progress)
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  for _, task_progress in pairs(player.task_progresses) do
    if task_progress.Type == progress.Type and task_progress.Remarks == progress.Remarks and task_progress.GameType == progress.GameType then
      task_progress.Value = task_progress.Value + progress.Value
      return
    end
  end
  table.insert(player.task_progresses, progress)
end

function GameTaskController:consumeTaskProcesses(player)
  local progresses = player.task_progresses or {}
  for _, progress in pairs(progresses) do
    self:consumeTaskProcess(progress)
  end
  player.task_progresses = {}
  Events.PlayerTaskConsumeProcessFinishEvent:invoke(self.userId)
end

function GameTaskController:consumeTaskProcess(progress)
  for key, tasks in pairs(self.dailyTasks) do
    for _, task in pairs(tasks) do
      if (Define.TaskStatus.PROGRESSING == task.status or Define.TaskStatus.FINISHED == task.status and task.nextTaskId ~= 0) and task:matching(progress) then
        Events.PlayerTaskProcessChangeEvent:invoke(self.userId, key, task)
      end
    end
  end
end

function GameTaskController:getDailyTasks(key)
  local tasks = self.dailyTasks[key]
  if tasks then
    return tasks
  end
  return {}
end

function GameTaskController:addDailyTask(key, taskId, progress, status, createTime)
  local tasks = self.dailyTasks[key]
  if not tasks then
    tasks = {}
    self.dailyTasks[key] = tasks
  end
  for _, record in pairs(tasks) do
    if record.taskId == taskId then
      return record
    end
  end
  local task = GameTask.new(taskId, progress, status, createTime)
  table.insert(tasks, task)
  Events.PlayerTaskProcessChangeEvent:invoke(self.userId, key, task)
  return task
end

function GameTaskController:removeDailyTask(key, taskId)
  local tasks = self.dailyTasks[key]
  if not tasks then
    return
  end
  for index, record in pairs(tasks) do
    if record.taskId == taskId then
      table.remove(tasks, index)
      return
    end
  end
end

function GameTaskController:transformToPlayerTaskData(_player)
  local player = _player or PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  local dailyTasksData = {}
  for key, tasks in pairs(self.dailyTasks) do
    local tasksData = {}
    for _, task in ipairs(tasks) do
      tasksData[tostring(task.taskId)] = {
        progress = task.progress,
        status = task.status,
        time = task.createTime
      }
    end
    dailyTasksData[key] = tasksData
  end
  player.daily_tasks = dailyTasksData
end

function GameTaskController:clearDailyTasks(key)
  self.dailyTasks[key] = {}
end

function GameTaskController:refreshDailyTasks(key)
  local tasks = self.dailyTasks[key]
  if not tasks then
    return
  end
  local taskIdList = {}
  for index = #tasks, 1, -1 do
    local record = tasks[index]
    local reFreshTime = 0
    local config = TaskConfig:getTaskById(record.taskId)
    if config.RefreshCycle == 1 then
      reFreshTime = DateUtil.getDayLastTime(record.createTime, true)
    elseif config.RefreshCycle == 2 then
      reFreshTime = DateUtil.getWeekLastTime(record.createTime, true)
    end
    if reFreshTime <= os.time() then
      table.remove(tasks, index)
      table.insert(taskIdList, 1, config.Id)
    end
  end
  for _, taskId in pairs(taskIdList) do
    self:addDailyTask(key, taskId)
  end
end

function GameTaskController:consumeAndRecycleTask(key)
  local tasks = self.dailyTasks[key]
  if not tasks then
    return
  end
  local effectTask = {}
  for index, task in pairs(tasks) do
    if task.status == Define.TaskStatus.FINISHED or task.status == Define.TaskStatus.RECEIVED then
      table.insert(effectTask, task.taskId)
      table.remove(tasks, index)
      local newTask = GameTask.new(task.taskId)
      table.insert(tasks, index, newTask)
      Events.PlayerTaskProcessChangeEvent:invoke(self.userId, key, newTask)
    end
  end
  return effectTask
end

function GameTaskController:continueSeasonTask(key, taskId)
  local player = PlayerManager:getPlayerByUserId(self.userId)
  if not player then
    return
  end
  local Task
  for _, task in pairs(self.dailyTasks[key]) do
    if task.taskId == taskId then
      Task = task
    end
  end
  if not Task then
    return
  end
  GameLicense:onFinishTaskAddEXP(player, taskId, "curLicenseSeasonTask")
  Task.status = Define.TaskStatus.RECEIVED
  local taskConfig = TaskConfig:getTaskById(taskId)
  if not taskConfig or taskConfig.NextTaskId == 0 then
    player.changeTaskId = taskId
    Events.PlayerTaskProcessChangeEvent:invoke(self.userId, key, Task)
    return
  end
  local GoalNum = taskConfig.GoalNum
  local NextTaskId = taskConfig.NextTaskId
  if NextTaskId == 0 then
    return
  end
  for i, task in pairs(self.dailyTasks[key]) do
    if task.taskId == taskId then
      self:removeDailyTask(key, taskId)
      player.changeTaskId = taskId
      local nextTask = TaskConfig:getTaskById(NextTaskId)
      if not nextTask then
        return
      end
      if task.progress >= nextTask.GoalNum then
        self:addDailyTask(key, NextTaskId, task.progress, Define.TaskStatus.FINISHED)
      else
        self:addDailyTask(key, NextTaskId, task.progress)
      end
    end
  end
end

function GameTaskController:refreshDailyTaskByTaskGroup(groupId, refresh)
  local tasks = TaskConfig:getTaskByGroupId(groupId)
  if refresh then
    self:clearDailyTasks("curLicenseDailyTask")
  end
  for _, task in pairs(tasks) do
    self:addDailyTask("curLicenseDailyTask", task.Id)
  end
end

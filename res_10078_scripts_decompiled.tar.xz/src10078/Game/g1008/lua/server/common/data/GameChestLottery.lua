GameChestLottery = {}

local function CostChestNum(c_player, c_chestId, c_num)
  local player_chest
  for _, chest in pairs(c_player.chests) do
    if chest.Id == c_chestId then
      player_chest = chest
    end
  end
  if not player_chest then
    return false
  end
  if c_num <= player_chest.HasNum then
    player_chest.HasNum = player_chest.HasNum - c_num
    local data = {}
    table.insert(data, {
      Id = player_chest.Id,
      HasNum = player_chest.HasNum
    })
    GameChestLottery:sendUpdateLotteryChestData(c_player, data)
    return true
  end
  local config = ChestConfig:getChestById(c_chestId)
  if not config then
    return false
  end
  if c_player.chest_integral >= config.NeedIntegral * c_num and c_player.yaoshi >= config.NeedKey * c_num then
    c_player.chest_integral = c_player.chest_integral - config.NeedIntegral * c_num
    c_player:subYaoShi(config.NeedKey * c_num, "key_LotteryChest", c_chestId)
    return true
  end
  return false
end

function GameChestLottery:sendUpdateLotteryIntegral(player)
  CommonPacketSender:sendBedWarShowBoxLottery(player.rakssid, false, player.chest_integral, ChestConfig:getUltimateChestIntegral())
end

function GameChestLottery:sendUpdateLotteryChestData(player, data)
  CommonPacketSender:sendBedWarBoxLotteryData(player.rakssid, json.encode(data))
end

function GameChestLottery:sendChestLotteryResult(player, rewardIds)
  if #rewardIds == 1 then
    CommonPacketSender:sendBedWarBoxRewardResult(player.rakssid, rewardIds[1])
  end
  if 1 < #rewardIds then
    CommonPacketSender:sendBedWarBoxRewardResults(player.rakssid, rewardIds)
  end
end

function GameChestLottery:initChestLotteryData(player)
  for _, chest in pairs(ChestConfig.Chests) do
    local data = {}
    data.Id = chest.Id
    data.HasNum = 0
    data.GetFreeTime = 0
    data.Integral = 0
    table.insert(player.chests, data)
  end
end

function GameChestLottery:syncChestLotteryData(player)
  local data = {}
  for _, chest in pairs(player.chests) do
    local config = ChestConfig:getChestById(chest.Id)
    if config then
      if config.GetFreeTime ~= -1 and os.time() - chest.GetFreeTime >= config.GetFreeTime then
        chest.GetFreeTime = os.time()
        chest.HasNum = chest.HasNum + 1
      end
      table.insert(data, {
        Id = chest.Id,
        HasNum = chest.HasNum
      })
    end
  end
  GameChestLottery:sendUpdateLotteryChestData(player, data)
  GameChestLottery:sendUpdateLotteryIntegral(player)
end

function GameChestLottery:onPlayerOpenLotteryChest(player, chestId, num)
  num = num or 1
  local oldIntegral = player.chest_integral
  if not CostChestNum(player, chestId, num) then
    return
  end
  local rewardIds = {}
  for _ = 1, num do
    local rewardId = GameChestLottery:onPlayerLottery(player, chestId)
    table.insert(rewardIds, rewardId)
  end
  player.taskController:packingProgressData(Define.TaskType.GrowUp.OpenChest, chestId, num)
  GameChestLottery:sendChestLotteryResult(player, rewardIds)
  if oldIntegral ~= player.chest_integral then
    GameChestLottery:sendUpdateLotteryIntegral(player)
  end
end

function GameChestLottery:onPlayerConfirmPayLottery(player, chestId)
  local config = ChestConfig:getChestById(chestId)
  if not config then
    return
  end
  local lackNum = config.NeedKey - player.yaoshi
  if lackNum <= player:getDiamond() then
    player:consumeDiamonds(599 + config.Id, lackNum, Define.OpenLotteryChest .. "#" .. config.Id)
    return
  end
end

function GameChestLottery:onPlayerLottery(player, chestId, cost)
  local config = ChestConfig:getChestById(chestId)
  if not config then
    return
  end
  if cost then
    player.yaoshi = 0
    player:syncHallInfo()
  end
  local chest_reward = config.Rewards[LotteryUtil:get(tostring(config.Id))]
  if not chest_reward then
    return
  end
  local reward = RewardConfig:getRewardById(chest_reward.RewardId)
  local rewardId = GameReward:onPlayerGetReward(player, reward)
  if rewardId then
    player.chest_integral = player.chest_integral + config.AddIntegral
    return rewardId
  end
end

return GameChestLottery

GameReward = {}
local PropPacketManager = require("common.manager.PropPacketManager")

function GameReward:sendNotificationResult(player, reward)
  if reward and reward.IsNotification and #reward.NotificationContent ~= 0 then
    local data = {
      message = reward.NotificationContent,
      top = true
    }
    if #reward.NotificationParams ~= 0 then
      data.params = player:getDisplayName() .. "#" .. reward.NotificationParams
    else
      data.params = player:getDisplayName()
    end
    WebService:SendMsg(nil, json.encode(data), 4, "game", GameType)
  end
end

function GameReward:onPlayerGetReward(player, reward)
  if not reward then
    return false
  end
  local hasGet
  if reward.RewardType == Define.RewardType.KEY then
    self:onPlayerRewardKey(player, reward.RewardId, reward.Count)
  end
  if reward.RewardType == Define.RewardType.Ticket then
    self:onPlayerRewardTicket(player, reward.RewardId, reward.Count)
  end
  if reward.RewardType == Define.RewardType.STORE then
    self:onPlayerRewardStore(player, reward)
  end
  if reward.RewardType == Define.RewardType.HORN then
    self:onPlayerRewardHorn(player, reward.RewardId, reward.Count)
  end
  if reward.RewardType == Define.RewardType.CHEST then
    self:addPlayerLotteryChest(player, reward.RewardId, reward.Count)
  end
  if reward.RewardType == Define.RewardType.RUNE then
    self:onPlayerRewardRune(player, reward.RewardId, reward.Count)
  end
  if reward.RewardType == Define.RewardType.DRESS_CHIP then
    LogUtil.logWarning("Config Error: [RewardType == Define.RewardType.DRESS_CHIP]   RewardId = " .. tostring(reward.RewardId), debug.traceback())
  end
  if reward.RewardType == Define.RewardType.DRESS then
    local newId = DressConfig:getNewIdByOldId(reward.RewardId)
    local goods = CustomShopConfig:getGoodsConfig(newId)
    if goods then
      hasGet = not CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.Buy)
    end
  end
  if reward.RewardType == Define.RewardType.PRIVILEGE_CARD then
    Privilege.addPrivilegeTime(player, reward.RewardId, reward.Time)
  end
  if reward.RewardType == Define.RewardType.CUSTOM_SHOP then
    local goods = CustomShopConfig:getGoodsConfig(reward.RewardId)
    if goods then
      hasGet = not CustomShop:onBuyGoods(player, goods, true, CustomShopGoodsGetWay.Buy)
    end
  end
  if reward.RewardType == Define.RewardType.COMMON_CHIP then
    hasGet = self:onPlayerRewardDressChip(player, reward.Count)
  end
  if reward.RewardType == Define.RewardType.FAKE_DIAMOND then
    hasGet = player:addFakeDiamonds(reward.Count)
  end
  if reward.RewardType == Define.RewardType.PROP_PACKET then
    PropPacketManager:onAddItem(player, reward.RewardId, reward.Count)
  end
  if hasGet then
    local redress_reward = RewardConfig:getRewardById(reward.RedressRewardId)
    if redress_reward then
      return self:onPlayerGetReward(player, redress_reward)
    else
      print("Do not have Reward by Id(" .. reward.RedressRewardId .. ")")
    end
  end
  self:sendNotificationResult(player, reward)
  return reward.Id
end

function GameReward:onPlayerRewardKey(player, id, count)
  player:addYaoShi(count)
end

function GameReward:onPlayerRewardTicket(player, id, count)
  player:addTicket(count)
end

function GameReward:onPlayerRewardHorn(player, id, count)
  player:addHorn(count)
end

function GameReward:onPlayerRewardStore(player, reward)
  local goods = StoreConfig:getGoodsById(reward.RewardId)
  if not goods then
    return false
  end
  local success = false
  GameStore:checkCanBuyGoods(player, goods, false, function(canAdd)
    if canAdd then
      if goods.Type == GoodsType.Armor then
        if goods.Level > StoreConfig:getEquipArmorLevel(player, goods.LevelGroup) then
          success = GameStore:onPlayerBuyGoods(player.userId, reward.RewardId, false)
        end
      else
        success = GameStore:onPlayerBuyGoods(player.userId, reward.RewardId, false)
      end
    end
  end)
  return success
end

function GameReward:addPlayerLotteryChest(player, id, count)
  local data = {}
  for _, chest in pairs(player.chests) do
    if chest.Id == id then
      chest.HasNum = chest.HasNum + count
      table.insert(data, {
        Id = chest.Id,
        HasNum = chest.HasNum
      })
    end
  end
  if #data == 0 then
    table.insert(player.chests, {
      Id = id,
      HasNum = count,
      GetFreeTime = 0,
      Integral = 0
    })
    table.insert(data, {Id = id, HasNum = count})
  end
  GameChestLottery:sendUpdateLotteryChestData(player, data)
end

function GameReward:onPlayerAddExp(player, count)
  player:addExp(count)
end

function GameReward:onPlayerRewardRune(player, id, count)
  if count <= 0 then
    return
  end
  for k, v in pairs(player.rune) do
    if v.runeId == id then
      v.num = v.num + count
      return
    end
  end
  local data = {runeId = id, num = count}
  table.insert(player.rune, data)
end

function GameReward:onPlayerRewardDressChip(player, count)
  player:addCommonChip(count)
end

return GameReward

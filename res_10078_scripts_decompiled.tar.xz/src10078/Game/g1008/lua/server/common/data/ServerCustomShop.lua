require("common.custom.CustomShopBlock")
require("common.custom.CustomShopEffectArrow")
require("common.custom.CustomShopAction")
require("common.custom.CustomShopFootprint")
require("common.custom.CustomShopSwordLight")
require("common.custom.CustomShopPet")
require("common.custom.CustomShopCloth")
require("common.custom.CustomShopDress")
local ChipPrice = 2

local function checkPlayerAndGoods(userId, goodsId)
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  local goods = CustomShopConfig:getGoodsConfig(goodsId)
  if not goods then
    return
  end
  return player, goods
end

local function checkPlayerFirstInit(player)
  if TableUtil.getTableSize(player.custom_goods) ~= 0 then
    return
  end
  local settings = CustomShopConfig:getCustomShop()
  for _, setting in pairs(settings) do
    for _, type in pairs(setting.types) do
      for _, tab in pairs(type) do
        local equipCount = CustomShopConfig:getEquipCount(tab.TabId)
        for _, goods in pairs(tab.GoodsList) do
          if goods.Default then
            local group = player.custom_goods[tostring(goods.TabId)] or {}
            player.custom_goods[tostring(goods.TabId)] = group
            if 0 < equipCount then
              group[tostring(goods.Id)] = {
                goods.Id,
                CustomShopGoodsStatus.Equiped,
                goods.Time
              }
            else
              group[tostring(goods.Id)] = {
                goods.Id,
                CustomShopGoodsStatus.UnEquip,
                goods.Time
              }
            end
            equipCount = equipCount - 1
          end
        end
      end
    end
  end
end

function CustomShop:init()
  EventObservable:registerDataCallBack("BuyCustomGoods", function(userId, data)
    local goodsId = data:getNumberParam("goodsId")
    local coinId = data:getNumberParam("coinId")
    local player, goods = checkPlayerAndGoods(userId, goodsId)
    if not player then
      return
    end
    CustomShop:onBuyGoods(player, goods, false, CustomShopGoodsGetWay.Buy, coinId)
  end, DataBuilderProcessor)
  EventObservable:registerDataCallBack("UnloadCustomGoods", function(userId, goodsId)
    local player, goods = checkPlayerAndGoods(userId, goodsId)
    if not player then
      return
    end
    CustomShop:onUnloadGoods(player, goods)
  end)
  EventObservable:registerDataCallBack("EquipCustomGoods", function(userId, goodsId)
    local player, goods = checkPlayerAndGoods(userId, goodsId)
    if not player then
      return
    end
    CustomShop:onEquipGoods(player, goods)
  end)
  EventObservable:registerDataCallBack("BuyCustomGoodsWithChipAndKey", function(userId, data)
    local goodsId = data:getNumberParam("goodsId")
    local player, goods = checkPlayerAndGoods(userId, goodsId)
    if not player then
      return
    end
    if goods.CoinId2 ~= Define.Money.COMMON_CHIP then
      return
    end
    local lockNum = goods.DiscountPrices2 - player.commonChip
    if 0 < lockNum then
      if player.yaoshi > lockNum * ChipPrice then
        player:subYaoShi(lockNum * ChipPrice)
        player:addCommonChip(lockNum)
      else
        return
      end
    end
    CustomShop:onBuyGoods(player, goods, false, CustomShopGoodsGetWay.Buy, Define.Money.COMMON_CHIP)
  end, DataBuilderProcessor)
end

CustomShop:init()

function CustomShop:transformOldDress(player)
  local totalChipCount = 0
  local oldChipInfo = {}
  for _, oldDress in pairs(player.dress) do
    if oldDress.Status == Define.GameDressStoreStatus.HAS_GET or oldDress.Status == Define.GameDressStoreStatus.HAS_USE or oldDress.Status == Define.GameDressStoreStatus.JUST_BUY then
      local status = CustomShopGoodsStatus.UnEquip
      local getWay = CustomShopGoodsGetWay.Buy
      if oldDress.Status == Define.GameDressStoreStatus.HAS_USE then
        status = CustomShopGoodsStatus.Equiped
      end
      if oldDress.In_Trial then
        getWay = CustomShopGoodsGetWay.TreasureChallenge
      end
      local newId = DressConfig:getNewIdByOldId(oldDress.Id)
      local goods = CustomShopConfig:getGoodsConfig(newId)
      if goods then
        player.custom_goods[tostring(goods.TabId)] = player.custom_goods[tostring(goods.TabId)] or {}
        local _goods = {
          newId,
          status,
          -1,
          getWay
        }
        player.custom_goods[tostring(goods.TabId)][tostring(goods.Id)] = _goods
      end
    end
    if 0 < oldDress.Chip then
      table.insert(oldChipInfo, {
        dressId = oldDress.Id,
        count = oldDress.Chip
      })
    end
    totalChipCount = totalChipCount + oldDress.Chip
  end
  player.dress = {}
  player:addCommonChip(totalChipCount)
  CommonPacketSender:sendTransformOldDressResult(player.rakssid, oldChipInfo, totalChipCount)
end

function CustomShop:onSyncPlayerAllGoods(player)
  checkPlayerFirstInit(player)
  local result = {}
  for TabId, group in pairs(player.custom_goods) do
    local remove = {}
    local equipCount = CustomShopConfig:getEquipCount(TabId)
    for goodsId, goods in pairs(group) do
      if goods[CustomGoodsIndex.Time] ~= -1 and os.time() > goods[CustomGoodsIndex.Time] then
        table.insert(remove, goodsId)
      else
        if goods[CustomGoodsIndex.Status] == CustomShopGoodsStatus.Equiped then
          local _goods = CustomShopConfig:getGoodsConfig(goodsId)
          if _goods then
            CustomShop:callModuleFunc("onEquipGoods", CustomShopConfig:getGoodsType(_goods), player, _goods)
          end
        end
        table.insert(result, goods)
      end
    end
    for _, goodsId in pairs(remove) do
      group[goodsId] = nil
    end
  end
  if 0 < #result then
    CustomShop:onPlayerGoodsChange(player, result)
  end
end

function CustomShop:onPlayerGoodsChange(player, goodsList)
  CommonPacketSender:sendCustomShopData(player.rakssid, goodsList)
end

local function onBuyGoodsSuccess(player, goods, getWay)
  local group = player.custom_goods[tostring(goods.TabId)] or {}
  local _goods = {
    goods.Id,
    CustomShopGoodsStatus.UnEquip,
    goods.Time,
    getWay
  }
  group[tostring(goods.Id)] = _goods
  CustomShop:onPlayerGoodsChange(player, {_goods})
  CommonPacketSender:sendBuyCustomGoodsSuccess(player.rakssid, goods.Id)
  ServerReportEvent.buy_custom_goods(player, goods.Id)
end

function CustomShop:onBuyGoods(player, goods, free, getWay, coinId)
  if goods.Price1 < 0 then
    return
  end
  local curCoinId = coinId or Define.Money.DIAMOND
  local group = player.custom_goods[tostring(goods.TabId)] or {}
  player.custom_goods[tostring(goods.TabId)] = group
  for _, _goods in pairs(group) do
    if _goods[CustomGoodsIndex.Id] == goods.Id and _goods[CustomGoodsIndex.Time] ~= 0 then
      return
    end
  end
  if free then
    onBuyGoodsSuccess(player, goods, getWay)
    return true
  end
  if curCoinId == Define.Money.DIAMOND then
    if not MoneyUtil:checkHasMoney(player, Define.Money.DIAMOND, goods.DiscountPrices1) then
      return
    end
    PayHelper.payDiamondsSync(player.userId, goods.Id, goods.DiscountPrices1, function()
      onBuyGoodsSuccess(player, goods, getWay)
      return true
    end)
  elseif curCoinId == Define.Money.KEY then
    if player:subYaoShi(goods.DiscountPrices1) then
      onBuyGoodsSuccess(player, goods, getWay)
      return true
    end
  elseif curCoinId == Define.Money.COMMON_CHIP and player:subCommonChip(goods.DiscountPrices2) then
    onBuyGoodsSuccess(player, goods, getWay)
    return true
  end
end

function CustomShop:onEquipGoods(player, goods)
  local group = player.custom_goods[tostring(goods.TabId)]
  if not group then
    return
  end
  local equipCount = CustomShopConfig:getEquipCount(goods.TabId)
  local result = {}
  if equipCount <= 1 then
    for _, _goods in pairs(group) do
      if _goods[CustomGoodsIndex.Status] == CustomShopGoodsStatus.Equiped then
        _goods[CustomGoodsIndex.Status] = CustomShopGoodsStatus.UnEquip
        table.insert(result, _goods)
        local goodsConfig = CustomShopConfig:getGoodsConfig(_goods[CustomGoodsIndex.Id])
        if goodsConfig then
          CustomShop:callModuleFunc("onUnloadGoods", CustomShopConfig:getGoodsType(goods), player, CustomShopConfig:getGoodsConfig(_goods[CustomGoodsIndex.Id]))
        end
      end
    end
  else
    local count = 0
    for _, _goods in pairs(group) do
      if _goods[CustomGoodsIndex.Status] == CustomShopGoodsStatus.Equiped then
        count = count + 1
      end
    end
    if equipCount <= count then
      return
    end
  end
  local _goods = group[tostring(goods.Id)]
  if not _goods or _goods.Time == 0 then
    return
  end
  if _goods[CustomGoodsIndex.Status] == CustomShopGoodsStatus.Equiped then
    return
  end
  CustomShop:callModuleFunc("onEquipGoods", CustomShopConfig:getGoodsType(goods), player, goods)
  _goods[CustomGoodsIndex.Status] = CustomShopGoodsStatus.Equiped
  table.insert(result, _goods)
  CustomShop:onPlayerGoodsChange(player, result)
end

function CustomShop:onUnloadGoods(player, goods)
  local group = player.custom_goods[tostring(goods.TabId)]
  if not group then
    return
  end
  local _goods = group[tostring(goods.Id)]
  if not _goods or group[tostring(goods.Id)].Time == 0 then
    return
  end
  if _goods[CustomGoodsIndex.Status] == CustomShopGoodsStatus.UnEquip then
    return
  end
  _goods[CustomGoodsIndex.Status] = CustomShopGoodsStatus.UnEquip
  CustomShop:onPlayerGoodsChange(player, {_goods})
  CustomShop:callModuleFunc("onUnloadGoods", CustomShopConfig:getGoodsType(goods), player, goods)
end

function CustomShop:onRecycleGoods(player, goods)
  if not player.custom_goods[tostring(goods.TabId)] then
    return
  end
  local _goods = player.custom_goods[tostring(goods.TabId)][tostring(goods.Id)]
  if not _goods then
    return
  end
  if _goods[CustomGoodsIndex.GetWay] ~= CustomShopGoodsGetWay.TreasureChallenge then
    return
  end
  _goods[CustomGoodsIndex.Status] = CustomShopGoodsStatus.UnEquip
  _goods[CustomGoodsIndex.Time] = 0
  CustomShop:onPlayerGoodsChange(player, {_goods})
  CustomShop:callModuleFunc("onUnloadGoods", CustomShopConfig:getGoodsType(goods), player, goods)
end

function CustomShop:getPlayerDressCount(player)
  local dressCount = 0
  for _, group in pairs(player.custom_goods) do
    for _, goods in pairs(group) do
      if goods[CustomGoodsIndex.Time] == -1 or os.time() < goods[CustomGoodsIndex.Time] then
        dressCount = dressCount + 1
      end
    end
  end
  return dressCount
end

function CustomShop:getPlayerThreeDress(player)
  local threeDress = {}
  for _, group in pairs(player.custom_goods or {}) do
    for _, goods in pairs(group or {}) do
      local value = 0
      local goodConfig = CustomShopConfig:getGoodsConfig(goods[CustomGoodsIndex.Id])
      if goodConfig then
        if goodConfig.CoinId1 == Define.Money.DIAMOND then
          value = goodConfig.Price1
        elseif goodConfig.CoinId1 == Define.Money.KEY then
          value = goodConfig.Price1 / 2
        end
        if #threeDress == 0 then
          table.insert(threeDress, {
            id = goods[CustomGoodsIndex.Id],
            value = value
          })
        else
          for index, dress in pairs(threeDress) do
            if value > dress.value then
              table.insert(threeDress, index, {
                id = goods[CustomGoodsIndex.Id],
                value = value
              })
              break
            end
            if index == #threeDress and index < 3 then
              table.insert(threeDress, {
                id = goods[CustomGoodsIndex.Id],
                value = value
              })
              break
            end
            if index == 3 then
              break
            end
          end
        end
      end
    end
  end
  local dressStr = ""
  for index, goods in pairs(threeDress) do
    dressStr = dressStr .. "#" .. tostring(goods.id)
    if index == 3 then
      break
    end
  end
  return dressStr
end

function CustomShop:getPlayerCurPet(player)
  for _, pet in pairs(player.custom_goods["1"] or {}) do
    if pet[CustomGoodsIndex.Status] == CustomShopGoodsStatus.Equiped then
      return pet[CustomGoodsIndex.Id]
    end
  end
  return 0
end

local BlockGoodsIndex = {
  Id = 1,
  Status = 2,
  Time = 3
}

function CustomShop:transformOldBlockSkin(player)
  for _, group in pairs(player.block_goods) do
    for _, _goods in pairs(group) do
      local id = _goods[BlockGoodsIndex.Id]
      local status = _goods[BlockGoodsIndex.Status]
      local goods = CustomShopConfig:getGoodsConfigBySetting(id)
      if goods then
        player.custom_goods[tostring(goods.TabId)] = player.custom_goods[tostring(goods.TabId)] or {}
        local _goods = {
          goods.Id,
          status,
          -1,
          goods.GetWay
        }
        player.custom_goods[tostring(goods.TabId)][tostring(goods.Id)] = _goods
      end
    end
  end
  player.block_goods = {}
end

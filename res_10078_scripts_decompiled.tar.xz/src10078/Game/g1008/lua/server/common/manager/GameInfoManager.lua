local function sendNewInfo(userId, className, infoKey, infoIndex)
  local dataStr = table.concat({
    className,
    
    infoKey,
    infoIndex
  }, "'")
  if userId == "0" then
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
      if player:checkReady() then
        CommonPacketSender:sendInfoNew(player.rakssid, dataStr)
      end
    end
  else
    local player = PlayerManager:getPlayerByUserId(userId)
    if player then
      CommonPacketSender:sendInfoNew(player.rakssid, dataStr)
    end
  end
end

local function adjustTeamPlayerCount()
  local teams = {
    ["0"] = {}
  }
  for teamId, _ in pairs(TeamConfig:getTeams()) do
    teams[tostring(teamId)] = {}
  end
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    table.insert(teams[tostring(player.teamId)], tostring(player.userId))
  end
  for teamId, _ in pairs(TeamConfig:getTeams()) do
    while #teams[tostring(teamId)] > GameConfig.teamPlayers do
      local morePlayerUserId = table.remove(teams[tostring(teamId)], #teams[tostring(teamId)])
      GameMatch.Teams[teamId]:subPlayer(morePlayerUserId)
      table.insert(teams["0"], morePlayerUserId)
    end
  end
  for _, userId in pairs(teams["0"]) do
    local morePlayer = PlayerManager:getPlayerByUserId(userId)
    if morePlayer then
      for teamId, _ in pairs(TeamConfig:getTeams()) do
        if #teams[tostring(teamId)] < GameConfig.teamPlayers then
          table.insert(teams[tostring(teamId)], userId)
          morePlayer.teamId = teamId
          morePlayer:initTeam()
          MessagesManage:sendSystemTipsToPlayer(morePlayer.rakssid, Messages:adjustTeamMsg(morePlayer))
          break
        end
      end
    end
  end
  for _, player in pairs(players) do
    local team = GameMatch.Teams[player.teamId]
    if team then
      team.info:addPlayer(player.userId)
      for _, itemId in pairs(team.initItems) do
        player:addInitItems(itemId)
      end
    end
  end
end

GameInfoManager = class("GameInfoManager", BaseInfoManager)
local instance

function GameInfoManager.Instance()
  if not instance then
    instance = GameInfoManager.new()
  end
  return instance
end

function GameInfoManager:initInfo()
  adjustTeamPlayerCount()
  LuaTimer:scheduleTimer(function()
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
      local healthPro = player:getHealth() / player:getMaxHealth()
      healthPro = math.floor(healthPro * 100) / 100
      player.info:setValue("blood", healthPro)
    end
  end, 100)
  self:onTick()
  HostApi.sendStartGame(PlayerManager:getPlayerCount())
  local userId = GameMatch:getOnePlayerUserId()
  if userId ~= nil then
    GameAnalytics:design(userId, 0, {
      "BedWarTeamInfo",
      TeamConfig:getTeamMaxMinDiff()
    })
  end
end

function GameInfoManager:register()
end

function GameInfoManager:onTick()
  local infoMap = self:getAllInfo()
  local changeInfoList = {}
  for _, info in pairs(infoMap) do
    local buildResult = info:buildChangePacket()
    if 0 < #buildResult then
      table.insert(changeInfoList, buildResult)
    end
  end
  if 0 < #changeInfoList then
    local result = table.concat(changeInfoList, "!")
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
      if player:checkReady() then
        CommonPacketSender:sendInfoUpdate(player.rakssid, result)
      end
    end
  end
end

function GameInfoManager:newInfo(className, infoKey)
  local index = self.super.newInfo(self, className, infoKey)
  sendNewInfo("0", className, infoKey, index)
end

function GameInfoManager:onPlayerReady(player)
  local infoMap = self:getAllInfo()
  for infoIndex, info in pairs(infoMap) do
    sendNewInfo(tostring(player.userId), info.__cname, info.infoKey, infoIndex)
    CommonPacketSender:sendInfoUpdate(player.rakssid, info:buildAllPacket())
  end
  if GameMatch.allowPvp then
    player:onSpawnInGame()
    CommonPacketSender:sendGameStart(player)
  end
end

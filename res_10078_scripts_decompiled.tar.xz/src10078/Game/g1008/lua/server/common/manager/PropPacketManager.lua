local PropPacketManager = {}
local UnloadIndex = -1

function PropPacketManager:onPlayerReady(player)
  player.propPacketData = player.propPacketData or {}
  player.propEquipData = {}
  PropPacketManager:onPlayerRespawn(player)
end

function PropPacketManager:onPlayerRespawn(player)
  if not player.propPacketData then
    return
  end
  for _, packetData in pairs(player.propPacketData) do
    if packetData.equipIndex ~= UnloadIndex then
      if not player.propEquipData[tostring(packetData.equipIndex)] then
        player.propEquipData[tostring(packetData.equipIndex)] = packetData.itemId
      else
        packetData.equipIndex = UnloadIndex
      end
    end
    packetData.needSync = true
  end
  PropPacketManager:updateEnginePacket(player)
  PropPacketManager:syncPacketData(player)
end

function PropPacketManager:onPlayerDied(player)
  player.propEquipData = {}
  PropPacketManager:updateEnginePacket(player)
end

function PropPacketManager:onAddItem(player, itemId, count)
  itemId = player.equip_dress[tostring(itemId)] or itemId
  local item = Item.getItemById(itemId)
  if not player.propPacketData[tostring(itemId)] then
    player.propPacketData[tostring(itemId)] = {
      itemId = itemId,
      count = 0,
      equipIndex = UnloadIndex
    }
    if item and 0 < item:getMaxDamage() then
      player.propPacketData[tostring(itemId)].damage = 0
    end
  end
  local propData = player.propPacketData[tostring(itemId)]
  if propData.count == 0 then
    PropPacketManager:onEquipItem(player, itemId)
  end
  propData.needSync = true
  propData.count = propData.count + count
  PropPacketManager:updateEnginePacket(player, propData.equipIndex)
  PropPacketManager:syncPacketData(player)
  return propData
end

function PropPacketManager:onItemDressChange(player, oldDressId, newDressId)
  local propData = player.propPacketData[tostring(oldDressId)]
  if propData then
    propData.needSync = true
    local newPropData = TableUtil.copyTable(propData)
    newPropData.itemId = newDressId
    player.propPacketData[tostring(newDressId)] = newPropData
    if propData.equipIndex ~= UnloadIndex then
      player.propEquipData[tostring(propData.equipIndex)] = newDressId
      PropPacketManager:updateEnginePacket(player, propData.equipIndex)
    end
    propData.equipIndex = UnloadIndex
    propData.count = 0
    PropPacketManager:syncPacketData(player)
  end
end

function PropPacketManager:onEquipItem(player, itemId)
  local propData = player.propPacketData[tostring(itemId)]
  if not propData or propData.equipIndex ~= UnloadIndex then
    return
  end
  for slot = Define.PROP_INDEX_START, Define.PROP_INDEX_END do
    local nowIndex = slot - Define.PROP_INDEX_START
    if not player.propEquipData[tostring(nowIndex)] then
      propData.equipIndex = nowIndex
      player.propEquipData[tostring(nowIndex)] = itemId
      PropPacketManager:updateEnginePacket(player, nowIndex)
      propData.needSync = true
      break
    end
  end
  PropPacketManager:syncPacketData(player)
end

function PropPacketManager:onUnloadItem(player, itemId)
  local propData = player.propPacketData[tostring(itemId)]
  if not propData or propData.equipIndex == UnloadIndex then
    return
  end
  local oldIndex = propData.equipIndex
  player.propEquipData[tostring(oldIndex)] = nil
  propData.equipIndex = UnloadIndex
  propData.needSync = true
  PropPacketManager:updateEnginePacket(player, oldIndex)
  PropPacketManager:syncPacketData(player)
end

function PropPacketManager:syncPacketData(player)
  LuaTimer:cancel(player.syncPacketDataKey or 0)
  player.syncPacketDataKey = LuaTimer:schedule(function()
    local data = {}
    for key, propData in pairs(player.propPacketData) do
      if propData.needSync then
        data[key] = propData
        propData.needSync = nil
      end
    end
    player:sendPacket({
      pid = "PropPacketData",
      data = json.encode(data)
    })
  end, 0)
end

function PropPacketManager:updateEnginePacket(player, index)
  if index == UnloadIndex then
    return
  end
  
  local function updateByIndex(propIndex)
    local propItemId = player.propEquipData[tostring(propIndex)]
    if propItemId then
      local propData = player.propPacketData[tostring(propItemId)]
      if Item.getItemById(propData.itemId) then
        if propData.itemId == ItemID.BLAZE_ROD then
          local EnchantList = ItemEnchantment:getEnchantmentList({"5"})
          player:replaceEchantmentItem(propData.itemId, propData.count, propData.damage or 0, EnchantList, propData.equipIndex + Define.PROP_INDEX_START)
        else
          player:replaceItem(propData.itemId, propData.count, propData.damage or 0, propData.equipIndex + Define.PROP_INDEX_START)
        end
      else
        player:replaceItem(BlockManager.getItemBlockId(propData.itemId), propData.count, propData.damage or 0, propData.equipIndex + Define.PROP_INDEX_START)
      end
    else
      local slot = propIndex + Define.PROP_INDEX_START
      local info = player:getInventory():getItemStackInfo(slot)
      if info.id ~= 0 then
        player:decrStackSize(slot, info.num)
      end
    end
  end
  
  if index then
    updateByIndex(index)
    return
  end
  for slot = Define.PROP_INDEX_START, Define.PROP_INDEX_END do
    updateByIndex(slot - Define.PROP_INDEX_START)
  end
end

function PropPacketManager:updateLuaPacket(player, slot)
  if slot < Define.PROP_INDEX_START and slot > Define.PROP_INDEX_END then
    return
  end
  if not player.propEquipData or not player.propPacketData then
    return
  end
  local index = slot - Define.PROP_INDEX_START
  local itemId = player.propEquipData[tostring(index)]
  if not itemId then
    return
  end
  local propData = player.propPacketData[tostring(itemId)]
  if not propData then
    return
  end
  local inv = player:getInventory()
  if inv then
    local info = inv:getItemStackInfo(slot)
    local realId = propData.itemId
    if not Item.getItemById(realId) then
      realId = BlockManager.getItemBlockId(realId)
    end
    if info.id == 0 or info.id == realId then
      propData.count = info.num
      if propData.damage then
        propData.damage = info.meta
      end
      if propData.count == 0 then
        player.propEquipData[tostring(index)] = nil
        propData.equipIndex = UnloadIndex
      end
      propData.needSync = true
      PropPacketManager:syncPacketData(player)
    end
  end
end

return PropPacketManager

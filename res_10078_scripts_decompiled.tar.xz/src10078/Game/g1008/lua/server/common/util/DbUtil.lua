local RecentPlayUtil = T(Global, "RecentPlayUtil")
local InGameUserIds = {}

function RecentPlayUtil:recordGamePlayer()
  local players = PlayerManager:getPlayers()
  for _, player1 in pairs(players) do
    if not PlayerManager:isAIPlayer(player1) then
      table.insert(InGameUserIds, player1.userId)
    end
  end
end

function RecentPlayUtil:updateRecentPlayRecord(player)
  if PlayerManager:isAIPlayer(player) then
    return
  end
  local recentPlayRecord = StringUtil.split(player.recentPlayRecord or "", ",")
  for _, userId in pairs(InGameUserIds) do
    if player.userId ~= userId then
      local uid = tostring(userId)
      if TableUtil.tableContain(recentPlayRecord, uid) then
        TableUtil.tableRemove(recentPlayRecord, uid)
      end
      table.insert(recentPlayRecord, 1, uid)
    end
  end
  while 30 < #recentPlayRecord do
    table.remove(recentPlayRecord)
  end
  player.recentPlayRecord = table.concat(recentPlayRecord, ",")
end

function RecentPlayUtil:sendPlayRecord(player)
  PacketSender:sendLuaCommonData(player.rakssid, "RecentPlayRecord", player.recentPlayRecord)
end

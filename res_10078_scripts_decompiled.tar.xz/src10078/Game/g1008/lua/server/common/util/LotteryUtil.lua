LotteryUtil = {}
LotteryUtil.prob = {}
LotteryUtil.alias = {}

function LotteryUtil:init(data, prob, alias)
  local nums = #data
  local small = {}
  local large = {}
  for i = 1, nums do
    data[i] = data[i] * nums
    if data[i] < 1 then
      table.insert(small, i)
    else
      table.insert(large, i)
    end
  end
  while 0 < #small and 0 < #large do
    local n_index = table.remove(small, 1)
    local a_index = table.remove(large, 1)
    prob[n_index] = data[n_index]
    alias[n_index] = a_index
    data[a_index] = data[a_index] + data[n_index] - 1
    if data[a_index] < 1 then
      table.insert(small, a_index)
    else
      table.insert(large, a_index)
    end
  end
  while 0 < #large do
    local n_index = table.remove(large, 1)
    prob[n_index] = 1
  end
  while 0 < #small do
    local n_index = table.remove(small, 1)
    prob[n_index] = 1
  end
  return prob, alias
end

function LotteryUtil:generation(prob, alias)
  if prob == nil or alias == nil then
    return 1
  end
  local nums = #prob
  local MAX_P = 100000
  local coin_toss = math.random(1, MAX_P) / MAX_P
  local col = math.random(1, nums)
  local b_head = coin_toss < prob[col]
  if b_head then
    return col
  else
    return alias[col]
  end
end

function LotteryUtil:initRandomSeed(remark, data)
  self.prob[remark], self.alias[remark] = self:init(data, {}, {})
end

function LotteryUtil:get(remark)
  return self:generation(self.prob[remark], self.alias[remark])
end

function LotteryUtil:setRandomSeed()
  math.randomseed(tostring(os.time()):reverse():sub(1, 7))
end

return LotteryUtil

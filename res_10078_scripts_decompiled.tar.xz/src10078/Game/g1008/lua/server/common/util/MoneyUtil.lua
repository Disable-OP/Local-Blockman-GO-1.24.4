MoneyUtil = {}

function MoneyUtil:checkHasMoney(player, type, price, chip)
  if type == Define.Money.DIAMOND then
    if isBeta then
      return price <= player.fakeDiamonds
    else
      return price <= player:getDiamond()
    end
  end
  if type == Define.Money.CHIP then
    chip = chip or 0
    return price <= chip
  end
  if type == Define.Money.KEY then
    return price <= player.yaoshi
  end
  return false
end

function MoneyUtil:consumeMoney(player, uniqueId, type, price, callback, source)
  if type == Define.Money.DIAMOND then
    PayHelper.payDiamondsSync(player.userId, uniqueId, price, function()
      callback()
    end)
  end
  if type == Define.Money.KEY then
    player:subYaoShi(price, source)
    callback()
  end
end

return

local function getSeasonDefaultScore(honorId)
  if honorId == 0 then
    return 1000
  elseif honorId == 1 then
    return 1100
  elseif honorId == 2 then
    return 1300
  elseif honorId == 3 then
    return 1600
  elseif honorId == 4 then
    return 2100
  else
    return 9999
  end
end

local NewReportUtil = {}

function NewReportUtil.getLevelData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "player_lv",
    value = player.level
  })
  callback(dataList)
end

function NewReportUtil.getCountryData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "country",
    value = player.dynamicAttr.country or ""
  })
  callback(dataList)
end

function NewReportUtil.getTotalGameTimeData(player, callback, retryTimes)
  retryTimes = retryTimes or 3
  if player.total_game_time ~= nil or retryTimes == 0 then
    local dataList = {}
    table.insert(dataList, {
      key = "total_game_time",
      value = player.total_game_time or -1
    })
    callback(dataList)
    return
  end
  WebService:GetGameTime(player.userId, {
    "g1008,g1046,g1061,g1062"
  }, function(code, data)
    if code == 1 then
      player.total_game_time = 0
      for gameType, game_time in pairs(data) do
        player.total_game_time = player.total_game_time + game_time
      end
    end
    NewReportUtil.getTotalGameTimeData(player, callback, retryTimes - 1)
  end)
end

function NewReportUtil.getGameTimesData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "game_start_times",
    value = player.game_start_times
  })
  table.insert(dataList, {
    key = "game_complete_times",
    value = player.game_complete_times
  })
  table.insert(dataList, {
    key = "game_victory_times",
    value = player.game_victory_times
  })
  callback(dataList)
end

function NewReportUtil.isFirstConsume(player, callback)
  local dataList = {}
  if player.have_cube_order ~= nil then
    table.insert(dataList, {
      key = "is_first_consume",
      value = not player.have_cube_order
    })
  else
    table.insert(dataList, {
      key = "is_first_consume",
      value = "error"
    })
  end
  callback(dataList)
end

function NewReportUtil.isFirstRecharge(player, callback)
  local dataList = {}
  if player.total_recharge_cube ~= nil then
    table.insert(dataList, {
      key = "is_first_recharge",
      value = player.total_recharge_cube == 0
    })
  else
    table.insert(dataList, {
      key = "is_first_recharge",
      value = "error"
    })
  end
  callback(dataList)
end

function NewReportUtil.getHonorData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "honor_score",
    value = player.honor
  })
  table.insert(dataList, {
    key = "honor_lv",
    value = player.honorId
  })
  table.insert(dataList, {
    key = "honor_lv_start",
    value = getSeasonDefaultScore(player.honorId)
  })
  table.insert(dataList, {
    key = "honor_lv_end",
    value = getSeasonDefaultScore(player.honorId + 1)
  })
  callback(dataList)
end

function NewReportUtil.getRuneCountData(player, callback)
  local rune_count_lv1 = 0
  local rune_count_lv2 = 0
  local rune_count_lv3 = 0
  for _, runeData in pairs(player.rune) do
    local runeId = runeData.runeId or 0
    local level = runeId % 10
    if level == 1 then
      rune_count_lv1 = rune_count_lv1 + runeData.num
    elseif level == 2 then
      rune_count_lv2 = rune_count_lv2 + runeData.num
    elseif level == 3 then
      rune_count_lv3 = rune_count_lv3 + runeData.num
    end
  end
  for _, equipRuneData in pairs(player.equip_rune) do
    if equipRuneData.id ~= 0 then
      local runeId = equipRuneData.id or 0
      local level = runeId % 10
      if level == 1 then
        rune_count_lv1 = rune_count_lv1 + 1
      elseif level == 2 then
        rune_count_lv2 = rune_count_lv2 + 1
      elseif level == 3 then
        rune_count_lv3 = rune_count_lv3 + 1
      end
    end
  end
  local dataList = {}
  table.insert(dataList, {
    key = "rune_count_lv1",
    value = rune_count_lv1
  })
  table.insert(dataList, {
    key = "rune_count_lv2",
    value = rune_count_lv2
  })
  table.insert(dataList, {
    key = "rune_count_lv3",
    value = rune_count_lv3
  })
  callback(dataList)
end

function NewReportUtil.getKeyCountData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "money_key",
    value = player.yaoshi
  })
  callback(dataList)
end

function NewReportUtil.getLicenseBuyTypeData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "license_buy_type",
    value = player.license_buy
  })
  callback(dataList)
end

function NewReportUtil.getLicenseRemainDaysData(player, callback)
  local DayCount = math.floor((GameLicense.seasonEndDate - os.time()) / 3600 / 24)
  local dataList = {}
  table.insert(dataList, {
    key = "license_remain_days",
    value = DayCount
  })
  callback(dataList)
end

function NewReportUtil.getLicenseLevelData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "license_lv",
    value = player.license_level
  })
  callback(dataList)
end

function NewReportUtil.getGameRecordData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "game_record",
    value = json.encode(player.last_game_record)
  })
  callback(dataList)
end

function NewReportUtil.getDiamondData(player, callback)
  local dataList = {}
  table.insert(dataList, {
    key = "money_diamond",
    value = player:getDiamond()
  })
  callback(dataList)
end

function NewReportUtil.getGameTimeData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {key = "game_time", value = 0})
  elseif GameMatch.allowPvp then
    local runSecond = os.time() - GameMatch.startGameTime
    table.insert(dataList, {key = "game_time", value = runSecond})
  else
    table.insert(dataList, {key = "game_time", value = 0})
  end
  callback(dataList)
end

function NewReportUtil.isHaveBedData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {
      key = "is_have_bed",
      value = false
    })
  else
    local selfTeam = player.team
    table.insert(dataList, {
      key = "is_have_bed",
      value = selfTeam.isHaveBed
    })
  end
  callback(dataList)
end

function NewReportUtil.getTeammateLifeCountData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {
      key = "teammate_life_count",
      value = 0
    })
  else
    local selfTeam = player.team
    table.insert(dataList, {
      key = "teammate_life_count",
      value = selfTeam:getCurPlayerCount()
    })
  end
  callback(dataList)
end

function NewReportUtil.getPlayerLifeCountData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {
      key = "player_life_count",
      value = 0
    })
  else
    local totalCount = 0
    for _, team in pairs(GameMatch.Teams) do
      totalCount = totalCount + team:getCurPlayerCount()
    end
    table.insert(dataList, {
      key = "player_life_count",
      value = totalCount
    })
  end
  callback(dataList)
end

function NewReportUtil.getHealthData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {key = "health", value = 0})
    table.insert(dataList, {key = "is_life", value = false})
  else
    table.insert(dataList, {
      key = "health",
      value = player:getHealth()
    })
    table.insert(dataList, {
      key = "is_life",
      value = player.isLife
    })
  end
  callback(dataList)
end

function NewReportUtil.getKillDieData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {key = "kill_count", value = 0})
    table.insert(dataList, {key = "die_count", value = 0})
  else
    local playerInfo = player.info
    local kill = tonumber(playerInfo:getValue("kill"))
    local die = tonumber(playerInfo:getValue("die"))
    table.insert(dataList, {key = "kill_count", value = kill})
    table.insert(dataList, {key = "die_count", value = die})
  end
  callback(dataList)
end

function NewReportUtil.isDieInMinuteData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {
      key = "is_die_in_minute",
      value = false
    })
  else
    local lastDieTime = player.lastDieTime
    local isDieInMinute = lastDieTime and os.time() - lastDieTime < 60 or false
    table.insert(dataList, {
      key = "is_die_in_minute",
      value = isDieInMinute
    })
  end
  callback(dataList)
end

function NewReportUtil.getTeamHonorRankData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {
      key = "all_team_average_honor",
      value = 0
    })
    table.insert(dataList, {
      key = "my_team_average_honor",
      value = 0
    })
    table.insert(dataList, {
      key = "my_team_rank",
      value = 0
    })
  else
    local teamRank = {}
    for index, team in pairs(GameMatch.Teams) do
      table.insert(teamRank, {
        teamId = team.id,
        averageHonor = team:getTeamAverageHonor()
      })
    end
    table.insert(dataList, {
      key = "all_team_average_honor",
      value = json.encode(teamRank)
    })
    table.sort(teamRank, function(teamA, teamB)
      return teamA.averageHonor > teamB.averageHonor
    end)
    for rank, teamData in pairs(teamRank) do
      if tonumber(teamData.teamId) == tonumber(player:getTeamId()) then
        table.insert(dataList, {
          key = "my_team_average_honor",
          value = teamData.averageHonor
        })
        table.insert(dataList, {
          key = "my_team_rank",
          value = rank
        })
        break
      end
    end
  end
  callback(dataList)
end

function NewReportUtil.getIvnStackCountData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {
      key = "inv_stack_count",
      value = -1
    })
  else
    local num = InventoryUtil:getPlayerInvSlotFullNum(player)
    table.insert(dataList, {
      key = "inv_stack_count",
      value = num
    })
  end
  callback(dataList)
end

function NewReportUtil.getArmorData(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {
      key = "armor_value",
      value = -1
    })
  else
    local ArmorValue = player:getTotalArmorValue()
    table.insert(dataList, {
      key = "armor_value",
      value = ArmorValue
    })
  end
  callback(dataList)
end

local swordIdToLevel = {
  ["268"] = 1,
  ["267"] = 2,
  ["283"] = 3,
  ["276"] = 4
}

function NewReportUtil.getMaxWeaponLevel(player, callback)
  local dataList = {}
  if BaseMain:getGameType() == "g1046" then
    table.insert(dataList, {
      key = "highest_sword_level",
      value = 0
    })
  else
    local swordId = player.info:getValue("ItemSword")
    local old_swordId = player:tryItemId2DressId(swordId)
    table.insert(dataList, {
      key = "highest_sword_level",
      value = swordIdToLevel[tostring(old_swordId)] or 0
    })
  end
  callback(dataList)
end

local function printToChat(player, MessageTable)
  for _, msg in pairs(MessageTable) do
    if BaseMain:getGameType() == "g1046" then
      MsgSender.sendMsg(msg, "")
    else
      GamePacketSender:sendBedWarChatToAll(player.userId, msg)
    end
  end
end

function NewReportUtil.report(player, event, funcList, parentId, callback)
  local reportData = {}
  local MessageTable = {}
  table.insert(MessageTable, "----------------------report-----------------------------")
  table.insert(MessageTable, BaseMain:getGameType() .. " " .. event)
  local getDataFunction
  
  function getDataFunction(function_index)
    local cur_function = funcList[function_index]
    if not cur_function then
      table.insert(MessageTable, "----------------------end-----------------------------")
      if isTest then
        printToChat(player, MessageTable)
      end
      local reportId = GameAnalytics:newDesign(player.userId, event, reportData, parentId)
      if callback then
        callback(reportId, os.time())
      end
      return
    end
    if type(cur_function) ~= "function" then
      getDataFunction(function_index + 1)
      return
    end
    cur_function(player, function(dataList)
      for _, data in pairs(dataList) do
        local reportKey = data.key
        local reportValue = data.value
        local keyLen = #reportKey
        local text = reportKey
        for _ = 1, 30 - keyLen do
          text = text .. "  "
        end
        text = text .. tostring(reportValue)
        table.insert(MessageTable, text)
        reportData[tostring(reportKey)] = reportValue
      end
      getDataFunction(function_index + 1)
    end)
  end
  
  getDataFunction(1)
end

return NewReportUtil

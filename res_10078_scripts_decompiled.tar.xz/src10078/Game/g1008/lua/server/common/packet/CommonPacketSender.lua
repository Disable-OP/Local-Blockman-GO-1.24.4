CommonPacketSender = {}

function CommonPacketSender:sendCustomShopData(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "CustomShopData", json.encode(data))
end

function CommonPacketSender:sendBuyCustomGoodsSuccess(rakssid, goodsId)
  PacketSender:sendLuaCommonData(rakssid, "BuyCustomGoodsSuccess", tostring(goodsId))
end

function CommonPacketSender:sendInfoUpdate(rakssid, dataStr)
  PacketSender:sendLuaCommonData(rakssid, "InfoUpdate", dataStr)
end

function CommonPacketSender:sendInfoNew(rakssid, dataStr)
  PacketSender:sendLuaCommonData(rakssid, "InfoNew", dataStr)
end

function CommonPacketSender:sendGameStart(player)
  PacketSender:sendLuaCommonData(player.rakssid, "GameStart")
  ServerReportEvent.player_game_start(player)
end

function CommonPacketSender:sendCanNotGiveUpChallenge(rakssid, hour, sec)
  local params = {hour = hour, sec = sec}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "CanNotGiveUpChallenge", data)
end

function CommonPacketSender:onPlayerFinishChallenge(rakssid, rewardId)
  PacketSender:sendLuaCommonData(rakssid, "FinishChallenge", rewardId)
end

function CommonPacketSender:sendSyncTreasureChallengeInfo(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "SyncChallengeInfo", json.encode(data))
end

function CommonPacketSender:sendReceiveNewChallenge(rakssid, rewardId)
  PacketSender:sendLuaCommonData(rakssid, "ReceiveNewChallenge", rewardId)
end

function CommonPacketSender:sendGiveUpChallenge(rakssid, rewardId)
  PacketSender:sendLuaCommonData(rakssid, "GiveUpChallenge", rewardId)
end

function CommonPacketSender:sendChallengeTimeout(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "ChallengeTimeout")
end

function CommonPacketSender:sendChallengeTaskInfo(rakssid, times, currRewardId, task)
  local params = {
    times = times,
    rewardId = currRewardId,
    taskId = task.taskId,
    progress = task.progress,
    status = task.status
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "ChallengeTaskInfo", data)
end

function CommonPacketSender:sendChallengePoints(rakssid, times, currRewardId, Points)
  local params = {
    times = times,
    rewardId = currRewardId,
    Points = Points
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "ChallengePoints", data)
end

function CommonPacketSender:sendAlreadyOwnedReward(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "AlreadyOwnedReward")
end

function CommonPacketSender:sendChallengeTimesChange(rakssid, times)
  PacketSender:sendLuaCommonData(rakssid, "ChallengeTimesChange", times)
end

function CommonPacketSender:syncTreasureChallengeTimes(rakssid, times)
  PacketSender:sendLuaCommonData(rakssid, "ChallengeTimes", times)
end

function CommonPacketSender:sendNewChallengeTip(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "NewChallenge")
end

function CommonPacketSender:sendBedWarPrivilegeData(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "PrivilegeData", data)
end

function CommonPacketSender:sendBuyGoodsSuccess(rakssid, goodsId)
  PacketSender:sendLuaCommonData(rakssid, "BuyGoodsSuccess", tostring(goodsId))
end

function CommonPacketSender:sendUseActionToAll(serverId, actionId)
  local params = {serverId = serverId, actionId = actionId}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:broadCastLuaCommonData("UseActionSuccess", data)
end

function CommonPacketSender:sendLicenseDailyTaskInfo(rakssid, task, finishNum)
  local params = {
    finishNum = finishNum,
    taskId = task.taskId,
    progress = task.progress,
    status = task.status
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LicenseDailyTask", data)
end

function CommonPacketSender:sendLicenseSeasonTaskInfo(rakssid, task, refreshId)
  local params = {
    refreshId = refreshId,
    taskId = task.taskId,
    progress = task.progress,
    status = task.status
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "LicenseSeasonTask", data)
end

function CommonPacketSender:sendBedWarBoxRewardResult(rakssid, rewardId)
  local params = {rewardId = rewardId}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "BoxRewardResult", data)
end

function CommonPacketSender:sendBedWarBoxRewardResults(rakssid, rewardIds)
  PacketSender:sendLuaCommonData(rakssid, "BoxRewardResults", table.concat(rewardIds, "#"))
end

function CommonPacketSender:sendBedWarShowBoxLottery(rakssid, isOpen, curIntegral, needIntegral)
  local params = {
    isOpen = isOpen,
    curIntegral = curIntegral,
    needIntegral = needIntegral
  }
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "ShowBoxLottery", data)
end

function CommonPacketSender:sendBedWarBoxLotteryData(rakssid, data)
  PacketSender:sendLuaCommonData(rakssid, "BoxLotteryData", data)
end

function CommonPacketSender:sendBedWarPlayerReady(rakssid)
  PacketSender:sendLuaCommonData(rakssid, "PlayerReady")
end

function CommonPacketSender:sendShowTreasureAd(rakssid, isShow, progress)
  local params = {isShow = isShow, progress = progress}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "ShowTreasureAd", data)
end

function CommonPacketSender:sendBedWarPlayerMoneyCount(rakssid, type, count)
  local params = {type = type, count = count}
  local data = DataBuilder.new():fromTable(params):getData()
  PacketSender:sendLuaCommonData(rakssid, "MoneyCount", data)
end

function CommonPacketSender:sendTransformOldDressResult(rakssid, oldChipInfo, newChipCount)
  local data = {oldChipInfo = oldChipInfo, newChipCount = newChipCount}
  PacketSender:sendLuaCommonData(rakssid, "TransformDress", json.encode(data))
end

function CommonPacketSender:sendShowReward(rakssid, rewardIds)
  PacketSender:sendLuaCommonData(rakssid, "BedWarShowReward", json.encode(rewardIds))
end

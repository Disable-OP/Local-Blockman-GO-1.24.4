local normalArrowId = ItemID.ARROW

function CustomShopEffectArrow:onEquipGoods(player, goods)
  local effectArrow = self.Settings[goods.SettingId]
  if not effectArrow then
    return
  end
  local oldArrowId = player.equip_dress[tostring(normalArrowId)] or normalArrowId
  player.equip_dress[tostring(normalArrowId)] = effectArrow.EffectArrowId
  local inv = player:getInventory()
  for index = 0, 35 do
    local info = inv:getItemStackInfo(index)
    if info.id == oldArrowId then
      inv:decrStackSize(index, info.num)
      player:tryAddItem(normalArrowId, info.num)
    end
  end
end

function CustomShopEffectArrow:onUnloadGoods(player, goods)
  local effectArrow = self.Settings[goods.SettingId]
  if not effectArrow then
    return
  end
  local oldArrowId = effectArrow.EffectArrowId
  player.equip_dress[tostring(normalArrowId)] = nil
  local inv = player:getInventory()
  for index = 0, 35 do
    local info = inv:getItemStackInfo(index)
    if info.id == oldArrowId then
      inv:decrStackSize(index, info.num)
      player:tryAddItem(normalArrowId, info.num)
    end
  end
end

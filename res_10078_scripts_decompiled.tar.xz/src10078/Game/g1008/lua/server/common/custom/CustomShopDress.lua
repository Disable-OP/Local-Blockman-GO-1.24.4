function CustomShopDress:onEquipGoods(player, goods)
  local setting = self.Settings[goods.SettingId]
  
  if not setting then
    return
  end
  local dressId = setting.ItemId
  local oldDressId = player.equip_dress[tostring(setting.OldItemId)] or setting.OldItemId
  player.equip_dress[tostring(setting.OldItemId)] = dressId
  if setting.PartName == "armor_head" then
    local newItemId = dressId
    if GameType ~= "g1046" then
      local inv = player:getInventory()
      local item = inv:getItemStackInfo(100)
      local oldItemId = ItemMapping:getOldItemId(item.id)
      newItemId = ItemMapping:getItemIdByDressId(oldItemId, dressId)
    end
    player.entityPlayerMP:replaceArmorItemWithEnchant(newItemId, 1, 0, {})
    player:changeClothes("custom_hat", 0)
  elseif GameType == "g1046" then
    player:addItem(dressId, 1)
  else
    local inv = player:getInventory()
    for index = 0, 35 do
      local info = inv:getItemStackInfo(index)
      if info.id == oldDressId then
        inv:decrStackSize(index, info.num)
        player:tryAddItem(dressId, info.num)
      end
    end
  end
end

function CustomShopDress:onUnloadGoods(player, goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  local oldDressId = player.equip_dress[tostring(setting.OldItemId)]
  player.equip_dress[tostring(setting.OldItemId)] = nil
  if GameType == "g1046" then
    if setting.PartName == "armor_head" then
      player.entityPlayerMP:replaceArmorItemWithEnchant(setting.ItemId, 1, 0, {})
      player:changeClothes("custom_hat", 0)
    else
      player:removeItem(setting.ItemId, 1, 0)
    end
  else
    local inv = player:getInventory()
    for index = 0, 35 do
      local info = inv:getItemStackInfo(index)
      if info.id == oldDressId then
        inv:decrStackSize(index, info.num)
        player:tryAddItem(setting.OldItemId, info.num)
      end
    end
  end
end

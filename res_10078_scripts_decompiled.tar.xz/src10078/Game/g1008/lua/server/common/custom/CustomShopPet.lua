local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

function CustomShopPet:onEquipGoods(player, goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  player.info:setValue("petId", setting.Id)
  PlayerCustomInfoUtil:reportCustomInfo(player.userId, "int", Define.PlayerCustomInfo.CurrentPet, setting.Id, "2")
end

function CustomShopPet:onUnloadGoods(player, goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  player.info:setValue("petId", "0")
end

function CustomShopCommand:onEquipGoods(player, goods)
  local command = self.Settings[goods.SettingId]
  
  if not command then
    return
  end
end

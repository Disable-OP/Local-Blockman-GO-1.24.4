function CustomShopFootprint:onEquipGoods(player, goods)
  local footprint = self.Settings[goods.SettingId]
  
  if not footprint then
    return
  end
  local builder = DataBuilder.new()
  builder:addParam("bodyName", footprint.PartName)
  builder:addParam("bodyId", footprint.MeshName)
  player.entityPlayerMP:addCustomBodyPart("footprint", builder:getData())
end

function CustomShopFootprint:onUnloadGoods(player, goods)
  local footprint = self.Settings[goods.SettingId]
  if not footprint then
    return
  end
  local builder = DataBuilder.new()
  builder:addParam("bodyName", "effect_footprint")
  builder:addParam("bodyId", "")
  player.entityPlayerMP:addCustomBodyPart("footprint", builder:getData())
end

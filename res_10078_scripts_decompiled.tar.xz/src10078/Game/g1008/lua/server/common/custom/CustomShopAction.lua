function CustomShopAction:onEquipGoods(player, goods)
  local action = self.Settings[goods.SettingId]
  
  if not action then
    return
  end
  player.equip_action = player.equip_action or {}
  table.insert(player.equip_action, 1, tostring(action.ActionId))
end

function CustomShopAction:onUnloadGoods(player, goods)
  local action = self.Settings[goods.SettingId]
  if not action then
    return
  end
  for index, actionId in pairs(player.equip_action) do
    if actionId == tostring(action.ActionId) then
      table.remove(player.equip_action, index)
    end
  end
end

function CustomShopSwordLight:onEquipGoods(player, goods)
  local setting = self.Settings[goods.SettingId]
  
  if not setting then
    return
  end
  player.info:setValue("curSwordLight", goods.SettingId)
end

function CustomShopSwordLight:onUnloadGoods(player, goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  player.info:setValue("curSwordLight", "0")
end

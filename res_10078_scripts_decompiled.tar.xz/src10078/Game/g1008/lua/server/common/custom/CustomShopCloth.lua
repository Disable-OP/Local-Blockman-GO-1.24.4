function CustomShopCloth:onEquipGoods(player, goods)
  local setting = self.Settings[goods.SettingId]
  
  if not setting then
    return
  end
  local group = player.custom_goods[tostring(goods.TabId)] or {}
  for _, _goods in pairs(group) do
    if _goods[CustomGoodsIndex.Status] == CustomShopGoodsStatus.Equiped then
      _goods[CustomGoodsIndex.Status] = CustomShopGoodsStatus.UnEquip
      CustomShop:onPlayerGoodsChange(player, {_goods})
      local oldGoods = CustomShopConfig:getGoodsConfig(_goods[CustomGoodsIndex.Id])
      if oldGoods then
        local oldSetting = self.Settings[oldGoods.SettingId]
        if oldSetting and oldSetting.PartName == setting.PartName then
          CustomShop:callModuleFunc("onUnloadGoods", CustomShopConfig:getGoodsType(goods), player, oldGoods)
        end
      end
    end
  end
  player:changeClothes(setting.PartName, tonumber(setting.MeshName))
end

function CustomShopCloth:onUnloadGoods(player, goods)
  local setting = self.Settings[goods.SettingId]
  if not setting then
    return
  end
  player:changeClothes(setting.PartName, 0)
end

function CustomShopCloth:onPlayerRespawn(player)
  for tabId, group in pairs(player.custom_goods) do
    local type = CustomShopConfig:getTabType(tonumber(tabId))
    if type == CustomGoodsType.Cloth then
      for _, _goods in pairs(group) do
        if _goods[CustomGoodsIndex.Status] == CustomShopGoodsStatus.Equiped then
          local goods = CustomShopConfig:getGoodsConfig(_goods[CustomGoodsIndex.Id])
          if goods then
            local setting = self.Settings[goods.SettingId]
            if setting then
              player:changeClothes(setting.PartName, tonumber(setting.MeshName))
            end
          end
        end
      end
    end
  end
end

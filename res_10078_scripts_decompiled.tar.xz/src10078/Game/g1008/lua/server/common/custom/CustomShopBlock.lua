local PropPacketManager = require("common.manager.PropPacketManager")

local function onEquipChange(player, tabId)
  local skinOrder = player.skin_order[tostring(tabId)] or 0
  local WallOrder = player.wall_order[tostring(tabId)] or 0
  local map = BlockShopConfig:getBlockMap(tabId, skinOrder, WallOrder)
  if not map then
    return
  end
  local realId = map.BlockId
  if GameType ~= "g1046" and realId == BlockID.CLOTH then
    realId = player:getClothBlockId()
  end
  local oldDressId = player.equip_dress[tostring(realId)] or realId
  local newDressId = map.DressBlockId or realId
  local blockItemId = BlockManager.getItemBlockId(oldDressId)
  PropPacketManager:onItemDressChange(player, oldDressId, newDressId)
  player.equip_dress[tostring(realId)] = newDressId
  local inv = player:getInventory()
  for index = 0, 35 do
    local info = inv:getItemStackInfo(index)
    if info.id == blockItemId then
      inv:decrStackSize(index, info.num)
      player:tryAddItem(map.BlockId, info.num)
    end
  end
end

function CustomShopBlock:onEquipGoods(player, goods)
  local blockGoods = self.Settings[goods.SettingId]
  if not blockGoods then
    return
  end
  if blockGoods.Type == BlockShopConfig.Type.Skin then
    player.skin_order[tostring(blockGoods.TabId)] = blockGoods.Order
  else
    player.wall_order[tostring(blockGoods.TabId)] = blockGoods.Order
  end
  onEquipChange(player, blockGoods.TabId)
end

function CustomShopBlock:onUnloadGoods(player, goods)
  local blockGoods = self.Settings[goods.SettingId]
  if not blockGoods then
    return
  end
  if blockGoods.Type == BlockShopConfig.Type.Skin then
    player.skin_order[tostring(blockGoods.TabId)] = nil
  else
    player.wall_order[tostring(blockGoods.TabId)] = nil
  end
  onEquipChange(player, blockGoods.TabId)
end

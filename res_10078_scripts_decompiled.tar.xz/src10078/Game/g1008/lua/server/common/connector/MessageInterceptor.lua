local MessageInterceptor = class("MessageInterceptor", require("engine_base.connector.IConnectorMsgInterceptor"))
local ConnectorInterceptor = T(Global, "ConnectorInterceptor")
local ConnectorCenter = T(Global, "ConnectorCenter")
local Game2ConnectorMsgType = {SameServerMsg = 31001}
local Connector2GameMsgType = {SameServerMsg = 31001}

function MessageInterceptor:init()
  self.range = {30000, 39999}
end

function MessageInterceptor:initMsgFunc()
  self:registerMsgFunc(Game2ConnectorMsgType.SameServerMsg, self.onSameServerMsg)
end

function MessageInterceptor:onSameServerMsg(_, _, data)
  ConnectorCenter:onMsgReceive(Connector2GameMsgType.SameServerMsg, {}, data)
  return true
end

ConnectorInterceptor:registerInterceptor(T(Global, "MessageInterceptor", MessageInterceptor.new()))

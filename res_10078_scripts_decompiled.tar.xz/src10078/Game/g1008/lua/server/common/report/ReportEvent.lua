local function printToChat(userId, MessageTable)
  for _, msg in pairs(MessageTable) do
    if BaseMain:getGameType() == "g1046" then
      MsgSender.sendMsg(msg, "")
    else
      GamePacketSender:sendBedWarChatToAll(userId, msg)
    end
  end
end

local function newDesign(userId, event, event_map)
  if AIManager and AIManager:isAIByUserId(userId) then
    return
  end
  if isTest then
    local MessageTable = {}
    table.insert(MessageTable, "----------------------report-----------------------------")
    table.insert(MessageTable, "event : " .. tostring(event))
    table.insert(MessageTable, "user_id : " .. tostring(userId))
    for key, value in pairs(event_map) do
      table.insert(MessageTable, key .. " : " .. tostring(value))
    end
    table.insert(MessageTable, "----------------------end-----------------------------")
    printToChat(userId, MessageTable)
  end
  GameAnalytics:newDesign(userId, event, event_map)
end

local ReportEvent = {}
local ReportValue = require("common.report.ReportValue")

function ReportEvent.player_login(player)
  player.login_time = os.time()
  player.ready_time = player.login_time
  newDesign(player.userId, "player_login", {})
end

function ReportEvent.player_ready(player)
  player.ready_time = os.time()
  newDesign(player.userId, "player_ready", {})
end

function ReportEvent.player_logout(player)
  newDesign(player.userId, "player_logout", {})
end

function ReportEvent.player_game_start(player)
  local event_map = {}
  local key_list = {"ai_game", "map_id"}
  for _, key in pairs(key_list) do
    event_map[key] = ReportValue[key](player)
  end
  newDesign(player.userId, "player_game_start", event_map)
end

function ReportEvent.player_game_end(player)
  local event_map = {}
  local key_list = {
    "ai_game",
    "map_id",
    "game_result_type",
    "player_running_second",
    "game_running_second",
    "total_average_fps"
  }
  for _, key in pairs(key_list) do
    event_map[key] = ReportValue[key](player)
  end
  newDesign(player.userId, "player_game_end", event_map)
end

function ReportEvent.player_minute_fps(player)
  local event_map = {}
  local key_list = {
    "ai_game",
    "map_id",
    "player_running_minute",
    "minute_average_fps",
    "minute_nim_fps",
    "minute_max_fps",
    "total_average_fps"
  }
  for _, key in pairs(key_list) do
    event_map[key] = ReportValue[key](player)
  end
  newDesign(player.userId, "player_minute_fps", event_map)
end

function ReportEvent.server_game_end()
  local event_map = {}
  local key_list = {
    "ai_game",
    "map_id",
    "game_running_second"
  }
  for _, key in pairs(key_list) do
    event_map[key] = ReportValue[key]()
  end
  newDesign(0, "server_game_end", event_map)
end

function ReportEvent.buy_custom_goods(player, goodsId)
  newDesign(player.userId, "buy_custom_goods", {goodsId = goodsId})
end

ServerReportEvent = ReportEvent

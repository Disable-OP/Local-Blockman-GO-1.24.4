GoldIngotPrivilege = {}

function GoldIngotPrivilege:init(config)
  self.id = tonumber(config.Id)
  self.interval = tonumber(config.Interval)
  self.itemID = tonumber(config.ItemId)
  self.itemCount = tonumber(config.ItemCount)
end

function GoldIngotPrivilege:onPlayerBuy(player)
end

function GoldIngotPrivilege:onTick(ticks)
  if not GameMatch:isGameStart() then
    return
  end
  if ticks % self.interval ~= 0 then
    return
  end
  local players = PlayerManager:getPlayers()
  for _, player in pairs(players) do
    if Privilege.checkHavePrivilege(player, self.id) then
      player:tryAddItem(self.itemID, self.itemCount)
    end
  end
end

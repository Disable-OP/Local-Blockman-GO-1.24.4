DoubleExpPrivilege = {}

function DoubleExpPrivilege:init(config)
  self.id = tonumber(config.Id)
end

function DoubleExpPrivilege:onPlayerBuy(player)
end

function DoubleExpPrivilege:onPlayerReward(player)
  return Privilege.checkHavePrivilege(player, self.id)
end

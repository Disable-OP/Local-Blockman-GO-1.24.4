AddMaxHPPrivilege = {}

function AddMaxHPPrivilege:init(config)
  self.id = tonumber(config.Id)
  self.addMaxHP = tonumber(config.AddMaxHP)
end

function AddMaxHPPrivilege:onPlayerBuy(player)
  self:onPlayerRespawn(player)
end

function AddMaxHPPrivilege:onPlayerRespawn(player)
  if not Privilege.checkHavePrivilege(player, self.id) then
    return
  end
  local maxHealth = player:getMaxHealth() + self.addMaxHP
  player:changeMaxHealth(maxHealth)
end

local CountdownType = {
  Cancel = 0,
  AutoRespawn = 1,
  BuyRespawn = 2,
  HasPrivilege = 3
}
local KeepItemRecord = {}
local RespawnRecord = {}
local TimerKeyRecord = {}

local function checkRespawnImmediate(player)
  if not Privilege.checkHavePrivilege(player, RespawnPrivilege.id) then
    return
  end
  HostApi.sendKeepItemAndReviveCountDown(player.rakssid, 0, CountdownType.Cancel)
  RespawnHelper.addRespawnCountdown(player, 0)
end

local function onBuyKeepItem(userId, isBuy)
  LuaTimer:cancel(TimerKeyRecord[tostring(userId)])
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  if player.isKeepItem then
    return
  end
  if not isBuy then
    player.isKeepItem = false
    checkRespawnImmediate(player)
    return
  end
  local record = KeepItemRecord[tostring(player.userId)] or 1
  local setting = RespawnConfig:getKeepItemSetting(record)
  if not MoneyUtil:checkHasMoney(player, Define.Money.DIAMOND, setting.Price) then
    player.isKeepItem = false
    checkRespawnImmediate(player)
    return
  end
  player.isKeepItem = true
  PayHelper.payDiamondsSync(userId, 20000 + setting.Id, setting.Price, function()
    KeepItemRecord[tostring(player.userId)] = record + 1
    checkRespawnImmediate(player)
  end, function()
    player.isKeepItem = false
    if player:checkReady() then
      checkRespawnImmediate(player)
    end
  end)
end

local function onBuyRespawn(userId, isBuy)
  LuaTimer:cancel(TimerKeyRecord[tostring(userId)])
  local player = PlayerManager:getPlayerByUserId(userId)
  if not player then
    return
  end
  HostApi.sendKeepItemAndReviveCountDown(player.rakssid, 0, CountdownType.Cancel)
  if player.realLife then
    return
  end
  if not isBuy then
    player:onDie()
    GameMatch:ifGameOver()
    return
  end
  if not player.isLife then
    GameMatch:ifGameOver()
    return
  end
  local record = RespawnRecord[tostring(player.userId)] or 1
  local setting = RespawnConfig:getRespawnSetting(record)
  if not MoneyUtil:checkHasMoney(player, Define.Money.DIAMOND, setting.Price) then
    player:onDie()
    GameMatch:ifGameOver()
    return
  end
  player.realLife = true
  player.isKeepItem = true
  if setting then
    PayHelper.payDiamondsSync(userId, 10000 + setting.Id, setting.Price, function()
      RespawnRecord[tostring(player.userId)] = record + 1
      RespawnHelper.addRespawnCountdown(player, 0)
    end, function()
      player.realLife = false
      if player:checkReady() then
        player:onDie()
      end
      GameMatch:ifGameOver()
    end)
  else
    player:onDie()
    GameMatch:ifGameOver()
  end
end

RespawnPrivilege = {}

function RespawnPrivilege:init(config)
  self.id = tonumber(config.Id)
  CommonDataEvents:registerCallBack("BuyKeepItem", function(userId, isBuy)
    onBuyKeepItem(userId, isBuy == "true")
  end)
  CommonDataEvents:registerCallBack("BuyRespawn", function(userId, isBuy)
    onBuyRespawn(userId, isBuy == "true")
  end)
end

function RespawnPrivilege:onPlayerBuy(player)
end

function RespawnPrivilege:onShowBuyKeepItem(player)
  local record = KeepItemRecord[tostring(player.userId)] or 1
  KeepItemRecord[tostring(player.userId)] = record
  local setting = RespawnConfig:getKeepItemSetting(record)
  local time = setting.Time
  if not Privilege.checkHavePrivilege(player, self.id) then
    time = time - tonumber(player.info:getValue("runeSubSpawnTime"))
    RespawnHelper.addRespawnCountdown(player, time)
    HostApi.sendKeepItemAndReviveCountDown(player.rakssid, time, CountdownType.AutoRespawn)
  else
    RespawnHelper.addRespawnCountdown(player, time)
    HostApi.sendKeepItemAndReviveCountDown(player.rakssid, time, CountdownType.HasPrivilege)
  end
  player.isKeepItem = false
  LuaTimer:cancel(TimerKeyRecord[tostring(player.userId)])
  TimerKeyRecord[tostring(player.userId)] = LuaTimer:schedule(function()
    onBuyKeepItem(player.userId, false)
  end, time * 1000)
  GamePacketSender:sendBuyKeepItem(player.rakssid, time, setting.Price)
end

function RespawnPrivilege:onShowBuyRespawn(player)
  player.realLife = false
  local record = RespawnRecord[tostring(player.userId)] or 1
  RespawnRecord[tostring(player.userId)] = record
  local setting = RespawnConfig:getRespawnSetting(record)
  if not setting then
    player:onDie()
    GameMatch:ifGameOver()
    return
  end
  if not player.isLife then
    return
  end
  HostApi.sendKeepItemAndReviveCountDown(player.rakssid, setting.Time, CountdownType.BuyRespawn)
  GamePacketSender:sendBuyRespawn(player.rakssid, setting.Time, setting.Price)
  LuaTimer:cancel(TimerKeyRecord[tostring(player.userId)])
  TimerKeyRecord[tostring(player.userId)] = LuaTimer:schedule(function()
    onBuyRespawn(player.userId, false)
  end, setting.Time * 1000)
end

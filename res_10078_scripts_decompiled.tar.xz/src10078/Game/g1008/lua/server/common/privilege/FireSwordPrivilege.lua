FireSwordPrivilege = {}

function FireSwordPrivilege:init(config)
  self.id = tonumber(config.Id)
  self.enchantId = tonumber(config.EnchantId)
  self.enchantLv = tonumber(config.EnchantLv)
end

function FireSwordPrivilege:onPlayerBuy(player)
  if BaseMain:getGameType() == "g1046" then
    return
  end
  local inv = player:getInventory()
  for index = 0, 35 do
    local info = inv:getItemStackInfo(index)
    if info.id ~= 0 then
      local item = Item.getItemById(info.id)
      if item and item:getClassName() == "ItemSword" then
        local enchantList = ItemEnchantment:getItemEnchantmentList(inv, index)
        inv:decrStackSize(index, info.num)
        player:tryAddItem(info.id, info.num, 0, enchantList)
      end
    end
  end
end

function FireSwordPrivilege:onPlayerGetSword(player, enchantList)
  if not Privilege.checkHavePrivilege(player, self.id) then
    return enchantList
  end
  enchantList = enchantList or {}
  for _, enchant in pairs(enchantList) do
    if enchant[1] == self.enchantId then
      enchant[2] = math.max(self.enchantLv, enchant[2])
      return enchantList
    end
  end
  table.insert(enchantList, {
    self.enchantId,
    self.enchantLv
  })
  return enchantList
end

function FireSwordPrivilege:removeSwordGain(enchantList)
  if not enchantList then
    return
  end
  for pos, enchant in pairs(enchantList) do
    if self.enchantId == enchant[1] and self.enchantLv == enchant[2] then
      table.remove(enchantList, pos)
      break
    end
  end
end

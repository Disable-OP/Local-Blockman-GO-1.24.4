local GetCustomValueApi = "/bedwar/api/v1/user/game/date/value/get"
local SetCustomValueApi = "/bedwar/api/v1/inner/user/game/date/value/set"
local GetCustomValueListApi = "/bedwar/api/v1/user/game/date/batch/value/get"

function WebService:SetPlayerCustomDataValue(userId, dataInfo)
  local path = self.ServerHttpHost .. SetCustomValueApi
  local body = {
    params = dataInfo,
    requestType = "2",
    userId = tonumber(userId)
  }
  WebService.asyncPost(path, {}, body)
end

function WebService:addPlayerCustomDataValue(userId, dataType, key, value)
  local path = self.ServerHttpHost .. SetCustomValueApi
  local body = {
    params = {
      {
        dataType = dataType,
        key = key,
        value = value
      }
    },
    requestType = "1",
    userId = tonumber(userId)
  }
  WebService.asyncPost(path, {}, body, function(data, code)
  end)
end

function WebService:GetPlayerCustomDataValue(userId, fields, callback)
  local path = self.ServerHttpHost .. GetCustomValueApi
  local params = {
    {
      "userId",
      tostring(userId)
    },
    {
      "fields",
      table.concat(fields, ",")
    }
  }
  WebService.asyncGet(path, params, function(data, code)
    if not data then
      return
    end
    local userInfo = {}
    userInfo.userId = userId
    for _, key_value in pairs(data) do
      userInfo[key_value.key] = key_value.value
    end
    UserInfoCache:UpdateUserInfos({userInfo})
    callback(code, data)
  end)
end

function WebService:GetPlayersCustomDataValue(userIds, fields, callback)
  local path = self.ServerHttpHost .. GetCustomValueListApi
  local params = {
    {
      "userId",
      table.concat(userIds, ",")
    },
    {
      "fields",
      table.concat(fields, ",")
    }
  }
  WebService.asyncGet(path, params, function(data, code)
    if not data then
      return
    end
    local userInfo = {}
    for userId, _userInfo in pairs(data) do
      local data = {}
      data.userId = tonumber(userId)
      for _, info in pairs(_userInfo) do
        data[info.key] = info.value
      end
      table.insert(userInfo, data)
    end
    UserInfoCache:UpdateUserInfos(userInfo)
    if callback then
      callback(code, data)
    end
  end)
end

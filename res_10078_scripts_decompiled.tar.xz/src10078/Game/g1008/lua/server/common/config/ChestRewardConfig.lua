ChestRewardConfig = {}
ChestRewardConfig.ChestRewards = {}
ChestRewardConfig.RewardType = {
  RUNE = 1,
  DRESS_CHIP = 2,
  DRESS = 3,
  PRIVILEGE_CARD = 4,
  KEY = 5
}

function ChestRewardConfig:initConfig(rewards)
  for _, reward in pairs(rewards) do
    table.insert(self.ChestRewards, {
      Id = tonumber(reward.Id) or 0,
      Type = tonumber(reward.Type) or 0,
      RewardId = tonumber(reward.RewardId) or 0,
      Weight = tonumber(reward.Weight) or 0
    })
  end
end

function ChestRewardConfig:getChestRewardByType(type)
  local rewards = {}
  for _, reward in pairs(self.ChestRewards) do
    if reward.Type == type then
      table.insert(rewards, reward)
    end
  end
  return rewards
end

function ChestRewardConfig:getChestRewardId(id)
  for _, reward in pairs(self.ChestRewards) do
    if reward.Id == id then
      return reward
    end
  end
end

return ChestRewardConfig

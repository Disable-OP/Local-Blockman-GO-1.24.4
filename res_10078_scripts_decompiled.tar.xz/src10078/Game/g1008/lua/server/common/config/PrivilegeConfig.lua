require("common.privilege.GoldIngotPrivilege")
require("common.privilege.AddMaxHPPrivilege")
require("common.privilege.FireSwordPrivilege")
require("common.privilege.GoodsStorePrivilege")
require("common.privilege.RespawnPrivilege")
require("common.privilege.DoubleExpPrivilege")
local Privileges = {}

local function init()
  local mappings = {
    AddMaxHPPrivilege = AddMaxHPPrivilege,
    FireSwordPrivilege = FireSwordPrivilege,
    GoldIngotPrivilege = GoldIngotPrivilege,
    GoodsStorePrivilege = GoodsStorePrivilege,
    RespawnPrivilege = RespawnPrivilege,
    DoubleExpPrivilege = DoubleExpPrivilege
  }
  local config = FileUtil.getConfigFromYml("setting/PrivilegeSetting", true)
  for _, item in pairs(config.Privileges or {}) do
    local class = mappings[item.Name]
    if class then
      class:init(item)
    end
    Privileges[tostring(item.Id)] = {
      BuyTime = tonumber(item.BuyTime) or 43200,
      Class = class
    }
  end
end

init()
Privilege = {}

function Privilege.checkHavePrivilege(player, privilegeId)
  if #player.privilegeCard == 0 then
    return false
  end
  for _, privilege in pairs(player.privilegeCard) do
    if privilege.privilegeId == privilegeId and privilege.time >= os.time() then
      return true
    end
  end
  return false
end

function Privilege.syncPrivilegeTime(player)
  local data = {}
  for _, privilege in pairs(player.privilegeCard) do
    table.insert(data, {
      Id = privilege.privilegeId,
      Time = math.max(privilege.time - os.time(), 0)
    })
  end
  CommonPacketSender:sendBedWarPrivilegeData(player.rakssid, json.encode(data))
end

function Privilege.addPrivilegeTime(player, privilegeId, addTime)
  local config = Privileges[tostring(privilegeId)]
  if not config then
    return
  end
  local time = addTime or config.BuyTime
  for _, privilege in pairs(player.privilegeCard) do
    if privilege.privilegeId == privilegeId then
      local isNewAdd = privilege.time < os.time()
      privilege.time = math.max(privilege.time, os.time()) + time
      Privilege.syncPrivilegeTime(player)
      if isNewAdd then
        config.Class:onPlayerBuy(player)
      end
      return
    end
  end
  local privilege = {
    privilegeId = privilegeId,
    time = os.time() + time
  }
  table.insert(player.privilegeCard, privilege)
  Privilege.syncPrivilegeTime(player)
  config.Class:onPlayerBuy(player)
end

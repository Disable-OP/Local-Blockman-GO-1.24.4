DressConfig = {}
DressConfig.Dress = {}

function DressConfig:initConfig(dress)
  for _, config in pairs(dress) do
    local curDress = {}
    curDress.Id = tonumber(config.Id)
    curDress.ItemId = tonumber(config.ItemId)
    curDress.NewCustomId = tonumber(config.NewCustomId)
    curDress.TabType = tonumber(config.TabType)
    curDress.Name = config.Name
    curDress.OldItemId = config.OldItemId
    curDress.PriceType = tonumber(config.PriceType) or 0
    curDress.Price = tonumber(config.Price) or 0
    curDress.UnlockLevel = tonumber(config.UnlockLevel)
    curDress.HasGet = config.HasGet == "1"
    table.insert(self.Dress, curDress)
  end
end

function DressConfig:getDress(id)
  for _, config in pairs(DressConfig.Dress) do
    if config.Id == id then
      return config
    end
  end
end

function DressConfig:getDressByItemId(ItemId)
  for _, config in pairs(DressConfig.Dress) do
    if config.ItemId == ItemId then
      return config
    end
  end
end

function DressConfig:getNewIdByOldId(id)
  for _, config in pairs(DressConfig.Dress) do
    if config.Id == id then
      return config.NewCustomId
    end
  end
end

return DressConfig

ChestConfig = {}
ChestConfig.Chests = {}
ChestConfig.ChestType = {
  BRONZE_CHEST = 1,
  ULTIMATE_CHEST = 2,
  HORN_CHEST = 3
}

function ChestConfig:initConfig(chests)
  LotteryUtil:setRandomSeed()
  for _, chest in pairs(chests) do
    local data = {
      Id = tonumber(chest.Id),
      Type = tonumber(chest.Type),
      GetFreeTime = tonumber(chest.GetFreeTime),
      NeedKey = tonumber(chest.NeedKey),
      AddIntegral = tonumber(chest.AddIntegral),
      NeedIntegral = tonumber(chest.NeedIntegral),
      PayTip = chest.PayTip,
      Rewards = ChestRewardConfig:getChestRewardByType(tonumber(chest.Type))
    }
    table.insert(self.Chests, data)
    local seeds = {}
    local AllWeight = 0
    for _, reward in pairs(data.Rewards) do
      AllWeight = AllWeight + reward.Weight
    end
    for _, reward in pairs(data.Rewards) do
      table.insert(seeds, reward.Weight / AllWeight)
    end
    LotteryUtil:initRandomSeed(chest.Id, seeds)
  end
end

function ChestConfig:getChestById(id)
  for _, chest in pairs(self.Chests) do
    if chest.Id == id then
      return chest
    end
  end
end

function ChestConfig:getChestByType(type)
  for _, chest in pairs(self.Chests) do
    if chest.Type == type then
      return chest
    end
  end
end

function ChestConfig:getUltimateChestIntegral()
  for _, chest in pairs(self.Chests) do
    if chest.Type == ChestConfig.ChestType.ULTIMATE_CHEST then
      return chest.NeedIntegral
    end
  end
  return 2000
end

return ChestConfig

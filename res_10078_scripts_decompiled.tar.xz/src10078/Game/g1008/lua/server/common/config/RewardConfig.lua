RewardConfig = {}
RewardConfig.Rewards = {}

function RewardConfig:initConfig(configs)
  for _, config in pairs(configs) do
    local item = {
      Id = tonumber(config.Id) or 0,
      Name = config.Name or "",
      Image = config.Image or "",
      Desc = config.Desc or "",
      RewardId = tonumber(config.RewardId) or 0,
      RewardType = tonumber(config.RewardType) or 0,
      RedressRewardId = tonumber(config.RedressRewardId) or 0,
      Count = tonumber(config.Count) or 0,
      Time = tonumber(config.Time) or 0,
      IsNotification = config.IsNotification == "1",
      NotificationContent = config.NotificationContent or ""
    }
    if config.NotificationParams ~= "#" then
      item.NotificationParams = config.NotificationParams
    else
      item.NotificationParams = ""
    end
    self.Rewards[item.Id] = item
  end
end

function RewardConfig:getRewardById(id)
  return self.Rewards[tonumber(id)]
end

function RewardConfig:getRewardByIds(ids)
  local rewards = {}
  ids = StringUtil.split(ids, "#")
  for _, id in pairs(ids) do
    local reward = RewardConfig:getRewardById(tonumber(id))
    if reward ~= nil then
      table.insert(rewards, reward)
    end
  end
  return rewards
end

return RewardConfig

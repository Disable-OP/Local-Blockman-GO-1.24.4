local oldPayDiamondsSync = PayHelper.payDiamondsSync

function PayHelper.payDiamondsSync(userId, uniqueId, diamonds, successCallback, failedCallback, subKey)
  if isBeta then
    local player = PlayerManager:getPlayerByUserId(userId)
    if player and diamonds <= player.fakeDiamonds then
      player:subFakeDiamonds(diamonds)
      successCallback(player)
      return
    end
    return
  else
    return oldPayDiamondsSync(userId, uniqueId, diamonds, successCallback, failedCallback, subKey)
  end
end
